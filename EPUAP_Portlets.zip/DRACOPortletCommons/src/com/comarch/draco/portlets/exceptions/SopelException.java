package com.comarch.draco.portlets.exceptions;

public class SopelException extends Exception
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = -7902858817120931080L;

	public  SopelException( )
	 {
		 super () ;
	 }
	 
	 public  SopelException(String msg)
	 {
		 super (msg) ;
	 } 
}
