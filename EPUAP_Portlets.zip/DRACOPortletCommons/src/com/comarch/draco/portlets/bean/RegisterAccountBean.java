package com.comarch.draco.portlets.bean;

public class RegisterAccountBean {
	
	private String name;
	
	private String secondName;
	
	private String surname;
	
	private String email;
	
	private String password;
	
	private String passwordRetype;
	
	private boolean passMethod;
	
	private boolean certMethod;
	
	private boolean setupOrg;
	
	private String xmlToShow;
	
	private String xml;
	
	
	private String login;
	
	

	public RegisterAccountBean() {
		
		name = "";
		secondName = "";
		surname = "";
		email = "";
		password = "";
		passwordRetype = "";
		
		passMethod = true;
		certMethod = false;
		
		setupOrg = true;
		
		xml=null;
		xmlToShow="";
		
		login="";
		
	}

	
	
	
	public String getXmlToShow() {
		return xmlToShow;
	}




	public void setXmlToShow(String xmlToShow) {
		this.xmlToShow = xmlToShow;
	}




	public String getXml() {
		return xml;
	}




	public void setXml(String xml) {
		this.xml = xml;
	}




	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSecondName() {
		return secondName;
	}

	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasswordRetype() {
		return passwordRetype;
	}

	public void setPasswordRetype(String passwordRetype) {
		this.passwordRetype = passwordRetype;
	}

	public boolean isPassMethod() {
		return passMethod;
	}

	public void setPassMethod(boolean passMethod) {
		this.passMethod = passMethod;
	}

	public boolean isCertMethod() {
		return certMethod;
	}

	public void setCertMethod(boolean certMethod) {
		this.certMethod = certMethod;
	}

	public boolean isSetupOrg() {
		return setupOrg;
	}

	public void setSetupOrg(boolean setupOrg) {
		this.setupOrg = setupOrg;
	}




	public String getLogin() {
		return login;
	}




	public void setLogin(String login) {
		this.login = login;
	}

	
	
	
	

}
