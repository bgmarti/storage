package com.comarch.draco.portlets.config;


public class Config {
	
	
	public static final String dracoConsoleAPI_wsdd = "DracoConsole-client.wsdd";
	
	public static final String dracoConsoleAPI_webServiceUrl="http://10.133.140.53:28080/axis/services/DracoConsoleAPI";
	public static final String sopelWebServiceUrl="http://10.133.140.53:28080/axis2/services/Sopel2Service";
	
	public static final String XML="\n<Root>\n" +
							 "<Alfa>Pierwszy</Alfa>\n"+
							 "<Beta>Drugi</Beta>\n"+
							 "</Root>";
	
	
	//certificate
	public static final String BEGIN_CERTIFICATE="-----BEGIN CERTIFICATE-----";
	public static final String END_CERTIFICATE="-----END CERTIFICATE-----";
	public static final String CERTIFICATE_PATTERN="\\<ds:X509Certificate>(.*)\\</ds:X509Certificate>";
	

	public static final String REGISTER_ACCOUNT_BEAN="RegisterAccountBean";
	public static final String ERRORS="RegisterAccountErrors";
	
	
	//actions
	public static final String ACTION_MODIFY_ACCOUNT="do";
	public static final String ACTION_MODIFY_PASSWORD="modifyPassword";
	public static final String ACTION_REMOVE_PASSWORD="removePassword";
	public static final String ACTION_MODIFY_CERTIFICATE="modifyCertificate";
	public static final String ACTION_REMOVE_CERTIFICATE="removeCertificate";

}
