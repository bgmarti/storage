package com.comarch.draco.portlets;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.comarch.draco.portlets.bean.RegisterAccountBean;
import com.comarch.draco.portlets.config.Config;
import com.comarch.draco.portlets.exceptions.SopelException;

import comarch.security.sopel2e.Sopel2E;


public class Commons {
	
	static Log logger = LogFactory.getLog( Commons.class);

	
	 public static  RegisterAccountBean getBean(PortletRequest request)
	    {
	        PortletSession session = request.getPortletSession();
	        if(session == null)
	        {
	            return null;
	        }
	        
	        RegisterAccountBean bean = (RegisterAccountBean)session.getAttribute(Config.REGISTER_ACCOUNT_BEAN);
	       
	        if(bean == null)
	        {
	            bean = new RegisterAccountBean();
	            session.setAttribute(Config.REGISTER_ACCOUNT_BEAN, bean);
	        }
	        return bean;
	    }
	 	
	
	
	public static String getTgsIdFromCookie(RenderRequest request)
	{
		
		HttpServletRequest r=(HttpServletRequest) request;
		
		Cookie cookies[]=r.getCookies();
		
		logger.debug("COOKIES:");
		
		String tgsId=null;
		
		for(int i=0;i<cookies.length;i++)
		{
			logger.debug("Name:"+cookies[i].getName()+"   Value:"+cookies[i].getValue());
			
			if(cookies[i].getName().equalsIgnoreCase("TGSID"))
			{
				tgsId=cookies[i].getValue();
				break;
			}
		}
		
		logger.debug("TGS ID FETCHED:"+tgsId);
		
		return tgsId;
		
	}
	
	 public static String generateXMLStructure() throws SopelException
	 {
		 
		 String result=null;
		 
		 int ret;
			
		 comarch.security.sopel2e.Sopel2E sopel=new Sopel2E();
			 
		 String fullSignatureDoc[]= sopel.GenerateSignatureFromRoot(Config.XML.getBytes());
		
		 ret=Integer.parseInt(fullSignatureDoc[0]);
			 
		 if(ret==0)
		 {
			result=fullSignatureDoc[1];
			logger.debug("fullSignatureDoc[1]:"+fullSignatureDoc[1]);
				 
		 }
		 else
			 throw new SopelException("Sopel error on GenerateSignatureFromRoot() code:"+ret+"");
	

		 //make hex
		 char[] resultInHex=Hex.encodeHex(result.getBytes());
		
		 return new String(resultInHex); 	 
	 }
	 
	 
	 public static String getCertificateFromSignedXML(String signedXml) throws DecoderException
	 {
		 	
		 	String certificate=null;
		 
		 	byte by_xml[]=Hex.decodeHex(signedXml.toCharArray());
			
			String xml=new String(by_xml);
			
			logger.debug("Signed xml:"+xml);
			
			Pattern pattern = Pattern.compile( Config.CERTIFICATE_PATTERN, Pattern.DOTALL );

			Matcher m = pattern.matcher( xml );
			
			if ( m.find())
	        {
				int gc = m.groupCount();
				
				if(gc>0)
				{
					String certBody=m.group( 1 );
					certificate=Config.BEGIN_CERTIFICATE+'\n'+
								certBody+'\n'+
								Config.END_CERTIFICATE;
				}
				else
					logger.error("Group count == 0 ");
			
	        }
			else
				logger.error("Pattern "+Config.CERTIFICATE_PATTERN+" not found");
			
			return certificate; 
	 }

}
