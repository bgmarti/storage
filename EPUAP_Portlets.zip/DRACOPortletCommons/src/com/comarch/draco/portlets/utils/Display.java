package com.comarch.draco.portlets.utils;

import java.io.IOException;

import javax.portlet.RenderResponse;



public class Display {
	
	public static void setErrorOnPage(String message,RenderResponse response) throws IOException
	 {
			response.getWriter().println("<b style='font-family:Verdana;font-size:11px;color:#FA0000;'>"+message+"</b>");
	 }

}
