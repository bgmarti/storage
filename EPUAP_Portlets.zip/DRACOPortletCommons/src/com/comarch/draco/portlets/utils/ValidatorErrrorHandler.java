
package com.comarch.draco.portlets.utils;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * @author Marcin Rybak
 *
 */ 
public class ValidatorErrrorHandler {
	
	static Log logger = LogFactory.getLog( ValidatorErrrorHandler.class);
	
	
	private HashMap errors;


	/**
	 * 
	 */
	public ValidatorErrrorHandler() {
		errors=new HashMap();
	}

	
	public void addError(String name,String value)
	{
		errors.put(name, value);	
	}
	
	public String showError(String name)
	{
		String value=(String) errors.get(name);
		
		if(value!=null)
			return value;
		else
			return "";
	}
	
	public boolean hasErrors()
	{
		return !errors.isEmpty();
	}
	
}
