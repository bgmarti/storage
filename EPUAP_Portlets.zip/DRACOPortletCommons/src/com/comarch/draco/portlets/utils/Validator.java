package com.comarch.draco.portlets.utils;

public class Validator {
	 
	
	public static boolean isCorrectIPFormat(String value) {
		
		if(value==null)
			return false;
		
		return value.matches("(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])");
	}
	
	public static boolean isCorrectDateFormat(String value)
	{
		if(value==null)
			return false;
		
		return value.matches("(19|20)\\d\\d[-](0[1-9]|1[012])[-](0[1-9]|[12][0-9]|3[01])");
	}
	
	public static boolean isCorrectHourFormat(String value)
	{
		if(value==null)
			return false;
		
		return value.matches("^((0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?)$");
	}
	
	public static boolean isCorrectEmailFormat(String value)
	{
		return value.matches("^[a-zA-Z][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$");
	}

	
	public static boolean isNotEmpty(String value)
	{
		return (value != null && value.trim().length() != 0); 
	}
	
	public static boolean hasProperLength(String value,int maxLength)
	{
		if(value==null)
			return false;
		
		return (value.length()<maxLength);
	}
}
