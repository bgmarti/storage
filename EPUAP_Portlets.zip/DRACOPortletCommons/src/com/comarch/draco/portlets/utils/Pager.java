
package com.comarch.draco.portlets.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * @author Marcin Rybak
 *
 */ 
public class Pager {
	
	static Log logger = LogFactory.getLog( Pager.class);
	
	
	private Integer pageToShow;
	
	private Integer sort;
	
	private Integer totalRecords;

	private Integer recordsPerPage;
	
	private Integer from;
	
	private Integer to;
	
	
	
	
	

	/**
	 * 
	 */
	public Pager() {
	}

	
	
	
	/**
	 * @param pageToShow
	 * @param sort
	 */
	public Pager(Integer pageToShow, Integer sort) {
		this.pageToShow = pageToShow;
		this.sort = sort;
	}

	
	


	/**
	 * @param pageToShow
	 * @param sort
	 * @param totalRecords
	 * @param recordsPerPage
	 */
	public Pager(Integer pageToShow, Integer sort, Integer totalRecords, Integer recordsPerPage) {
		this.pageToShow = pageToShow;
		this.sort = sort;
		this.totalRecords = totalRecords;
		this.recordsPerPage = recordsPerPage;
	}




	/**
	 * @param pageToShow
	 * @param sort
	 * @param totalRecords
	 * @param recordsPerPage
	 * @param from
	 * @param to
	 */
	public Pager(Integer pageToShow, Integer sort, Integer totalRecords, Integer recordsPerPage, Integer from, Integer to) {
		this.pageToShow = pageToShow;
		this.sort = sort;
		this.totalRecords = totalRecords;
		this.recordsPerPage = recordsPerPage;
		this.from = from;
		this.to = to;
	}




	/**
	 * @return the from
	 */
	public Integer getFrom() {
		return from;
	}

	/**
	 * @param from the from to set
	 */
	public void setFrom(Integer from) {
		this.from = from;
	}

	/**
	 * @return the pageToShow
	 */
	public Integer getPageToShow() {
		return pageToShow;
	}

	/**
	 * @param pageToShow the pageToShow to set
	 */
	public void setPageToShow(Integer pageToShow) {
		this.pageToShow = pageToShow;
	}

	/**
	 * @return the recordsPerPage
	 */
	public Integer getRecordsPerPage() {
		return recordsPerPage;
	}

	/**
	 * @param recordsPerPage the recordsPerPage to set
	 */
	public void setRecordsPerPage(Integer recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	/**
	 * @return the sort
	 */
	public Integer getSort() {
		return sort;
	}

	/**
	 * @param sort the sort to set
	 */
	public void setSort(Integer sort) {
		this.sort = sort;
	}

	/**
	 * @return the to
	 */
	public Integer getTo() {
		return to;
	}

	/**
	 * @param to the to to set
	 */
	public void setTo(Integer to) {
		this.to = to;
	}

	/**
	 * @return the totalRecords
	 */
	public Integer getTotalRecords() {
		return totalRecords;
	}

	/**
	 * @param totalRecords the totalRecords to set
	 */
	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	
	
	
	
}
