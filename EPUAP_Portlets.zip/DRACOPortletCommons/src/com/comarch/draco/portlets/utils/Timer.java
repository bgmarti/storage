package com.comarch.draco.portlets.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class Timer {
	  
	static Log logger = LogFactory.getLog(Timer.class);
	
	private long startTime=0;
	
	private boolean active;
	
	
	/**
	 * 
	 */
	public Timer() {
		
		this.active=true;
		
		startTime=java.util.Calendar.getInstance().getTimeInMillis();
	}
	
	/**
	 * 
	 */
	public Timer(boolean active) {
		
		this.active=active;
		
		if(!active)
			return;
		
		startTime=java.util.Calendar.getInstance().getTimeInMillis();	
	}
	
	public void getTimeElapsed()
	{
		if(!active)
			return;
		
		long endTime=java.util.Calendar.getInstance().getTimeInMillis();
		
		long duration=endTime-startTime;
		
		logger.debug("#DRACO TIMER#-->"+"Duration time:"+duration);
	}
	
	public void getTimeElapsed(String text)
	{
		if(!active)
			return;
		
		long endTime=java.util.Calendar.getInstance().getTimeInMillis();
		
		long duration=endTime-startTime;
		
		logger.debug("#DRACO TIMER#-->"+text+"-->Duration time:"+duration+" ms");
		//System.out.println("#DRACO TIMER#-->"+text+"-->Duration time:"+duration+" ms");
		
	}
	
	public void reset()
	{
		if(!active)
			return;
		
		startTime=java.util.Calendar.getInstance().getTimeInMillis();	
	}
	
	

}	
