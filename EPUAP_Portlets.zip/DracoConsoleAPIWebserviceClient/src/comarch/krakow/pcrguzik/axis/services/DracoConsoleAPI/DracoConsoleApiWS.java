/**
 * DracoConsoleApiWS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI;

public interface DracoConsoleApiWS extends java.rmi.Remote {
    public com.comarch.biod.draco.UserData getUserData() throws java.rmi.RemoteException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;
    public void modifyUser(java.lang.String name, java.lang.String secondName, java.lang.String surname, java.lang.String email) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;
    public void addPasswordMethod(java.lang.String password, int iUserID) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;
    public void removePasswordMethod() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;
    public void removeCertificateMethod() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;
    public void changePawssword(java.lang.String newPassword) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;
    public void addCertificateMethod(java.lang.String certificate, int iUserID) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;
    public void changeCertificate(java.lang.String cert) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;
    public com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure getRolesForUser() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;
    public com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure getRolesForOrg() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;
    public int registerAccount(java.lang.String name, java.lang.String secondName, java.lang.String surname, java.lang.String email) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;
}
