/**
 * DracoConsoleAPISoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI;

public class DracoConsoleAPISoapBindingStub extends org.apache.axis.client.Stub implements comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWS {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[11];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getUserData");
        oper.setReturnType(new javax.xml.namespace.QName("http://draco.biod.comarch.com", "UserData"));
        oper.setReturnClass(com.comarch.biod.draco.UserData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getUserDataReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException",
                      new javax.xml.namespace.QName("http://exceptions.consoleAPI.draco.security.comarch.com", "DracoConsoleException"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("modifyUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "name"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "secondName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "surname"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "email"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("addPasswordMethod");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "password"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "iUserID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException",
                      new javax.xml.namespace.QName("http://exceptions.consoleAPI.draco.security.comarch.com", "DracoConsoleException"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("removePasswordMethod");
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException",
                      new javax.xml.namespace.QName("http://exceptions.consoleAPI.draco.security.comarch.com", "DracoConsoleException"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("removeCertificateMethod");
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException",
                      new javax.xml.namespace.QName("http://exceptions.consoleAPI.draco.security.comarch.com", "DracoConsoleException"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("changePawssword");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "newPassword"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("addCertificateMethod");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "certificate"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "iUserID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException",
                      new javax.xml.namespace.QName("http://exceptions.consoleAPI.draco.security.comarch.com", "DracoConsoleException"), 
                      true
                     ));
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("changeCertificate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "cert"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRolesForUser");
        oper.setReturnType(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "TreeNodeStructure"));
        oper.setReturnClass(com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getRolesForUserReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRolesForOrg");
        oper.setReturnType(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "TreeNodeStructure"));
        oper.setReturnClass(com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getRolesForOrgReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("registerAccount");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "name"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "secondName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "surname"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "email"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "registerAccountReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "fault"),
                      "comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException",
                      new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException"), 
                      true
                     ));
        _operations[10] = oper;

    }

    public DracoConsoleAPISoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public DracoConsoleAPISoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public DracoConsoleAPISoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://biod.comarch.com", "Debugable");
            cachedSerQNames.add(qName);
            cls = com.comarch.biod.Debugable.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://biod.comarch.com", "Versioned");
            cachedSerQNames.add(qName);
            cls = com.comarch.biod.Versioned.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://draco.biod.comarch.com", "UserData");
            cachedSerQNames.add(qName);
            cls = com.comarch.biod.draco.UserData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://exceptions.consoleAPI.draco.security.comarch.com", "DracoConsoleException");
            cachedSerQNames.add(qName);
            cls = com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://pcrguzik.krakow.comarch:8080/axis/services/DracoConsoleAPI", "ArrayOf_xsd_anyType");
            cachedSerQNames.add(qName);
            cls = java.lang.Object[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://statefull.ejb.console.ls.protector.security.comarch", "ProtectorConsoleEJBException");
            cachedSerQNames.add(qName);
            cls = comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "DracoTreeNode");
            cachedSerQNames.add(qName);
            cls = com.comarch.security.draco.consoleAPI.webservice.DracoTreeNode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "TreeNodeStructure");
            cachedSerQNames.add(qName);
            cls = com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.comarch.biod.draco.UserData getUserData() throws java.rmi.RemoteException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "getUserData"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.comarch.biod.draco.UserData) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.comarch.biod.draco.UserData) org.apache.axis.utils.JavaUtils.convert(_resp, com.comarch.biod.draco.UserData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) {
              throw (com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void modifyUser(java.lang.String name, java.lang.String secondName, java.lang.String surname, java.lang.String email) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "modifyUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {name, secondName, surname, email});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void addPasswordMethod(java.lang.String password, int iUserID) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "addPasswordMethod"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {password, new java.lang.Integer(iUserID)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) {
              throw (com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void removePasswordMethod() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "removePasswordMethod"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) {
              throw (com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void removeCertificateMethod() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "removeCertificateMethod"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) {
              throw (com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void changePawssword(java.lang.String newPassword) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "changePawssword"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {newPassword});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void addCertificateMethod(java.lang.String certificate, int iUserID) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException, com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "addCertificateMethod"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {certificate, new java.lang.Integer(iUserID)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) {
              throw (com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void changeCertificate(java.lang.String cert) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "changeCertificate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cert});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure getRolesForUser() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "getRolesForUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure) org.apache.axis.utils.JavaUtils.convert(_resp, com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure getRolesForOrg() throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://webservice.consoleAPI.draco.security.comarch.com", "getRolesForOrg"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure) org.apache.axis.utils.JavaUtils.convert(_resp, com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public int registerAccount(java.lang.String name, java.lang.String secondName, java.lang.String surname, java.lang.String email) throws java.rmi.RemoteException, comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://generated.consoleAPI.draco.security.comarch.com", "registerAccount"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {name, secondName, surname, email});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) {
              throw (comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
