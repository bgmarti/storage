/**
 * DracoConsoleApiWSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI;

public interface DracoConsoleApiWSService extends javax.xml.rpc.Service {
    public java.lang.String getDracoConsoleAPIAddress();

    public comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWS getDracoConsoleAPI() throws javax.xml.rpc.ServiceException;

    public comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWS getDracoConsoleAPI(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
