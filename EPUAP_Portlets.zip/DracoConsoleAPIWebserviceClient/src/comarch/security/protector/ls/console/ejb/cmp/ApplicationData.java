/**
 * ApplicationData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class ApplicationData  implements java.io.Serializable {
    private java.lang.Integer appAc;

    private java.lang.Integer appGroupID;

    private java.lang.String appUsernameMask;

    private java.lang.Integer authMethods;

    private java.lang.String baseURL;

    private java.util.Date deactivationDate;

    private java.lang.String description;

    private java.lang.Integer expireTime;

    private java.lang.String frBegin;

    private java.lang.String frEnd;

    private java.lang.Integer id;

    private java.lang.String moBegin;

    private java.lang.String moEnd;

    private java.lang.Integer mother;

    private java.lang.String name;

    private java.lang.Integer owner;

    private java.lang.Integer primaryKey;

    private java.lang.String saBegin;

    private java.lang.String saEnd;

    private java.lang.String status;

    private java.lang.String suBegin;

    private java.lang.String suEnd;

    private java.lang.String thBegin;

    private java.lang.String thEnd;

    private java.lang.Integer trustLevelID;

    private java.lang.String tuBegin;

    private java.lang.String tuEnd;

    private java.lang.Integer usernameCertificareFromCN;

    private java.lang.String usrMaskLdapOperateAtt;

    private java.lang.String weBegin;

    private java.lang.String weEnd;

    public ApplicationData() {
    }

    public ApplicationData(
           java.lang.Integer appAc,
           java.lang.Integer appGroupID,
           java.lang.String appUsernameMask,
           java.lang.Integer authMethods,
           java.lang.String baseURL,
           java.util.Date deactivationDate,
           java.lang.String description,
           java.lang.Integer expireTime,
           java.lang.String frBegin,
           java.lang.String frEnd,
           java.lang.Integer id,
           java.lang.String moBegin,
           java.lang.String moEnd,
           java.lang.Integer mother,
           java.lang.String name,
           java.lang.Integer owner,
           java.lang.Integer primaryKey,
           java.lang.String saBegin,
           java.lang.String saEnd,
           java.lang.String status,
           java.lang.String suBegin,
           java.lang.String suEnd,
           java.lang.String thBegin,
           java.lang.String thEnd,
           java.lang.Integer trustLevelID,
           java.lang.String tuBegin,
           java.lang.String tuEnd,
           java.lang.Integer usernameCertificareFromCN,
           java.lang.String usrMaskLdapOperateAtt,
           java.lang.String weBegin,
           java.lang.String weEnd) {
           this.appAc = appAc;
           this.appGroupID = appGroupID;
           this.appUsernameMask = appUsernameMask;
           this.authMethods = authMethods;
           this.baseURL = baseURL;
           this.deactivationDate = deactivationDate;
           this.description = description;
           this.expireTime = expireTime;
           this.frBegin = frBegin;
           this.frEnd = frEnd;
           this.id = id;
           this.moBegin = moBegin;
           this.moEnd = moEnd;
           this.mother = mother;
           this.name = name;
           this.owner = owner;
           this.primaryKey = primaryKey;
           this.saBegin = saBegin;
           this.saEnd = saEnd;
           this.status = status;
           this.suBegin = suBegin;
           this.suEnd = suEnd;
           this.thBegin = thBegin;
           this.thEnd = thEnd;
           this.trustLevelID = trustLevelID;
           this.tuBegin = tuBegin;
           this.tuEnd = tuEnd;
           this.usernameCertificareFromCN = usernameCertificareFromCN;
           this.usrMaskLdapOperateAtt = usrMaskLdapOperateAtt;
           this.weBegin = weBegin;
           this.weEnd = weEnd;
    }


    /**
     * Gets the appAc value for this ApplicationData.
     * 
     * @return appAc
     */
    public java.lang.Integer getAppAc() {
        return appAc;
    }


    /**
     * Sets the appAc value for this ApplicationData.
     * 
     * @param appAc
     */
    public void setAppAc(java.lang.Integer appAc) {
        this.appAc = appAc;
    }


    /**
     * Gets the appGroupID value for this ApplicationData.
     * 
     * @return appGroupID
     */
    public java.lang.Integer getAppGroupID() {
        return appGroupID;
    }


    /**
     * Sets the appGroupID value for this ApplicationData.
     * 
     * @param appGroupID
     */
    public void setAppGroupID(java.lang.Integer appGroupID) {
        this.appGroupID = appGroupID;
    }


    /**
     * Gets the appUsernameMask value for this ApplicationData.
     * 
     * @return appUsernameMask
     */
    public java.lang.String getAppUsernameMask() {
        return appUsernameMask;
    }


    /**
     * Sets the appUsernameMask value for this ApplicationData.
     * 
     * @param appUsernameMask
     */
    public void setAppUsernameMask(java.lang.String appUsernameMask) {
        this.appUsernameMask = appUsernameMask;
    }


    /**
     * Gets the authMethods value for this ApplicationData.
     * 
     * @return authMethods
     */
    public java.lang.Integer getAuthMethods() {
        return authMethods;
    }


    /**
     * Sets the authMethods value for this ApplicationData.
     * 
     * @param authMethods
     */
    public void setAuthMethods(java.lang.Integer authMethods) {
        this.authMethods = authMethods;
    }


    /**
     * Gets the baseURL value for this ApplicationData.
     * 
     * @return baseURL
     */
    public java.lang.String getBaseURL() {
        return baseURL;
    }


    /**
     * Sets the baseURL value for this ApplicationData.
     * 
     * @param baseURL
     */
    public void setBaseURL(java.lang.String baseURL) {
        this.baseURL = baseURL;
    }


    /**
     * Gets the deactivationDate value for this ApplicationData.
     * 
     * @return deactivationDate
     */
    public java.util.Date getDeactivationDate() {
        return deactivationDate;
    }


    /**
     * Sets the deactivationDate value for this ApplicationData.
     * 
     * @param deactivationDate
     */
    public void setDeactivationDate(java.util.Date deactivationDate) {
        this.deactivationDate = deactivationDate;
    }


    /**
     * Gets the description value for this ApplicationData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this ApplicationData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the expireTime value for this ApplicationData.
     * 
     * @return expireTime
     */
    public java.lang.Integer getExpireTime() {
        return expireTime;
    }


    /**
     * Sets the expireTime value for this ApplicationData.
     * 
     * @param expireTime
     */
    public void setExpireTime(java.lang.Integer expireTime) {
        this.expireTime = expireTime;
    }


    /**
     * Gets the frBegin value for this ApplicationData.
     * 
     * @return frBegin
     */
    public java.lang.String getFrBegin() {
        return frBegin;
    }


    /**
     * Sets the frBegin value for this ApplicationData.
     * 
     * @param frBegin
     */
    public void setFrBegin(java.lang.String frBegin) {
        this.frBegin = frBegin;
    }


    /**
     * Gets the frEnd value for this ApplicationData.
     * 
     * @return frEnd
     */
    public java.lang.String getFrEnd() {
        return frEnd;
    }


    /**
     * Sets the frEnd value for this ApplicationData.
     * 
     * @param frEnd
     */
    public void setFrEnd(java.lang.String frEnd) {
        this.frEnd = frEnd;
    }


    /**
     * Gets the id value for this ApplicationData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this ApplicationData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the moBegin value for this ApplicationData.
     * 
     * @return moBegin
     */
    public java.lang.String getMoBegin() {
        return moBegin;
    }


    /**
     * Sets the moBegin value for this ApplicationData.
     * 
     * @param moBegin
     */
    public void setMoBegin(java.lang.String moBegin) {
        this.moBegin = moBegin;
    }


    /**
     * Gets the moEnd value for this ApplicationData.
     * 
     * @return moEnd
     */
    public java.lang.String getMoEnd() {
        return moEnd;
    }


    /**
     * Sets the moEnd value for this ApplicationData.
     * 
     * @param moEnd
     */
    public void setMoEnd(java.lang.String moEnd) {
        this.moEnd = moEnd;
    }


    /**
     * Gets the mother value for this ApplicationData.
     * 
     * @return mother
     */
    public java.lang.Integer getMother() {
        return mother;
    }


    /**
     * Sets the mother value for this ApplicationData.
     * 
     * @param mother
     */
    public void setMother(java.lang.Integer mother) {
        this.mother = mother;
    }


    /**
     * Gets the name value for this ApplicationData.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ApplicationData.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the owner value for this ApplicationData.
     * 
     * @return owner
     */
    public java.lang.Integer getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this ApplicationData.
     * 
     * @param owner
     */
    public void setOwner(java.lang.Integer owner) {
        this.owner = owner;
    }


    /**
     * Gets the primaryKey value for this ApplicationData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this ApplicationData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }


    /**
     * Gets the saBegin value for this ApplicationData.
     * 
     * @return saBegin
     */
    public java.lang.String getSaBegin() {
        return saBegin;
    }


    /**
     * Sets the saBegin value for this ApplicationData.
     * 
     * @param saBegin
     */
    public void setSaBegin(java.lang.String saBegin) {
        this.saBegin = saBegin;
    }


    /**
     * Gets the saEnd value for this ApplicationData.
     * 
     * @return saEnd
     */
    public java.lang.String getSaEnd() {
        return saEnd;
    }


    /**
     * Sets the saEnd value for this ApplicationData.
     * 
     * @param saEnd
     */
    public void setSaEnd(java.lang.String saEnd) {
        this.saEnd = saEnd;
    }


    /**
     * Gets the status value for this ApplicationData.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this ApplicationData.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the suBegin value for this ApplicationData.
     * 
     * @return suBegin
     */
    public java.lang.String getSuBegin() {
        return suBegin;
    }


    /**
     * Sets the suBegin value for this ApplicationData.
     * 
     * @param suBegin
     */
    public void setSuBegin(java.lang.String suBegin) {
        this.suBegin = suBegin;
    }


    /**
     * Gets the suEnd value for this ApplicationData.
     * 
     * @return suEnd
     */
    public java.lang.String getSuEnd() {
        return suEnd;
    }


    /**
     * Sets the suEnd value for this ApplicationData.
     * 
     * @param suEnd
     */
    public void setSuEnd(java.lang.String suEnd) {
        this.suEnd = suEnd;
    }


    /**
     * Gets the thBegin value for this ApplicationData.
     * 
     * @return thBegin
     */
    public java.lang.String getThBegin() {
        return thBegin;
    }


    /**
     * Sets the thBegin value for this ApplicationData.
     * 
     * @param thBegin
     */
    public void setThBegin(java.lang.String thBegin) {
        this.thBegin = thBegin;
    }


    /**
     * Gets the thEnd value for this ApplicationData.
     * 
     * @return thEnd
     */
    public java.lang.String getThEnd() {
        return thEnd;
    }


    /**
     * Sets the thEnd value for this ApplicationData.
     * 
     * @param thEnd
     */
    public void setThEnd(java.lang.String thEnd) {
        this.thEnd = thEnd;
    }


    /**
     * Gets the trustLevelID value for this ApplicationData.
     * 
     * @return trustLevelID
     */
    public java.lang.Integer getTrustLevelID() {
        return trustLevelID;
    }


    /**
     * Sets the trustLevelID value for this ApplicationData.
     * 
     * @param trustLevelID
     */
    public void setTrustLevelID(java.lang.Integer trustLevelID) {
        this.trustLevelID = trustLevelID;
    }


    /**
     * Gets the tuBegin value for this ApplicationData.
     * 
     * @return tuBegin
     */
    public java.lang.String getTuBegin() {
        return tuBegin;
    }


    /**
     * Sets the tuBegin value for this ApplicationData.
     * 
     * @param tuBegin
     */
    public void setTuBegin(java.lang.String tuBegin) {
        this.tuBegin = tuBegin;
    }


    /**
     * Gets the tuEnd value for this ApplicationData.
     * 
     * @return tuEnd
     */
    public java.lang.String getTuEnd() {
        return tuEnd;
    }


    /**
     * Sets the tuEnd value for this ApplicationData.
     * 
     * @param tuEnd
     */
    public void setTuEnd(java.lang.String tuEnd) {
        this.tuEnd = tuEnd;
    }


    /**
     * Gets the usernameCertificareFromCN value for this ApplicationData.
     * 
     * @return usernameCertificareFromCN
     */
    public java.lang.Integer getUsernameCertificareFromCN() {
        return usernameCertificareFromCN;
    }


    /**
     * Sets the usernameCertificareFromCN value for this ApplicationData.
     * 
     * @param usernameCertificareFromCN
     */
    public void setUsernameCertificareFromCN(java.lang.Integer usernameCertificareFromCN) {
        this.usernameCertificareFromCN = usernameCertificareFromCN;
    }


    /**
     * Gets the usrMaskLdapOperateAtt value for this ApplicationData.
     * 
     * @return usrMaskLdapOperateAtt
     */
    public java.lang.String getUsrMaskLdapOperateAtt() {
        return usrMaskLdapOperateAtt;
    }


    /**
     * Sets the usrMaskLdapOperateAtt value for this ApplicationData.
     * 
     * @param usrMaskLdapOperateAtt
     */
    public void setUsrMaskLdapOperateAtt(java.lang.String usrMaskLdapOperateAtt) {
        this.usrMaskLdapOperateAtt = usrMaskLdapOperateAtt;
    }


    /**
     * Gets the weBegin value for this ApplicationData.
     * 
     * @return weBegin
     */
    public java.lang.String getWeBegin() {
        return weBegin;
    }


    /**
     * Sets the weBegin value for this ApplicationData.
     * 
     * @param weBegin
     */
    public void setWeBegin(java.lang.String weBegin) {
        this.weBegin = weBegin;
    }


    /**
     * Gets the weEnd value for this ApplicationData.
     * 
     * @return weEnd
     */
    public java.lang.String getWeEnd() {
        return weEnd;
    }


    /**
     * Sets the weEnd value for this ApplicationData.
     * 
     * @param weEnd
     */
    public void setWeEnd(java.lang.String weEnd) {
        this.weEnd = weEnd;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ApplicationData)) return false;
        ApplicationData other = (ApplicationData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.appAc==null && other.getAppAc()==null) || 
             (this.appAc!=null &&
              this.appAc.equals(other.getAppAc()))) &&
            ((this.appGroupID==null && other.getAppGroupID()==null) || 
             (this.appGroupID!=null &&
              this.appGroupID.equals(other.getAppGroupID()))) &&
            ((this.appUsernameMask==null && other.getAppUsernameMask()==null) || 
             (this.appUsernameMask!=null &&
              this.appUsernameMask.equals(other.getAppUsernameMask()))) &&
            ((this.authMethods==null && other.getAuthMethods()==null) || 
             (this.authMethods!=null &&
              this.authMethods.equals(other.getAuthMethods()))) &&
            ((this.baseURL==null && other.getBaseURL()==null) || 
             (this.baseURL!=null &&
              this.baseURL.equals(other.getBaseURL()))) &&
            ((this.deactivationDate==null && other.getDeactivationDate()==null) || 
             (this.deactivationDate!=null &&
              this.deactivationDate.equals(other.getDeactivationDate()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.expireTime==null && other.getExpireTime()==null) || 
             (this.expireTime!=null &&
              this.expireTime.equals(other.getExpireTime()))) &&
            ((this.frBegin==null && other.getFrBegin()==null) || 
             (this.frBegin!=null &&
              this.frBegin.equals(other.getFrBegin()))) &&
            ((this.frEnd==null && other.getFrEnd()==null) || 
             (this.frEnd!=null &&
              this.frEnd.equals(other.getFrEnd()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.moBegin==null && other.getMoBegin()==null) || 
             (this.moBegin!=null &&
              this.moBegin.equals(other.getMoBegin()))) &&
            ((this.moEnd==null && other.getMoEnd()==null) || 
             (this.moEnd!=null &&
              this.moEnd.equals(other.getMoEnd()))) &&
            ((this.mother==null && other.getMother()==null) || 
             (this.mother!=null &&
              this.mother.equals(other.getMother()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey()))) &&
            ((this.saBegin==null && other.getSaBegin()==null) || 
             (this.saBegin!=null &&
              this.saBegin.equals(other.getSaBegin()))) &&
            ((this.saEnd==null && other.getSaEnd()==null) || 
             (this.saEnd!=null &&
              this.saEnd.equals(other.getSaEnd()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.suBegin==null && other.getSuBegin()==null) || 
             (this.suBegin!=null &&
              this.suBegin.equals(other.getSuBegin()))) &&
            ((this.suEnd==null && other.getSuEnd()==null) || 
             (this.suEnd!=null &&
              this.suEnd.equals(other.getSuEnd()))) &&
            ((this.thBegin==null && other.getThBegin()==null) || 
             (this.thBegin!=null &&
              this.thBegin.equals(other.getThBegin()))) &&
            ((this.thEnd==null && other.getThEnd()==null) || 
             (this.thEnd!=null &&
              this.thEnd.equals(other.getThEnd()))) &&
            ((this.trustLevelID==null && other.getTrustLevelID()==null) || 
             (this.trustLevelID!=null &&
              this.trustLevelID.equals(other.getTrustLevelID()))) &&
            ((this.tuBegin==null && other.getTuBegin()==null) || 
             (this.tuBegin!=null &&
              this.tuBegin.equals(other.getTuBegin()))) &&
            ((this.tuEnd==null && other.getTuEnd()==null) || 
             (this.tuEnd!=null &&
              this.tuEnd.equals(other.getTuEnd()))) &&
            ((this.usernameCertificareFromCN==null && other.getUsernameCertificareFromCN()==null) || 
             (this.usernameCertificareFromCN!=null &&
              this.usernameCertificareFromCN.equals(other.getUsernameCertificareFromCN()))) &&
            ((this.usrMaskLdapOperateAtt==null && other.getUsrMaskLdapOperateAtt()==null) || 
             (this.usrMaskLdapOperateAtt!=null &&
              this.usrMaskLdapOperateAtt.equals(other.getUsrMaskLdapOperateAtt()))) &&
            ((this.weBegin==null && other.getWeBegin()==null) || 
             (this.weBegin!=null &&
              this.weBegin.equals(other.getWeBegin()))) &&
            ((this.weEnd==null && other.getWeEnd()==null) || 
             (this.weEnd!=null &&
              this.weEnd.equals(other.getWeEnd())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAppAc() != null) {
            _hashCode += getAppAc().hashCode();
        }
        if (getAppGroupID() != null) {
            _hashCode += getAppGroupID().hashCode();
        }
        if (getAppUsernameMask() != null) {
            _hashCode += getAppUsernameMask().hashCode();
        }
        if (getAuthMethods() != null) {
            _hashCode += getAuthMethods().hashCode();
        }
        if (getBaseURL() != null) {
            _hashCode += getBaseURL().hashCode();
        }
        if (getDeactivationDate() != null) {
            _hashCode += getDeactivationDate().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getExpireTime() != null) {
            _hashCode += getExpireTime().hashCode();
        }
        if (getFrBegin() != null) {
            _hashCode += getFrBegin().hashCode();
        }
        if (getFrEnd() != null) {
            _hashCode += getFrEnd().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getMoBegin() != null) {
            _hashCode += getMoBegin().hashCode();
        }
        if (getMoEnd() != null) {
            _hashCode += getMoEnd().hashCode();
        }
        if (getMother() != null) {
            _hashCode += getMother().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        if (getSaBegin() != null) {
            _hashCode += getSaBegin().hashCode();
        }
        if (getSaEnd() != null) {
            _hashCode += getSaEnd().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getSuBegin() != null) {
            _hashCode += getSuBegin().hashCode();
        }
        if (getSuEnd() != null) {
            _hashCode += getSuEnd().hashCode();
        }
        if (getThBegin() != null) {
            _hashCode += getThBegin().hashCode();
        }
        if (getThEnd() != null) {
            _hashCode += getThEnd().hashCode();
        }
        if (getTrustLevelID() != null) {
            _hashCode += getTrustLevelID().hashCode();
        }
        if (getTuBegin() != null) {
            _hashCode += getTuBegin().hashCode();
        }
        if (getTuEnd() != null) {
            _hashCode += getTuEnd().hashCode();
        }
        if (getUsernameCertificareFromCN() != null) {
            _hashCode += getUsernameCertificareFromCN().hashCode();
        }
        if (getUsrMaskLdapOperateAtt() != null) {
            _hashCode += getUsrMaskLdapOperateAtt().hashCode();
        }
        if (getWeBegin() != null) {
            _hashCode += getWeBegin().hashCode();
        }
        if (getWeEnd() != null) {
            _hashCode += getWeEnd().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ApplicationData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "ApplicationData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appAc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "appAc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appGroupID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "appGroupID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appUsernameMask");
        elemField.setXmlName(new javax.xml.namespace.QName("", "appUsernameMask"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authMethods");
        elemField.setXmlName(new javax.xml.namespace.QName("", "authMethods"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baseURL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "baseURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deactivationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deactivationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expireTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expireTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "frBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "frEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mother");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mother"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("", "owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "saBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "saEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "thBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "thEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trustLevelID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "trustLevelID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tuBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tuBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tuEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tuEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usernameCertificareFromCN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usernameCertificareFromCN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usrMaskLdapOperateAtt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usrMaskLdapOperateAtt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("weBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "weBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("weEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "weEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
