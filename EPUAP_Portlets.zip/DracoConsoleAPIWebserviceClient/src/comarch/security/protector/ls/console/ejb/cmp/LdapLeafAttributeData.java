/**
 * LdapLeafAttributeData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class LdapLeafAttributeData  implements java.io.Serializable {
    private java.lang.String dbField;

    private java.lang.Integer id;

    private java.lang.String ldapAttribute;

    private java.lang.String ldapAttributeValue;

    private java.lang.Integer ldapID;

    private java.lang.Integer leafType;

    private java.lang.Integer primaryKey;

    private java.lang.Integer required;

    public LdapLeafAttributeData() {
    }

    public LdapLeafAttributeData(
           java.lang.String dbField,
           java.lang.Integer id,
           java.lang.String ldapAttribute,
           java.lang.String ldapAttributeValue,
           java.lang.Integer ldapID,
           java.lang.Integer leafType,
           java.lang.Integer primaryKey,
           java.lang.Integer required) {
           this.dbField = dbField;
           this.id = id;
           this.ldapAttribute = ldapAttribute;
           this.ldapAttributeValue = ldapAttributeValue;
           this.ldapID = ldapID;
           this.leafType = leafType;
           this.primaryKey = primaryKey;
           this.required = required;
    }


    /**
     * Gets the dbField value for this LdapLeafAttributeData.
     * 
     * @return dbField
     */
    public java.lang.String getDbField() {
        return dbField;
    }


    /**
     * Sets the dbField value for this LdapLeafAttributeData.
     * 
     * @param dbField
     */
    public void setDbField(java.lang.String dbField) {
        this.dbField = dbField;
    }


    /**
     * Gets the id value for this LdapLeafAttributeData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this LdapLeafAttributeData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the ldapAttribute value for this LdapLeafAttributeData.
     * 
     * @return ldapAttribute
     */
    public java.lang.String getLdapAttribute() {
        return ldapAttribute;
    }


    /**
     * Sets the ldapAttribute value for this LdapLeafAttributeData.
     * 
     * @param ldapAttribute
     */
    public void setLdapAttribute(java.lang.String ldapAttribute) {
        this.ldapAttribute = ldapAttribute;
    }


    /**
     * Gets the ldapAttributeValue value for this LdapLeafAttributeData.
     * 
     * @return ldapAttributeValue
     */
    public java.lang.String getLdapAttributeValue() {
        return ldapAttributeValue;
    }


    /**
     * Sets the ldapAttributeValue value for this LdapLeafAttributeData.
     * 
     * @param ldapAttributeValue
     */
    public void setLdapAttributeValue(java.lang.String ldapAttributeValue) {
        this.ldapAttributeValue = ldapAttributeValue;
    }


    /**
     * Gets the ldapID value for this LdapLeafAttributeData.
     * 
     * @return ldapID
     */
    public java.lang.Integer getLdapID() {
        return ldapID;
    }


    /**
     * Sets the ldapID value for this LdapLeafAttributeData.
     * 
     * @param ldapID
     */
    public void setLdapID(java.lang.Integer ldapID) {
        this.ldapID = ldapID;
    }


    /**
     * Gets the leafType value for this LdapLeafAttributeData.
     * 
     * @return leafType
     */
    public java.lang.Integer getLeafType() {
        return leafType;
    }


    /**
     * Sets the leafType value for this LdapLeafAttributeData.
     * 
     * @param leafType
     */
    public void setLeafType(java.lang.Integer leafType) {
        this.leafType = leafType;
    }


    /**
     * Gets the primaryKey value for this LdapLeafAttributeData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this LdapLeafAttributeData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }


    /**
     * Gets the required value for this LdapLeafAttributeData.
     * 
     * @return required
     */
    public java.lang.Integer getRequired() {
        return required;
    }


    /**
     * Sets the required value for this LdapLeafAttributeData.
     * 
     * @param required
     */
    public void setRequired(java.lang.Integer required) {
        this.required = required;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LdapLeafAttributeData)) return false;
        LdapLeafAttributeData other = (LdapLeafAttributeData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dbField==null && other.getDbField()==null) || 
             (this.dbField!=null &&
              this.dbField.equals(other.getDbField()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.ldapAttribute==null && other.getLdapAttribute()==null) || 
             (this.ldapAttribute!=null &&
              this.ldapAttribute.equals(other.getLdapAttribute()))) &&
            ((this.ldapAttributeValue==null && other.getLdapAttributeValue()==null) || 
             (this.ldapAttributeValue!=null &&
              this.ldapAttributeValue.equals(other.getLdapAttributeValue()))) &&
            ((this.ldapID==null && other.getLdapID()==null) || 
             (this.ldapID!=null &&
              this.ldapID.equals(other.getLdapID()))) &&
            ((this.leafType==null && other.getLeafType()==null) || 
             (this.leafType!=null &&
              this.leafType.equals(other.getLeafType()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey()))) &&
            ((this.required==null && other.getRequired()==null) || 
             (this.required!=null &&
              this.required.equals(other.getRequired())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDbField() != null) {
            _hashCode += getDbField().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getLdapAttribute() != null) {
            _hashCode += getLdapAttribute().hashCode();
        }
        if (getLdapAttributeValue() != null) {
            _hashCode += getLdapAttributeValue().hashCode();
        }
        if (getLdapID() != null) {
            _hashCode += getLdapID().hashCode();
        }
        if (getLeafType() != null) {
            _hashCode += getLeafType().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        if (getRequired() != null) {
            _hashCode += getRequired().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LdapLeafAttributeData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "LdapLeafAttributeData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dbField");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dbField"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapAttributeValue");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapAttributeValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("leafType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "leafType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("required");
        elemField.setXmlName(new javax.xml.namespace.QName("", "required"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
