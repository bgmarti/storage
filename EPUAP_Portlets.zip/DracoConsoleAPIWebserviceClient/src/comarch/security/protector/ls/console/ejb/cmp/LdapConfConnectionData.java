/**
 * LdapConfConnectionData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class LdapConfConnectionData  implements java.io.Serializable {
    private java.lang.Integer SSL;

    private java.lang.String description;

    private java.lang.Integer id;

    private java.lang.String ldapBaseDn;

    private java.lang.String ldapPort;

    private java.lang.String ldapServerDnsName;

    private java.lang.String ldapUser;

    private java.lang.String ldapUserPassword;

    private java.lang.String name;

    private java.lang.Integer primaryKey;

    public LdapConfConnectionData() {
    }

    public LdapConfConnectionData(
           java.lang.Integer SSL,
           java.lang.String description,
           java.lang.Integer id,
           java.lang.String ldapBaseDn,
           java.lang.String ldapPort,
           java.lang.String ldapServerDnsName,
           java.lang.String ldapUser,
           java.lang.String ldapUserPassword,
           java.lang.String name,
           java.lang.Integer primaryKey) {
           this.SSL = SSL;
           this.description = description;
           this.id = id;
           this.ldapBaseDn = ldapBaseDn;
           this.ldapPort = ldapPort;
           this.ldapServerDnsName = ldapServerDnsName;
           this.ldapUser = ldapUser;
           this.ldapUserPassword = ldapUserPassword;
           this.name = name;
           this.primaryKey = primaryKey;
    }


    /**
     * Gets the SSL value for this LdapConfConnectionData.
     * 
     * @return SSL
     */
    public java.lang.Integer getSSL() {
        return SSL;
    }


    /**
     * Sets the SSL value for this LdapConfConnectionData.
     * 
     * @param SSL
     */
    public void setSSL(java.lang.Integer SSL) {
        this.SSL = SSL;
    }


    /**
     * Gets the description value for this LdapConfConnectionData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this LdapConfConnectionData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the id value for this LdapConfConnectionData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this LdapConfConnectionData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the ldapBaseDn value for this LdapConfConnectionData.
     * 
     * @return ldapBaseDn
     */
    public java.lang.String getLdapBaseDn() {
        return ldapBaseDn;
    }


    /**
     * Sets the ldapBaseDn value for this LdapConfConnectionData.
     * 
     * @param ldapBaseDn
     */
    public void setLdapBaseDn(java.lang.String ldapBaseDn) {
        this.ldapBaseDn = ldapBaseDn;
    }


    /**
     * Gets the ldapPort value for this LdapConfConnectionData.
     * 
     * @return ldapPort
     */
    public java.lang.String getLdapPort() {
        return ldapPort;
    }


    /**
     * Sets the ldapPort value for this LdapConfConnectionData.
     * 
     * @param ldapPort
     */
    public void setLdapPort(java.lang.String ldapPort) {
        this.ldapPort = ldapPort;
    }


    /**
     * Gets the ldapServerDnsName value for this LdapConfConnectionData.
     * 
     * @return ldapServerDnsName
     */
    public java.lang.String getLdapServerDnsName() {
        return ldapServerDnsName;
    }


    /**
     * Sets the ldapServerDnsName value for this LdapConfConnectionData.
     * 
     * @param ldapServerDnsName
     */
    public void setLdapServerDnsName(java.lang.String ldapServerDnsName) {
        this.ldapServerDnsName = ldapServerDnsName;
    }


    /**
     * Gets the ldapUser value for this LdapConfConnectionData.
     * 
     * @return ldapUser
     */
    public java.lang.String getLdapUser() {
        return ldapUser;
    }


    /**
     * Sets the ldapUser value for this LdapConfConnectionData.
     * 
     * @param ldapUser
     */
    public void setLdapUser(java.lang.String ldapUser) {
        this.ldapUser = ldapUser;
    }


    /**
     * Gets the ldapUserPassword value for this LdapConfConnectionData.
     * 
     * @return ldapUserPassword
     */
    public java.lang.String getLdapUserPassword() {
        return ldapUserPassword;
    }


    /**
     * Sets the ldapUserPassword value for this LdapConfConnectionData.
     * 
     * @param ldapUserPassword
     */
    public void setLdapUserPassword(java.lang.String ldapUserPassword) {
        this.ldapUserPassword = ldapUserPassword;
    }


    /**
     * Gets the name value for this LdapConfConnectionData.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this LdapConfConnectionData.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the primaryKey value for this LdapConfConnectionData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this LdapConfConnectionData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LdapConfConnectionData)) return false;
        LdapConfConnectionData other = (LdapConfConnectionData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.SSL==null && other.getSSL()==null) || 
             (this.SSL!=null &&
              this.SSL.equals(other.getSSL()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.ldapBaseDn==null && other.getLdapBaseDn()==null) || 
             (this.ldapBaseDn!=null &&
              this.ldapBaseDn.equals(other.getLdapBaseDn()))) &&
            ((this.ldapPort==null && other.getLdapPort()==null) || 
             (this.ldapPort!=null &&
              this.ldapPort.equals(other.getLdapPort()))) &&
            ((this.ldapServerDnsName==null && other.getLdapServerDnsName()==null) || 
             (this.ldapServerDnsName!=null &&
              this.ldapServerDnsName.equals(other.getLdapServerDnsName()))) &&
            ((this.ldapUser==null && other.getLdapUser()==null) || 
             (this.ldapUser!=null &&
              this.ldapUser.equals(other.getLdapUser()))) &&
            ((this.ldapUserPassword==null && other.getLdapUserPassword()==null) || 
             (this.ldapUserPassword!=null &&
              this.ldapUserPassword.equals(other.getLdapUserPassword()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSSL() != null) {
            _hashCode += getSSL().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getLdapBaseDn() != null) {
            _hashCode += getLdapBaseDn().hashCode();
        }
        if (getLdapPort() != null) {
            _hashCode += getLdapPort().hashCode();
        }
        if (getLdapServerDnsName() != null) {
            _hashCode += getLdapServerDnsName().hashCode();
        }
        if (getLdapUser() != null) {
            _hashCode += getLdapUser().hashCode();
        }
        if (getLdapUserPassword() != null) {
            _hashCode += getLdapUserPassword().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LdapConfConnectionData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "LdapConfConnectionData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SSL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SSL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapBaseDn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapBaseDn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapPort");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapPort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapServerDnsName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapServerDnsName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapUserPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapUserPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
