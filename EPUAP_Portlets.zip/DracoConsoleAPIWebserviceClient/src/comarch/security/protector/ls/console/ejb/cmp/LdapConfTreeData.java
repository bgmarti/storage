/**
 * LdapConfTreeData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class LdapConfTreeData  implements java.io.Serializable {
    private java.lang.String PINAttribute;

    private java.lang.String certificateAttribute;

    private java.lang.Integer domainID;

    private java.lang.String groupElementAttribute;

    private java.lang.String groupElementAttributeKey;

    private java.lang.String groupElementAttributeKeyUsr;

    private java.lang.String groupElementAttributeUsr;

    private java.lang.String groupLeafRoot;

    private java.lang.Integer groupRecursiveSearch;

    private java.lang.String groupsBranch;

    private java.lang.Integer groupsInUser;

    private java.lang.Integer id;

    private java.lang.String initialGroupFilter;

    private java.lang.String initialUserFilter;

    private java.lang.Integer ldapID;

    private java.lang.String lockAttribute;

    private java.lang.String nameAttribute;

    private java.lang.String passwordAttribute;

    private java.lang.String phoneAttribute;

    private java.lang.Integer primaryKey;

    private java.lang.String protectorIDAttribute;

    private java.lang.Integer recursiveSearch;

    private java.lang.String roleLeafRoot;

    private java.lang.String rolesBranch;

    private java.lang.String surameAttribute;

    private java.lang.Integer usePass;

    private java.lang.String userLeafRoot;

    private java.lang.String usersBranch;

    public LdapConfTreeData() {
    }

    public LdapConfTreeData(
           java.lang.String PINAttribute,
           java.lang.String certificateAttribute,
           java.lang.Integer domainID,
           java.lang.String groupElementAttribute,
           java.lang.String groupElementAttributeKey,
           java.lang.String groupElementAttributeKeyUsr,
           java.lang.String groupElementAttributeUsr,
           java.lang.String groupLeafRoot,
           java.lang.Integer groupRecursiveSearch,
           java.lang.String groupsBranch,
           java.lang.Integer groupsInUser,
           java.lang.Integer id,
           java.lang.String initialGroupFilter,
           java.lang.String initialUserFilter,
           java.lang.Integer ldapID,
           java.lang.String lockAttribute,
           java.lang.String nameAttribute,
           java.lang.String passwordAttribute,
           java.lang.String phoneAttribute,
           java.lang.Integer primaryKey,
           java.lang.String protectorIDAttribute,
           java.lang.Integer recursiveSearch,
           java.lang.String roleLeafRoot,
           java.lang.String rolesBranch,
           java.lang.String surameAttribute,
           java.lang.Integer usePass,
           java.lang.String userLeafRoot,
           java.lang.String usersBranch) {
           this.PINAttribute = PINAttribute;
           this.certificateAttribute = certificateAttribute;
           this.domainID = domainID;
           this.groupElementAttribute = groupElementAttribute;
           this.groupElementAttributeKey = groupElementAttributeKey;
           this.groupElementAttributeKeyUsr = groupElementAttributeKeyUsr;
           this.groupElementAttributeUsr = groupElementAttributeUsr;
           this.groupLeafRoot = groupLeafRoot;
           this.groupRecursiveSearch = groupRecursiveSearch;
           this.groupsBranch = groupsBranch;
           this.groupsInUser = groupsInUser;
           this.id = id;
           this.initialGroupFilter = initialGroupFilter;
           this.initialUserFilter = initialUserFilter;
           this.ldapID = ldapID;
           this.lockAttribute = lockAttribute;
           this.nameAttribute = nameAttribute;
           this.passwordAttribute = passwordAttribute;
           this.phoneAttribute = phoneAttribute;
           this.primaryKey = primaryKey;
           this.protectorIDAttribute = protectorIDAttribute;
           this.recursiveSearch = recursiveSearch;
           this.roleLeafRoot = roleLeafRoot;
           this.rolesBranch = rolesBranch;
           this.surameAttribute = surameAttribute;
           this.usePass = usePass;
           this.userLeafRoot = userLeafRoot;
           this.usersBranch = usersBranch;
    }


    /**
     * Gets the PINAttribute value for this LdapConfTreeData.
     * 
     * @return PINAttribute
     */
    public java.lang.String getPINAttribute() {
        return PINAttribute;
    }


    /**
     * Sets the PINAttribute value for this LdapConfTreeData.
     * 
     * @param PINAttribute
     */
    public void setPINAttribute(java.lang.String PINAttribute) {
        this.PINAttribute = PINAttribute;
    }


    /**
     * Gets the certificateAttribute value for this LdapConfTreeData.
     * 
     * @return certificateAttribute
     */
    public java.lang.String getCertificateAttribute() {
        return certificateAttribute;
    }


    /**
     * Sets the certificateAttribute value for this LdapConfTreeData.
     * 
     * @param certificateAttribute
     */
    public void setCertificateAttribute(java.lang.String certificateAttribute) {
        this.certificateAttribute = certificateAttribute;
    }


    /**
     * Gets the domainID value for this LdapConfTreeData.
     * 
     * @return domainID
     */
    public java.lang.Integer getDomainID() {
        return domainID;
    }


    /**
     * Sets the domainID value for this LdapConfTreeData.
     * 
     * @param domainID
     */
    public void setDomainID(java.lang.Integer domainID) {
        this.domainID = domainID;
    }


    /**
     * Gets the groupElementAttribute value for this LdapConfTreeData.
     * 
     * @return groupElementAttribute
     */
    public java.lang.String getGroupElementAttribute() {
        return groupElementAttribute;
    }


    /**
     * Sets the groupElementAttribute value for this LdapConfTreeData.
     * 
     * @param groupElementAttribute
     */
    public void setGroupElementAttribute(java.lang.String groupElementAttribute) {
        this.groupElementAttribute = groupElementAttribute;
    }


    /**
     * Gets the groupElementAttributeKey value for this LdapConfTreeData.
     * 
     * @return groupElementAttributeKey
     */
    public java.lang.String getGroupElementAttributeKey() {
        return groupElementAttributeKey;
    }


    /**
     * Sets the groupElementAttributeKey value for this LdapConfTreeData.
     * 
     * @param groupElementAttributeKey
     */
    public void setGroupElementAttributeKey(java.lang.String groupElementAttributeKey) {
        this.groupElementAttributeKey = groupElementAttributeKey;
    }


    /**
     * Gets the groupElementAttributeKeyUsr value for this LdapConfTreeData.
     * 
     * @return groupElementAttributeKeyUsr
     */
    public java.lang.String getGroupElementAttributeKeyUsr() {
        return groupElementAttributeKeyUsr;
    }


    /**
     * Sets the groupElementAttributeKeyUsr value for this LdapConfTreeData.
     * 
     * @param groupElementAttributeKeyUsr
     */
    public void setGroupElementAttributeKeyUsr(java.lang.String groupElementAttributeKeyUsr) {
        this.groupElementAttributeKeyUsr = groupElementAttributeKeyUsr;
    }


    /**
     * Gets the groupElementAttributeUsr value for this LdapConfTreeData.
     * 
     * @return groupElementAttributeUsr
     */
    public java.lang.String getGroupElementAttributeUsr() {
        return groupElementAttributeUsr;
    }


    /**
     * Sets the groupElementAttributeUsr value for this LdapConfTreeData.
     * 
     * @param groupElementAttributeUsr
     */
    public void setGroupElementAttributeUsr(java.lang.String groupElementAttributeUsr) {
        this.groupElementAttributeUsr = groupElementAttributeUsr;
    }


    /**
     * Gets the groupLeafRoot value for this LdapConfTreeData.
     * 
     * @return groupLeafRoot
     */
    public java.lang.String getGroupLeafRoot() {
        return groupLeafRoot;
    }


    /**
     * Sets the groupLeafRoot value for this LdapConfTreeData.
     * 
     * @param groupLeafRoot
     */
    public void setGroupLeafRoot(java.lang.String groupLeafRoot) {
        this.groupLeafRoot = groupLeafRoot;
    }


    /**
     * Gets the groupRecursiveSearch value for this LdapConfTreeData.
     * 
     * @return groupRecursiveSearch
     */
    public java.lang.Integer getGroupRecursiveSearch() {
        return groupRecursiveSearch;
    }


    /**
     * Sets the groupRecursiveSearch value for this LdapConfTreeData.
     * 
     * @param groupRecursiveSearch
     */
    public void setGroupRecursiveSearch(java.lang.Integer groupRecursiveSearch) {
        this.groupRecursiveSearch = groupRecursiveSearch;
    }


    /**
     * Gets the groupsBranch value for this LdapConfTreeData.
     * 
     * @return groupsBranch
     */
    public java.lang.String getGroupsBranch() {
        return groupsBranch;
    }


    /**
     * Sets the groupsBranch value for this LdapConfTreeData.
     * 
     * @param groupsBranch
     */
    public void setGroupsBranch(java.lang.String groupsBranch) {
        this.groupsBranch = groupsBranch;
    }


    /**
     * Gets the groupsInUser value for this LdapConfTreeData.
     * 
     * @return groupsInUser
     */
    public java.lang.Integer getGroupsInUser() {
        return groupsInUser;
    }


    /**
     * Sets the groupsInUser value for this LdapConfTreeData.
     * 
     * @param groupsInUser
     */
    public void setGroupsInUser(java.lang.Integer groupsInUser) {
        this.groupsInUser = groupsInUser;
    }


    /**
     * Gets the id value for this LdapConfTreeData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this LdapConfTreeData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the initialGroupFilter value for this LdapConfTreeData.
     * 
     * @return initialGroupFilter
     */
    public java.lang.String getInitialGroupFilter() {
        return initialGroupFilter;
    }


    /**
     * Sets the initialGroupFilter value for this LdapConfTreeData.
     * 
     * @param initialGroupFilter
     */
    public void setInitialGroupFilter(java.lang.String initialGroupFilter) {
        this.initialGroupFilter = initialGroupFilter;
    }


    /**
     * Gets the initialUserFilter value for this LdapConfTreeData.
     * 
     * @return initialUserFilter
     */
    public java.lang.String getInitialUserFilter() {
        return initialUserFilter;
    }


    /**
     * Sets the initialUserFilter value for this LdapConfTreeData.
     * 
     * @param initialUserFilter
     */
    public void setInitialUserFilter(java.lang.String initialUserFilter) {
        this.initialUserFilter = initialUserFilter;
    }


    /**
     * Gets the ldapID value for this LdapConfTreeData.
     * 
     * @return ldapID
     */
    public java.lang.Integer getLdapID() {
        return ldapID;
    }


    /**
     * Sets the ldapID value for this LdapConfTreeData.
     * 
     * @param ldapID
     */
    public void setLdapID(java.lang.Integer ldapID) {
        this.ldapID = ldapID;
    }


    /**
     * Gets the lockAttribute value for this LdapConfTreeData.
     * 
     * @return lockAttribute
     */
    public java.lang.String getLockAttribute() {
        return lockAttribute;
    }


    /**
     * Sets the lockAttribute value for this LdapConfTreeData.
     * 
     * @param lockAttribute
     */
    public void setLockAttribute(java.lang.String lockAttribute) {
        this.lockAttribute = lockAttribute;
    }


    /**
     * Gets the nameAttribute value for this LdapConfTreeData.
     * 
     * @return nameAttribute
     */
    public java.lang.String getNameAttribute() {
        return nameAttribute;
    }


    /**
     * Sets the nameAttribute value for this LdapConfTreeData.
     * 
     * @param nameAttribute
     */
    public void setNameAttribute(java.lang.String nameAttribute) {
        this.nameAttribute = nameAttribute;
    }


    /**
     * Gets the passwordAttribute value for this LdapConfTreeData.
     * 
     * @return passwordAttribute
     */
    public java.lang.String getPasswordAttribute() {
        return passwordAttribute;
    }


    /**
     * Sets the passwordAttribute value for this LdapConfTreeData.
     * 
     * @param passwordAttribute
     */
    public void setPasswordAttribute(java.lang.String passwordAttribute) {
        this.passwordAttribute = passwordAttribute;
    }


    /**
     * Gets the phoneAttribute value for this LdapConfTreeData.
     * 
     * @return phoneAttribute
     */
    public java.lang.String getPhoneAttribute() {
        return phoneAttribute;
    }


    /**
     * Sets the phoneAttribute value for this LdapConfTreeData.
     * 
     * @param phoneAttribute
     */
    public void setPhoneAttribute(java.lang.String phoneAttribute) {
        this.phoneAttribute = phoneAttribute;
    }


    /**
     * Gets the primaryKey value for this LdapConfTreeData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this LdapConfTreeData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }


    /**
     * Gets the protectorIDAttribute value for this LdapConfTreeData.
     * 
     * @return protectorIDAttribute
     */
    public java.lang.String getProtectorIDAttribute() {
        return protectorIDAttribute;
    }


    /**
     * Sets the protectorIDAttribute value for this LdapConfTreeData.
     * 
     * @param protectorIDAttribute
     */
    public void setProtectorIDAttribute(java.lang.String protectorIDAttribute) {
        this.protectorIDAttribute = protectorIDAttribute;
    }


    /**
     * Gets the recursiveSearch value for this LdapConfTreeData.
     * 
     * @return recursiveSearch
     */
    public java.lang.Integer getRecursiveSearch() {
        return recursiveSearch;
    }


    /**
     * Sets the recursiveSearch value for this LdapConfTreeData.
     * 
     * @param recursiveSearch
     */
    public void setRecursiveSearch(java.lang.Integer recursiveSearch) {
        this.recursiveSearch = recursiveSearch;
    }


    /**
     * Gets the roleLeafRoot value for this LdapConfTreeData.
     * 
     * @return roleLeafRoot
     */
    public java.lang.String getRoleLeafRoot() {
        return roleLeafRoot;
    }


    /**
     * Sets the roleLeafRoot value for this LdapConfTreeData.
     * 
     * @param roleLeafRoot
     */
    public void setRoleLeafRoot(java.lang.String roleLeafRoot) {
        this.roleLeafRoot = roleLeafRoot;
    }


    /**
     * Gets the rolesBranch value for this LdapConfTreeData.
     * 
     * @return rolesBranch
     */
    public java.lang.String getRolesBranch() {
        return rolesBranch;
    }


    /**
     * Sets the rolesBranch value for this LdapConfTreeData.
     * 
     * @param rolesBranch
     */
    public void setRolesBranch(java.lang.String rolesBranch) {
        this.rolesBranch = rolesBranch;
    }


    /**
     * Gets the surameAttribute value for this LdapConfTreeData.
     * 
     * @return surameAttribute
     */
    public java.lang.String getSurameAttribute() {
        return surameAttribute;
    }


    /**
     * Sets the surameAttribute value for this LdapConfTreeData.
     * 
     * @param surameAttribute
     */
    public void setSurameAttribute(java.lang.String surameAttribute) {
        this.surameAttribute = surameAttribute;
    }


    /**
     * Gets the usePass value for this LdapConfTreeData.
     * 
     * @return usePass
     */
    public java.lang.Integer getUsePass() {
        return usePass;
    }


    /**
     * Sets the usePass value for this LdapConfTreeData.
     * 
     * @param usePass
     */
    public void setUsePass(java.lang.Integer usePass) {
        this.usePass = usePass;
    }


    /**
     * Gets the userLeafRoot value for this LdapConfTreeData.
     * 
     * @return userLeafRoot
     */
    public java.lang.String getUserLeafRoot() {
        return userLeafRoot;
    }


    /**
     * Sets the userLeafRoot value for this LdapConfTreeData.
     * 
     * @param userLeafRoot
     */
    public void setUserLeafRoot(java.lang.String userLeafRoot) {
        this.userLeafRoot = userLeafRoot;
    }


    /**
     * Gets the usersBranch value for this LdapConfTreeData.
     * 
     * @return usersBranch
     */
    public java.lang.String getUsersBranch() {
        return usersBranch;
    }


    /**
     * Sets the usersBranch value for this LdapConfTreeData.
     * 
     * @param usersBranch
     */
    public void setUsersBranch(java.lang.String usersBranch) {
        this.usersBranch = usersBranch;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LdapConfTreeData)) return false;
        LdapConfTreeData other = (LdapConfTreeData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PINAttribute==null && other.getPINAttribute()==null) || 
             (this.PINAttribute!=null &&
              this.PINAttribute.equals(other.getPINAttribute()))) &&
            ((this.certificateAttribute==null && other.getCertificateAttribute()==null) || 
             (this.certificateAttribute!=null &&
              this.certificateAttribute.equals(other.getCertificateAttribute()))) &&
            ((this.domainID==null && other.getDomainID()==null) || 
             (this.domainID!=null &&
              this.domainID.equals(other.getDomainID()))) &&
            ((this.groupElementAttribute==null && other.getGroupElementAttribute()==null) || 
             (this.groupElementAttribute!=null &&
              this.groupElementAttribute.equals(other.getGroupElementAttribute()))) &&
            ((this.groupElementAttributeKey==null && other.getGroupElementAttributeKey()==null) || 
             (this.groupElementAttributeKey!=null &&
              this.groupElementAttributeKey.equals(other.getGroupElementAttributeKey()))) &&
            ((this.groupElementAttributeKeyUsr==null && other.getGroupElementAttributeKeyUsr()==null) || 
             (this.groupElementAttributeKeyUsr!=null &&
              this.groupElementAttributeKeyUsr.equals(other.getGroupElementAttributeKeyUsr()))) &&
            ((this.groupElementAttributeUsr==null && other.getGroupElementAttributeUsr()==null) || 
             (this.groupElementAttributeUsr!=null &&
              this.groupElementAttributeUsr.equals(other.getGroupElementAttributeUsr()))) &&
            ((this.groupLeafRoot==null && other.getGroupLeafRoot()==null) || 
             (this.groupLeafRoot!=null &&
              this.groupLeafRoot.equals(other.getGroupLeafRoot()))) &&
            ((this.groupRecursiveSearch==null && other.getGroupRecursiveSearch()==null) || 
             (this.groupRecursiveSearch!=null &&
              this.groupRecursiveSearch.equals(other.getGroupRecursiveSearch()))) &&
            ((this.groupsBranch==null && other.getGroupsBranch()==null) || 
             (this.groupsBranch!=null &&
              this.groupsBranch.equals(other.getGroupsBranch()))) &&
            ((this.groupsInUser==null && other.getGroupsInUser()==null) || 
             (this.groupsInUser!=null &&
              this.groupsInUser.equals(other.getGroupsInUser()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.initialGroupFilter==null && other.getInitialGroupFilter()==null) || 
             (this.initialGroupFilter!=null &&
              this.initialGroupFilter.equals(other.getInitialGroupFilter()))) &&
            ((this.initialUserFilter==null && other.getInitialUserFilter()==null) || 
             (this.initialUserFilter!=null &&
              this.initialUserFilter.equals(other.getInitialUserFilter()))) &&
            ((this.ldapID==null && other.getLdapID()==null) || 
             (this.ldapID!=null &&
              this.ldapID.equals(other.getLdapID()))) &&
            ((this.lockAttribute==null && other.getLockAttribute()==null) || 
             (this.lockAttribute!=null &&
              this.lockAttribute.equals(other.getLockAttribute()))) &&
            ((this.nameAttribute==null && other.getNameAttribute()==null) || 
             (this.nameAttribute!=null &&
              this.nameAttribute.equals(other.getNameAttribute()))) &&
            ((this.passwordAttribute==null && other.getPasswordAttribute()==null) || 
             (this.passwordAttribute!=null &&
              this.passwordAttribute.equals(other.getPasswordAttribute()))) &&
            ((this.phoneAttribute==null && other.getPhoneAttribute()==null) || 
             (this.phoneAttribute!=null &&
              this.phoneAttribute.equals(other.getPhoneAttribute()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey()))) &&
            ((this.protectorIDAttribute==null && other.getProtectorIDAttribute()==null) || 
             (this.protectorIDAttribute!=null &&
              this.protectorIDAttribute.equals(other.getProtectorIDAttribute()))) &&
            ((this.recursiveSearch==null && other.getRecursiveSearch()==null) || 
             (this.recursiveSearch!=null &&
              this.recursiveSearch.equals(other.getRecursiveSearch()))) &&
            ((this.roleLeafRoot==null && other.getRoleLeafRoot()==null) || 
             (this.roleLeafRoot!=null &&
              this.roleLeafRoot.equals(other.getRoleLeafRoot()))) &&
            ((this.rolesBranch==null && other.getRolesBranch()==null) || 
             (this.rolesBranch!=null &&
              this.rolesBranch.equals(other.getRolesBranch()))) &&
            ((this.surameAttribute==null && other.getSurameAttribute()==null) || 
             (this.surameAttribute!=null &&
              this.surameAttribute.equals(other.getSurameAttribute()))) &&
            ((this.usePass==null && other.getUsePass()==null) || 
             (this.usePass!=null &&
              this.usePass.equals(other.getUsePass()))) &&
            ((this.userLeafRoot==null && other.getUserLeafRoot()==null) || 
             (this.userLeafRoot!=null &&
              this.userLeafRoot.equals(other.getUserLeafRoot()))) &&
            ((this.usersBranch==null && other.getUsersBranch()==null) || 
             (this.usersBranch!=null &&
              this.usersBranch.equals(other.getUsersBranch())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPINAttribute() != null) {
            _hashCode += getPINAttribute().hashCode();
        }
        if (getCertificateAttribute() != null) {
            _hashCode += getCertificateAttribute().hashCode();
        }
        if (getDomainID() != null) {
            _hashCode += getDomainID().hashCode();
        }
        if (getGroupElementAttribute() != null) {
            _hashCode += getGroupElementAttribute().hashCode();
        }
        if (getGroupElementAttributeKey() != null) {
            _hashCode += getGroupElementAttributeKey().hashCode();
        }
        if (getGroupElementAttributeKeyUsr() != null) {
            _hashCode += getGroupElementAttributeKeyUsr().hashCode();
        }
        if (getGroupElementAttributeUsr() != null) {
            _hashCode += getGroupElementAttributeUsr().hashCode();
        }
        if (getGroupLeafRoot() != null) {
            _hashCode += getGroupLeafRoot().hashCode();
        }
        if (getGroupRecursiveSearch() != null) {
            _hashCode += getGroupRecursiveSearch().hashCode();
        }
        if (getGroupsBranch() != null) {
            _hashCode += getGroupsBranch().hashCode();
        }
        if (getGroupsInUser() != null) {
            _hashCode += getGroupsInUser().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getInitialGroupFilter() != null) {
            _hashCode += getInitialGroupFilter().hashCode();
        }
        if (getInitialUserFilter() != null) {
            _hashCode += getInitialUserFilter().hashCode();
        }
        if (getLdapID() != null) {
            _hashCode += getLdapID().hashCode();
        }
        if (getLockAttribute() != null) {
            _hashCode += getLockAttribute().hashCode();
        }
        if (getNameAttribute() != null) {
            _hashCode += getNameAttribute().hashCode();
        }
        if (getPasswordAttribute() != null) {
            _hashCode += getPasswordAttribute().hashCode();
        }
        if (getPhoneAttribute() != null) {
            _hashCode += getPhoneAttribute().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        if (getProtectorIDAttribute() != null) {
            _hashCode += getProtectorIDAttribute().hashCode();
        }
        if (getRecursiveSearch() != null) {
            _hashCode += getRecursiveSearch().hashCode();
        }
        if (getRoleLeafRoot() != null) {
            _hashCode += getRoleLeafRoot().hashCode();
        }
        if (getRolesBranch() != null) {
            _hashCode += getRolesBranch().hashCode();
        }
        if (getSurameAttribute() != null) {
            _hashCode += getSurameAttribute().hashCode();
        }
        if (getUsePass() != null) {
            _hashCode += getUsePass().hashCode();
        }
        if (getUserLeafRoot() != null) {
            _hashCode += getUserLeafRoot().hashCode();
        }
        if (getUsersBranch() != null) {
            _hashCode += getUsersBranch().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LdapConfTreeData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "LdapConfTreeData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PINAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PINAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "certificateAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "domainID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupElementAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupElementAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupElementAttributeKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupElementAttributeKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupElementAttributeKeyUsr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupElementAttributeKeyUsr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupElementAttributeUsr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupElementAttributeUsr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupLeafRoot");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupLeafRoot"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupRecursiveSearch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupRecursiveSearch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupsBranch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupsBranch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupsInUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupsInUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("initialGroupFilter");
        elemField.setXmlName(new javax.xml.namespace.QName("", "initialGroupFilter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("initialUserFilter");
        elemField.setXmlName(new javax.xml.namespace.QName("", "initialUserFilter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lockAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lockAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nameAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passwordAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "passwordAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phoneAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "phoneAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protectorIDAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "protectorIDAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recursiveSearch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "recursiveSearch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roleLeafRoot");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roleLeafRoot"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rolesBranch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "rolesBranch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("surameAttribute");
        elemField.setXmlName(new javax.xml.namespace.QName("", "surameAttribute"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usePass");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usePass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userLeafRoot");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userLeafRoot"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usersBranch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usersBranch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
