/**
 * RoleData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class RoleData  implements java.io.Serializable {
    private java.lang.Integer contextID;

    private java.lang.Integer ctxType;

    private java.lang.String description;

    private java.lang.Integer id;

    private java.lang.Integer isLocal;

    private java.lang.String ldapDN;

    private java.lang.String name;

    private java.lang.Integer primaryKey;

    public RoleData() {
    }

    public RoleData(
           java.lang.Integer contextID,
           java.lang.Integer ctxType,
           java.lang.String description,
           java.lang.Integer id,
           java.lang.Integer isLocal,
           java.lang.String ldapDN,
           java.lang.String name,
           java.lang.Integer primaryKey) {
           this.contextID = contextID;
           this.ctxType = ctxType;
           this.description = description;
           this.id = id;
           this.isLocal = isLocal;
           this.ldapDN = ldapDN;
           this.name = name;
           this.primaryKey = primaryKey;
    }


    /**
     * Gets the contextID value for this RoleData.
     * 
     * @return contextID
     */
    public java.lang.Integer getContextID() {
        return contextID;
    }


    /**
     * Sets the contextID value for this RoleData.
     * 
     * @param contextID
     */
    public void setContextID(java.lang.Integer contextID) {
        this.contextID = contextID;
    }


    /**
     * Gets the ctxType value for this RoleData.
     * 
     * @return ctxType
     */
    public java.lang.Integer getCtxType() {
        return ctxType;
    }


    /**
     * Sets the ctxType value for this RoleData.
     * 
     * @param ctxType
     */
    public void setCtxType(java.lang.Integer ctxType) {
        this.ctxType = ctxType;
    }


    /**
     * Gets the description value for this RoleData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this RoleData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the id value for this RoleData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this RoleData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the isLocal value for this RoleData.
     * 
     * @return isLocal
     */
    public java.lang.Integer getIsLocal() {
        return isLocal;
    }


    /**
     * Sets the isLocal value for this RoleData.
     * 
     * @param isLocal
     */
    public void setIsLocal(java.lang.Integer isLocal) {
        this.isLocal = isLocal;
    }


    /**
     * Gets the ldapDN value for this RoleData.
     * 
     * @return ldapDN
     */
    public java.lang.String getLdapDN() {
        return ldapDN;
    }


    /**
     * Sets the ldapDN value for this RoleData.
     * 
     * @param ldapDN
     */
    public void setLdapDN(java.lang.String ldapDN) {
        this.ldapDN = ldapDN;
    }


    /**
     * Gets the name value for this RoleData.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this RoleData.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the primaryKey value for this RoleData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this RoleData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RoleData)) return false;
        RoleData other = (RoleData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.contextID==null && other.getContextID()==null) || 
             (this.contextID!=null &&
              this.contextID.equals(other.getContextID()))) &&
            ((this.ctxType==null && other.getCtxType()==null) || 
             (this.ctxType!=null &&
              this.ctxType.equals(other.getCtxType()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.isLocal==null && other.getIsLocal()==null) || 
             (this.isLocal!=null &&
              this.isLocal.equals(other.getIsLocal()))) &&
            ((this.ldapDN==null && other.getLdapDN()==null) || 
             (this.ldapDN!=null &&
              this.ldapDN.equals(other.getLdapDN()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getContextID() != null) {
            _hashCode += getContextID().hashCode();
        }
        if (getCtxType() != null) {
            _hashCode += getCtxType().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getIsLocal() != null) {
            _hashCode += getIsLocal().hashCode();
        }
        if (getLdapDN() != null) {
            _hashCode += getLdapDN().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RoleData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "RoleData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contextID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contextID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ctxType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ctxType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isLocal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isLocal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldapDN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldapDN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
