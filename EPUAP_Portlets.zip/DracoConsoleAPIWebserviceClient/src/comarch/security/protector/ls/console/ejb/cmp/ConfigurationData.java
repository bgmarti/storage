/**
 * ConfigurationData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class ConfigurationData  implements java.io.Serializable {
    private java.lang.Integer backPassNumber;

    private java.lang.String defaultBeginTime;

    private java.lang.String defaultBeginWeekendTime;

    private java.lang.String defaultEndTime;

    private java.lang.String defaultEndWeekendTime;

    private java.lang.String defaultInterval;

    private java.lang.String defaultWeekendInterval;

    private java.lang.Integer failedLoginCountAllowed;

    private java.lang.Integer id;

    private java.lang.Boolean isCurrent;

    private java.lang.Integer lockoutDuration;

    private java.lang.Integer maxPassLen;

    private java.lang.Integer minDigitsInPass;

    private java.lang.Integer minPassLen;

    private java.lang.Integer minSpecCharsInPass;

    private java.lang.Integer passValidity;

    private java.lang.Integer passValidityTime;

    private java.lang.Integer primaryKey;

    public ConfigurationData() {
    }

    public ConfigurationData(
           java.lang.Integer backPassNumber,
           java.lang.String defaultBeginTime,
           java.lang.String defaultBeginWeekendTime,
           java.lang.String defaultEndTime,
           java.lang.String defaultEndWeekendTime,
           java.lang.String defaultInterval,
           java.lang.String defaultWeekendInterval,
           java.lang.Integer failedLoginCountAllowed,
           java.lang.Integer id,
           java.lang.Boolean isCurrent,
           java.lang.Integer lockoutDuration,
           java.lang.Integer maxPassLen,
           java.lang.Integer minDigitsInPass,
           java.lang.Integer minPassLen,
           java.lang.Integer minSpecCharsInPass,
           java.lang.Integer passValidity,
           java.lang.Integer passValidityTime,
           java.lang.Integer primaryKey) {
           this.backPassNumber = backPassNumber;
           this.defaultBeginTime = defaultBeginTime;
           this.defaultBeginWeekendTime = defaultBeginWeekendTime;
           this.defaultEndTime = defaultEndTime;
           this.defaultEndWeekendTime = defaultEndWeekendTime;
           this.defaultInterval = defaultInterval;
           this.defaultWeekendInterval = defaultWeekendInterval;
           this.failedLoginCountAllowed = failedLoginCountAllowed;
           this.id = id;
           this.isCurrent = isCurrent;
           this.lockoutDuration = lockoutDuration;
           this.maxPassLen = maxPassLen;
           this.minDigitsInPass = minDigitsInPass;
           this.minPassLen = minPassLen;
           this.minSpecCharsInPass = minSpecCharsInPass;
           this.passValidity = passValidity;
           this.passValidityTime = passValidityTime;
           this.primaryKey = primaryKey;
    }


    /**
     * Gets the backPassNumber value for this ConfigurationData.
     * 
     * @return backPassNumber
     */
    public java.lang.Integer getBackPassNumber() {
        return backPassNumber;
    }


    /**
     * Sets the backPassNumber value for this ConfigurationData.
     * 
     * @param backPassNumber
     */
    public void setBackPassNumber(java.lang.Integer backPassNumber) {
        this.backPassNumber = backPassNumber;
    }


    /**
     * Gets the defaultBeginTime value for this ConfigurationData.
     * 
     * @return defaultBeginTime
     */
    public java.lang.String getDefaultBeginTime() {
        return defaultBeginTime;
    }


    /**
     * Sets the defaultBeginTime value for this ConfigurationData.
     * 
     * @param defaultBeginTime
     */
    public void setDefaultBeginTime(java.lang.String defaultBeginTime) {
        this.defaultBeginTime = defaultBeginTime;
    }


    /**
     * Gets the defaultBeginWeekendTime value for this ConfigurationData.
     * 
     * @return defaultBeginWeekendTime
     */
    public java.lang.String getDefaultBeginWeekendTime() {
        return defaultBeginWeekendTime;
    }


    /**
     * Sets the defaultBeginWeekendTime value for this ConfigurationData.
     * 
     * @param defaultBeginWeekendTime
     */
    public void setDefaultBeginWeekendTime(java.lang.String defaultBeginWeekendTime) {
        this.defaultBeginWeekendTime = defaultBeginWeekendTime;
    }


    /**
     * Gets the defaultEndTime value for this ConfigurationData.
     * 
     * @return defaultEndTime
     */
    public java.lang.String getDefaultEndTime() {
        return defaultEndTime;
    }


    /**
     * Sets the defaultEndTime value for this ConfigurationData.
     * 
     * @param defaultEndTime
     */
    public void setDefaultEndTime(java.lang.String defaultEndTime) {
        this.defaultEndTime = defaultEndTime;
    }


    /**
     * Gets the defaultEndWeekendTime value for this ConfigurationData.
     * 
     * @return defaultEndWeekendTime
     */
    public java.lang.String getDefaultEndWeekendTime() {
        return defaultEndWeekendTime;
    }


    /**
     * Sets the defaultEndWeekendTime value for this ConfigurationData.
     * 
     * @param defaultEndWeekendTime
     */
    public void setDefaultEndWeekendTime(java.lang.String defaultEndWeekendTime) {
        this.defaultEndWeekendTime = defaultEndWeekendTime;
    }


    /**
     * Gets the defaultInterval value for this ConfigurationData.
     * 
     * @return defaultInterval
     */
    public java.lang.String getDefaultInterval() {
        return defaultInterval;
    }


    /**
     * Sets the defaultInterval value for this ConfigurationData.
     * 
     * @param defaultInterval
     */
    public void setDefaultInterval(java.lang.String defaultInterval) {
        this.defaultInterval = defaultInterval;
    }


    /**
     * Gets the defaultWeekendInterval value for this ConfigurationData.
     * 
     * @return defaultWeekendInterval
     */
    public java.lang.String getDefaultWeekendInterval() {
        return defaultWeekendInterval;
    }


    /**
     * Sets the defaultWeekendInterval value for this ConfigurationData.
     * 
     * @param defaultWeekendInterval
     */
    public void setDefaultWeekendInterval(java.lang.String defaultWeekendInterval) {
        this.defaultWeekendInterval = defaultWeekendInterval;
    }


    /**
     * Gets the failedLoginCountAllowed value for this ConfigurationData.
     * 
     * @return failedLoginCountAllowed
     */
    public java.lang.Integer getFailedLoginCountAllowed() {
        return failedLoginCountAllowed;
    }


    /**
     * Sets the failedLoginCountAllowed value for this ConfigurationData.
     * 
     * @param failedLoginCountAllowed
     */
    public void setFailedLoginCountAllowed(java.lang.Integer failedLoginCountAllowed) {
        this.failedLoginCountAllowed = failedLoginCountAllowed;
    }


    /**
     * Gets the id value for this ConfigurationData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this ConfigurationData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the isCurrent value for this ConfigurationData.
     * 
     * @return isCurrent
     */
    public java.lang.Boolean getIsCurrent() {
        return isCurrent;
    }


    /**
     * Sets the isCurrent value for this ConfigurationData.
     * 
     * @param isCurrent
     */
    public void setIsCurrent(java.lang.Boolean isCurrent) {
        this.isCurrent = isCurrent;
    }


    /**
     * Gets the lockoutDuration value for this ConfigurationData.
     * 
     * @return lockoutDuration
     */
    public java.lang.Integer getLockoutDuration() {
        return lockoutDuration;
    }


    /**
     * Sets the lockoutDuration value for this ConfigurationData.
     * 
     * @param lockoutDuration
     */
    public void setLockoutDuration(java.lang.Integer lockoutDuration) {
        this.lockoutDuration = lockoutDuration;
    }


    /**
     * Gets the maxPassLen value for this ConfigurationData.
     * 
     * @return maxPassLen
     */
    public java.lang.Integer getMaxPassLen() {
        return maxPassLen;
    }


    /**
     * Sets the maxPassLen value for this ConfigurationData.
     * 
     * @param maxPassLen
     */
    public void setMaxPassLen(java.lang.Integer maxPassLen) {
        this.maxPassLen = maxPassLen;
    }


    /**
     * Gets the minDigitsInPass value for this ConfigurationData.
     * 
     * @return minDigitsInPass
     */
    public java.lang.Integer getMinDigitsInPass() {
        return minDigitsInPass;
    }


    /**
     * Sets the minDigitsInPass value for this ConfigurationData.
     * 
     * @param minDigitsInPass
     */
    public void setMinDigitsInPass(java.lang.Integer minDigitsInPass) {
        this.minDigitsInPass = minDigitsInPass;
    }


    /**
     * Gets the minPassLen value for this ConfigurationData.
     * 
     * @return minPassLen
     */
    public java.lang.Integer getMinPassLen() {
        return minPassLen;
    }


    /**
     * Sets the minPassLen value for this ConfigurationData.
     * 
     * @param minPassLen
     */
    public void setMinPassLen(java.lang.Integer minPassLen) {
        this.minPassLen = minPassLen;
    }


    /**
     * Gets the minSpecCharsInPass value for this ConfigurationData.
     * 
     * @return minSpecCharsInPass
     */
    public java.lang.Integer getMinSpecCharsInPass() {
        return minSpecCharsInPass;
    }


    /**
     * Sets the minSpecCharsInPass value for this ConfigurationData.
     * 
     * @param minSpecCharsInPass
     */
    public void setMinSpecCharsInPass(java.lang.Integer minSpecCharsInPass) {
        this.minSpecCharsInPass = minSpecCharsInPass;
    }


    /**
     * Gets the passValidity value for this ConfigurationData.
     * 
     * @return passValidity
     */
    public java.lang.Integer getPassValidity() {
        return passValidity;
    }


    /**
     * Sets the passValidity value for this ConfigurationData.
     * 
     * @param passValidity
     */
    public void setPassValidity(java.lang.Integer passValidity) {
        this.passValidity = passValidity;
    }


    /**
     * Gets the passValidityTime value for this ConfigurationData.
     * 
     * @return passValidityTime
     */
    public java.lang.Integer getPassValidityTime() {
        return passValidityTime;
    }


    /**
     * Sets the passValidityTime value for this ConfigurationData.
     * 
     * @param passValidityTime
     */
    public void setPassValidityTime(java.lang.Integer passValidityTime) {
        this.passValidityTime = passValidityTime;
    }


    /**
     * Gets the primaryKey value for this ConfigurationData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this ConfigurationData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConfigurationData)) return false;
        ConfigurationData other = (ConfigurationData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.backPassNumber==null && other.getBackPassNumber()==null) || 
             (this.backPassNumber!=null &&
              this.backPassNumber.equals(other.getBackPassNumber()))) &&
            ((this.defaultBeginTime==null && other.getDefaultBeginTime()==null) || 
             (this.defaultBeginTime!=null &&
              this.defaultBeginTime.equals(other.getDefaultBeginTime()))) &&
            ((this.defaultBeginWeekendTime==null && other.getDefaultBeginWeekendTime()==null) || 
             (this.defaultBeginWeekendTime!=null &&
              this.defaultBeginWeekendTime.equals(other.getDefaultBeginWeekendTime()))) &&
            ((this.defaultEndTime==null && other.getDefaultEndTime()==null) || 
             (this.defaultEndTime!=null &&
              this.defaultEndTime.equals(other.getDefaultEndTime()))) &&
            ((this.defaultEndWeekendTime==null && other.getDefaultEndWeekendTime()==null) || 
             (this.defaultEndWeekendTime!=null &&
              this.defaultEndWeekendTime.equals(other.getDefaultEndWeekendTime()))) &&
            ((this.defaultInterval==null && other.getDefaultInterval()==null) || 
             (this.defaultInterval!=null &&
              this.defaultInterval.equals(other.getDefaultInterval()))) &&
            ((this.defaultWeekendInterval==null && other.getDefaultWeekendInterval()==null) || 
             (this.defaultWeekendInterval!=null &&
              this.defaultWeekendInterval.equals(other.getDefaultWeekendInterval()))) &&
            ((this.failedLoginCountAllowed==null && other.getFailedLoginCountAllowed()==null) || 
             (this.failedLoginCountAllowed!=null &&
              this.failedLoginCountAllowed.equals(other.getFailedLoginCountAllowed()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.isCurrent==null && other.getIsCurrent()==null) || 
             (this.isCurrent!=null &&
              this.isCurrent.equals(other.getIsCurrent()))) &&
            ((this.lockoutDuration==null && other.getLockoutDuration()==null) || 
             (this.lockoutDuration!=null &&
              this.lockoutDuration.equals(other.getLockoutDuration()))) &&
            ((this.maxPassLen==null && other.getMaxPassLen()==null) || 
             (this.maxPassLen!=null &&
              this.maxPassLen.equals(other.getMaxPassLen()))) &&
            ((this.minDigitsInPass==null && other.getMinDigitsInPass()==null) || 
             (this.minDigitsInPass!=null &&
              this.minDigitsInPass.equals(other.getMinDigitsInPass()))) &&
            ((this.minPassLen==null && other.getMinPassLen()==null) || 
             (this.minPassLen!=null &&
              this.minPassLen.equals(other.getMinPassLen()))) &&
            ((this.minSpecCharsInPass==null && other.getMinSpecCharsInPass()==null) || 
             (this.minSpecCharsInPass!=null &&
              this.minSpecCharsInPass.equals(other.getMinSpecCharsInPass()))) &&
            ((this.passValidity==null && other.getPassValidity()==null) || 
             (this.passValidity!=null &&
              this.passValidity.equals(other.getPassValidity()))) &&
            ((this.passValidityTime==null && other.getPassValidityTime()==null) || 
             (this.passValidityTime!=null &&
              this.passValidityTime.equals(other.getPassValidityTime()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBackPassNumber() != null) {
            _hashCode += getBackPassNumber().hashCode();
        }
        if (getDefaultBeginTime() != null) {
            _hashCode += getDefaultBeginTime().hashCode();
        }
        if (getDefaultBeginWeekendTime() != null) {
            _hashCode += getDefaultBeginWeekendTime().hashCode();
        }
        if (getDefaultEndTime() != null) {
            _hashCode += getDefaultEndTime().hashCode();
        }
        if (getDefaultEndWeekendTime() != null) {
            _hashCode += getDefaultEndWeekendTime().hashCode();
        }
        if (getDefaultInterval() != null) {
            _hashCode += getDefaultInterval().hashCode();
        }
        if (getDefaultWeekendInterval() != null) {
            _hashCode += getDefaultWeekendInterval().hashCode();
        }
        if (getFailedLoginCountAllowed() != null) {
            _hashCode += getFailedLoginCountAllowed().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getIsCurrent() != null) {
            _hashCode += getIsCurrent().hashCode();
        }
        if (getLockoutDuration() != null) {
            _hashCode += getLockoutDuration().hashCode();
        }
        if (getMaxPassLen() != null) {
            _hashCode += getMaxPassLen().hashCode();
        }
        if (getMinDigitsInPass() != null) {
            _hashCode += getMinDigitsInPass().hashCode();
        }
        if (getMinPassLen() != null) {
            _hashCode += getMinPassLen().hashCode();
        }
        if (getMinSpecCharsInPass() != null) {
            _hashCode += getMinSpecCharsInPass().hashCode();
        }
        if (getPassValidity() != null) {
            _hashCode += getPassValidity().hashCode();
        }
        if (getPassValidityTime() != null) {
            _hashCode += getPassValidityTime().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConfigurationData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "ConfigurationData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("backPassNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "backPassNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultBeginTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultBeginTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultBeginWeekendTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultBeginWeekendTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultEndTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultEndTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultEndWeekendTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultEndWeekendTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("defaultWeekendInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "defaultWeekendInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("failedLoginCountAllowed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "failedLoginCountAllowed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isCurrent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isCurrent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lockoutDuration");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lockoutDuration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxPassLen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxPassLen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minDigitsInPass");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minDigitsInPass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minPassLen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minPassLen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minSpecCharsInPass");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minSpecCharsInPass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passValidity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "passValidity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passValidityTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "passValidityTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
