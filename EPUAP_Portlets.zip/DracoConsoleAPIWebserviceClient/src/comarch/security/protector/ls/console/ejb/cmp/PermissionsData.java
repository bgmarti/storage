/**
 * PermissionsData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class PermissionsData  implements java.io.Serializable {
    private java.lang.Integer application_id;

    private java.lang.Boolean approvalNeed;

    private java.lang.String description;

    private java.lang.Integer id;

    private java.lang.String name;

    private java.lang.Integer permissionGroupId;

    private java.lang.String permission_type;

    private java.lang.Integer primaryKey;

    public PermissionsData() {
    }

    public PermissionsData(
           java.lang.Integer application_id,
           java.lang.Boolean approvalNeed,
           java.lang.String description,
           java.lang.Integer id,
           java.lang.String name,
           java.lang.Integer permissionGroupId,
           java.lang.String permission_type,
           java.lang.Integer primaryKey) {
           this.application_id = application_id;
           this.approvalNeed = approvalNeed;
           this.description = description;
           this.id = id;
           this.name = name;
           this.permissionGroupId = permissionGroupId;
           this.permission_type = permission_type;
           this.primaryKey = primaryKey;
    }


    /**
     * Gets the application_id value for this PermissionsData.
     * 
     * @return application_id
     */
    public java.lang.Integer getApplication_id() {
        return application_id;
    }


    /**
     * Sets the application_id value for this PermissionsData.
     * 
     * @param application_id
     */
    public void setApplication_id(java.lang.Integer application_id) {
        this.application_id = application_id;
    }


    /**
     * Gets the approvalNeed value for this PermissionsData.
     * 
     * @return approvalNeed
     */
    public java.lang.Boolean getApprovalNeed() {
        return approvalNeed;
    }


    /**
     * Sets the approvalNeed value for this PermissionsData.
     * 
     * @param approvalNeed
     */
    public void setApprovalNeed(java.lang.Boolean approvalNeed) {
        this.approvalNeed = approvalNeed;
    }


    /**
     * Gets the description value for this PermissionsData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this PermissionsData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the id value for this PermissionsData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this PermissionsData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the name value for this PermissionsData.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this PermissionsData.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the permissionGroupId value for this PermissionsData.
     * 
     * @return permissionGroupId
     */
    public java.lang.Integer getPermissionGroupId() {
        return permissionGroupId;
    }


    /**
     * Sets the permissionGroupId value for this PermissionsData.
     * 
     * @param permissionGroupId
     */
    public void setPermissionGroupId(java.lang.Integer permissionGroupId) {
        this.permissionGroupId = permissionGroupId;
    }


    /**
     * Gets the permission_type value for this PermissionsData.
     * 
     * @return permission_type
     */
    public java.lang.String getPermission_type() {
        return permission_type;
    }


    /**
     * Sets the permission_type value for this PermissionsData.
     * 
     * @param permission_type
     */
    public void setPermission_type(java.lang.String permission_type) {
        this.permission_type = permission_type;
    }


    /**
     * Gets the primaryKey value for this PermissionsData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this PermissionsData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PermissionsData)) return false;
        PermissionsData other = (PermissionsData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.application_id==null && other.getApplication_id()==null) || 
             (this.application_id!=null &&
              this.application_id.equals(other.getApplication_id()))) &&
            ((this.approvalNeed==null && other.getApprovalNeed()==null) || 
             (this.approvalNeed!=null &&
              this.approvalNeed.equals(other.getApprovalNeed()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.permissionGroupId==null && other.getPermissionGroupId()==null) || 
             (this.permissionGroupId!=null &&
              this.permissionGroupId.equals(other.getPermissionGroupId()))) &&
            ((this.permission_type==null && other.getPermission_type()==null) || 
             (this.permission_type!=null &&
              this.permission_type.equals(other.getPermission_type()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getApplication_id() != null) {
            _hashCode += getApplication_id().hashCode();
        }
        if (getApprovalNeed() != null) {
            _hashCode += getApprovalNeed().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getPermissionGroupId() != null) {
            _hashCode += getPermissionGroupId().hashCode();
        }
        if (getPermission_type() != null) {
            _hashCode += getPermission_type().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PermissionsData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "PermissionsData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("application_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "application_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalNeed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "approvalNeed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("permissionGroupId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "permissionGroupId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("permission_type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "permission_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
