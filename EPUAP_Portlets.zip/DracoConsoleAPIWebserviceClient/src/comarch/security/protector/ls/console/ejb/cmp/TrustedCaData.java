/**
 * TrustedCaData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class TrustedCaData  implements java.io.Serializable {
    private java.lang.String ca_dn;

    private java.lang.String ca_name;

    private java.lang.String certificate;

    private java.lang.String description;

    private java.lang.Integer draco_id;

    private java.lang.Integer id;

    private java.lang.Integer primaryKey;

    public TrustedCaData() {
    }

    public TrustedCaData(
           java.lang.String ca_dn,
           java.lang.String ca_name,
           java.lang.String certificate,
           java.lang.String description,
           java.lang.Integer draco_id,
           java.lang.Integer id,
           java.lang.Integer primaryKey) {
           this.ca_dn = ca_dn;
           this.ca_name = ca_name;
           this.certificate = certificate;
           this.description = description;
           this.draco_id = draco_id;
           this.id = id;
           this.primaryKey = primaryKey;
    }


    /**
     * Gets the ca_dn value for this TrustedCaData.
     * 
     * @return ca_dn
     */
    public java.lang.String getCa_dn() {
        return ca_dn;
    }


    /**
     * Sets the ca_dn value for this TrustedCaData.
     * 
     * @param ca_dn
     */
    public void setCa_dn(java.lang.String ca_dn) {
        this.ca_dn = ca_dn;
    }


    /**
     * Gets the ca_name value for this TrustedCaData.
     * 
     * @return ca_name
     */
    public java.lang.String getCa_name() {
        return ca_name;
    }


    /**
     * Sets the ca_name value for this TrustedCaData.
     * 
     * @param ca_name
     */
    public void setCa_name(java.lang.String ca_name) {
        this.ca_name = ca_name;
    }


    /**
     * Gets the certificate value for this TrustedCaData.
     * 
     * @return certificate
     */
    public java.lang.String getCertificate() {
        return certificate;
    }


    /**
     * Sets the certificate value for this TrustedCaData.
     * 
     * @param certificate
     */
    public void setCertificate(java.lang.String certificate) {
        this.certificate = certificate;
    }


    /**
     * Gets the description value for this TrustedCaData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this TrustedCaData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the draco_id value for this TrustedCaData.
     * 
     * @return draco_id
     */
    public java.lang.Integer getDraco_id() {
        return draco_id;
    }


    /**
     * Sets the draco_id value for this TrustedCaData.
     * 
     * @param draco_id
     */
    public void setDraco_id(java.lang.Integer draco_id) {
        this.draco_id = draco_id;
    }


    /**
     * Gets the id value for this TrustedCaData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this TrustedCaData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the primaryKey value for this TrustedCaData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this TrustedCaData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TrustedCaData)) return false;
        TrustedCaData other = (TrustedCaData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ca_dn==null && other.getCa_dn()==null) || 
             (this.ca_dn!=null &&
              this.ca_dn.equals(other.getCa_dn()))) &&
            ((this.ca_name==null && other.getCa_name()==null) || 
             (this.ca_name!=null &&
              this.ca_name.equals(other.getCa_name()))) &&
            ((this.certificate==null && other.getCertificate()==null) || 
             (this.certificate!=null &&
              this.certificate.equals(other.getCertificate()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.draco_id==null && other.getDraco_id()==null) || 
             (this.draco_id!=null &&
              this.draco_id.equals(other.getDraco_id()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCa_dn() != null) {
            _hashCode += getCa_dn().hashCode();
        }
        if (getCa_name() != null) {
            _hashCode += getCa_name().hashCode();
        }
        if (getCertificate() != null) {
            _hashCode += getCertificate().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getDraco_id() != null) {
            _hashCode += getDraco_id().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TrustedCaData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "TrustedCaData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ca_dn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ca_dn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ca_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ca_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "certificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("draco_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "draco_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
