/**
 * UserData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.protector.ls.console.ejb.cmp;

public class UserData  implements java.io.Serializable {
    private java.lang.Integer authMethods;

    private java.lang.String certDigest;

    private java.util.Calendar creationDate;

    private java.lang.String deactivationDate;

    private java.lang.String description;

    private java.lang.String dn;

    private java.lang.String domain;

    private java.lang.String email;

    private java.lang.Integer failedLoginCount;

    private java.lang.String frBegin;

    private java.lang.String frEnd;

    private java.lang.String frInterval;

    private java.lang.Integer id;

    private java.lang.Boolean isAdmin;

    private java.lang.Boolean isGodAdmin;

    private java.lang.Integer isLdapUser;

    private java.lang.Integer isSystem;

    private java.util.Calendar lastFailedLogin;

    private java.util.Calendar lastPassExpNotification;

    private java.lang.String moBegin;

    private java.lang.String moEnd;

    private java.lang.String moInterval;

    private java.lang.String name;

    private java.lang.Integer orgID;

    private java.util.Calendar passExpirationDate;

    private java.lang.Integer passSequenceNr;

    private java.lang.String password;

    private java.util.Calendar passwordSetDate;

    private java.lang.Integer primaryKey;

    private java.lang.String protectorId;

    private java.lang.String saBegin;

    private java.lang.String saEnd;

    private java.lang.String saInterval;

    private java.lang.String secondName;

    private java.lang.String securid;

    private java.lang.Integer status;

    private java.lang.String suBegin;

    private java.lang.String suEnd;

    private java.lang.String suInterval;

    private java.lang.String surname;

    private java.lang.String thBegin;

    private java.lang.String thEnd;

    private java.lang.String thInterval;

    private java.lang.Integer trustLevelId;

    private java.lang.String tuBegin;

    private java.lang.String tuEnd;

    private java.lang.String tuInterval;

    private java.lang.String userCertificate;

    private java.lang.Integer userDomainID;

    private java.lang.String weBegin;

    private java.lang.String weEnd;

    private java.lang.String weInterval;

    public UserData() {
    }

    public UserData(
           java.lang.Integer authMethods,
           java.lang.String certDigest,
           java.util.Calendar creationDate,
           java.lang.String deactivationDate,
           java.lang.String description,
           java.lang.String dn,
           java.lang.String domain,
           java.lang.String email,
           java.lang.Integer failedLoginCount,
           java.lang.String frBegin,
           java.lang.String frEnd,
           java.lang.String frInterval,
           java.lang.Integer id,
           java.lang.Boolean isAdmin,
           java.lang.Boolean isGodAdmin,
           java.lang.Integer isLdapUser,
           java.lang.Integer isSystem,
           java.util.Calendar lastFailedLogin,
           java.util.Calendar lastPassExpNotification,
           java.lang.String moBegin,
           java.lang.String moEnd,
           java.lang.String moInterval,
           java.lang.String name,
           java.lang.Integer orgID,
           java.util.Calendar passExpirationDate,
           java.lang.Integer passSequenceNr,
           java.lang.String password,
           java.util.Calendar passwordSetDate,
           java.lang.Integer primaryKey,
           java.lang.String protectorId,
           java.lang.String saBegin,
           java.lang.String saEnd,
           java.lang.String saInterval,
           java.lang.String secondName,
           java.lang.String securid,
           java.lang.Integer status,
           java.lang.String suBegin,
           java.lang.String suEnd,
           java.lang.String suInterval,
           java.lang.String surname,
           java.lang.String thBegin,
           java.lang.String thEnd,
           java.lang.String thInterval,
           java.lang.Integer trustLevelId,
           java.lang.String tuBegin,
           java.lang.String tuEnd,
           java.lang.String tuInterval,
           java.lang.String userCertificate,
           java.lang.Integer userDomainID,
           java.lang.String weBegin,
           java.lang.String weEnd,
           java.lang.String weInterval) {
           this.authMethods = authMethods;
           this.certDigest = certDigest;
           this.creationDate = creationDate;
           this.deactivationDate = deactivationDate;
           this.description = description;
           this.dn = dn;
           this.domain = domain;
           this.email = email;
           this.failedLoginCount = failedLoginCount;
           this.frBegin = frBegin;
           this.frEnd = frEnd;
           this.frInterval = frInterval;
           this.id = id;
           this.isAdmin = isAdmin;
           this.isGodAdmin = isGodAdmin;
           this.isLdapUser = isLdapUser;
           this.isSystem = isSystem;
           this.lastFailedLogin = lastFailedLogin;
           this.lastPassExpNotification = lastPassExpNotification;
           this.moBegin = moBegin;
           this.moEnd = moEnd;
           this.moInterval = moInterval;
           this.name = name;
           this.orgID = orgID;
           this.passExpirationDate = passExpirationDate;
           this.passSequenceNr = passSequenceNr;
           this.password = password;
           this.passwordSetDate = passwordSetDate;
           this.primaryKey = primaryKey;
           this.protectorId = protectorId;
           this.saBegin = saBegin;
           this.saEnd = saEnd;
           this.saInterval = saInterval;
           this.secondName = secondName;
           this.securid = securid;
           this.status = status;
           this.suBegin = suBegin;
           this.suEnd = suEnd;
           this.suInterval = suInterval;
           this.surname = surname;
           this.thBegin = thBegin;
           this.thEnd = thEnd;
           this.thInterval = thInterval;
           this.trustLevelId = trustLevelId;
           this.tuBegin = tuBegin;
           this.tuEnd = tuEnd;
           this.tuInterval = tuInterval;
           this.userCertificate = userCertificate;
           this.userDomainID = userDomainID;
           this.weBegin = weBegin;
           this.weEnd = weEnd;
           this.weInterval = weInterval;
    }


    /**
     * Gets the authMethods value for this UserData.
     * 
     * @return authMethods
     */
    public java.lang.Integer getAuthMethods() {
        return authMethods;
    }


    /**
     * Sets the authMethods value for this UserData.
     * 
     * @param authMethods
     */
    public void setAuthMethods(java.lang.Integer authMethods) {
        this.authMethods = authMethods;
    }


    /**
     * Gets the certDigest value for this UserData.
     * 
     * @return certDigest
     */
    public java.lang.String getCertDigest() {
        return certDigest;
    }


    /**
     * Sets the certDigest value for this UserData.
     * 
     * @param certDigest
     */
    public void setCertDigest(java.lang.String certDigest) {
        this.certDigest = certDigest;
    }


    /**
     * Gets the creationDate value for this UserData.
     * 
     * @return creationDate
     */
    public java.util.Calendar getCreationDate() {
        return creationDate;
    }


    /**
     * Sets the creationDate value for this UserData.
     * 
     * @param creationDate
     */
    public void setCreationDate(java.util.Calendar creationDate) {
        this.creationDate = creationDate;
    }


    /**
     * Gets the deactivationDate value for this UserData.
     * 
     * @return deactivationDate
     */
    public java.lang.String getDeactivationDate() {
        return deactivationDate;
    }


    /**
     * Sets the deactivationDate value for this UserData.
     * 
     * @param deactivationDate
     */
    public void setDeactivationDate(java.lang.String deactivationDate) {
        this.deactivationDate = deactivationDate;
    }


    /**
     * Gets the description value for this UserData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this UserData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the dn value for this UserData.
     * 
     * @return dn
     */
    public java.lang.String getDn() {
        return dn;
    }


    /**
     * Sets the dn value for this UserData.
     * 
     * @param dn
     */
    public void setDn(java.lang.String dn) {
        this.dn = dn;
    }


    /**
     * Gets the domain value for this UserData.
     * 
     * @return domain
     */
    public java.lang.String getDomain() {
        return domain;
    }


    /**
     * Sets the domain value for this UserData.
     * 
     * @param domain
     */
    public void setDomain(java.lang.String domain) {
        this.domain = domain;
    }


    /**
     * Gets the email value for this UserData.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this UserData.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the failedLoginCount value for this UserData.
     * 
     * @return failedLoginCount
     */
    public java.lang.Integer getFailedLoginCount() {
        return failedLoginCount;
    }


    /**
     * Sets the failedLoginCount value for this UserData.
     * 
     * @param failedLoginCount
     */
    public void setFailedLoginCount(java.lang.Integer failedLoginCount) {
        this.failedLoginCount = failedLoginCount;
    }


    /**
     * Gets the frBegin value for this UserData.
     * 
     * @return frBegin
     */
    public java.lang.String getFrBegin() {
        return frBegin;
    }


    /**
     * Sets the frBegin value for this UserData.
     * 
     * @param frBegin
     */
    public void setFrBegin(java.lang.String frBegin) {
        this.frBegin = frBegin;
    }


    /**
     * Gets the frEnd value for this UserData.
     * 
     * @return frEnd
     */
    public java.lang.String getFrEnd() {
        return frEnd;
    }


    /**
     * Sets the frEnd value for this UserData.
     * 
     * @param frEnd
     */
    public void setFrEnd(java.lang.String frEnd) {
        this.frEnd = frEnd;
    }


    /**
     * Gets the frInterval value for this UserData.
     * 
     * @return frInterval
     */
    public java.lang.String getFrInterval() {
        return frInterval;
    }


    /**
     * Sets the frInterval value for this UserData.
     * 
     * @param frInterval
     */
    public void setFrInterval(java.lang.String frInterval) {
        this.frInterval = frInterval;
    }


    /**
     * Gets the id value for this UserData.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this UserData.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the isAdmin value for this UserData.
     * 
     * @return isAdmin
     */
    public java.lang.Boolean getIsAdmin() {
        return isAdmin;
    }


    /**
     * Sets the isAdmin value for this UserData.
     * 
     * @param isAdmin
     */
    public void setIsAdmin(java.lang.Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }


    /**
     * Gets the isGodAdmin value for this UserData.
     * 
     * @return isGodAdmin
     */
    public java.lang.Boolean getIsGodAdmin() {
        return isGodAdmin;
    }


    /**
     * Sets the isGodAdmin value for this UserData.
     * 
     * @param isGodAdmin
     */
    public void setIsGodAdmin(java.lang.Boolean isGodAdmin) {
        this.isGodAdmin = isGodAdmin;
    }


    /**
     * Gets the isLdapUser value for this UserData.
     * 
     * @return isLdapUser
     */
    public java.lang.Integer getIsLdapUser() {
        return isLdapUser;
    }


    /**
     * Sets the isLdapUser value for this UserData.
     * 
     * @param isLdapUser
     */
    public void setIsLdapUser(java.lang.Integer isLdapUser) {
        this.isLdapUser = isLdapUser;
    }


    /**
     * Gets the isSystem value for this UserData.
     * 
     * @return isSystem
     */
    public java.lang.Integer getIsSystem() {
        return isSystem;
    }


    /**
     * Sets the isSystem value for this UserData.
     * 
     * @param isSystem
     */
    public void setIsSystem(java.lang.Integer isSystem) {
        this.isSystem = isSystem;
    }


    /**
     * Gets the lastFailedLogin value for this UserData.
     * 
     * @return lastFailedLogin
     */
    public java.util.Calendar getLastFailedLogin() {
        return lastFailedLogin;
    }


    /**
     * Sets the lastFailedLogin value for this UserData.
     * 
     * @param lastFailedLogin
     */
    public void setLastFailedLogin(java.util.Calendar lastFailedLogin) {
        this.lastFailedLogin = lastFailedLogin;
    }


    /**
     * Gets the lastPassExpNotification value for this UserData.
     * 
     * @return lastPassExpNotification
     */
    public java.util.Calendar getLastPassExpNotification() {
        return lastPassExpNotification;
    }


    /**
     * Sets the lastPassExpNotification value for this UserData.
     * 
     * @param lastPassExpNotification
     */
    public void setLastPassExpNotification(java.util.Calendar lastPassExpNotification) {
        this.lastPassExpNotification = lastPassExpNotification;
    }


    /**
     * Gets the moBegin value for this UserData.
     * 
     * @return moBegin
     */
    public java.lang.String getMoBegin() {
        return moBegin;
    }


    /**
     * Sets the moBegin value for this UserData.
     * 
     * @param moBegin
     */
    public void setMoBegin(java.lang.String moBegin) {
        this.moBegin = moBegin;
    }


    /**
     * Gets the moEnd value for this UserData.
     * 
     * @return moEnd
     */
    public java.lang.String getMoEnd() {
        return moEnd;
    }


    /**
     * Sets the moEnd value for this UserData.
     * 
     * @param moEnd
     */
    public void setMoEnd(java.lang.String moEnd) {
        this.moEnd = moEnd;
    }


    /**
     * Gets the moInterval value for this UserData.
     * 
     * @return moInterval
     */
    public java.lang.String getMoInterval() {
        return moInterval;
    }


    /**
     * Sets the moInterval value for this UserData.
     * 
     * @param moInterval
     */
    public void setMoInterval(java.lang.String moInterval) {
        this.moInterval = moInterval;
    }


    /**
     * Gets the name value for this UserData.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this UserData.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the orgID value for this UserData.
     * 
     * @return orgID
     */
    public java.lang.Integer getOrgID() {
        return orgID;
    }


    /**
     * Sets the orgID value for this UserData.
     * 
     * @param orgID
     */
    public void setOrgID(java.lang.Integer orgID) {
        this.orgID = orgID;
    }


    /**
     * Gets the passExpirationDate value for this UserData.
     * 
     * @return passExpirationDate
     */
    public java.util.Calendar getPassExpirationDate() {
        return passExpirationDate;
    }


    /**
     * Sets the passExpirationDate value for this UserData.
     * 
     * @param passExpirationDate
     */
    public void setPassExpirationDate(java.util.Calendar passExpirationDate) {
        this.passExpirationDate = passExpirationDate;
    }


    /**
     * Gets the passSequenceNr value for this UserData.
     * 
     * @return passSequenceNr
     */
    public java.lang.Integer getPassSequenceNr() {
        return passSequenceNr;
    }


    /**
     * Sets the passSequenceNr value for this UserData.
     * 
     * @param passSequenceNr
     */
    public void setPassSequenceNr(java.lang.Integer passSequenceNr) {
        this.passSequenceNr = passSequenceNr;
    }


    /**
     * Gets the password value for this UserData.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this UserData.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the passwordSetDate value for this UserData.
     * 
     * @return passwordSetDate
     */
    public java.util.Calendar getPasswordSetDate() {
        return passwordSetDate;
    }


    /**
     * Sets the passwordSetDate value for this UserData.
     * 
     * @param passwordSetDate
     */
    public void setPasswordSetDate(java.util.Calendar passwordSetDate) {
        this.passwordSetDate = passwordSetDate;
    }


    /**
     * Gets the primaryKey value for this UserData.
     * 
     * @return primaryKey
     */
    public java.lang.Integer getPrimaryKey() {
        return primaryKey;
    }


    /**
     * Sets the primaryKey value for this UserData.
     * 
     * @param primaryKey
     */
    public void setPrimaryKey(java.lang.Integer primaryKey) {
        this.primaryKey = primaryKey;
    }


    /**
     * Gets the protectorId value for this UserData.
     * 
     * @return protectorId
     */
    public java.lang.String getProtectorId() {
        return protectorId;
    }


    /**
     * Sets the protectorId value for this UserData.
     * 
     * @param protectorId
     */
    public void setProtectorId(java.lang.String protectorId) {
        this.protectorId = protectorId;
    }


    /**
     * Gets the saBegin value for this UserData.
     * 
     * @return saBegin
     */
    public java.lang.String getSaBegin() {
        return saBegin;
    }


    /**
     * Sets the saBegin value for this UserData.
     * 
     * @param saBegin
     */
    public void setSaBegin(java.lang.String saBegin) {
        this.saBegin = saBegin;
    }


    /**
     * Gets the saEnd value for this UserData.
     * 
     * @return saEnd
     */
    public java.lang.String getSaEnd() {
        return saEnd;
    }


    /**
     * Sets the saEnd value for this UserData.
     * 
     * @param saEnd
     */
    public void setSaEnd(java.lang.String saEnd) {
        this.saEnd = saEnd;
    }


    /**
     * Gets the saInterval value for this UserData.
     * 
     * @return saInterval
     */
    public java.lang.String getSaInterval() {
        return saInterval;
    }


    /**
     * Sets the saInterval value for this UserData.
     * 
     * @param saInterval
     */
    public void setSaInterval(java.lang.String saInterval) {
        this.saInterval = saInterval;
    }


    /**
     * Gets the secondName value for this UserData.
     * 
     * @return secondName
     */
    public java.lang.String getSecondName() {
        return secondName;
    }


    /**
     * Sets the secondName value for this UserData.
     * 
     * @param secondName
     */
    public void setSecondName(java.lang.String secondName) {
        this.secondName = secondName;
    }


    /**
     * Gets the securid value for this UserData.
     * 
     * @return securid
     */
    public java.lang.String getSecurid() {
        return securid;
    }


    /**
     * Sets the securid value for this UserData.
     * 
     * @param securid
     */
    public void setSecurid(java.lang.String securid) {
        this.securid = securid;
    }


    /**
     * Gets the status value for this UserData.
     * 
     * @return status
     */
    public java.lang.Integer getStatus() {
        return status;
    }


    /**
     * Sets the status value for this UserData.
     * 
     * @param status
     */
    public void setStatus(java.lang.Integer status) {
        this.status = status;
    }


    /**
     * Gets the suBegin value for this UserData.
     * 
     * @return suBegin
     */
    public java.lang.String getSuBegin() {
        return suBegin;
    }


    /**
     * Sets the suBegin value for this UserData.
     * 
     * @param suBegin
     */
    public void setSuBegin(java.lang.String suBegin) {
        this.suBegin = suBegin;
    }


    /**
     * Gets the suEnd value for this UserData.
     * 
     * @return suEnd
     */
    public java.lang.String getSuEnd() {
        return suEnd;
    }


    /**
     * Sets the suEnd value for this UserData.
     * 
     * @param suEnd
     */
    public void setSuEnd(java.lang.String suEnd) {
        this.suEnd = suEnd;
    }


    /**
     * Gets the suInterval value for this UserData.
     * 
     * @return suInterval
     */
    public java.lang.String getSuInterval() {
        return suInterval;
    }


    /**
     * Sets the suInterval value for this UserData.
     * 
     * @param suInterval
     */
    public void setSuInterval(java.lang.String suInterval) {
        this.suInterval = suInterval;
    }


    /**
     * Gets the surname value for this UserData.
     * 
     * @return surname
     */
    public java.lang.String getSurname() {
        return surname;
    }


    /**
     * Sets the surname value for this UserData.
     * 
     * @param surname
     */
    public void setSurname(java.lang.String surname) {
        this.surname = surname;
    }


    /**
     * Gets the thBegin value for this UserData.
     * 
     * @return thBegin
     */
    public java.lang.String getThBegin() {
        return thBegin;
    }


    /**
     * Sets the thBegin value for this UserData.
     * 
     * @param thBegin
     */
    public void setThBegin(java.lang.String thBegin) {
        this.thBegin = thBegin;
    }


    /**
     * Gets the thEnd value for this UserData.
     * 
     * @return thEnd
     */
    public java.lang.String getThEnd() {
        return thEnd;
    }


    /**
     * Sets the thEnd value for this UserData.
     * 
     * @param thEnd
     */
    public void setThEnd(java.lang.String thEnd) {
        this.thEnd = thEnd;
    }


    /**
     * Gets the thInterval value for this UserData.
     * 
     * @return thInterval
     */
    public java.lang.String getThInterval() {
        return thInterval;
    }


    /**
     * Sets the thInterval value for this UserData.
     * 
     * @param thInterval
     */
    public void setThInterval(java.lang.String thInterval) {
        this.thInterval = thInterval;
    }


    /**
     * Gets the trustLevelId value for this UserData.
     * 
     * @return trustLevelId
     */
    public java.lang.Integer getTrustLevelId() {
        return trustLevelId;
    }


    /**
     * Sets the trustLevelId value for this UserData.
     * 
     * @param trustLevelId
     */
    public void setTrustLevelId(java.lang.Integer trustLevelId) {
        this.trustLevelId = trustLevelId;
    }


    /**
     * Gets the tuBegin value for this UserData.
     * 
     * @return tuBegin
     */
    public java.lang.String getTuBegin() {
        return tuBegin;
    }


    /**
     * Sets the tuBegin value for this UserData.
     * 
     * @param tuBegin
     */
    public void setTuBegin(java.lang.String tuBegin) {
        this.tuBegin = tuBegin;
    }


    /**
     * Gets the tuEnd value for this UserData.
     * 
     * @return tuEnd
     */
    public java.lang.String getTuEnd() {
        return tuEnd;
    }


    /**
     * Sets the tuEnd value for this UserData.
     * 
     * @param tuEnd
     */
    public void setTuEnd(java.lang.String tuEnd) {
        this.tuEnd = tuEnd;
    }


    /**
     * Gets the tuInterval value for this UserData.
     * 
     * @return tuInterval
     */
    public java.lang.String getTuInterval() {
        return tuInterval;
    }


    /**
     * Sets the tuInterval value for this UserData.
     * 
     * @param tuInterval
     */
    public void setTuInterval(java.lang.String tuInterval) {
        this.tuInterval = tuInterval;
    }


    /**
     * Gets the userCertificate value for this UserData.
     * 
     * @return userCertificate
     */
    public java.lang.String getUserCertificate() {
        return userCertificate;
    }


    /**
     * Sets the userCertificate value for this UserData.
     * 
     * @param userCertificate
     */
    public void setUserCertificate(java.lang.String userCertificate) {
        this.userCertificate = userCertificate;
    }


    /**
     * Gets the userDomainID value for this UserData.
     * 
     * @return userDomainID
     */
    public java.lang.Integer getUserDomainID() {
        return userDomainID;
    }


    /**
     * Sets the userDomainID value for this UserData.
     * 
     * @param userDomainID
     */
    public void setUserDomainID(java.lang.Integer userDomainID) {
        this.userDomainID = userDomainID;
    }


    /**
     * Gets the weBegin value for this UserData.
     * 
     * @return weBegin
     */
    public java.lang.String getWeBegin() {
        return weBegin;
    }


    /**
     * Sets the weBegin value for this UserData.
     * 
     * @param weBegin
     */
    public void setWeBegin(java.lang.String weBegin) {
        this.weBegin = weBegin;
    }


    /**
     * Gets the weEnd value for this UserData.
     * 
     * @return weEnd
     */
    public java.lang.String getWeEnd() {
        return weEnd;
    }


    /**
     * Sets the weEnd value for this UserData.
     * 
     * @param weEnd
     */
    public void setWeEnd(java.lang.String weEnd) {
        this.weEnd = weEnd;
    }


    /**
     * Gets the weInterval value for this UserData.
     * 
     * @return weInterval
     */
    public java.lang.String getWeInterval() {
        return weInterval;
    }


    /**
     * Sets the weInterval value for this UserData.
     * 
     * @param weInterval
     */
    public void setWeInterval(java.lang.String weInterval) {
        this.weInterval = weInterval;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof UserData)) return false;
        UserData other = (UserData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.authMethods==null && other.getAuthMethods()==null) || 
             (this.authMethods!=null &&
              this.authMethods.equals(other.getAuthMethods()))) &&
            ((this.certDigest==null && other.getCertDigest()==null) || 
             (this.certDigest!=null &&
              this.certDigest.equals(other.getCertDigest()))) &&
            ((this.creationDate==null && other.getCreationDate()==null) || 
             (this.creationDate!=null &&
              this.creationDate.equals(other.getCreationDate()))) &&
            ((this.deactivationDate==null && other.getDeactivationDate()==null) || 
             (this.deactivationDate!=null &&
              this.deactivationDate.equals(other.getDeactivationDate()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.dn==null && other.getDn()==null) || 
             (this.dn!=null &&
              this.dn.equals(other.getDn()))) &&
            ((this.domain==null && other.getDomain()==null) || 
             (this.domain!=null &&
              this.domain.equals(other.getDomain()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.failedLoginCount==null && other.getFailedLoginCount()==null) || 
             (this.failedLoginCount!=null &&
              this.failedLoginCount.equals(other.getFailedLoginCount()))) &&
            ((this.frBegin==null && other.getFrBegin()==null) || 
             (this.frBegin!=null &&
              this.frBegin.equals(other.getFrBegin()))) &&
            ((this.frEnd==null && other.getFrEnd()==null) || 
             (this.frEnd!=null &&
              this.frEnd.equals(other.getFrEnd()))) &&
            ((this.frInterval==null && other.getFrInterval()==null) || 
             (this.frInterval!=null &&
              this.frInterval.equals(other.getFrInterval()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.isAdmin==null && other.getIsAdmin()==null) || 
             (this.isAdmin!=null &&
              this.isAdmin.equals(other.getIsAdmin()))) &&
            ((this.isGodAdmin==null && other.getIsGodAdmin()==null) || 
             (this.isGodAdmin!=null &&
              this.isGodAdmin.equals(other.getIsGodAdmin()))) &&
            ((this.isLdapUser==null && other.getIsLdapUser()==null) || 
             (this.isLdapUser!=null &&
              this.isLdapUser.equals(other.getIsLdapUser()))) &&
            ((this.isSystem==null && other.getIsSystem()==null) || 
             (this.isSystem!=null &&
              this.isSystem.equals(other.getIsSystem()))) &&
            ((this.lastFailedLogin==null && other.getLastFailedLogin()==null) || 
             (this.lastFailedLogin!=null &&
              this.lastFailedLogin.equals(other.getLastFailedLogin()))) &&
            ((this.lastPassExpNotification==null && other.getLastPassExpNotification()==null) || 
             (this.lastPassExpNotification!=null &&
              this.lastPassExpNotification.equals(other.getLastPassExpNotification()))) &&
            ((this.moBegin==null && other.getMoBegin()==null) || 
             (this.moBegin!=null &&
              this.moBegin.equals(other.getMoBegin()))) &&
            ((this.moEnd==null && other.getMoEnd()==null) || 
             (this.moEnd!=null &&
              this.moEnd.equals(other.getMoEnd()))) &&
            ((this.moInterval==null && other.getMoInterval()==null) || 
             (this.moInterval!=null &&
              this.moInterval.equals(other.getMoInterval()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.orgID==null && other.getOrgID()==null) || 
             (this.orgID!=null &&
              this.orgID.equals(other.getOrgID()))) &&
            ((this.passExpirationDate==null && other.getPassExpirationDate()==null) || 
             (this.passExpirationDate!=null &&
              this.passExpirationDate.equals(other.getPassExpirationDate()))) &&
            ((this.passSequenceNr==null && other.getPassSequenceNr()==null) || 
             (this.passSequenceNr!=null &&
              this.passSequenceNr.equals(other.getPassSequenceNr()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.passwordSetDate==null && other.getPasswordSetDate()==null) || 
             (this.passwordSetDate!=null &&
              this.passwordSetDate.equals(other.getPasswordSetDate()))) &&
            ((this.primaryKey==null && other.getPrimaryKey()==null) || 
             (this.primaryKey!=null &&
              this.primaryKey.equals(other.getPrimaryKey()))) &&
            ((this.protectorId==null && other.getProtectorId()==null) || 
             (this.protectorId!=null &&
              this.protectorId.equals(other.getProtectorId()))) &&
            ((this.saBegin==null && other.getSaBegin()==null) || 
             (this.saBegin!=null &&
              this.saBegin.equals(other.getSaBegin()))) &&
            ((this.saEnd==null && other.getSaEnd()==null) || 
             (this.saEnd!=null &&
              this.saEnd.equals(other.getSaEnd()))) &&
            ((this.saInterval==null && other.getSaInterval()==null) || 
             (this.saInterval!=null &&
              this.saInterval.equals(other.getSaInterval()))) &&
            ((this.secondName==null && other.getSecondName()==null) || 
             (this.secondName!=null &&
              this.secondName.equals(other.getSecondName()))) &&
            ((this.securid==null && other.getSecurid()==null) || 
             (this.securid!=null &&
              this.securid.equals(other.getSecurid()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.suBegin==null && other.getSuBegin()==null) || 
             (this.suBegin!=null &&
              this.suBegin.equals(other.getSuBegin()))) &&
            ((this.suEnd==null && other.getSuEnd()==null) || 
             (this.suEnd!=null &&
              this.suEnd.equals(other.getSuEnd()))) &&
            ((this.suInterval==null && other.getSuInterval()==null) || 
             (this.suInterval!=null &&
              this.suInterval.equals(other.getSuInterval()))) &&
            ((this.surname==null && other.getSurname()==null) || 
             (this.surname!=null &&
              this.surname.equals(other.getSurname()))) &&
            ((this.thBegin==null && other.getThBegin()==null) || 
             (this.thBegin!=null &&
              this.thBegin.equals(other.getThBegin()))) &&
            ((this.thEnd==null && other.getThEnd()==null) || 
             (this.thEnd!=null &&
              this.thEnd.equals(other.getThEnd()))) &&
            ((this.thInterval==null && other.getThInterval()==null) || 
             (this.thInterval!=null &&
              this.thInterval.equals(other.getThInterval()))) &&
            ((this.trustLevelId==null && other.getTrustLevelId()==null) || 
             (this.trustLevelId!=null &&
              this.trustLevelId.equals(other.getTrustLevelId()))) &&
            ((this.tuBegin==null && other.getTuBegin()==null) || 
             (this.tuBegin!=null &&
              this.tuBegin.equals(other.getTuBegin()))) &&
            ((this.tuEnd==null && other.getTuEnd()==null) || 
             (this.tuEnd!=null &&
              this.tuEnd.equals(other.getTuEnd()))) &&
            ((this.tuInterval==null && other.getTuInterval()==null) || 
             (this.tuInterval!=null &&
              this.tuInterval.equals(other.getTuInterval()))) &&
            ((this.userCertificate==null && other.getUserCertificate()==null) || 
             (this.userCertificate!=null &&
              this.userCertificate.equals(other.getUserCertificate()))) &&
            ((this.userDomainID==null && other.getUserDomainID()==null) || 
             (this.userDomainID!=null &&
              this.userDomainID.equals(other.getUserDomainID()))) &&
            ((this.weBegin==null && other.getWeBegin()==null) || 
             (this.weBegin!=null &&
              this.weBegin.equals(other.getWeBegin()))) &&
            ((this.weEnd==null && other.getWeEnd()==null) || 
             (this.weEnd!=null &&
              this.weEnd.equals(other.getWeEnd()))) &&
            ((this.weInterval==null && other.getWeInterval()==null) || 
             (this.weInterval!=null &&
              this.weInterval.equals(other.getWeInterval())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuthMethods() != null) {
            _hashCode += getAuthMethods().hashCode();
        }
        if (getCertDigest() != null) {
            _hashCode += getCertDigest().hashCode();
        }
        if (getCreationDate() != null) {
            _hashCode += getCreationDate().hashCode();
        }
        if (getDeactivationDate() != null) {
            _hashCode += getDeactivationDate().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getDn() != null) {
            _hashCode += getDn().hashCode();
        }
        if (getDomain() != null) {
            _hashCode += getDomain().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getFailedLoginCount() != null) {
            _hashCode += getFailedLoginCount().hashCode();
        }
        if (getFrBegin() != null) {
            _hashCode += getFrBegin().hashCode();
        }
        if (getFrEnd() != null) {
            _hashCode += getFrEnd().hashCode();
        }
        if (getFrInterval() != null) {
            _hashCode += getFrInterval().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getIsAdmin() != null) {
            _hashCode += getIsAdmin().hashCode();
        }
        if (getIsGodAdmin() != null) {
            _hashCode += getIsGodAdmin().hashCode();
        }
        if (getIsLdapUser() != null) {
            _hashCode += getIsLdapUser().hashCode();
        }
        if (getIsSystem() != null) {
            _hashCode += getIsSystem().hashCode();
        }
        if (getLastFailedLogin() != null) {
            _hashCode += getLastFailedLogin().hashCode();
        }
        if (getLastPassExpNotification() != null) {
            _hashCode += getLastPassExpNotification().hashCode();
        }
        if (getMoBegin() != null) {
            _hashCode += getMoBegin().hashCode();
        }
        if (getMoEnd() != null) {
            _hashCode += getMoEnd().hashCode();
        }
        if (getMoInterval() != null) {
            _hashCode += getMoInterval().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getOrgID() != null) {
            _hashCode += getOrgID().hashCode();
        }
        if (getPassExpirationDate() != null) {
            _hashCode += getPassExpirationDate().hashCode();
        }
        if (getPassSequenceNr() != null) {
            _hashCode += getPassSequenceNr().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getPasswordSetDate() != null) {
            _hashCode += getPasswordSetDate().hashCode();
        }
        if (getPrimaryKey() != null) {
            _hashCode += getPrimaryKey().hashCode();
        }
        if (getProtectorId() != null) {
            _hashCode += getProtectorId().hashCode();
        }
        if (getSaBegin() != null) {
            _hashCode += getSaBegin().hashCode();
        }
        if (getSaEnd() != null) {
            _hashCode += getSaEnd().hashCode();
        }
        if (getSaInterval() != null) {
            _hashCode += getSaInterval().hashCode();
        }
        if (getSecondName() != null) {
            _hashCode += getSecondName().hashCode();
        }
        if (getSecurid() != null) {
            _hashCode += getSecurid().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getSuBegin() != null) {
            _hashCode += getSuBegin().hashCode();
        }
        if (getSuEnd() != null) {
            _hashCode += getSuEnd().hashCode();
        }
        if (getSuInterval() != null) {
            _hashCode += getSuInterval().hashCode();
        }
        if (getSurname() != null) {
            _hashCode += getSurname().hashCode();
        }
        if (getThBegin() != null) {
            _hashCode += getThBegin().hashCode();
        }
        if (getThEnd() != null) {
            _hashCode += getThEnd().hashCode();
        }
        if (getThInterval() != null) {
            _hashCode += getThInterval().hashCode();
        }
        if (getTrustLevelId() != null) {
            _hashCode += getTrustLevelId().hashCode();
        }
        if (getTuBegin() != null) {
            _hashCode += getTuBegin().hashCode();
        }
        if (getTuEnd() != null) {
            _hashCode += getTuEnd().hashCode();
        }
        if (getTuInterval() != null) {
            _hashCode += getTuInterval().hashCode();
        }
        if (getUserCertificate() != null) {
            _hashCode += getUserCertificate().hashCode();
        }
        if (getUserDomainID() != null) {
            _hashCode += getUserDomainID().hashCode();
        }
        if (getWeBegin() != null) {
            _hashCode += getWeBegin().hashCode();
        }
        if (getWeEnd() != null) {
            _hashCode += getWeEnd().hashCode();
        }
        if (getWeInterval() != null) {
            _hashCode += getWeInterval().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(UserData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://cmp.ejb.console.ls.protector.security.comarch", "UserData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authMethods");
        elemField.setXmlName(new javax.xml.namespace.QName("", "authMethods"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certDigest");
        elemField.setXmlName(new javax.xml.namespace.QName("", "certDigest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "creationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deactivationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "deactivationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domain");
        elemField.setXmlName(new javax.xml.namespace.QName("", "domain"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("failedLoginCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "failedLoginCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "frBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "frEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "frInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isAdmin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isAdmin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isGodAdmin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isGodAdmin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isLdapUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isLdapUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isSystem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isSystem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastFailedLogin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lastFailedLogin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastPassExpNotification");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lastPassExpNotification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orgID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orgID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passExpirationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "passExpirationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passSequenceNr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "passSequenceNr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passwordSetDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "passwordSetDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("", "primaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protectorId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "protectorId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "saBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "saEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "saInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("secondName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "secondName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("securid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "securid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "suInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("surname");
        elemField.setXmlName(new javax.xml.namespace.QName("", "surname"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "thBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "thEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "thInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trustLevelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "trustLevelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tuBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tuBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tuEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tuEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tuInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tuInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userCertificate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userCertificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userDomainID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userDomainID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("weBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "weBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("weEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "weEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("weInterval");
        elemField.setXmlName(new javax.xml.namespace.QName("", "weInterval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
