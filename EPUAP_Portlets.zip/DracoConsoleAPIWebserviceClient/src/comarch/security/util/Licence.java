/**
 * Licence.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.util;

public class Licence  implements java.io.Serializable {
    private java.lang.String auth;

    private java.lang.Object[] authArray;

    private java.lang.String cnoSup;

    private java.lang.String db;

    private java.lang.String domainSup;

    private java.lang.String ldap;

    private java.lang.String licBegin;

    private java.lang.String licEnd;

    private java.lang.String licTO;

    private java.lang.String licTo;

    private java.lang.String maxApps;

    private java.lang.String maxUsers;

    private java.lang.String modules;

    private java.lang.Object[] modulesArray;

    public Licence() {
    }

    public Licence(
           java.lang.String auth,
           java.lang.Object[] authArray,
           java.lang.String cnoSup,
           java.lang.String db,
           java.lang.String domainSup,
           java.lang.String ldap,
           java.lang.String licBegin,
           java.lang.String licEnd,
           java.lang.String licTO,
           java.lang.String licTo,
           java.lang.String maxApps,
           java.lang.String maxUsers,
           java.lang.String modules,
           java.lang.Object[] modulesArray) {
           this.auth = auth;
           this.authArray = authArray;
           this.cnoSup = cnoSup;
           this.db = db;
           this.domainSup = domainSup;
           this.ldap = ldap;
           this.licBegin = licBegin;
           this.licEnd = licEnd;
           this.licTO = licTO;
           this.licTo = licTo;
           this.maxApps = maxApps;
           this.maxUsers = maxUsers;
           this.modules = modules;
           this.modulesArray = modulesArray;
    }


    /**
     * Gets the auth value for this Licence.
     * 
     * @return auth
     */
    public java.lang.String getAuth() {
        return auth;
    }


    /**
     * Sets the auth value for this Licence.
     * 
     * @param auth
     */
    public void setAuth(java.lang.String auth) {
        this.auth = auth;
    }


    /**
     * Gets the authArray value for this Licence.
     * 
     * @return authArray
     */
    public java.lang.Object[] getAuthArray() {
        return authArray;
    }


    /**
     * Sets the authArray value for this Licence.
     * 
     * @param authArray
     */
    public void setAuthArray(java.lang.Object[] authArray) {
        this.authArray = authArray;
    }


    /**
     * Gets the cnoSup value for this Licence.
     * 
     * @return cnoSup
     */
    public java.lang.String getCnoSup() {
        return cnoSup;
    }


    /**
     * Sets the cnoSup value for this Licence.
     * 
     * @param cnoSup
     */
    public void setCnoSup(java.lang.String cnoSup) {
        this.cnoSup = cnoSup;
    }


    /**
     * Gets the db value for this Licence.
     * 
     * @return db
     */
    public java.lang.String getDb() {
        return db;
    }


    /**
     * Sets the db value for this Licence.
     * 
     * @param db
     */
    public void setDb(java.lang.String db) {
        this.db = db;
    }


    /**
     * Gets the domainSup value for this Licence.
     * 
     * @return domainSup
     */
    public java.lang.String getDomainSup() {
        return domainSup;
    }


    /**
     * Sets the domainSup value for this Licence.
     * 
     * @param domainSup
     */
    public void setDomainSup(java.lang.String domainSup) {
        this.domainSup = domainSup;
    }


    /**
     * Gets the ldap value for this Licence.
     * 
     * @return ldap
     */
    public java.lang.String getLdap() {
        return ldap;
    }


    /**
     * Sets the ldap value for this Licence.
     * 
     * @param ldap
     */
    public void setLdap(java.lang.String ldap) {
        this.ldap = ldap;
    }


    /**
     * Gets the licBegin value for this Licence.
     * 
     * @return licBegin
     */
    public java.lang.String getLicBegin() {
        return licBegin;
    }


    /**
     * Sets the licBegin value for this Licence.
     * 
     * @param licBegin
     */
    public void setLicBegin(java.lang.String licBegin) {
        this.licBegin = licBegin;
    }


    /**
     * Gets the licEnd value for this Licence.
     * 
     * @return licEnd
     */
    public java.lang.String getLicEnd() {
        return licEnd;
    }


    /**
     * Sets the licEnd value for this Licence.
     * 
     * @param licEnd
     */
    public void setLicEnd(java.lang.String licEnd) {
        this.licEnd = licEnd;
    }


    /**
     * Gets the licTO value for this Licence.
     * 
     * @return licTO
     */
    public java.lang.String getLicTO() {
        return licTO;
    }


    /**
     * Sets the licTO value for this Licence.
     * 
     * @param licTO
     */
    public void setLicTO(java.lang.String licTO) {
        this.licTO = licTO;
    }


    /**
     * Gets the licTo value for this Licence.
     * 
     * @return licTo
     */
    public java.lang.String getLicTo() {
        return licTo;
    }


    /**
     * Sets the licTo value for this Licence.
     * 
     * @param licTo
     */
    public void setLicTo(java.lang.String licTo) {
        this.licTo = licTo;
    }


    /**
     * Gets the maxApps value for this Licence.
     * 
     * @return maxApps
     */
    public java.lang.String getMaxApps() {
        return maxApps;
    }


    /**
     * Sets the maxApps value for this Licence.
     * 
     * @param maxApps
     */
    public void setMaxApps(java.lang.String maxApps) {
        this.maxApps = maxApps;
    }


    /**
     * Gets the maxUsers value for this Licence.
     * 
     * @return maxUsers
     */
    public java.lang.String getMaxUsers() {
        return maxUsers;
    }


    /**
     * Sets the maxUsers value for this Licence.
     * 
     * @param maxUsers
     */
    public void setMaxUsers(java.lang.String maxUsers) {
        this.maxUsers = maxUsers;
    }


    /**
     * Gets the modules value for this Licence.
     * 
     * @return modules
     */
    public java.lang.String getModules() {
        return modules;
    }


    /**
     * Sets the modules value for this Licence.
     * 
     * @param modules
     */
    public void setModules(java.lang.String modules) {
        this.modules = modules;
    }


    /**
     * Gets the modulesArray value for this Licence.
     * 
     * @return modulesArray
     */
    public java.lang.Object[] getModulesArray() {
        return modulesArray;
    }


    /**
     * Sets the modulesArray value for this Licence.
     * 
     * @param modulesArray
     */
    public void setModulesArray(java.lang.Object[] modulesArray) {
        this.modulesArray = modulesArray;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Licence)) return false;
        Licence other = (Licence) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.auth==null && other.getAuth()==null) || 
             (this.auth!=null &&
              this.auth.equals(other.getAuth()))) &&
            ((this.authArray==null && other.getAuthArray()==null) || 
             (this.authArray!=null &&
              java.util.Arrays.equals(this.authArray, other.getAuthArray()))) &&
            ((this.cnoSup==null && other.getCnoSup()==null) || 
             (this.cnoSup!=null &&
              this.cnoSup.equals(other.getCnoSup()))) &&
            ((this.db==null && other.getDb()==null) || 
             (this.db!=null &&
              this.db.equals(other.getDb()))) &&
            ((this.domainSup==null && other.getDomainSup()==null) || 
             (this.domainSup!=null &&
              this.domainSup.equals(other.getDomainSup()))) &&
            ((this.ldap==null && other.getLdap()==null) || 
             (this.ldap!=null &&
              this.ldap.equals(other.getLdap()))) &&
            ((this.licBegin==null && other.getLicBegin()==null) || 
             (this.licBegin!=null &&
              this.licBegin.equals(other.getLicBegin()))) &&
            ((this.licEnd==null && other.getLicEnd()==null) || 
             (this.licEnd!=null &&
              this.licEnd.equals(other.getLicEnd()))) &&
            ((this.licTO==null && other.getLicTO()==null) || 
             (this.licTO!=null &&
              this.licTO.equals(other.getLicTO()))) &&
            ((this.licTo==null && other.getLicTo()==null) || 
             (this.licTo!=null &&
              this.licTo.equals(other.getLicTo()))) &&
            ((this.maxApps==null && other.getMaxApps()==null) || 
             (this.maxApps!=null &&
              this.maxApps.equals(other.getMaxApps()))) &&
            ((this.maxUsers==null && other.getMaxUsers()==null) || 
             (this.maxUsers!=null &&
              this.maxUsers.equals(other.getMaxUsers()))) &&
            ((this.modules==null && other.getModules()==null) || 
             (this.modules!=null &&
              this.modules.equals(other.getModules()))) &&
            ((this.modulesArray==null && other.getModulesArray()==null) || 
             (this.modulesArray!=null &&
              java.util.Arrays.equals(this.modulesArray, other.getModulesArray())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuth() != null) {
            _hashCode += getAuth().hashCode();
        }
        if (getAuthArray() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthArray());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthArray(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCnoSup() != null) {
            _hashCode += getCnoSup().hashCode();
        }
        if (getDb() != null) {
            _hashCode += getDb().hashCode();
        }
        if (getDomainSup() != null) {
            _hashCode += getDomainSup().hashCode();
        }
        if (getLdap() != null) {
            _hashCode += getLdap().hashCode();
        }
        if (getLicBegin() != null) {
            _hashCode += getLicBegin().hashCode();
        }
        if (getLicEnd() != null) {
            _hashCode += getLicEnd().hashCode();
        }
        if (getLicTO() != null) {
            _hashCode += getLicTO().hashCode();
        }
        if (getLicTo() != null) {
            _hashCode += getLicTo().hashCode();
        }
        if (getMaxApps() != null) {
            _hashCode += getMaxApps().hashCode();
        }
        if (getMaxUsers() != null) {
            _hashCode += getMaxUsers().hashCode();
        }
        if (getModules() != null) {
            _hashCode += getModules().hashCode();
        }
        if (getModulesArray() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getModulesArray());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getModulesArray(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Licence.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://util.security.comarch", "Licence"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("auth");
        elemField.setXmlName(new javax.xml.namespace.QName("", "auth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authArray");
        elemField.setXmlName(new javax.xml.namespace.QName("", "authArray"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cnoSup");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cnoSup"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("db");
        elemField.setXmlName(new javax.xml.namespace.QName("", "db"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainSup");
        elemField.setXmlName(new javax.xml.namespace.QName("", "domainSup"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ldap");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ldap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licBegin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "licBegin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licEnd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "licEnd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licTO");
        elemField.setXmlName(new javax.xml.namespace.QName("", "licTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licTo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "licTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxApps");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxApps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxUsers");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxUsers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modules");
        elemField.setXmlName(new javax.xml.namespace.QName("", "modules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modulesArray");
        elemField.setXmlName(new javax.xml.namespace.QName("", "modulesArray"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
