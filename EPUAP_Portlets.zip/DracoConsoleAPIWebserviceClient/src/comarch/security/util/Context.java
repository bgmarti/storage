/**
 * Context.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package comarch.security.util;

public class Context  implements java.io.Serializable {
    private java.lang.Object[] cnosList;

    private boolean god;

    private java.lang.Object[] org;

    public Context() {
    }

    public Context(
           java.lang.Object[] cnosList,
           boolean god,
           java.lang.Object[] org) {
           this.cnosList = cnosList;
           this.god = god;
           this.org = org;
    }


    /**
     * Gets the cnosList value for this Context.
     * 
     * @return cnosList
     */
    public java.lang.Object[] getCnosList() {
        return cnosList;
    }


    /**
     * Sets the cnosList value for this Context.
     * 
     * @param cnosList
     */
    public void setCnosList(java.lang.Object[] cnosList) {
        this.cnosList = cnosList;
    }


    /**
     * Gets the god value for this Context.
     * 
     * @return god
     */
    public boolean isGod() {
        return god;
    }


    /**
     * Sets the god value for this Context.
     * 
     * @param god
     */
    public void setGod(boolean god) {
        this.god = god;
    }


    /**
     * Gets the org value for this Context.
     * 
     * @return org
     */
    public java.lang.Object[] getOrg() {
        return org;
    }


    /**
     * Sets the org value for this Context.
     * 
     * @param org
     */
    public void setOrg(java.lang.Object[] org) {
        this.org = org;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Context)) return false;
        Context other = (Context) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cnosList==null && other.getCnosList()==null) || 
             (this.cnosList!=null &&
              java.util.Arrays.equals(this.cnosList, other.getCnosList()))) &&
            this.god == other.isGod() &&
            ((this.org==null && other.getOrg()==null) || 
             (this.org!=null &&
              java.util.Arrays.equals(this.org, other.getOrg())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCnosList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCnosList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCnosList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isGod() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getOrg() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrg());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrg(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Context.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://util.security.comarch", "Context"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cnosList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cnosList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("god");
        elemField.setXmlName(new javax.xml.namespace.QName("", "god"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
