/**
 * Sopel2ServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.comarch.security.sopel.ws;

public interface Sopel2ServicePortType extends java.rmi.Remote {
    public com.comarch.security.sopel.ws.xsd.ExtendResult extendToXadesA(byte[] signature) throws java.rmi.RemoteException;
    public com.comarch.security.sopel.ws.xsd.ExtendResult extendToXadesT(byte[] signature) throws java.rmi.RemoteException;
    public com.comarch.security.sopel.ws.xsd.VerifyResult verifyXadesAndExtend(byte[] signature, com.comarch.security.sopel.ws.xsd.FileData[] attachments, com.comarch.security.sopel.ws.xsd.FileData[] schemas, java.lang.Integer operation) throws java.rmi.RemoteException;
}
