/**
 * TimeStampInfoStruct.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.comarch.security.sopel.ws.xsd;

public class TimeStampInfoStruct  implements java.io.Serializable {
    private java.lang.String timeStampTime;

    private java.lang.Integer verifyStatus;

    public TimeStampInfoStruct() {
    }

    public TimeStampInfoStruct(
           java.lang.String timeStampTime,
           java.lang.Integer verifyStatus) {
           this.timeStampTime = timeStampTime;
           this.verifyStatus = verifyStatus;
    }


    /**
     * Gets the timeStampTime value for this TimeStampInfoStruct.
     * 
     * @return timeStampTime
     */
    public java.lang.String getTimeStampTime() {
        return timeStampTime;
    }


    /**
     * Sets the timeStampTime value for this TimeStampInfoStruct.
     * 
     * @param timeStampTime
     */
    public void setTimeStampTime(java.lang.String timeStampTime) {
        this.timeStampTime = timeStampTime;
    }


    /**
     * Gets the verifyStatus value for this TimeStampInfoStruct.
     * 
     * @return verifyStatus
     */
    public java.lang.Integer getVerifyStatus() {
        return verifyStatus;
    }


    /**
     * Sets the verifyStatus value for this TimeStampInfoStruct.
     * 
     * @param verifyStatus
     */
    public void setVerifyStatus(java.lang.Integer verifyStatus) {
        this.verifyStatus = verifyStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TimeStampInfoStruct)) return false;
        TimeStampInfoStruct other = (TimeStampInfoStruct) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.timeStampTime==null && other.getTimeStampTime()==null) || 
             (this.timeStampTime!=null &&
              this.timeStampTime.equals(other.getTimeStampTime()))) &&
            ((this.verifyStatus==null && other.getVerifyStatus()==null) || 
             (this.verifyStatus!=null &&
              this.verifyStatus.equals(other.getVerifyStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTimeStampTime() != null) {
            _hashCode += getTimeStampTime().hashCode();
        }
        if (getVerifyStatus() != null) {
            _hashCode += getVerifyStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TimeStampInfoStruct.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "TimeStampInfoStruct"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeStampTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "timeStampTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifyStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "verifyStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
