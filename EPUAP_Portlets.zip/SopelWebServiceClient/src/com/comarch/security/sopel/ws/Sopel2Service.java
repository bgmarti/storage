/**
 * Sopel2Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.comarch.security.sopel.ws;

public interface Sopel2Service extends javax.xml.rpc.Service {
    public java.lang.String getSopel2ServiceSOAP12port_httpAddress();

    public com.comarch.security.sopel.ws.Sopel2ServicePortType getSopel2ServiceSOAP12port_http() throws javax.xml.rpc.ServiceException;

    public com.comarch.security.sopel.ws.Sopel2ServicePortType getSopel2ServiceSOAP12port_http(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getSopel2ServiceSOAP11port_httpAddress();

    public com.comarch.security.sopel.ws.Sopel2ServicePortType getSopel2ServiceSOAP11port_http() throws javax.xml.rpc.ServiceException;

    public com.comarch.security.sopel.ws.Sopel2ServicePortType getSopel2ServiceSOAP11port_http(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
