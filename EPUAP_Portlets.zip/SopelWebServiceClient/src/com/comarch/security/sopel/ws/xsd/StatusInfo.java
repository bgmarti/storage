/**
 * StatusInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.comarch.security.sopel.ws.xsd;

public class StatusInfo  implements java.io.Serializable {
    private com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] archiveTimeStamp;

    private java.lang.String commitmentType;

    private java.lang.Integer gracePeriod;

    private java.lang.String parentSignatureId;

    private java.lang.String signatureCertIssuer;

    private java.lang.String signatureCertSerial;

    private java.lang.String signatureId;

    private com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] signatureTimeStamp;

    private java.lang.String signingTime;

    private java.lang.String[] uriIDs;

    private java.lang.Integer verifySignerCert;

    private java.lang.String verifySignerCertUsage;

    private java.lang.Integer verifyStatus;

    public StatusInfo() {
    }

    public StatusInfo(
           com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] archiveTimeStamp,
           java.lang.String commitmentType,
           java.lang.Integer gracePeriod,
           java.lang.String parentSignatureId,
           java.lang.String signatureCertIssuer,
           java.lang.String signatureCertSerial,
           java.lang.String signatureId,
           com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] signatureTimeStamp,
           java.lang.String signingTime,
           java.lang.String[] uriIDs,
           java.lang.Integer verifySignerCert,
           java.lang.String verifySignerCertUsage,
           java.lang.Integer verifyStatus) {
           this.archiveTimeStamp = archiveTimeStamp;
           this.commitmentType = commitmentType;
           this.gracePeriod = gracePeriod;
           this.parentSignatureId = parentSignatureId;
           this.signatureCertIssuer = signatureCertIssuer;
           this.signatureCertSerial = signatureCertSerial;
           this.signatureId = signatureId;
           this.signatureTimeStamp = signatureTimeStamp;
           this.signingTime = signingTime;
           this.uriIDs = uriIDs;
           this.verifySignerCert = verifySignerCert;
           this.verifySignerCertUsage = verifySignerCertUsage;
           this.verifyStatus = verifyStatus;
    }


    /**
     * Gets the archiveTimeStamp value for this StatusInfo.
     * 
     * @return archiveTimeStamp
     */
    public com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] getArchiveTimeStamp() {
        return archiveTimeStamp;
    }


    /**
     * Sets the archiveTimeStamp value for this StatusInfo.
     * 
     * @param archiveTimeStamp
     */
    public void setArchiveTimeStamp(com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] archiveTimeStamp) {
        this.archiveTimeStamp = archiveTimeStamp;
    }

    public com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct getArchiveTimeStamp(int i) {
        return this.archiveTimeStamp[i];
    }

    public void setArchiveTimeStamp(int i, com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct _value) {
        this.archiveTimeStamp[i] = _value;
    }


    /**
     * Gets the commitmentType value for this StatusInfo.
     * 
     * @return commitmentType
     */
    public java.lang.String getCommitmentType() {
        return commitmentType;
    }


    /**
     * Sets the commitmentType value for this StatusInfo.
     * 
     * @param commitmentType
     */
    public void setCommitmentType(java.lang.String commitmentType) {
        this.commitmentType = commitmentType;
    }


    /**
     * Gets the gracePeriod value for this StatusInfo.
     * 
     * @return gracePeriod
     */
    public java.lang.Integer getGracePeriod() {
        return gracePeriod;
    }


    /**
     * Sets the gracePeriod value for this StatusInfo.
     * 
     * @param gracePeriod
     */
    public void setGracePeriod(java.lang.Integer gracePeriod) {
        this.gracePeriod = gracePeriod;
    }


    /**
     * Gets the parentSignatureId value for this StatusInfo.
     * 
     * @return parentSignatureId
     */
    public java.lang.String getParentSignatureId() {
        return parentSignatureId;
    }


    /**
     * Sets the parentSignatureId value for this StatusInfo.
     * 
     * @param parentSignatureId
     */
    public void setParentSignatureId(java.lang.String parentSignatureId) {
        this.parentSignatureId = parentSignatureId;
    }


    /**
     * Gets the signatureCertIssuer value for this StatusInfo.
     * 
     * @return signatureCertIssuer
     */
    public java.lang.String getSignatureCertIssuer() {
        return signatureCertIssuer;
    }


    /**
     * Sets the signatureCertIssuer value for this StatusInfo.
     * 
     * @param signatureCertIssuer
     */
    public void setSignatureCertIssuer(java.lang.String signatureCertIssuer) {
        this.signatureCertIssuer = signatureCertIssuer;
    }


    /**
     * Gets the signatureCertSerial value for this StatusInfo.
     * 
     * @return signatureCertSerial
     */
    public java.lang.String getSignatureCertSerial() {
        return signatureCertSerial;
    }


    /**
     * Sets the signatureCertSerial value for this StatusInfo.
     * 
     * @param signatureCertSerial
     */
    public void setSignatureCertSerial(java.lang.String signatureCertSerial) {
        this.signatureCertSerial = signatureCertSerial;
    }


    /**
     * Gets the signatureId value for this StatusInfo.
     * 
     * @return signatureId
     */
    public java.lang.String getSignatureId() {
        return signatureId;
    }


    /**
     * Sets the signatureId value for this StatusInfo.
     * 
     * @param signatureId
     */
    public void setSignatureId(java.lang.String signatureId) {
        this.signatureId = signatureId;
    }


    /**
     * Gets the signatureTimeStamp value for this StatusInfo.
     * 
     * @return signatureTimeStamp
     */
    public com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] getSignatureTimeStamp() {
        return signatureTimeStamp;
    }


    /**
     * Sets the signatureTimeStamp value for this StatusInfo.
     * 
     * @param signatureTimeStamp
     */
    public void setSignatureTimeStamp(com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct[] signatureTimeStamp) {
        this.signatureTimeStamp = signatureTimeStamp;
    }

    public com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct getSignatureTimeStamp(int i) {
        return this.signatureTimeStamp[i];
    }

    public void setSignatureTimeStamp(int i, com.comarch.security.sopel.ws.xsd.TimeStampInfoStruct _value) {
        this.signatureTimeStamp[i] = _value;
    }


    /**
     * Gets the signingTime value for this StatusInfo.
     * 
     * @return signingTime
     */
    public java.lang.String getSigningTime() {
        return signingTime;
    }


    /**
     * Sets the signingTime value for this StatusInfo.
     * 
     * @param signingTime
     */
    public void setSigningTime(java.lang.String signingTime) {
        this.signingTime = signingTime;
    }


    /**
     * Gets the uriIDs value for this StatusInfo.
     * 
     * @return uriIDs
     */
    public java.lang.String[] getUriIDs() {
        return uriIDs;
    }


    /**
     * Sets the uriIDs value for this StatusInfo.
     * 
     * @param uriIDs
     */
    public void setUriIDs(java.lang.String[] uriIDs) {
        this.uriIDs = uriIDs;
    }

    public java.lang.String getUriIDs(int i) {
        return this.uriIDs[i];
    }

    public void setUriIDs(int i, java.lang.String _value) {
        this.uriIDs[i] = _value;
    }


    /**
     * Gets the verifySignerCert value for this StatusInfo.
     * 
     * @return verifySignerCert
     */
    public java.lang.Integer getVerifySignerCert() {
        return verifySignerCert;
    }


    /**
     * Sets the verifySignerCert value for this StatusInfo.
     * 
     * @param verifySignerCert
     */
    public void setVerifySignerCert(java.lang.Integer verifySignerCert) {
        this.verifySignerCert = verifySignerCert;
    }


    /**
     * Gets the verifySignerCertUsage value for this StatusInfo.
     * 
     * @return verifySignerCertUsage
     */
    public java.lang.String getVerifySignerCertUsage() {
        return verifySignerCertUsage;
    }


    /**
     * Sets the verifySignerCertUsage value for this StatusInfo.
     * 
     * @param verifySignerCertUsage
     */
    public void setVerifySignerCertUsage(java.lang.String verifySignerCertUsage) {
        this.verifySignerCertUsage = verifySignerCertUsage;
    }


    /**
     * Gets the verifyStatus value for this StatusInfo.
     * 
     * @return verifyStatus
     */
    public java.lang.Integer getVerifyStatus() {
        return verifyStatus;
    }


    /**
     * Sets the verifyStatus value for this StatusInfo.
     * 
     * @param verifyStatus
     */
    public void setVerifyStatus(java.lang.Integer verifyStatus) {
        this.verifyStatus = verifyStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof StatusInfo)) return false;
        StatusInfo other = (StatusInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.archiveTimeStamp==null && other.getArchiveTimeStamp()==null) || 
             (this.archiveTimeStamp!=null &&
              java.util.Arrays.equals(this.archiveTimeStamp, other.getArchiveTimeStamp()))) &&
            ((this.commitmentType==null && other.getCommitmentType()==null) || 
             (this.commitmentType!=null &&
              this.commitmentType.equals(other.getCommitmentType()))) &&
            ((this.gracePeriod==null && other.getGracePeriod()==null) || 
             (this.gracePeriod!=null &&
              this.gracePeriod.equals(other.getGracePeriod()))) &&
            ((this.parentSignatureId==null && other.getParentSignatureId()==null) || 
             (this.parentSignatureId!=null &&
              this.parentSignatureId.equals(other.getParentSignatureId()))) &&
            ((this.signatureCertIssuer==null && other.getSignatureCertIssuer()==null) || 
             (this.signatureCertIssuer!=null &&
              this.signatureCertIssuer.equals(other.getSignatureCertIssuer()))) &&
            ((this.signatureCertSerial==null && other.getSignatureCertSerial()==null) || 
             (this.signatureCertSerial!=null &&
              this.signatureCertSerial.equals(other.getSignatureCertSerial()))) &&
            ((this.signatureId==null && other.getSignatureId()==null) || 
             (this.signatureId!=null &&
              this.signatureId.equals(other.getSignatureId()))) &&
            ((this.signatureTimeStamp==null && other.getSignatureTimeStamp()==null) || 
             (this.signatureTimeStamp!=null &&
              java.util.Arrays.equals(this.signatureTimeStamp, other.getSignatureTimeStamp()))) &&
            ((this.signingTime==null && other.getSigningTime()==null) || 
             (this.signingTime!=null &&
              this.signingTime.equals(other.getSigningTime()))) &&
            ((this.uriIDs==null && other.getUriIDs()==null) || 
             (this.uriIDs!=null &&
              java.util.Arrays.equals(this.uriIDs, other.getUriIDs()))) &&
            ((this.verifySignerCert==null && other.getVerifySignerCert()==null) || 
             (this.verifySignerCert!=null &&
              this.verifySignerCert.equals(other.getVerifySignerCert()))) &&
            ((this.verifySignerCertUsage==null && other.getVerifySignerCertUsage()==null) || 
             (this.verifySignerCertUsage!=null &&
              this.verifySignerCertUsage.equals(other.getVerifySignerCertUsage()))) &&
            ((this.verifyStatus==null && other.getVerifyStatus()==null) || 
             (this.verifyStatus!=null &&
              this.verifyStatus.equals(other.getVerifyStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArchiveTimeStamp() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getArchiveTimeStamp());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getArchiveTimeStamp(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCommitmentType() != null) {
            _hashCode += getCommitmentType().hashCode();
        }
        if (getGracePeriod() != null) {
            _hashCode += getGracePeriod().hashCode();
        }
        if (getParentSignatureId() != null) {
            _hashCode += getParentSignatureId().hashCode();
        }
        if (getSignatureCertIssuer() != null) {
            _hashCode += getSignatureCertIssuer().hashCode();
        }
        if (getSignatureCertSerial() != null) {
            _hashCode += getSignatureCertSerial().hashCode();
        }
        if (getSignatureId() != null) {
            _hashCode += getSignatureId().hashCode();
        }
        if (getSignatureTimeStamp() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSignatureTimeStamp());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSignatureTimeStamp(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSigningTime() != null) {
            _hashCode += getSigningTime().hashCode();
        }
        if (getUriIDs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getUriIDs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getUriIDs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getVerifySignerCert() != null) {
            _hashCode += getVerifySignerCert().hashCode();
        }
        if (getVerifySignerCertUsage() != null) {
            _hashCode += getVerifySignerCertUsage().hashCode();
        }
        if (getVerifyStatus() != null) {
            _hashCode += getVerifyStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StatusInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "StatusInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("archiveTimeStamp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "archiveTimeStamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "TimeStampInfoStruct"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commitmentType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "commitmentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gracePeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "gracePeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentSignatureId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "parentSignatureId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signatureCertIssuer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "signatureCertIssuer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signatureCertSerial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "signatureCertSerial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signatureId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "signatureId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signatureTimeStamp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "signatureTimeStamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "TimeStampInfoStruct"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signingTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "signingTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uriIDs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "uriIDs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifySignerCert");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "verifySignerCert"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifySignerCertUsage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "verifySignerCertUsage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifyStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://ws.sopel.security.comarch.com/xsd", "verifyStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
