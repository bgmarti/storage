package com.comarch.draco.portlets;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.xml.rpc.ServiceException;

import org.apache.axis.EngineConfiguration;
import org.apache.axis.client.Stub;
import org.apache.axis.configuration.FileProvider;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.comarch.draco.portlets.config.Config;
import com.comarch.draco.portlets.utils.Display;
import com.comarch.draco.portlets.webservice.DracoPortletSendHandler;
import com.comarch.security.draco.consoleAPI.webservice.TreeNodeStructure;

import comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWS;
import comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWSServiceLocator;

/**
 * A sample portlet
 */
public class DRACOShowUserPrivsPortlet extends javax.portlet.GenericPortlet {
	
	
	static Log logger = LogFactory.getLog( DRACOShowUserPrivsPortlet.class);

	/**
	 * @see javax.portlet.Portlet#init()
	 */
	public void init() throws PortletException{
		super.init();
	}

	/**
	 * Serve up the <code>view</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		
		String tgsId=Commons.getTgsIdFromCookie(request);
		
		if(tgsId==null)
		{	
			Display.setErrorOnPage("NO TGS ID FOUND IN COOKIES",response);
	        return;
		}

		
		EngineConfiguration  file = new FileProvider(Config.dracoConsoleAPI_wsdd);
		DracoConsoleApiWS api=null;
		try {
			DracoConsoleApiWSServiceLocator locator=new DracoConsoleApiWSServiceLocator(file);
			locator.DracoConsoleAPI_address=Config.dracoConsoleAPI_webServiceUrl;
			api = locator.getDracoConsoleAPI();
			
		} catch (ServiceException e) {
			logger.error(e,e);
			Display.setErrorOnPage(e.getMessage(),response);
	        return;
		}

		Stub stub = (Stub)api;
		stub._setProperty(DracoPortletSendHandler.TGSID, tgsId);
		
		TreeNodeStructure tree=null;
		
		try{
			tree=api.getRolesForUser();
		}
		catch (Exception e)
		{
			logger.error(e,e);
			Display.setErrorOnPage(e.getMessage(),response);
	        return;
		}

		request.setAttribute("tree",tree);
	
		
	
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher("/jsp/ShowUserPrivs.jsp");
		rd.include(request,response);
		
		 
	}

	

}
