package com.comarch.draco.portlets.config;


public class Config {
	
	public static final String dracoConsoleAPI_wsdd = "DracoConsole-client.wsdd";
	
	public static final String dracoConsoleAPI_webServiceUrl="http://10.133.140.53:28080/axis/services/DracoConsoleAPI";


}
