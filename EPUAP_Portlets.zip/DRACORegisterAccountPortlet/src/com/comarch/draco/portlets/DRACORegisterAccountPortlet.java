package com.comarch.draco.portlets;
 
import java.io.*;
import java.rmi.RemoteException;
import java.util.ResourceBundle;


import javax.portlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.xml.rpc.ServiceException;

import org.apache.axis.EngineConfiguration;
import org.apache.axis.configuration.FileProvider;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.comarch.draco.portlets.bean.RegisterAccountBean;
import com.comarch.draco.portlets.config.Config;
import com.comarch.draco.portlets.exceptions.SopelException;

import com.comarch.draco.portlets.display.Display;
import com.comarch.draco.portlets.utils.Validator;
import com.comarch.draco.portlets.utils.ValidatorErrrorHandler;
import com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;
import com.comarch.security.sopel.ws.Sopel2ServiceLocator;
import com.comarch.security.sopel.ws.Sopel2ServicePortType;
import com.comarch.security.sopel.ws.xsd.StatusInfo;
import com.comarch.security.sopel.ws.xsd.VerifyResult;

import comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWS;
import comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWSServiceLocator;
import comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;

/**
 * A sample portlet
 */
public class DRACORegisterAccountPortlet extends javax.portlet.GenericPortlet {
	

	static Log logger = LogFactory.getLog( DRACORegisterAccountPortlet.class);

	private ValidatorErrrorHandler errorHandler=new ValidatorErrrorHandler();
	
	ResourceBundle res;
	
	private String dracoConsoleAPI_webServiceUrl=null;
	
	private String sopelWebServiceUrl=null;
	
	private String login=null;
	
	
	//actual mode
	private int MODE=Config.Mode.SHOW;


	
	/**
	 * @see javax.portlet.Portlet#init()
	 */
	public void init() throws PortletException{
		super.init();
		
	}

	/**
	 * Serve up the <code>view</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		
		response.setContentType("text/html");
		PortletRequestDispatcher rd = null;
		res=getResourceBundle(request.getLocale());
		
	
		
		 RegisterAccountBean bean = Commons.getBean(request);

		 if(bean == null)
		 {
			 	Display.displayMessageOnPage(res.getString("Error"), response);
			 	logger.error("NO PORTLET SESSION YET");
		        return;
		 }   
		 
		 logger.info("REGISTER ACCOUNT PORTLET STARTED");
		 logger.info("MODE:"+MODE);
		 
		 
		 switch(MODE)
			{
				
				case Config.Mode.SHOW:
					
					//clean all fields
					bean.reset();
					request.setAttribute(Config.ERRORS, new ValidatorErrrorHandler());
					
					
					try {
						dracoConsoleAPI_webServiceUrl=Config.getDracoConsoleAPI_webServiceUrl((HttpServletRequest) request);
						sopelWebServiceUrl=Config.getSopel_WebServiceUrl((HttpServletRequest) request);
					} catch (IOException e) {
						logger.error(e,e);
						Display.displayMessageOnPage(res.getString("Error"), response);
						return;
					}
					
					try {
						bean.setXml(Commons.generateXMLStructure());
					} catch (SopelException e) {
						logger.error(e,e);
						Display.displayMessageOnPage(res.getString("Error"), response);
						return;
					}
					bean.setXmlToShow(Config.XML);
					

					rd =getPortletContext().getRequestDispatcher("/jsp/RegisterAccount.jsp");
		    		rd.include(request,response);	
					
					break;
					
				case Config.Mode.FAILED:
					
					request.setAttribute(Config.ERRORS, errorHandler);
					
					rd =getPortletContext().getRequestDispatcher("/jsp/RegisterAccount.jsp");
				    rd.include(request,response);	
				    
				    MODE=Config.Mode.SHOW;
				    
				    break;
				    
				 
				case Config.Mode.SUCCESS:
					
		    		request.setAttribute("login",login);
		    		
		    		rd =getPortletContext().getRequestDispatcher("/jsp/Success.jsp");
		    		rd.include(request,response);	
		    		
		    		MODE=Config.Mode.SHOW;
		    		
		    		break;
		    		
		    	default:
		    		logger.error("PORTLET MODE IS UNDEFINED");
		    		Display.displayMessageOnPage(res.getString("Errror"), response);
	  
			} 	  
	}



	/**
	 * Process an action request.
	 * 
	 * @see javax.portlet.Portlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)
	 */
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException
	{	
	
		RegisterAccountBean bean=Commons.getBean(request);
		
		bean.setName(request.getParameter("name"));
		bean.setSecondName(request.getParameter("secondName"));
		bean.setSurname(request.getParameter("surname"));
		bean.setEmail(request.getParameter("email"));
		
		bean.setPassword(request.getParameter("password"));
		bean.setPasswordRetype(request.getParameter("passwordRetype"));
		
		bean.setSetupOrg(Boolean.valueOf(request.getParameter("setupOrg")).booleanValue());
		bean.setCertMethod(Boolean.valueOf(request.getParameter("certMethod")).booleanValue());
		bean.setPassMethod(Boolean.valueOf(request.getParameter("passMethod")).booleanValue());
		
		
		
		//do the validation
		errorHandler=doValidation(bean);
		boolean SUCCESS=!errorHandler.hasErrors();
		
		//if validation sucessfull->register account
		if(SUCCESS)	
		{
			String signedXml=request.getParameter("sign");
			
			//check if registration process succeded
			SUCCESS=registerAccount(bean,signedXml);
		}
		
		
		if(SUCCESS)									//if alles gutten!
			MODE=Config.Mode.SUCCESS;
		else										//something went wrong...	
		{	
			MODE=Config.Mode.FAILED;
			errorHandler.addError("output",res.getString("Message.failed"));
		}
		
	}
	
	
	private boolean registerAccount(RegisterAccountBean bean,String signedXml)
	{

		
		//check sign if required
		if(bean.isCertMethod())
		{
			if(!verifySign(signedXml))		//sign verification-->call sopel webservice
				return false;		
		}
		
		
		EngineConfiguration  file = new FileProvider(Config.dracoConsoleAPI_wsdd);
		DracoConsoleApiWS api=null;
		try {
			DracoConsoleApiWSServiceLocator locator=new DracoConsoleApiWSServiceLocator(file);
			 locator.setDracoConsoleAPIEndpointAddress(dracoConsoleAPI_webServiceUrl);
			 api = locator.getDracoConsoleAPI();
			
		} catch (ServiceException e) {
			logger.error(e,e);
			return false;
		}

		//create account
		int userId;
		try{
			userId =api.registerAccount(bean.getName(),bean.getSecondName(), bean.getSurname(),bean.getEmail());
			logger.info("User added with id:"+userId);
		}
		catch (ProtectorConsoleEJBException e) {
			logger.error(e,e);
			return false;
		} catch (DracoConsoleException e) {
			logger.error(e,e);
			return false;
		} catch (RemoteException e) {
			logger.error(e,e);
			return false;
		}
		

		//set password
		if(bean.isPassMethod())
		{
			try {
				api.addPasswordMethod(bean.getPassword(),userId);
				
			} catch (ProtectorConsoleEJBException e) {
				logger.error(e,e);
				return false;
			} catch (DracoConsoleException e) {
				logger.error(e,e);
				return false;
			} catch (RemoteException e) {
				logger.error(e,e);
				return false;
			}
			
		}
		
		//set certificate
		if(bean.isCertMethod())
		{	
			
			try {
				String certificate=Commons.getCertificateFromSignedXML(signedXml);
				
				api.addCertificateMethod(certificate, userId);
				
			} catch (ProtectorConsoleEJBException e) {
				logger.error(e,e);
				return false;
			} catch (DracoConsoleException e) {
				logger.error(e,e);
				return false;
			} catch (RemoteException e) {
				logger.error(e,e);
				return false;
			} catch (DecoderException e) {
				logger.error(e,e);
				return false;
			}	
		}
		
		
		//get login
		try {
			login=api.getUserNameByID(userId);
		} catch (ProtectorConsoleEJBException e) {
			logger.error(e,e);
			return false;
		} catch (DracoConsoleException e) {
			logger.error(e,e);
			return false;
		} catch (RemoteException e) {
			logger.error(e,e);
			return false;
		} 
		
		logger.info("ADDED USER ACCOUNT WITH GIVEN ID:"+login);
		
		return true;
	}
	
	
	private boolean verifySign(String signInHex)
	{

		
		Sopel2ServicePortType sopel=null;
		try {
			Sopel2ServiceLocator locator=new Sopel2ServiceLocator();
		
			locator.setSopel2ServiceSOAP12port_httpEndpointAddress(sopelWebServiceUrl);
			
			sopel=locator.getSopel2ServiceSOAP11port_http();
		} catch (ServiceException e) {
			logger.error(e,e);
			return false;
		}
		
		
		String xmlWithSignature=null;
		try {
			xmlWithSignature = Commons.addSignatureToXML(Config.XML, signInHex,Config.XML_END_TAG);
		} catch (DecoderException e) {
			logger.error(e,e);
			return false;
		}
	
		VerifyResult result=null;
		try 
		{
			result=sopel.verifyXadesAndExtend(xmlWithSignature.getBytes(), null, null, new Integer(0));
							
		} catch (RemoteException e) {
			logger.error(e,e);
			return false;
		} catch (Exception e) {
			logger.error(e,e);
			return false;
		}
		
		StatusInfo[] statusInfos =result.getStatusInfos();
		StatusInfo statusInfo = statusInfos[0];
		
		if (statusInfo.getVerifyStatus().intValue() != 0 || (statusInfo.getVerifySignerCert().intValue() != 0)) 
		{
			logger.error("SIGNATURE UNCORRECT OR STH WENT WRONG: verifyStatus:" + statusInfo.getVerifyStatus()+",verifySignerCert:"+statusInfo.getVerifySignerCert());
			return false;
		}
		
		logger.debug("SIGNATURE CORRECT(verified by sopel)");
		return true;
	}
	

	 private ValidatorErrrorHandler doValidation(RegisterAccountBean bean)
	 {
		 
		 ValidatorErrrorHandler err=new ValidatorErrrorHandler();
		 
		 //is any method chosen?
		 if(!bean.isCertMethod()&&!bean.isPassMethod())
			 err.addError("output",res.getString("Message.failed"));
		 
		 
		 //validate input
		 if(!Validator.isNotEmpty(bean.getName()))
			 err.addError("name",res.getString("Message.required"));
		 
		 if(!Validator.isNotEmpty(bean.getSurname()))
			 err.addError("surname",res.getString("Message.required"));
		 
		 if(!Validator.isNotEmpty(bean.getEmail()))
			 err.addError("email",res.getString("Message.required"));
		 else
			 if(!Validator.isCorrectEmailFormat(bean.getEmail()))
				 err.addError("email",res.getString("Message.invalid"));

		return err;
	 }
	 
	 

	 
	 


	
}
