	
	/*DEFINE VARIABLES*/
	var DEBUG=false;//true;	
	
	
	/*!!!!!!!!!!variables must be initialized on page*/
	 var form;
	
	 /*CLASS TEXT*/
	  function Text()
	  {
	 		this.fieldMustBeChecked='Field must be checked';
	 		this.methodNotChosen="Method not chosen";
	 		
	 		this.passwordCannotBeEmpty="Password cannot be empty";
	 		this.passwordsAreDifferent="Passwords are different";
	 		
	 		this.emailCannotBeEmpty="Email cannot be empty";
	 		this.emailsAreDifferent="Emails are different";
	 		
	 		this.errorOccured="Error occured";
	 		
	 		this.loadFailed="Load failed";
	 		
	 		this.installComplete='Install complete.Start browser again ';
	 
	 		this.installationError='Error while  installing component. ';
	 		
	 		this.installationFailed='Component instalation failed';
	  }
	  o_text=new Text;
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 function setForm(formName)
	 {
		    form=document.getElementsByName(formName)[0];	
	 }

     function InitCheckboxes(passMethodIsChecked,certMethodIsChecked)
     {

	 		form.passMethod.checked=passMethodIsChecked;
	 		form.certMethod.checked=certMethodIsChecked;
     }
        
     
    function CertMethodClicked()
    {
         if(form.certMethod.checked==true)
         {
                document.getElementById('certMethodMsg').style.visibility='visible';
         }
         else
                 document.getElementById('certMethodMsg').style.visibility='hidden';
    }
    
    function PassMethodClicked()
    {
         if(form.passMethod.checked==true)
         {
                form.password.readOnly=false;
                form.passwordRetype.readOnly=false;
         }
         else
         {
         		form.password.readOnly=true;
                form.passwordRetype.readOnly=true;
         }
    }

    function checkMethods()
	{	
		
		var passMethod=form.passMethod.checked;
		var certMethod=form.certMethod.checked;
		
		if(!passMethod&&!certMethod)
		{
			alert(o_text.methodNotChosen);
			return false;
		}
		
		return true;
	}
	
	function checkPassword()
	{	
		if(!form.passMethod.checked)
			return true;
			
		var password=form.password.value;
		var passwordRetype=form.passwordRetype.value;
		
		
		if(password.length==0)
		{
			alert(o_text.passwordCannotBeEmpty);
			return false;
		}
		
		if(password!=passwordRetype)
		{
			alert(o_text.passwordsAreDifferent);
			return false;
		}
		
		
		return true;
	}
	
	function checkEmail()
	{	
			
		var email=form.email.value;
		var emailRetype=form.emailRetype.value;
		
		
		if(email.length==0)
		{
			alert(o_text.emailCannotBeEmpty);
			return false;
		}
		
		if(email!=emailRetype)
		{
			alert(o_text.emailsAreDifferent);
			return false;
		}
		
		
		return true;
	}
	
	function doSubmit()
	{
		//is email ok?
        if(!checkEmail())
			return;

		//is at least one method chosen
		if(!checkMethods())
			return;
		
		//is password ok?
		if(!checkPassword())
			return;
			
		
		//if certificate logon method  is chosen	
		if(form.certMethod.checked)
		{
			//is sign procedure successful?
			if(!signDocument())
				return;	
		}
		

		form.passMethod.value=form.passMethod.checked;
		form.certMethod.value=form.certMethod.checked;
		
		
		form.submit();

	}
	

    function signDocument() 
    {
                if(DEBUG)
                  alert("Component version:"+componentVersion+" Actual version:"+actualComponentVersion);
                  
                  if (actualComponentVersion!=componentVersion) 
                  		return false;
                  
                  try
                  {		
                  		var xmlHex=form.xml.value;
                  		
                      	if(DEBUG)
                      		alert("HEX from xml:"+xmlHex);
                      	
                      	var out = signObject.SignDocument(signObject.SelectCert(),xmlHex);
                      	
                      	if(DEBUG)
                      		alert("Component SignDocument output:"+out);
                  } 
                  catch (err) 
                  {
                  	   alert(err.message);
                  
                       if (is_opera5up) 
                       {
                         alert( o_text.errorOccured+''+err.msg);
                         //document.getElementById("operaInfo").style.display = 'block';
                       }
                       
                       return false;
                  }
                  
                  //split result    
                  if (is_opera5up) 
                  {
                        tab = out.split("[|]");
                  } 
                  else 
                  {
                        tab = out.split("|");
                  }


                  var errCode = tab[0];
                  form.sign.value = tab[1];
                    
                  if (errCode==0)
                  {
                          if(form.sign.value.length > 0) 
                        	 return true;
                  }
                  else 
                  {
                        alert('Error:'+tab[0]);
                  }
                  
                  return false;
	 }

	

	

