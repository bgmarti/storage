var PageUtilsJS=new function(){

        var DEBUG=true;	


        this.ValidateForm=function(formToValidate)
        {	
    		for(var i=0;i<formToValidate.length;i=i+1)
    			if(!formToValidate[i].Validate())
    				return false;
    				
    		return true;		
        }


       /*INNER CLASS ->VALIDATION*/
       this.FieldToValidate=function(_object_id,_required,_invalid,_pattern,_default_value)
       {
	   var object_id=_object_id;
	   var pattern=_pattern;
	   var default_value=_default_value;
	   var invalid=_invalid;
	   var required=_required;
			
	  this.Validate=function()
          {
    		
                              var object=document.getElementById(object_id);
    		              var value=object.value;
    		              alert(value);
    		
    		              if(required!=null)
    		              {
    		              	if(value.length==0)
    			        {
					alert(required);
					
					if(default_value)
						object.value=default_value;
						
					return false;
				}	
    			
    		              }	
    	
    		              if(invalid!=null&&value.length!=0)
    		              {
                                   var myregexp = new RegExp(pattern);
    			           var result=myregexp.exec(value);
    			
    			           if(result==null)
    			           {
                                      alert(invalid);
    				
    				      if(default_value)
    					 object.value=default_value;
    				
	                              return false;
    			           }		
    		               }
                        		
            }

       }
       
       /*INNER CLASS ->ACTIVE-X COMPONENT*/
       this.ActiveXComponent=function(_id,_actualComponentVersion, _xpiPath,_codeBase,_classId,_mimeType)
       {

            var id=_id;
            var actualComponentVersion=_actualComponentVersion ;
	    var xpiPath=_xpiPath;
	    var codeBase=_codeBase;
	
	    var classId=_classId;
	    var mimeType=_mimeType;
	    
	    
	    var componentVersion;
	    var componentType;
	    
	    var componentObject;
	    
	    
	    //message properties
	    var messages=new function()
	    {
                this.errorOccured="errorOccured";
                this.loadFailed="loadFailed";
                this.installComplete="installComplete";
                this.installationError="installationError";
                this.installationFailed="installationFailed";
            }
            
            
            this.setMessages=function(_errorOccured,_loadFailed,_installComplete,
                                       _installationError,_installationFailed)
	    {
                messages.errorOccured=_errorOccured;
                messages.loadFailed=_loadFailed;
                messages.installComplete=_installComplete;
                messages.installationError=_installationError;
                messages.installationFailed=_installationFailed;
            }
            
	    
	    var setComponentObject=function()
	    {
                if (componentType=="A")
                {
                   var obj=document.getElementById(id);

                   if(obj)
                   {
                       componentObject = obj;
                   }
                   else
                   {
                       alert(messages.errorOccured + obj);
                       return;
                   }
                } else
        	   if (componentType=="P")
        	   {
                       componentObject = document.embeds[0];
                   }	
            }
            
            
            this.loadComponentOnPage=function()
	    {

	
              if(typeof(is_win)=="undefined"||typeof(is_ie4up)=="undefined"||
                 typeof(is_nav6up)=="undefined"||typeof(is_opera5up)=="undefined")
              {
                   alert("detectBrowserLib.js required!")
                   return;
              }



        	
	      if(is_win && is_ie4up)
              {
                document.write('   <object classid="'+classId+'" width="0" height="0" id="signAX" codebase="'+codeBase+'">\n');
                document.write('     '+messages.loadFailed+'\n');
                document.write('   </object>');
                componentType = "A";
              }
              else
              if(is_nav6up || is_opera5up)
              {
                document.write('   <embed name="SignPlugin" type="'+mimeType+'" width="1" height="1" hidden="true"></embed>\n');
                componentType = "P";
              }
          	
               setComponentObject();     	
           }
           
           
           var installComplete=function(name,result)
	   {
               if(result == 0)
               {
                  alert(messages.installComplete);
                  // window.location.reload( true );
               } else
          		if(result == 999)
          		{
               		    alert(messages.installComplete);
               		    //alert('Musisz ponownie uruchomic komputer');
            	        }else
            	        {
               		    alert(messages.installationError+":"+result);
            	        }
           }
	
	
	  this.testPlugin=function()
	  {	
	  
    	    try
    	    {
                componentVersion=componentObject.GetVersion();
            }
            catch (err)
            {

              if(is_nav6up)
              {
                   try
                   {
                        var xpi={'SignPlugin':xpiPath};
                        var ret=InstallTrigger.install(xpi,installComplete);
                        if (!ret)
                        {
                            alert(messages.installationFailed+' '+ret);
                    	}
                    }
                    catch( err2 )
                    {
                        alert( messages.errorOccured+' '+err2.msg );
                    }

                        return;
                }
                else
                     if (is_opera5up)
                     {
                     	alert('Opera nie jest wspomagana');
                     	//document.getElementById("operaInfo").style.display = 'block';
                     }
             }

             if (componentVersion != actualComponentVersion)
             {
                if(is_nav6up)
                {
                   try
                   {
                      var xpi={'SignPlugin':xpiPath};
                      var ret=InstallTrigger.install(xpi,installComplete);

                      if (!ret)
                      {
                          alert(messages.installationFailed+''+ret);
                      }
                   }
                   catch( err2 )
                   {
                      alert( messages.errorOccured+''+err2.msg );
                   }
                   
                 }
                 else if (is_opera5up)
               	      {
                        alert('Zainstaluj now� wersj� komponentu.\n1. Zapisz plik instalacyjny na dysku\n2. Wy��cz przegl�dark�\n3. Uruchom zapisany instalator');
                        //document.getElementById("operaInfo").style.display = 'block';
                      }
            }

	  }

       }
       /*END OF CLASS*/	
    	
    	
}






	

	
	

