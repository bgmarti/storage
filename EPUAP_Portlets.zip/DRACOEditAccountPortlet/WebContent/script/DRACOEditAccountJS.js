
//define class
var DRACOEditAccountJS=new function(){
	
	/*DEFINE VARIABLES*/
	var DEBUG=true;	
	
	
	/*variables must be initialized on page*/
	 var form;
	
	 var actualComponentVersion ;
	 var xpiPath;
	 var codeBase;
	 
	 var classId;
	 var mimeType;
	
	
	
	 /*sub CLASS TEXT*/
	  function Text()
	  {
	 		this.fieldMustBeChecked='Field must be checked';
	 		this.methodNotChosen="Method not chosen";
	 		
	 		this.passwordCannotBeEmpty="Password cannot be empty";
	 		this.passwordsAreDifferent="Passwords are different";
	 		
	 		this.emailCannotBeEmpty="Email cannot be empty";
	 		this.emailsAreDifferent="Emails are different";
	 		
	 		this.errorOccured="Error occured";
	 		
	 		this.loadFailed="Load failed";
	 		
	 		this.installComplete='Install complete.Start browser again ';
	
	 		this.installationError='Error while  installing component. ';
	 		
	 		this.installationFailed='Component instalation failed';
	  }
	 var o_text=new Text;
	 

	function checkPassword()
	{	

		
		var password=form.password.value;
		var passwordRetype=form.passwordRetype.value;
		
		
		if(password.length==0)
		{
			alert(o_text.passwordCannotBeEmpty);
			return false;
		}
		
		if(password!=passwordRetype)
		{
			alert(o_text.passwordsAreDifferent);
			return false;
		}
		
		
		return true;
	}
	
	
        function checkEmail()
	{	
		var email=form.email.value;
		var emailRetype=form.emailRetype.value;
		
		
		if(email.length==0)
		{
			alert(o_text.emailCannotBeEmpty);
			return false;
		}
		
		if(email!=emailRetype)
		{
			alert(o_text.emailsAreDifferent);
			return false;
		}
		
		
		return true;
	}
	

	
	
	/******************************************************public methods*/
	this.getTextToFill=function()
        {
                 return o_text;
        }

        this.setAction=function(action)
	{
              form.dispatchAction.value=action;
              alert(action);
        }

	
	this.setForm=function(formName)
	{
		form=document.getElementsByName(formName)[0];	
	}
	
	this.setActualComponentVersion=function(value)
	{
		actualComponentVersion=value;
	}
	
	this.setXpiPath=function(value)
	{
		xpiPath=value;
	}
	
	this.setCodeBase=function(value)
	{
		codeBase=value;
	}
	
	this.setClassId=function(value)
	{
		classId=value;
	}
	
	this.setMimeType=function(value)
	{
		mimeType=value;
	}
	
	
	
	this.doSubmit=function()
	{
		form.submit();
	}
	
	this.modifyAccount=function()
	{
	
		//is email ok?
                if(!checkEmail())
			return;
			
		form.submit();
	}
	
	this.modifyPassword=function()
	{
		//is password ok?
		if(!checkPassword())
			return;
	
		form.submit();
	}
	
	this.modifyCertificate=function()
	{
		loadComponentOnPage();
	 		
                 if(!testPlugin())
                 {
                                  return;
	 	  }
	 	
	 	//is sign procedure successful?
		if(!signDocument())
				return;	
		
		form.submit();
		
	}
	
	
	
	/*ACTIVE-X SECTION*/
	var componentVersion;
	var componentType="";
	var signObject;
	
	
	function setSignObject() 
	{

        if (componentType=="A")
        {
            var signAX=document.getElementById('signAX');
        
           if(signAX) 
           {
               signObject = signAX;
           } 
           else 
           {
               alert(o_text.errorOccured + signObject);
               return;
           }
        } else 
        	if (componentType=="P") 
        	{
               signObject = document.embeds[0];
            }
   		
    }
	
	
	function loadComponentOnPage()
	{
		
	      if(is_win && is_ie4up)
          {
                document.write('   <object classid="'+classId+'" width="0" height="0" id="signAX" codebase="'+codeBase+'">\n');
                document.write('     '+o_text.loadFailed+'\n');
                document.write('   </object>');
                componentType = "A";
          }
           else
              if(is_nav6up || is_opera5up)
              {
                document.write('   <embed name="SignPlugin" type="'+mimeType+'" width="1" height="1" hidden="true"></embed>\n');
                componentType = "P";
          	  }

          setSignObject();	
    }
	
	
	
	function installComplete(name,result)
	{
          if(result == 0) 
          {
              alert(o_text.installComplete);
              // window.location.reload( true );
          } else 
          		if(result == 999) 
          		{
               		alert(o_text.installComplete);
               		//alert('Musisz ponownie uruchomic komputer');
            	}else 
            	{
               		alert(o_text.installationError+""+result);
            	}
    }
	
	
	function testPlugin() 
	{	
    	 try
    	 {
             componentVersion=signObject.GetVersion();
         } 
         catch (err) 
         {

              if(is_nav6up)
              {
                   try 
                   {
                        var xpi={'SignPlugin':xpiPath};
                        var ret=InstallTrigger.install(xpi,installComplete);
                        if (!ret)
                        {
                            alert(o_text.installationFailed+''+ret);
                    	}
                    } 
                    catch( err2 ) 
                    {
                        alert(o_text.errorOccured+''+err2.msg );
                    }

                    return false;
                }
                else
                     if (is_opera5up)
                     {
                     	alert('Opera nie jest wspomagana');
                     	return false;
                     	//document.getElementById("operaInfo").style.display = 'block';
                     }            
         }
         
          if (componentVersion != actualComponentVersion) 
          {
              if(is_nav6up) 
              {
                   try 
                   {
                      var xpi={'SignPlugin':xpiPath};
                      var ret=InstallTrigger.install(xpi,installComplete);
                      
                      if (!ret)
                      {
                          alert(o_text.installationFailed+''+ret);
                          return false;
                      }
                      
                   } 
                   catch( err2 ) 
                   {
                      alert(o_text.errorOccured+''+err2.msg );
                      return false;
                   }
               } 
               else if (is_opera5up) 
               		{
                        alert('Zainstaluj nową wersję komponentu.\n1. Zapisz plik instalacyjny na dysku\n2. Wyłącz przeglądarkę\n3. Uruchom zapisany instalator');
                        //document.getElementById("operaInfo").style.display = 'block';
                        return false;
                    }
           }
           
           return true;
  
	}
	
				
    function signDocument() 
    {
                if(DEBUG)
                  alert("Component version:"+componentVersion+" Actual version:"+actualComponentVersion);
                  
                  if (actualComponentVersion!=componentVersion) 
                  		return false;
                  
                  try
                  {		
                  		var xmlHex=form.xml.value;
                  		
                      	if(DEBUG)
                      		alert("HEX from xml:"+xmlHex);
                      	
                      	var out = signObject.SignDocument(signObject.SelectCert(),xmlHex);
                      	
                      	if(DEBUG)
                      		alert("Component SignDocument output:"+out);
                  } 
                  catch (err) 
                  {
                  	   alert(err.message);
                  
                       if (is_opera5up) 
                       {
                         alert(o_text.errorOccured+''+err.msg);
                         //document.getElementById("operaInfo").style.display = 'block';
                       }
                       
                       return false;
                  }
                  
                  //split result    
                  if (is_opera5up) 
                  {
                        tab = out.split("[|]");
                  } 
                  else 
                  {
                        tab = out.split("|");
                  }


                  var errCode = tab[0];
                  form.sign.value = tab[1];
                    
                  if (errCode==0)
                  {
                          if(form.sign.value.length > 0) 
                        	 return true;
                  }
                  else 
                  {
                        alert('Error:'+tab[0]);
                  }
                  
                  return false;
	 }	
}


//------------------------------------------------------------------------VALIDATION SECTION
		
		function ObjectToValidate(_object_id,_err_message_required,_err_message_invalid,_pattern,_default_value)
		{
			var object_id=_object_id;
			var pattern=_pattern;
			var default_value=_default_value;
			var err_message_invalid=_err_message_invalid;
			var err_message_required=_err_message_required;
			
			this.Validate=function()
			{

                             var object=document.getElementById(object_id);
                             var value=object.value;
    		             //alert(value);

                             if(err_message_required!=null)
    		             {
    		             	if(value.length==0)
    		              	{
                                      	alert(err_message_required);
					
					if(default_value)
						object.value=default_value;
						
					return false;
				}
                                	
    			      }	
    	
    		              if(err_message_invalid!=null&&value.length!=0)
    		              {
                                   var myregexp = new RegExp(objectToValidate.pattern);
    			           var result=myregexp.exec(value);
    			
    			           if(result==null)
    			           {
                                       	alert(err_message_invalid);
    				
    				        if(default_value)
    					     object.value=default_value;
	                                return false;
	                           }
                              }		

                              return true;	
                         }
                         
                         
                         
                         ObjectToValidate.ValidateForm=function(formToValidate)
    	                 {
    		
                              for(var i=0;i<formToValidate.length;i=i+1)
    		              	if(!formToValidate[i].Validate())
                                   return false;
    				
    		              return true;		
		         }
		         

		}
	
