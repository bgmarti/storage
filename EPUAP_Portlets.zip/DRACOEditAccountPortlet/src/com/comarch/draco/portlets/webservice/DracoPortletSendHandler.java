package com.comarch.draco.portlets.webservice;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;

import org.apache.axis.AxisFault;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.handlers.BasicHandler;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DracoPortletSendHandler extends BasicHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String TGSID="tgsid";
	
	public void invoke(MessageContext msgContext) throws AxisFault {

		Log log = LogFactory.getLog(DracoPortletSendHandler.class);
		
		SOAPMessage sOAPMsg = msgContext.getMessage();
		Message msg = msgContext.getCurrentMessage();
		
		log.info("Handler BEGIN");
		
		try {
			SOAPHeader header = sOAPMsg.getSOAPHeader();
			
			Object tgsId = msgContext.getProperty(TGSID);

			log.info(TGSID+": " + tgsId.toString());
		
			if (tgsId == null) {
				throw new AxisFault("Parameters missing");
			}
			
			Name name = msg.getSOAPEnvelope().createName(TGSID);
			SOAPHeaderElement headerElement = header.addHeaderElement(name);
			headerElement.setValue(tgsId.toString());
			
			
		} catch (SOAPException e) {
			log.error(e,e);
		}
		
	}
	
}
