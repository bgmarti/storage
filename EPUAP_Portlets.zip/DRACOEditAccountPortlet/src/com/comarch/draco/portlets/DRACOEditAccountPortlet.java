package com.comarch.draco.portlets;
 
import java.io.*;
import java.rmi.RemoteException;
import java.util.ResourceBundle;

import javax.portlet.*;
import javax.xml.rpc.ServiceException;

import org.apache.axis.EngineConfiguration;
import org.apache.axis.client.Stub;
import org.apache.axis.configuration.FileProvider;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.comarch.biod.draco.UserData;
import com.comarch.draco.portlets.bean.RegisterAccountBean;
import com.comarch.draco.portlets.config.Config;
import com.comarch.draco.portlets.exceptions.SopelException;
import com.comarch.draco.portlets.utils.Display;
import com.comarch.draco.portlets.utils.ValidatorErrrorHandler;
import com.comarch.draco.portlets.webservice.DracoPortletSendHandler;
import com.comarch.security.draco.consoleAPI.exceptions.DracoConsoleException;

import comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWS;
import comarch.krakow.pcrguzik.axis.services.DracoConsoleAPI.DracoConsoleApiWSServiceLocator;
import comarch.security.protector.ls.console.ejb.statefull.ProtectorConsoleEJBException;



public class DRACOEditAccountPortlet extends javax.portlet.GenericPortlet {
	
	
	static Log logger = LogFactory.getLog( DRACOEditAccountPortlet.class);
	
	
	private ValidatorErrrorHandler errorHandler=new ValidatorErrrorHandler();
	
	private boolean SUCCESS=false;
	
	
	ResourceBundle res;

	
	String tgsId;
	
	/**
	 * @see javax.portlet.Portlet#init()
	 */
	public void init() throws PortletException{
		super.init();
	}

	/**
	 * Serve up the <code>view</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		
		
		response.setContentType("text/html");
		request.setAttribute(Config.ERRORS, errorHandler);
		
		PortletRequestDispatcher rd = null;
		RegisterAccountBean bean = Commons.getBean(request);
		
		res=getResourceBundle(request.getLocale());

		 if(bean == null)
		 {
			 	Display.setErrorOnPage("NO PORTLET SESSION YET", response);
		        return;
		 }   
		 
		 logger.info("EDIT ACCOUNT PORTLET STARTED");
		 
		 if(bean.getXml()==null)
			 try {
				bean.setXml(Commons.generateXMLStructure());
			} catch (SopelException e) {
				Display.setErrorOnPage(e.getMessage(), response);
		        return;
			}
			
		bean.setXmlToShow(Config.XML);
		 
		tgsId=Commons.getTgsIdFromCookie(request);
		try {
			getUsetData(tgsId, bean);
		} catch (ServiceException e) {
			Display.setErrorOnPage(e.getMessage(), response);
		}
		 
		 
	    
		if(SUCCESS)	//validation succeded
		{	
	    		String success="<b style='font-size:50px'>Konto u�ytkownika za�o�one pomy�lnie.<br>Zost�� nadany login xyvdfdfbsdea</b>";
		    	response.getWriter().println(success);
		}	
		else
		{
			    rd =getPortletContext().getRequestDispatcher("/jsp/EditAccount.jsp");
			    rd.include(request,response);	
		}
  
	}

	

	/**
	 * Process an action request.
	 * 
	 * @see javax.portlet.Portlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)
	 */
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException 
	{	
		
		 EngineConfiguration  file = new FileProvider(Config.dracoConsoleAPI_wsdd);
		 DracoConsoleApiWS api=null;
		
		 DracoConsoleApiWSServiceLocator locator=new DracoConsoleApiWSServiceLocator(file);
		 locator.DracoConsoleAPI_address=Config.dracoConsoleAPI_webServiceUrl;
		 try {
			api = locator.getDracoConsoleAPI();
		} catch (ServiceException e) {
			e.printStackTrace();
		}
				
		 Stub stub = (Stub)api;

		 stub._setProperty(DracoPortletSendHandler.TGSID, tgsId);
		 
		 
		 System.out
			.println("ALLES GUTRRRRRRRRRRRRRREN!!!!!!!");
		 
		 String signedXml=request.getParameter("sign");
		 
		 try {
			String certificate=Commons.getCertificateFromSignedXML(signedXml);
			api.changeCertificate(certificate);
		} catch (DecoderException e) {
			e.printStackTrace();
		}
			
		
		 
		 //api.removePasswordMethod();
		 
		 //api.changePawssword("aqq");
		 
		 
		 
		 
		 
		 
		 
		 String action1=request.getParameter(Config.ACTION_MODIFY_ACCOUNT);
		 
		System.out
				.println(action1==null);
		
		String action2=request.getParameter(Config.ACTION_MODIFY_PASSWORD);
		System.out
		.println(action2==null);

		
		String action3=request.getParameter(Config.ACTION_REMOVE_PASSWORD);
		System.out
		.println(action3==null);


		String action4=request.getParameter(Config.ACTION_MODIFY_CERTIFICATE);
		System.out
		.println(action4==null);


		String action5=request.getParameter(Config.ACTION_REMOVE_CERTIFICATE);
		System.out
		.println(action5==null);


		
		/*
		
		bean.setName(request.getParameter("name"));
		bean.setSecondName(request.getParameter("secondName"));
		bean.setSurname(request.getParameter("surname"));
		bean.setEmail(request.getParameter("email"));
		
		bean.setPassword(request.getParameter("password"));
		bean.setPasswordRetype(request.getParameter("passwordRetype"));
		
		bean.setSetupOrg(Boolean.valueOf(request.getParameter("setupOrg")).booleanValue());
		bean.setCertMethod(Boolean.valueOf(request.getParameter("certMethod")).booleanValue());
		bean.setPassMethod(Boolean.valueOf(request.getParameter("passMethod")).booleanValue());
	
		
		//do the validation
		errorHandler=doValidation(bean);
		
		if(!errorHandler.hasErrors())	//validation sucessfull
		{
			registerAccount(bean);
			//SUCCESS=true;
			
		}
		*/
	  }  

	private void getUsetData(String tgsId,RegisterAccountBean bean) throws ServiceException, DracoConsoleException, RemoteException
	{
		 EngineConfiguration  file = new FileProvider(Config.dracoConsoleAPI_wsdd);
		 DracoConsoleApiWS api=null;
		
		 DracoConsoleApiWSServiceLocator locator=new DracoConsoleApiWSServiceLocator(file);
		 locator.DracoConsoleAPI_address=Config.dracoConsoleAPI_webServiceUrl;
		 api = locator.getDracoConsoleAPI();
				
		 Stub stub = (Stub)api;

		 stub._setProperty(DracoPortletSendHandler.TGSID, tgsId);

		 
		 UserData user=null;
		 user=api.getUserData();
		 
		 bean.setName(user.getFirstName());
		 bean.setSecondName(user.getSecondName());
		 bean.setSurname(user.getLastName());
		 bean.setEmail(user.getEmail());
			
		 logger.info("User fetched with parameters:"+user.getFirstName()+","+user.getLastName()+ ","+user.getEmail());
	}
	
	 
	 private void registerAccount(RegisterAccountBean bean)
	 {
		 //TODO:call web service method
	 }
	 
	
}
