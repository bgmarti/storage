;try {
/* module-key = 'com.atlassian.confluence.plugins.pagetree:pagetree-js-resources', location = 'soy/pagetree.soy' */
// This file was automatically generated from pagetree.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Pagetree.Macro.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Pagetree == 'undefined') { Confluence.Templates.Pagetree = {}; }
if (typeof Confluence.Templates.Pagetree.Macro == 'undefined') { Confluence.Templates.Pagetree.Macro = {}; }


Confluence.Templates.Pagetree.Macro.loadingIndicator = function(opt_data, opt_ignored) {
  return '<div class="plugin_pagetree_children_loading_wrapper"><div class="spinner"/><span class="plugin_pagetree_children_loading">' + soy.$$escapeHtml("Loading...") + '</span></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Pagetree.Macro.loadingIndicator.soyTemplateName = 'Confluence.Templates.Pagetree.Macro.loadingIndicator';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.pagetree:pagetree-js-resources', location = 'com/atlassian/confluence/plugins/pagetree/resource/javascript/pagetree.js' */
(function(){var A=function(M){this.$=M;
var H=this.$;
var b=999;
var c=true;
var K=false;
var W={};
var D={};
var N=function(k,j,f,i,e){if(j==undefined||j==null){j=!B(k)
}if(f==undefined||f==null){f=0
}if(!L(k,j)){var h=H("#children"+k);
if(Z(h)){var g=H("#plusminus"+k);
if(j==c){g.removeClass("icon-section-closed").addClass("icon-section-opened")
}else{g.removeClass("icon-section-opened").addClass("icon-section-closed")
}if(j==c){if(e==false){h.slideDown(300)
}else{h.removeClass("plugin-pagetree-hide-children");
h.animate({opacity:1})
}}else{if(e==false){h.slideUp(300)
}else{h.animate({opacity:0},{complete:function(){h.addClass("plugin-pagetree-hide-children")
}})
}}if(i){R(k)
}}else{J(k,new Array(),f,"",i,e)
}}if(i){R(k)
}};
var Z=function(e){return e.children("ul[id]").length>0
};
var B=function(f){var e=H("#plusminus"+f);
return(e.length>0)?(e.hasClass("icon-minus")||e.hasClass("icon-section-opened")):K
};
var L=function(f,e){return B(f)==e
};
var I=function(h,g,f){a(h,c,g,f)
};
var X=function(h,g,f){a(h,K,g,f)
};
var a=function(k,i,h,g){G(k);
var j=H("#"+k);
var f=j.find("div.plugin_pagetree_children_container");
f.each(function(e){var l=V(this.id);
N(l,i,b,e==f.length-1,g)
});
h.preventDefault();
h.stopPropagation()
};
var V=function(e){if(!e||e==undefined){return null
}if(e.indexOf("plusminus")!=-1){return e.substring("plusminus".length)
}if(e.indexOf("children")!=-1){return e.substring("children".length)
}return null
};
var C=function(e){if(!e||e==undefined){return null
}return S(e)[1]
};
var S=function(e){if(!e||e==undefined){return null
}return e.split("-")
};
var G=function(f){var e=C(f);
H("div.plugin_pagetree").each(function(g){if(g==e){H(this).find("span.plugin_pagetree_status").removeClass("hidden");
H(this).find("div.plugin_pagetree_expandcollapse").addClass("hidden")
}})
};
var R=function(f){var e=C(f);
H("div.plugin_pagetree").each(function(g){if(g==e){H(this).find("span.plugin_pagetree_status").addClass("hidden");
H(this).find("div.plugin_pagetree_expandcollapse").removeClass("hidden")
}})
};
var F=function(l,f,i,h,k,e,g){var j=W[l];
if(f=="Orphan"){j+="&hasRoot=false&spaceKey="+k
}else{j+="&hasRoot=true&pageId="+f
}j+="&treeId="+l+"&startDepth="+h+"&mobile="+g;
H.each(i,function(){j+="&ancestors="+this
});
j+="&treePageId="+e;
if(g==false){j=(AJS.params.serverUrl||"")+j
}return j
};
var Q=function(g){var f=g;
var e=null;
H("div.plugin_pagetree").each(function(h){if(h==f){e=H(this)
}});
return e
};
var P=function(e){var f=e.children("fieldset");
var g=new Object();
if(f.length>0){f.children("input").each(function(){g[this.name]=this.value
})
}return g
};
var O=function(e){var g=e.children("fieldset");
var h=new Array();
if(g.length>0){var f=g.children("fieldset");
if(f.length>0){f.children("input").each(function(){h.push(this.value)
})
}}return h
};
var E=function(g,f){var e=H("a.plugin_pagetree_childtoggle",g);
e.each(function(){var h=H(this);
h.attr("href","#").bind("click",function(k){var i=h.parent().parent().children("div.plugin_pagetree_children_container");
var j=i.attr("id");
var l=j.substring(8);
N(l,null,null,null,f);
k.preventDefault();
k.stopPropagation()
})
})
};
var U=function(e){var f=H(document.createElement("div"));
f.html(e);
return f.find("ul[id^='child_ul']").length
};
var J=function(n,g,s,q,j,f,h){var r=n;
var k=j;
var e=S(n);
var i=e[0];
var m=e[1];
var l=H("#children"+n);
var p=P(Q(m));
var t=false;
function o(){l.find(".plugin_pagetree_children_loading_wrapper .spinner").spin("small")
}l.append(Confluence.Templates.Pagetree.Macro.loadingIndicator());
if(h){setTimeout(function(){if(!t){o()
}},250)
}else{o()
}H.ajax({type:"GET",url:F(m,i,g,s,q,p.treePageId,f),dataType:"text",success:function(u){if(U(u)){l.html(u);
t=true;
if(l.children().length&&l.hasClass("hidden")){l.removeClass("hidden")
}E(l,f);
H("#plusminus"+r).addClass("icon-section-opened").removeClass("icon-section-closed");
H("#childrenspan"+D[parseInt(m)]+"-"+m).addClass("plugin_pagetree_current");
if(k){R(r)
}T(l);
if(AJS.PageGadget&&AJS.PageGadget.contentsUpdated){AJS.PageGadget.contentsUpdated()
}}else{window.location=p.loginUrl
}AJS.trigger("pagetree-children-loaded")
},error:function(u){if(u.status=="403"){l.text(p["i18n-pagetree.error.permission"])
}else{l.text(p["i18n-pagetree.error.general"])
}}})
};
var T=function(e){H("div.plugin_pagetree_children_container:empty",e).addClass("hidden")
};
var Y=function(e,j){var h=P(e);
var k=h.noRoot=="true";
var g=k?"Orphan-"+j:h.rootPageId+"-"+j;
var f=h.mobile=="true";
W[j]=h.treeRequestId;
if(f==false){D[j]=AJS.params.pageId
}else{D[j]=H("div.content-container").parent().attr("data-content-id")
}e.children("fieldset").each(function(){var l=H(this);
l.children("input[treeId]").attr("value",j);
l.children("input[rootPage]").attr("value",g)
});
if(k){e.find("div.plugin_pagetree_children").attr("id","childrenOrphan-"+j);
e.find("a.plugin_pagetree_expandall").click(function(l){I("childrenOrphan-"+j,l,f);
return false
});
e.find("a.plugin_pagetree_collapseall").click(function(l){X("childrenOrphan-"+j,l,f);
return false
})
}else{e.find("div.plugin_pagetree_children").attr("id","children"+g);
e.find("a.plugin_pagetree_expandall").click(function(l){I("children"+g,l,f);
return false
});
e.find("a.plugin_pagetree_collapseall").click(function(l){X("children"+g,l,f);
return false
})
}var i=O(e);
J(g,i,h.startDepth,h.spaceKey,"",f,true)
};
this.initPageTrees=function(){H("div.plugin_pagetree").each(function(e){Y(H(this),e)
});
d()
};
var d=function(){var e=self.placeFocus;
if(e){self.placeFocus=function(){var f=H("form[name='pagetreesearchform']");
f.attr("name","inlinecommentform");
e();
f.attr("name","pagetreesearchform")
}
}};
H(".open-flyout-to-search").bind("click",function(e){if(H(".fly-out-open").length){setTimeout(function(){ConfluenceMobile.flyout.hide()
},400)
}else{setTimeout(function(){ConfluenceMobile.flyout.show()
},400)
}e.stopPropagation();
e.preventDefault()
})
};
Confluence=Confluence||{};
Confluence.Plugins=Confluence.Plugins||{};
Confluence.Plugins.PagetreeMacro={bind:function(B){var C=new A(B);
C.initPageTrees()
}}
})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.pagetree:pagetree-js-resources', location = 'com/atlassian/confluence/plugins/pagetree/resource/javascript/pagetree-desktop.js' */
AJS.toInit(function(A){Confluence.Plugins.PagetreeMacro.bind(A)
});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:help-dialog-extension', location = '/jira/help-dialog.js' */
if(Confluence.KeyboardShortcuts){Confluence.KeyboardShortcuts.Editor.push({context:"editor.actions",descKey:"Insert JIRA Issue/Filter"+":",keys:[["Ctrl+Shift+J"]]})};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-mentions-plugin:help-dialog-extension', location = 'js/help-dialog.js' */
AJS.toInit(function(a){Confluence.KeyboardShortcuts&&Confluence.KeyboardShortcuts.Autoformat.push({action:"@",context:"autoformat.autocomplete",description:"Mention"})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:internal-aui-browser', location = 'js/aui/internal/browser.js' */
(function(A){AJS._internal=AJS._internal||{};AJS._internal.browser=A(AJS.$)})(function(B){var A={};var C=null;A.supportsCalc=function(){if(C===null){var D=B('<div style="height: 10px; height: -webkit-calc(20px + 0); height: calc(20px);"></div>');C=(20===D.appendTo(document.documentElement).height());D.remove()}return C};A.supportsRequestAnimationFrame=function(){return !!window.requestAnimationFrame};return A});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:dialog2', location = 'js/dialog2.js' */
(function(A){AJS.dialog2=A(AJS.$,AJS.layer,AJS._internal.widget)})(function(D,G,C){var F={"aui-focus":"false","aui-blanketed":"true"};function B(H){D.each(F,function(I,J){var K="data-"+I;if(!H[0].hasAttribute(K)){H.attr(K,J)}})}function A(H){if(H){this.$el=D(H)}else{this.$el=D(aui.dialog.dialog2({}))}B(this.$el)}A.prototype.on=function(I,H){G(this.$el).on(I,H);return this};A.prototype.off=function(I,H){G(this.$el).off(I,H);return this};A.prototype.show=function(){G(this.$el).show();return this};A.prototype.hide=function(){G(this.$el).hide();return this};A.prototype.remove=function(){G(this.$el).remove();return this};A.prototype.isVisible=function(){return G(this.$el).isVisible()};var E=C("dialog2",A);E.on=function(H,I){G.on(H,".aui-dialog2",I);return this};E.off=function(H,I){G.off(H,".aui-dialog2",I);return this};D(document).on("click",".aui-dialog2-header-close",function(H){H.preventDefault();E(D(this).closest(".aui-dialog2")).hide()});E.on("show",function(K,J){var I=[".aui-dialog2-content",".aui-dialog2-footer",".aui-dialog2-header"];var H;I.some(function(L){H=J.find(L+" :aui-tabbable");return H.length});H&&H.first().focus()});E.on("hide",function(J,I){var H=G(I);if(I.data("aui-remove-on-hide")){H.remove()}});return E});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:dialog2', location = 'soy/dialog2.soy' */
// This file was automatically generated from dialog2.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace aui.dialog.
 */

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.dialog == 'undefined') { aui.dialog = {}; }


aui.dialog.dialog2 = function(opt_data, opt_ignored) {
  return '' + aui.dialog.dialog2Chrome({id: opt_data.id, titleId: opt_data.id ? opt_data.id + '-dialog-title' : null, modal: opt_data.modal, tagName: opt_data.tagName, removeOnHide: opt_data.removeOnHide, visible: opt_data.visible, size: opt_data.size, extraClasses: opt_data.extraClasses, extraAttributes: opt_data.extraAttributes, content: '' + aui.dialog.dialog2Content({id: null, titleText: opt_data.titleText, titleContent: opt_data.titleContent, headerActionContent: opt_data.headerActionContent, headerSecondaryContent: opt_data.headerSecondaryContent, modal: opt_data.modal, content: opt_data.content, footerHintText: opt_data.footerHintText, footerHintContent: opt_data.footerHintContent, footerActionContent: opt_data.footerActionContent})});
};
if (goog.DEBUG) {
  aui.dialog.dialog2.soyTemplateName = 'aui.dialog.dialog2';
}


aui.dialog.dialog2Chrome = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<' + soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'section') + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ((opt_data.titleId) ? ' aria-labelledby="' + soy.$$escapeHtml(opt_data.titleId) + '"' : '') + ' role="dialog" class=" aui-layer aui-dialog2 aui-dialog2-' + soy.$$escapeHtml(opt_data.size ? opt_data.size : 'medium') + aui.renderExtraClasses(opt_data) + '"' + ((opt_data.modal) ? 'data-aui-modal="true"' : '') + ((opt_data.removeOnHide) ? 'data-aui-remove-on-hide="true"' : '') + ((opt_data.visible != true) ? 'aria-hidden="true"' : '') + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.content) ? soy.$$filterNoAutoescape(opt_data.content) : '') + '</' + soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'section') + '>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Chrome.soyTemplateName = 'aui.dialog.dialog2Chrome';
}


aui.dialog.dialog2Content = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '' + aui.dialog.dialog2Header({titleId: opt_data.id ? opt_data.id + '-dialog-title' : null, titleText: opt_data.titleText, titleContent: opt_data.titleContent, actionContent: opt_data.headerActionContent, secondaryContent: opt_data.headerSecondaryContent, modal: opt_data.modal}) + aui.dialog.dialog2Panel(opt_data) + aui.dialog.dialog2Footer({hintText: opt_data.footerHintText, hintContent: opt_data.footerHintContent, actionContent: opt_data.footerActionContent});
};
if (goog.DEBUG) {
  aui.dialog.dialog2Content.soyTemplateName = 'aui.dialog.dialog2Content';
}


aui.dialog.dialog2Header = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<header' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="aui-dialog2-header' + aui.renderExtraClasses(opt_data) + '"' + aui.renderExtraAttributes(opt_data) + '><h2 ' + ((opt_data.titleId) ? ' id="' + soy.$$escapeHtml(opt_data.titleId) + '"' : '') + ' class="aui-dialog2-header-main">' + ((opt_data.titleText) ? soy.$$escapeHtml(opt_data.titleText) : '') + ((opt_data.titleContent) ? soy.$$filterNoAutoescape(opt_data.titleContent) : '') + '</h2>' + ((opt_data.actionContent) ? '<div class="aui-dialog2-header-actions">' + soy.$$filterNoAutoescape(opt_data.actionContent) + '</div>' : '') + ((opt_data.secondaryContent) ? '<div class="aui-dialog2-header-secondary">' + soy.$$filterNoAutoescape(opt_data.secondaryContent) + '</div>' : '') + ((opt_data.modal != true) ? '<a class="aui-dialog2-header-close"><span class="aui-icon aui-icon-small aui-iconfont-close-dialog">' + soy.$$escapeHtml("Close") + '</span></a>' : '') + '</header>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Header.soyTemplateName = 'aui.dialog.dialog2Header';
}


aui.dialog.dialog2Footer = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<footer' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="aui-dialog2-footer' + aui.renderExtraClasses(opt_data) + '"' + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.actionContent) ? '<div class="aui-dialog2-footer-actions">' + soy.$$filterNoAutoescape(opt_data.actionContent) + '</div>' : '') + ((opt_data.hintText || opt_data.hintContent) ? '<div class="aui-dialog2-footer-hint">' + ((opt_data.hintText) ? soy.$$escapeHtml(opt_data.hintText) : '') + ((opt_data.hintContent) ? soy.$$filterNoAutoescape(opt_data.hintContent) : '') + '</div>' : '') + '</footer>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Footer.soyTemplateName = 'aui.dialog.dialog2Footer';
}


aui.dialog.dialog2Panel = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<div' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="aui-dialog2-content' + aui.renderExtraClasses(opt_data) + '"' + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.content) ? soy.$$filterNoAutoescape(opt_data.content) : '') + '</div>';
};
if (goog.DEBUG) {
  aui.dialog.dialog2Panel.soyTemplateName = 'aui.dialog.dialog2Panel';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:page-loading-indicator', location = '/includes/js/page-loading-indicator.js' */
define("confluence/page-loading-indicator",["jquery","underscore","ajs","confluence/templates"],function(c,g,a,h){return function(b){function d(){return c(".confluence-page-loading-blanket",b)}function e(){return c(".confluence-loading-indicator",b)}return{show:function(){0===d().length&&c(b).append(h.pageLoadingIndicator());d().show();e().spin({lines:12,length:8,width:4,radius:10,trail:60,speed:1.5,color:"#F0F0F0"})},hide:function(){e().stop();d().hide()},showUntilResolved:function(c,b){this.show();
c.always(g.bind(this.hide,this));b&&c.fail(function(){a.messages.error(".confluence-page-loading-errors",{body:b})})},showUntilDialogVisible:function(b,d){var f=this,e=d||"An error has occurred connecting to the server. Please try again.",g=c(".aui-dialog:visible"),h=c(".aui-dialog2:visible");!g.length&&!h.length&&f.show();b.always(f.hide).fail(function(){a.messages.error(".confluence-page-loading-errors",{body:e})});a.bind("show.dialog",function i(){a.unbind("show.dialog",i);f.hide()});if(null!=a.dialog2&&void 0!=a.dialog2)a.dialog2.on("show",
function j(){a.dialog2.off("show",j);f.hide()})},destroy:function(){b.remove(".confluence-page-loading-blanket")}}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence/page-loading-indicator","Confluence.PageLoadingIndicator");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:page-loading-indicator', location = '/includes/soy/page-loading-indicator.soy' */
// This file was automatically generated from page-loading-indicator.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }


Confluence.Templates.pageLoadingIndicator = function(opt_data, opt_ignored) {
  return '<div class="confluence-page-loading-errors"></div><div class="confluence-page-loading-blanket aui-blanket" aria-hidden="false"><div class="confluence-loading-indicator"></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.pageLoadingIndicator.soyTemplateName = 'Confluence.Templates.pageLoadingIndicator';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:event', location = '/includes/js/api/event.js' */
define("confluence/api/event",["ajs"],function(a){return{bind:function(){a.bind.apply(this,arguments)},unbind:function(){a.unbind.apply(this,arguments)},trigger:function(){a.trigger.apply(this,arguments)},stopEvent:function(){a.stopEvent.apply(this,arguments)}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:deferred-loaders', location = '/includes/js/deferred-dialog-loader.js' */
define("confluence/deferred-dialog-loader",["underscore","jquery","ajs","confluence/page-loading-indicator","confluence/api/event"],function(a,d,e,g,f){return function(){var h=g(d("body"));a.each({userStatus:{resource:"confluence.userstatus:userstatus-resources",selector:"#create-user-status-link",event:"deferred.userstatus.click"},movePageDialogTools:{resource:"confluence.web.resources:page-move-resources",selector:"#action-move-page-dialog-link",event:"deferred.page-move.tools-menu"},movePageDialogEditor:{resource:"confluence.web.resources:page-move-resources",
selector:"#rte-button-location",event:"deferred.page-move.editor"},moveBlogDialogTools:{resource:"confluence.web.resources:page-move-resources",selector:"#action-move-blogpost-dialog-link",event:"deferred.blog-move.tools-menu"},availableGadgetsHelp:{resource:"com.atlassian.confluence.plugins.gadgets:gadget-directory-resources",selector:"#gadget-directory-link",event:"deferred.available-gadgets.help-menu"},aboutConfluenceHelp:{resource:"confluence.web.resources:about",selector:"#confluence-about-link",
event:"deferred.about-confluence.help-menu"}},function(b){d("body").on("click",b.selector,function(a){var c=WRM.require("wr!"+b.resource,function(){f.trigger(b.event)});h.showUntilDialogVisible(c);c=b.resource+".requested";e.Analytics?e.Analytics.triggerPrivacyPolicySafeEvent(c):f.trigger("analyticsEvent",{name:c});a.preventDefault()})})}});require("confluence/module-exporter").safeRequire("confluence/deferred-dialog-loader",function(a){require("ajs").toInit(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:deferred-loaders', location = '/includes/js/page-permissions-deferred-loader.js' */
define("confluence/page-permissions-deferred-loader","confluence/dark-features confluence/legacy ajs confluence/page-loading-indicator jquery wrm".split(" "),function(a,b,c,d,e,f){var g=d(e("body"));return function(a){var b=f.require("wr!com.atlassian.confluence.plugins.confluence-page-restrictions-dialog:dialog-resources",function(){c.trigger("deferred.page.permissions")});g.showUntilDialogVisible(b,"There was an error loading the page restrictions. Please try again later.");a.preventDefault()}});
require("confluence/module-exporter").safeRequire("confluence/page-permissions-deferred-loader",function(a){var b=require("ajs");b.toInit(function(c){c("body").on("click","#rte-button-restrictions,#action-page-permissions-link",a);b.bind("system-content-metadata.open-restrictions-dialog",a)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:nps-amd-shims', location = '/js/amd-shims/ajs.js' */
define("atlassian-nps-plugin/js/amd-shims/ajs",function(){return AJS});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:nps-amd-shims', location = '/js/amd-shims/templates.js' */
define("atlassian-nps-plugin/js/amd-shims/templates",function(){return NPS.Templates});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:nps-amd-shims', location = '/js/amd-shims/wrm.js' */
define("atlassian-nps-plugin/js/amd-shims/wrm",function(){return WRM});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:nps-util', location = '/js/nps/util.js' */
define("atlassian-nps-plugin/js/nps/util",["atlassian-nps-plugin/js/nps/product","atlassian-nps-plugin/js/amd-shims/ajs"],function(b,a){var c={};c.kfyShuffle=function(g){for(var f=g.length-1;f>0;f--){var d=Math.floor(Math.random()*(f+1));var e=g[f];g[f]=g[d];g[d]=e}return g};c.sendAnalyticsEvent=function(d,e){e=e||{};e.product=b.getProductName().toLowerCase();e.page=window.location.pathname.replace(/\//g," ");var f={name:"nps."+d,data:e};a.trigger("analyticsEvent",f)};c.hasShowingDialog=function(){return a.$(".aui-dialog:visible, aui-dialog2:visible").length>0};return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:nps-util', location = '/js/nps/submission.js' */
define("atlassian-nps-plugin/js/nps/submission",["atlassian-nps-plugin/js/nps/util"],function(b){var a={};a.showNotification=function(c){b.sendAnalyticsEvent("notification.show",c)};a.startSurvey=function(){b.sendAnalyticsEvent("survey.start",{})};a.cancelSurvey=function(c){var d={};if(c){d.cancelContext=c}b.sendAnalyticsEvent("survey.cancel",d)};a.ignoreSurvey=function(){b.sendAnalyticsEvent("survey.ignore",{})};a.submitSurvey=function(c){b.sendAnalyticsEvent("survey.submit",c)};a.scheduleNextSurveyDate=function(c){b.sendAnalyticsEvent("survey.schedule",c)};a.showAcknowledgementFlag=function(c){b.sendAnalyticsEvent("server.acknowledge.show",c)};a.acceptAcknowledgementFlag=function(c){b.sendAnalyticsEvent("server.acknowledge.accept",c)};a.closeAcknowledgementFlag=function(c){b.sendAnalyticsEvent("server.acknowledge.close",c)};a.updateNpsStatus=function(c){b.sendAnalyticsEvent("server.status.changed",c)};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:atlassian-nps-plugin-resources', location = '/js/nps/product/confluence.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:atlassian-nps-plugin-resources', location = '/js/nps/client-storage.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:atlassian-nps-plugin-resources', location = '/js/nps/config-manager-server.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:atlassian-nps-plugin-resources', location = '/js/nps/session-manager.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:atlassian-nps-plugin-resources', location = '/js/atlassian-nps-plugin.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:atlassian-nps-plugin-resources', location = '/js/bootstrap.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.mxgraph.confluence.plugins.diagramly:drawio-blueprint-resources-main', location = 'js/DiagramlyBlueprintInit.js' */
AJS.toInit(function(){if(Confluence&&Confluence.Blueprint&&Confluence.Blueprint.register){Confluence.Blueprint.register("com.mxgraph.confluence.plugins.diagramly:drawio-blueprint-item",function(b,c,a){window.location=Confluence.getContextPath()+"/pages/createpage.action?spaceKey="+encodeURIComponent(c)+"&newSpaceKey="+encodeURIComponent(c)+(b.getParentPageId()?"&fromPageId="+b.getParentPageId():"")+"&diagramlyBlueprint=1"})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:blueprint-first-time-tooltip-resources', location = 'com/atlassian/confluence/plugins/createcontent/js/first-time-tooptip.js' */
AJS.bind("sidebar.finished-loading",function(){var a=AJS.Meta.get("blueprint-index-popup-key");AJS.debug("Index key for "+a);if(a){Confluence.Blueprint.showIndexPagePopup(a)}});Confluence.Blueprint=AJS.$.extend(Confluence.Blueprint,{showIndexPagePopup:function(b){var d=function(i){return function(l,j,k){l.html(Confluence.Templates.Blueprints.sidebarIndexPagePopup({indexPageTitle:i.toLowerCase()}));k()}};var a=AJS.$(AJS.$("li.blueprint."+b)[0]);var h=a.text();var g=AJS.$(".icon",a);var f="blueprintIndexSidebarPopup";var c=AJS.InlineDialog(g.is(":visible")?g:AJS.$(".acs-nav-sections .quick-links-section"),f,d(h),{addActiveClass:false,hideDelay:null,noBind:true});AJS.$(document).bind("showLayer",function(i){var j=f+".inline-dialog-check";AJS.$("body").unbind("click."+j)});c.show();var e=function(i){AJS.$(document).on("click","#dismiss-index-popup",function(){i.hide();return false})}(c);AJS.bind("quickedit.success",function(){c.hide()})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:blueprint-first-time-tooltip-resources', location = 'com/atlassian/confluence/plugins/createcontent/soy/sidebar-index-page-popup.soy' */
// This file was automatically generated from sidebar-index-page-popup.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Blueprints.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Blueprints == 'undefined') { Confluence.Templates.Blueprints = {}; }


Confluence.Templates.Blueprints.sidebarIndexPagePopup = function(opt_data, opt_ignored) {
  return '<h2>' + soy.$$escapeHtml(AJS.format("Find your {0} here",opt_data.indexPageTitle)) + '</h2><p>' + soy.$$escapeHtml(AJS.format("You\x27\x27ve created a {0} page. A shortcut in your sidebar has been added where you can find other {0} in this space.",opt_data.indexPageTitle)) + '</p><br/><form>' + aui.buttons.button({text: "Dismiss", id: 'dismiss-index-popup'}) + '</form>';
};
if (goog.DEBUG) {
  Confluence.Templates.Blueprints.sidebarIndexPagePopup.soyTemplateName = 'Confluence.Templates.Blueprints.sidebarIndexPagePopup';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:create-from-template-resources', location = 'com/atlassian/confluence/plugins/createcontent/js/create-from-template-macro.js' */
AJS.toInit(function(b){var a=b(".create-from-template-button");a.each(function(){var d=b(this);if(d.attr("aria-disabled")=="true"){var c={live:true,gravity:"n",title:"data-tooltip",delayIn:250,delayOut:0};d.tooltip(c)}else{d.click(function(){d.addClass("launching-dialog");Confluence.Blueprint.loadDialogAndOpenTemplate(d.data());return false})}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-create-content-plugin:create-from-template-resources', location = 'com/atlassian/confluence/plugins/createcontent/soy/create-from-template-macro.soy' */
// This file was automatically generated from create-from-template-macro.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Blueprints.CreateFromTemplate.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Blueprints == 'undefined') { Confluence.Templates.Blueprints = {}; }
if (typeof Confluence.Templates.Blueprints.CreateFromTemplate == 'undefined') { Confluence.Templates.Blueprints.CreateFromTemplate = {}; }


Confluence.Templates.Blueprints.CreateFromTemplate.macroTemplate = function(opt_data, opt_ignored) {
  return '<a class=\'aui-button create-from-template-button\'' + ((! opt_data.hasCreatePermission) ? 'aria-disabled=\'true\' data-tooltip="' + soy.$$escapeHtml("Sorry, you don\x27t have permission to create content. Contact your space administrator to request access.") + '"' : '') + 'data-space-key=\'' + soy.$$escapeHtml(opt_data.spaceKey) + '\' href=\'' + soy.$$escapeHtml(opt_data.createContentUrl) + '\'' + ((opt_data.title) ? 'data-title=\'' + soy.$$escapeHtml(opt_data.title) + '\'' : '') + ((opt_data.templateId) ? 'data-template-id=\'' + soy.$$escapeHtml(opt_data.templateId) + '\'' : '') + ((opt_data.contentBlueprintId) ? 'data-content-blueprint-id=\'' + soy.$$escapeHtml(opt_data.contentBlueprintId) + '\'' : '') + '>' + soy.$$escapeHtml(opt_data.buttonLabel) + '</a>';
};
if (goog.DEBUG) {
  Confluence.Templates.Blueprints.CreateFromTemplate.macroTemplate.soyTemplateName = 'Confluence.Templates.Blueprints.CreateFromTemplate.macroTemplate';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.contributors:contributors-web-resources', location = 'com/atlassian/confluence/contributors/scripts/contributors.js' */
require(["ajs","underscore"],function(a,b){a.toInit(function(c){c("div.contributors-macro-ajax-container").each(function(){var e=c(this);var d=c.parseJSON(b.unescape(e.find(".contributors-macro-parameters")[0].innerHTML));e.text("Generating contributors information...");c.ajax({dataType:"json",url:Confluence.getContextPath()+"/rest/com.atlassian.confluence.contributors/1.0/contributors",data:d,success:function(f){if(f.errorMessage){e.text(f.errorMessage)}else{e.html(Confluence.ContributorsMacro.renderContent(f));e.find(".show-hidden-contributors").click(function(){e.find(".hidden-contributor").removeClass("hidden");c(this).parent().remove();return false})}},error:function(h,f,g){e.text("Failed to retrieve contributors information"+": "+g)}})})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.contributors:contributors-web-resources', location = 'com/atlassian/confluence/contributors/templates/contributors-macro.soy' */
// This file was automatically generated from contributors-macro.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.ContributorsMacro.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.ContributorsMacro == 'undefined') { Confluence.ContributorsMacro = {}; }


Confluence.ContributorsMacro.ajaxContainer = function(opt_data, opt_ignored) {
  return '<div class="contributors-macro-ajax-container"><div style="display; none;" class="contributors-macro-parameters">' + soy.$$escapeHtml(opt_data.macroParameters) + '</div></div>';
};
if (goog.DEBUG) {
  Confluence.ContributorsMacro.ajaxContainer.soyTemplateName = 'Confluence.ContributorsMacro.ajaxContainer';
}


Confluence.ContributorsMacro.renderContent = function(opt_data, opt_ignored) {
  return '<div class="plugin-contributors">' + ((opt_data.layoutStyle == 'FLAT') ? Confluence.ContributorsMacro.flatLayout(opt_data) : (opt_data.layoutStyle == 'LIST') ? Confluence.ContributorsMacro.listLayout(opt_data) : '<span>Unknown layout style</span>') + '</div>';
};
if (goog.DEBUG) {
  Confluence.ContributorsMacro.renderContent.soyTemplateName = 'Confluence.ContributorsMacro.renderContent';
}


Confluence.ContributorsMacro.flatLayout = function(opt_data, opt_ignored) {
  return '<div class="plugin-contributors"><span><span>' + Confluence.ContributorsMacro.flatContributorsList({contributors: opt_data.visibleContributors, showCount: opt_data.showCount, showTime: opt_data.showTime}) + ((opt_data.hiddenContributors.length > 0) ? ',' : '') + '</span>' + ((opt_data.hiddenContributors.length > 0) ? '<span class="hidden hidden-contributor">' + Confluence.ContributorsMacro.flatContributorsList({contributors: opt_data.hiddenContributors, showCount: opt_data.showCount, showTime: opt_data.showTime}) + '</span><span><a href="#" class="show-hidden-contributors" title="' + soy.$$escapeHtml(AJS.format("{0} more...",opt_data.hiddenContributors.length)) + '">...</a></span>' : '') + '</span></div>';
};
if (goog.DEBUG) {
  Confluence.ContributorsMacro.flatLayout.soyTemplateName = 'Confluence.ContributorsMacro.flatLayout';
}


Confluence.ContributorsMacro.listLayout = function(opt_data, opt_ignored) {
  var output = '<div class="plugin-contributors"><ul class="contributors-list">';
  var contributorList39 = opt_data.visibleContributors;
  var contributorListLen39 = contributorList39.length;
  for (var contributorIndex39 = 0; contributorIndex39 < contributorListLen39; contributorIndex39++) {
    var contributorData39 = contributorList39[contributorIndex39];
    output += '<li>' + Confluence.ContributorsMacro.contributor({contributor: contributorData39, showCount: opt_data.showCount, showTime: opt_data.showTime}) + '</li>';
  }
  if (opt_data.hiddenContributors.length > 0) {
    output += '<li><a href="#" class="show-hidden-contributors" title="' + soy.$$escapeHtml(AJS.format("{0} more...",opt_data.hiddenContributors.length)) + '">...</a></li>';
    var contributorList52 = opt_data.hiddenContributors;
    var contributorListLen52 = contributorList52.length;
    for (var contributorIndex52 = 0; contributorIndex52 < contributorListLen52; contributorIndex52++) {
      var contributorData52 = contributorList52[contributorIndex52];
      output += '<li class="hidden hidden-contributor">' + Confluence.ContributorsMacro.contributor({contributor: contributorData52, showCount: opt_data.showCount, showTime: opt_data.showTime}) + '</li>';
    }
  }
  output += '</ul></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.ContributorsMacro.listLayout.soyTemplateName = 'Confluence.ContributorsMacro.listLayout';
}


Confluence.ContributorsMacro.flatContributorsList = function(opt_data, opt_ignored) {
  var output = '';
  var contributorList62 = opt_data.contributors;
  var contributorListLen62 = contributorList62.length;
  for (var contributorIndex62 = 0; contributorIndex62 < contributorListLen62; contributorIndex62++) {
    var contributorData62 = contributorList62[contributorIndex62];
    output += ((! (contributorIndex62 == 0)) ? ',' : '') + Confluence.ContributorsMacro.contributor({contributor: contributorData62, showCount: opt_data.showCount, showTime: opt_data.showTime});
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.ContributorsMacro.flatContributorsList.soyTemplateName = 'Confluence.ContributorsMacro.flatContributorsList';
}


Confluence.ContributorsMacro.contributor = function(opt_data, opt_ignored) {
  return Confluence.Templates.User.usernameLink({username: opt_data.contributor.idString, fullName: opt_data.contributor.fullNameString, canView: false}) + ' ' + ((opt_data.showCount) ? soy.$$escapeHtml(opt_data.contributor.totalCount) : '') + ' ' + ((opt_data.showTime) ? '(' + soy.$$escapeHtml(opt_data.contributor.relativeLastActiveTimeStr) + ')' : '');
};
if (goog.DEBUG) {
  Confluence.ContributorsMacro.contributor.soyTemplateName = 'Confluence.ContributorsMacro.contributor';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.issue-status-plugin:issue-status-resources', location = 'templates/status.soy' */
// This file was automatically generated from status.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace JIRA.Template.Util.Issue.Status.
 */

if (typeof JIRA == 'undefined') { var JIRA = {}; }
if (typeof JIRA.Template == 'undefined') { JIRA.Template = {}; }
if (typeof JIRA.Template.Util == 'undefined') { JIRA.Template.Util = {}; }
if (typeof JIRA.Template.Util.Issue == 'undefined') { JIRA.Template.Util.Issue = {}; }
if (typeof JIRA.Template.Util.Issue.Status == 'undefined') { JIRA.Template.Util.Issue.Status = {}; }


JIRA.Template.Util.Issue.Status.issueStatusResolver = function(opt_data, opt_ignored) {
  return '' + ((! opt_data.issueStatus) ? '<span class="aui-icon aui-icon-small aui-iconfont-help jira-issue-status-render-error" title="' + soy.$$escapeHtml("No issue status information was provided") + '"></span>' : (opt_data.issueStatus.statusCategory) ? JIRA.Template.Util.Issue.Status.issueStatus(opt_data) : JIRA.Template.Util.Issue.Status.iconStatus({name: opt_data.issueStatus.name, iconUrl: opt_data.issueStatus.iconUrl, description: opt_data.issueStatus.description, isCompact: opt_data.isCompact}));
};
if (goog.DEBUG) {
  JIRA.Template.Util.Issue.Status.issueStatusResolver.soyTemplateName = 'JIRA.Template.Util.Issue.Status.issueStatusResolver';
}


JIRA.Template.Util.Issue.Status.iconStatus = function(opt_data, opt_ignored) {
  return '<img src="' + soy.$$escapeHtml(opt_data.iconUrl) + '" width="16" height="16" alt="' + soy.$$escapeHtml(opt_data.name) + '" title="' + soy.$$escapeHtml(opt_data.name) + ((opt_data.description) ? ' - ' + soy.$$escapeHtml(opt_data.description) : '') + '" class="jira-issue-status-icon">' + ((! opt_data.isCompact) ? ' ' + soy.$$escapeHtml(opt_data.name) : '');
};
if (goog.DEBUG) {
  JIRA.Template.Util.Issue.Status.iconStatus.soyTemplateName = 'JIRA.Template.Util.Issue.Status.iconStatus';
}


JIRA.Template.Util.Issue.Status.issueStatus = function(opt_data, opt_ignored) {
  return '' + JIRA.Template.Util.Issue.Status.statusLozenge({name: opt_data.issueStatus.name, categoryKey: opt_data.issueStatus.statusCategory.key, colorName: opt_data.issueStatus.statusCategory.colorName, description: opt_data.issueStatus.description, isSubtle: opt_data.isSubtle, isCompact: opt_data.isCompact, maxWidth: opt_data.maxWidth});
};
if (goog.DEBUG) {
  JIRA.Template.Util.Issue.Status.issueStatus.soyTemplateName = 'JIRA.Template.Util.Issue.Status.issueStatus';
}


JIRA.Template.Util.Issue.Status.statusLozenge = function(opt_data, opt_ignored) {
  var output = '';
  var maxWidth__soy46 = opt_data.maxWidth ? opt_data.maxWidth : 'medium';
  var tooltipContent__soy47 = '<span class="jira-issue-status-tooltip-title">' + soy.$$escapeHtml(opt_data.name) + '</span>' + ((opt_data.description) ? '<br><span class="jira-issue-status-tooltip-desc">' + soy.$$escapeHtml(opt_data.description) + '</span>' : '');
  output += '<span class=" jira-issue-status-lozenge aui-lozenge ' + JIRA.Template.Util.Issue.Status.statusLozengeClasses(opt_data) + ((opt_data.isSubtle && ! opt_data.isCompact) ? ' aui-lozenge-subtle' : '') + ((opt_data.isCompact) ? ' jira-issue-status-lozenge-compact' : '') + ' jira-issue-status-lozenge-max-width-' + soy.$$escapeHtml(maxWidth__soy46) + '" data-tooltip="' + soy.$$escapeHtml(tooltipContent__soy47) + '">' + soy.$$escapeHtml(opt_data.name) + '</span>';
  return output;
};
if (goog.DEBUG) {
  JIRA.Template.Util.Issue.Status.statusLozenge.soyTemplateName = 'JIRA.Template.Util.Issue.Status.statusLozenge';
}


JIRA.Template.Util.Issue.Status.statusLozengeClasses = function(opt_data, opt_ignored) {
  return 'jira-issue-status-lozenge-' + soy.$$escapeHtml(opt_data.colorName ? opt_data.colorName : 'medium-gray') + ' ' + ((opt_data.categoryKey) ? 'jira-issue-status-lozenge-' + soy.$$escapeHtml(opt_data.categoryKey) : '');
};
if (goog.DEBUG) {
  JIRA.Template.Util.Issue.Status.statusLozengeClasses.soyTemplateName = 'JIRA.Template.Util.Issue.Status.statusLozengeClasses';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.issue-status-plugin:issue-status-resources', location = '/js/issue-status-plugin.js' */
AJS.$(function(){if(AJS.$.fn.tooltip){AJS.$(".jira-issue-status-lozenge[data-tooltip]").tooltip({aria:true,gravity:AJS.$.fn.tipsy.autoWE,delayIn:100,html:true,live:true,title:"data-tooltip",className:"jira-issue-status-tooltip"})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-jira-metadata:confluence-jira-metadata-resources', location = 'soy/jira-metadata.soy' */
// This file was automatically generated from jira-metadata.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Metadata.JIRA.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Metadata == 'undefined') { Confluence.Templates.Metadata = {}; }
if (typeof Confluence.Templates.Metadata.JIRA == 'undefined') { Confluence.Templates.Metadata.JIRA = {}; }


Confluence.Templates.Metadata.JIRA.metadata = function(opt_data, opt_ignored) {
  var output = '<div id="jira-metadata-dialog" class="rendered-content"><h2 class="title">' + soy.$$escapeHtml("JIRA links") + '</h2><div class="items-section">';
  var groupList6 = opt_data.groups;
  var groupListLen6 = groupList6.length;
  for (var groupIndex6 = 0; groupIndex6 < groupListLen6; groupIndex6++) {
    var groupData6 = groupList6[groupIndex6];
    if (groupData6.items.length) {
      switch (groupData6.type) {
        case 'ISSUES':
          output += Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Issues", type: groupData6.type, links: groupData6.links});
          break;
        case 'SPRINTS':
          output += Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Sprints", type: groupData6.type, links: groupData6.links});
          break;
        case 'VERSIONS':
          output += Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Versions", type: groupData6.type, links: groupData6.links});
          break;
        case 'EPICS':
          output += Confluence.Templates.Metadata.JIRA.renderGroup({items: groupData6.items, headingText: "Epics", type: groupData6.type, links: groupData6.links});
          break;
      }
    }
  }
  output += '</div>' + Confluence.Templates.Metadata.JIRA.renderAuthPrompts({appLinks: opt_data.unauthorisedAppLinks}) + Confluence.Templates.Metadata.JIRA.renderJiraErrors(opt_data) + '</div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.metadata.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.metadata';
}


Confluence.Templates.Metadata.JIRA.featureDiscovery = function(opt_data, opt_ignored) {
  return '<div id="jira-metadata-feature-discovery"><h2>' + soy.$$escapeHtml("View related JIRA items here") + '</h2><p>' + soy.$$escapeHtml("Now you can see which epics, sprints, versions and issues relate to this page.") + '</p><div class="aui-toolbar2" role="toolbar"><div class="aui-toolbar2-inner">' + aui.buttons.button({text: "Show me", extraClasses: 'showme'}) + aui.buttons.button({text: "Don\x27t show again", type: 'link', extraClasses: 'close'}) + '</div></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.featureDiscovery.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.featureDiscovery';
}


Confluence.Templates.Metadata.JIRA.nometadata = function(opt_data, opt_ignored) {
  return '<div id="jira-metadata-dialog" class="rendered-content">' + aui.message.warning({content: '<p>' + soy.$$escapeHtml("JIRA links cannot be displayed. Either you do not have correct JIRA permissions or the links have been removed.") + '</p>'}) + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.nometadata.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.nometadata';
}


Confluence.Templates.Metadata.JIRA.renderAuthPrompts = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.appLinks.length) {
    var param66 = '';
    if (opt_data.appLinks.length == 1) {
      var appLink__soy69 = opt_data.appLinks[0];
      param66 += '<p>' + soy.$$filterNoAutoescape(AJS.format("{0}Login \x26amp; Approve{1} to retrieve data from {2}",'<a class="jira-metadata-auth-link" href="#" data-href="' + appLink__soy69.authorisationUrl + '">','</a>',appLink__soy69.htmlSafeName)) + '</p>';
    } else {
      param66 += '<p>' + soy.$$escapeHtml("Authenticate to retrieve data from the following instances:") + '</p>';
      var appLinkList78 = opt_data.appLinks;
      var appLinkListLen78 = appLinkList78.length;
      for (var appLinkIndex78 = 0; appLinkIndex78 < appLinkListLen78; appLinkIndex78++) {
        var appLinkData78 = appLinkList78[appLinkIndex78];
        param66 += '<div><a class="jira-metadata-auth-link" href="#" data-href="' + soy.$$escapeHtml(appLinkData78.authorisationUrl) + '">' + soy.$$escapeHtml(appLinkData78.name) + '</a></div>';
      }
    }
    output += aui.message.hint({content: param66});
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.renderAuthPrompts.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.renderAuthPrompts';
}


Confluence.Templates.Metadata.JIRA.renderGroup = function(opt_data, opt_ignored) {
  var output = '<div class="jira-metadata-section ' + soy.$$escapeHtml(opt_data.type) + '-section"><div class="section-label"><span class="icon"></span><span>' + soy.$$escapeHtml(opt_data.headingText) + '</span></div><ul class="jira-metadata-list jira-' + soy.$$escapeHtml(opt_data.type) + '-list">';
  var itemList94 = opt_data.items;
  var itemListLen94 = itemList94.length;
  for (var itemIndex94 = 0; itemIndex94 < itemListLen94; itemIndex94++) {
    var itemData94 = itemList94[itemIndex94];
    output += '<li class="jira-metadata-item"><span class="item-label"><a href="' + soy.$$escapeHtml("/confluence") + '/plugins/servlet/jira-metadata/redirect?u=' + soy.$$escapeUri(itemData94.url) + '&t=' + soy.$$escapeHtml(opt_data.type) + '" title="' + soy.$$escapeHtml(itemData94.name) + '">' + soy.$$escapeHtml(itemData94.name) + '</a>' + ((itemData94.status) ? '&nbsp;' + ((itemData94.status.statusCategory) ? JIRA.Template.Util.Issue.Status.issueStatusResolver({issueStatus: itemData94.status, isSubtle: true}) : '<span class="item-status">(' + soy.$$escapeHtml(itemData94.status.name) + ')</span>') : '') + '</span>' + ((itemData94.description != '') ? '<span class="item-subtext">' + soy.$$escapeHtml(itemData94.description) + '</span>' : '') + '</li>';
  }
  output += '</ul><ul class="jira-metadata-list ' + soy.$$escapeHtml(opt_data.type) + '-more-link">';
  var linkList130 = opt_data.links;
  var linkListLen130 = linkList130.length;
  for (var linkIndex130 = 0; linkIndex130 < linkListLen130; linkIndex130++) {
    var linkData130 = linkList130[linkIndex130];
    output += '<li class="jira-metadata-item"><a href="' + soy.$$escapeHtml("/confluence") + '/plugins/servlet/jira-metadata/redirect?u=' + soy.$$escapeUri(linkData130.url) + '&t=' + soy.$$escapeHtml(opt_data.type) + '&more">' + soy.$$escapeHtml(AJS.format("View {0} more in {1}",linkData130.numItems,linkData130.appName)) + '</a></li>';
  }
  output += '</ul></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.renderGroup.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.renderGroup';
}


Confluence.Templates.Metadata.JIRA.loadingMetadata = function(opt_data, opt_ignored) {
  return '<div id="jira-metadata-dialog"><h2 class="title">' + soy.$$escapeHtml("JIRA links") + '</h2><div class="spinner-container"><div class="spinner"></div></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.loadingMetadata.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.loadingMetadata';
}


Confluence.Templates.Metadata.JIRA.renderJiraErrors = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.errors.length == 1) {
    var error__soy150 = opt_data.errors[0];
    output += aui.message.warning({content: '<p>' + soy.$$escapeHtml("Unable to retrieve JIRA metadata.") + ' ' + soy.$$escapeHtml(error__soy150.errorMessage) + '</p>'});
  } else if (opt_data.errors.length > 1) {
    var param159 = '<p>' + soy.$$escapeHtml("Unable to retrieve JIRA metadata. The following errors occurred:") + '</p><ul>';
    var errorList163 = opt_data.errors;
    var errorListLen163 = errorList163.length;
    for (var errorIndex163 = 0; errorIndex163 < errorListLen163; errorIndex163++) {
      var errorData163 = errorList163[errorIndex163];
      param159 += '<li>' + soy.$$escapeHtml(errorData163.errorMessage) + '</li>';
    }
    param159 += '</ul>';
    output += aui.message.warning({content: param159});
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.renderJiraErrors.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.renderJiraErrors';
}


Confluence.Templates.Metadata.JIRA.unknownError = function(opt_data, opt_ignored) {
  return '<div id="jira-metadata-dialog" class="rendered-content">' + aui.message.warning({content: '<p>' + soy.$$escapeHtml("Unable to retrieve JIRA metadata. Could not connect to Confluence") + '</p>'}) + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Metadata.JIRA.unknownError.soyTemplateName = 'Confluence.Templates.Metadata.JIRA.unknownError';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-jira-metadata:confluence-jira-metadata-resources', location = '/js/jira-metadata.js' */
AJS.toInit(function(h){var i="com.atlassian.confluence.plugins.confluence-jira-metadata";var s=false;var o;var l;var q="jira-metadata-dialog";var g=h("#content-metadata-jira");var t;var e="jira-metadata-discovery";var r=AJS.Meta.get("jira-metadata-count");var k="linked-issues-dropdown";if(r>0){p(r,AJS.Meta.get("jira-metadata-count-incomplete"))}else{if(r==-1){h.ajax({url:AJS.contextPath()+"/rest/jira-metadata/1.0/metadata/aggregate?pageId="+AJS.Meta.get("page-id"),type:"GET",dataType:"json",contentType:"application/json",cache:false,success:function(u){if(u.count>0){p(u.count,u.incomplete)}}})}}function p(v,u){f(v,u);g.removeClass("hidden");if(b()){o=AJS.InlineDialog(g,q,function(x,w,y){AJS.trigger("analytics",{name:"confluence.jira.metadata.expanded"});if(!l||!s){l=x;y();a(x)}else{y()}return false},{hideDelay:null});g.click(function(){if(h("#"+q).is(":visible")){o.hide()}})}if(g&&j()){m();g.one("click",function(){Confluence.FeatureDiscovery.forPlugin(i).markDiscovered(k)})}}function f(v,u){if(!u){h("#content-metadata-jira > span").text(v==1?"1 JIRA link":AJS.format("{0} JIRA links",v))}}function b(){return !g.attr("href")}function m(){t=AJS.InlineDialog(g,e,function(v,u,w){v.html(Confluence.Templates.Metadata.JIRA.featureDiscovery());v.find(".showme").on("click",function(){Confluence.FeatureDiscovery.forPlugin(i).markDiscovered(k);t.hide();o.show()});v.find(".close").on("click",function(){Confluence.FeatureDiscovery.forPlugin(i).markDiscovered(k);t.hide()});w()},{noBind:true,closeOthers:false,hideDelay:null});t.show();Confluence.FeatureDiscovery.forPlugin(i).addDiscoveryView(k)}function j(){return !AJS.Meta.get("blueprint-index-popup-key")&&Confluence.FeatureDiscovery.forPlugin(i).shouldShow(k)}function a(){d();l.html(Confluence.Templates.Metadata.JIRA.loadingMetadata());l.find(".spinner").spin("medium");h.ajax({url:AJS.contextPath()+"/rest/jira-metadata/1.0/metadata?pageId="+AJS.Meta.get("page-id"),type:"GET",dataType:"json",contentType:"application/json",error:function(u){c();l.html(Confluence.Templates.Metadata.JIRA.unknownError())},success:function(u){c();s=true;f(u.count,false);var v;if(u.count===0&&!(u.unauthorisedAppLinks&&u.unauthorisedAppLinks.length>0)&&u.errors.length==0){AJS.trigger("analytics",{name:"confluence.jira.metadata.error.no-metadata"});v=Confluence.Templates.Metadata.JIRA.nometadata()}else{v=Confluence.Templates.Metadata.JIRA.metadata(u)}l.html(v);setTimeout(function(){l.find("#"+q).addClass("show")},0);n()},complete:function(){h("#"+q+" .icon-close").click(function(u){u.stopPropagation();h(this).closest(".closable").remove()})}})}function n(){h(".jira-metadata-auth-link").click(function(u){u.preventDefault();AppLinks.authenticateRemoteCredentials(h(this).data("href"),a,function(){})})}function d(){if(l&&l.height()>0){l.css("height",l.height())}}function c(){l&&l.css("height","")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-jira-content:confluence-jira-content-loader', location = 'com/atlassian/confluence/plugins/createjiracontent/js/page-helper.js' */
AJS.toInit(function(d){var c="com.atlassian.confluence.plugins.confluence-jira-content:create-JIRA-issue-summary";var g="wr!com.atlassian.confluence.plugins.confluence-jira-content:confluence-jira-content-resources";var b="Loading\u2026";var e=false;var j=d("div.jira-issues-created");if(j.length>0){if(window.history&&window.history.replaceState){var h=window.location.href;var i=h.substr(0,h.indexOf("JIRAIssuesCreated")-1);window.history.replaceState({},document.title,i)}var a=j.find("#jira-content-message-panel-error-warning");var f=j.find("#jira-content-message-panel-view-more-link");f.click(function(k){k.preventDefault();f.hide();a.show()});if(j.hasClass("success")){setTimeout(function(){j.hide()},10000)}}Confluence&&Confluence.HighlightAction&&Confluence.HighlightAction.registerButtonHandler(c,{onClick:function(l){var k;if(!e){var m=function(o,n,p){o.html('<span class="aui-icon aui-icon-wait"></span> '+b);p();return false};k=d("<div>");Confluence.CreateJiraContent.Dialogs.appendDialogTarget(l.area.average,k);dialog=Confluence.ScrollingInlineDialog(k,"create-issue-loading-dialog",m,{});dialog.show();e=true}WRM.require(g).done(function(){if(Confluence.CreateJiraContent.FeatureDiscovery.shouldShowFeatureDiscovery()){Confluence.CreateJiraContent.Dialogs.showFeatureDiscoveryDialog(l)}else{Confluence.CreateJiraContent.Dialogs.showCreateIssueDialog(l)}if(typeof k!=="undefined"){k.remove()}})},shouldDisplay:Confluence.HighlightAction.WORKING_AREA.MAINCONTENT_ONLY});Confluence.CreateJiraContent={Dialogs:{}};Confluence.CreateJiraContent.Dialogs.appendDialogTarget=function(l,k){Confluence.DocThemeUtils.appendAbsolutePositionedElement(k);k.css({top:l.top,height:l.height,left:l.left,width:l.width,"z-index":-9999,position:"absolute"}).addClass("confluence-jira-content-dialog-target")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-fixed-headers:utils', location = '/js/utils/dom.js' */
define("confluence/fh/utils/dom",["jquery","ajs","exports"],function(j,p,i){var q,d,a,n;function k(r){if(k.done&&!r){return}var s="#main .aui-page-panel-outer-content";d=j(s).length!==0?j(s):j("#main");a=j("#header");n=j("#main-header");k.done=true}function f(){var r=p.Meta.get("content-type");if(r==="page"||r==="blogpost"){j(tinymce.activeEditor.getWin().document).find("body#tinymce").addClass("page-edit")}}function o(){k();n.css({width:d.outerWidth()-(parseInt(d.css("padding-left"))+parseInt(d.css("padding-right")))})}function c(){k();var r=parseInt(n.css("top"))+n.outerHeight();if(isNaN(r)||r===c.lastValue){return}c.lastValue=r;p.trigger("sticky-table-headers.change.options",{fixedOffset:r,cacheHeaderHeight:true})}function e(t,r,s){if(s){e[s]=e[s]||{};if(r===e[s].lastValue){return}e[s].lastValue=r}t.css({transform:"translateY("+r+"px)","-webkit-transform":"translateY("+r+"px)","-ms-transform":"translateY("+r+"px)"})}function m(u,r,s){var t={};s.forEach(function(v){t[v]=u.css(v)});r.css(t)}var l={mt:"margin-top",mr:"margin-right",ml:"margin-left",mb:"margin-bottom",pt:"padding-top",pr:"padding-right",pl:"padding-left",pb:"padding-bottom",ff:"font-family",fsi:"font-size",fst:"font-style",fw:"font-weight",td:"text-decoration",ls:"letter-spacing",ta:"text-align",c:"color"};l.margin=[l.mt,l.mr,l.ml,l.mb];l.padding=[l.pt,l.pr,l.pl,l.pb];l.font=[l.ff,l.fsi,l.fst,l.fw];function b(){k();if(q){return q}q=j('<div id="main-header-placeholder"></div>');var t=j("#title-text"),s=t.find("a"),r=t.clone().removeAttr("id"),u=r.find("a");m(n,q,l.margin.concat(l.padding));q.css({height:n.outerHeight()});m(t,r,l.font.concat(l.td,l.ls,l.ta,l.pr,l.pb,l.pl,l.mr,l.mb,l.ml));r.css({paddingTop:parseInt(t.css("padding-top"))+Math.round(t.offset().top-n.offset().top)});m(s,u,l.font.concat(l.margin,l.padding,l.font,l.c,l.td,l.ls,l.ta));q.append(r);return q}function g(){q&&q.remove()}function h(t){t=typeof(t)==="string"?t:j(this).attr("href");if(!t){return}k();var s=a.outerHeight();var r=j(t.replace(/(!|\"|\$|%|&|'|\(|\)|\*|\+|,|\.|\/|\:|;|<|=|>|\?|@|\[|\\|\]|\^|`|\{|\||\}|~)/g,"\\$1"));if(r.length){window.scrollTo(0,r.offset().top-s);if(history&&"pushState" in history){history.pushState({},document.title,window.location.pathname+window.location.search+t);return false}}}i.forceInitialize=function(){k(true)};i.addClassToPage=f;i.adjustMainHeaderSize=o;i.updateTableStickyHeaderOption=c;i.translateVertical=e;i.createMainHeaderPlaceHolder=b;i.removeMainHeaderPlaceHolder=g;i.scrollIfAnchor=h});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-fixed-headers:handlers', location = '/js/handlers/page-view-handler.js' */
define("confluence/fh/handlers/page-view-handler",["confluence/fh/utils/dom","jquery","ajs","exports"],function(z,i,m,G){var E,s,D,n,v,d,C,h,e,w,F,r=false,l=false,f=false,j=0,u=0,g=0,y=50,b=100,q="by-hover",t="by-scroll",B="by-other",a=B,o=false;function c(H){if(c.done&&!H){return}E=i("#header");s=i("#main .aui-page-panel-outer-content");s.length===0&&(s=i("#main"));D=i("#main-header");n=i("#action-menu-link");v=z.createMainHeaderPlaceHolder();d=i(".ia-splitter-left .ia-fixed-sidebar");C=D.prop("style");h=s.prop("style");e=Math.round(E.offset().top);w=E.height();F=Math.round(D.offset().top)-w-(parseInt(s.css("padding-top"))+parseInt(D.css("margin-top")));c.done=true}var x=function(){c();var I=i(window).scrollTop();var K=I>e;if(K&&parseInt(d.css("top"))<w){d.css({top:w+"px"})}if(!r&&K){r=true;E.addClass("fixed-header");s.css({marginTop:w+"px"})}else{if(!K){E.removeClass("fixed-header");h.removeProperty("margin-top");r=false}}var O=I>F;if(!l&&O){l=true;D.find("#title-text").hide();D.css({position:"fixed",width:s.outerWidth()-(parseInt(s.css("padding-left"))+parseInt(s.css("padding-right"))),right:0,top:w+"px",marginTop:0,paddingTop:parseInt(s.css("padding-top"))+parseInt(D.css("margin-top")),paddingBottom:parseInt(s.css("padding-top"))+parseInt(D.css("margin-top")),paddingLeft:s.css("padding-left"),paddingRight:s.css("padding-right"),zIndex:b});D.before(z.createMainHeaderPlaceHolder())}else{if(!O){["position","width","right","top","margin-top","padding-top","padding-bottom","padding-left","padding-right","z-index"].forEach(function(P){C.removeProperty(P)});D.removeClass("overlay-header");D.find("#title-text").show();l=false;f=false;z.removeMainHeaderPlaceHolder()}}var M,L,J=D.outerHeight(),H=j-I,N=parseInt(D.css("top"))+H;if(I<=0){g=0;u=0;M=w}else{if(l&&H>0){if(N>w){g=w;u=0;M=w;L=b}else{g+=Math.abs(H);if(g>=y||I<=J){u-=Math.abs(H);M=N;L=b}}if(I>J+y&&!f){D.addClass("overlay-header");f=true}a=t}else{if(l&&H<0){if(N<w-J){g=0;u=J;M=w-J;L=0}else{u+=Math.abs(H);M=N}}}}if(L!==undefined&&M!==undefined){D.css({top:M+"px",zIndex:L})}else{if(M!==undefined){D.css({top:M+"px"})}}if(o){z.translateVertical(n,u,n.attr("id"))}z.updateTableStickyHeaderOption();j=I};function A(){if(!l||u===0){return}u=0;D.addClass("overlay-header");D.css({top:w+"px",zIndex:b});if(o){z.translateVertical(n,u,n.attr("id"))}z.updateTableStickyHeaderOption()}function p(){c();A();a=q}function k(){c();A();m.bind("quick-edit.viewport.saved",function(){E.removeAttr("style");z.removeMainHeaderPlaceHolder()});i(window).off("scroll",x).off("resize.confluence-fixed-headers-responsive");m.trigger("analyticsEvent",{name:"view.edit.transition.edit.button.clicked",data:{method:a}})}G.forceInitialize=function(){c(true)};G.onScrollHandler=x;G.onHoverActionMenuLinkHandler=p;G.onClickEditPageLinkHandler=k;G.isKeepDotDotDotButton=o;G.__getShowMainHeaderBy=function(){return a};G.__getFixedHeader=function(){return r};G.__getFixedMainHeader=function(){return l};G.__setFixedHeader=function(H){r=H};G.__setFixedMainHeader=function(H){l=H};G.__setMainHeaderOverlay=function(H){f=H};G.__setScrollPosition=function(H){j=H};G.__setMovingDistance=function(H){u=H}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-fixed-headers:confluence-fixed-headers-view-content-resources', location = '/js/confluence-fixed-headers.js' */
require(["confluence/fh/utils/dom","confluence/fh/handlers/page-view-handler","ajs","jquery"],function(d,b,a,c){a.toInit(function(){if(!a.Meta.get("content-type")){return}if(c("#main-content style").length>0){return}var e=c("#header"),l=c("#main-header"),i=c("#main"),g=c("#content"),k=c("#editPageLink"),m=c("#action-menu-link");var n=["inline-dialog-notifications-miniview","inline-dialog-confluence-watch","inline-dialog-shareContentPopup","inline-dialog-ap-inline-dialog-content-confstats-connect-dev__confstats-live-watcher","inline-dialog-jira-metadata-dialog"];var j=function(){var p=c('.aui-dropdown2[aria-hidden="false"]');p.length&&c('.aui-dropdown2-trigger[aria-owns="'+p.attr("id")+'"]').trigger("aui-button-invoke");var o=c(".aui-inline-dialog:visible");if(o.length){o=o.filter(function(){var s=c(this);var r=s.attr("id");return s.hasClass("non-persistence-dialog")||n.indexOf(r)!==-1});o.css({display:"none"});var q=".aui-button.active, .aui-nav-imagelink.active";e.find(q).removeClass("active");l.find(q).removeClass("active");document.activeElement.blur()}};var h=new MutationObserver(function(o){d.adjustMainHeaderSize()});h.observe(i[0],{attributes:true,attributeFilter:["style"]});var f=new MutationObserver(function(o){g.css("padding-right")==="0px"&&g.css({paddingRight:"28px"})});f.observe(g[0],{attributes:true,attributeFilter:["style"]});c(window).on("resize.confluence-fixed-headers-responsive",a.debounce(d.adjustMainHeaderSize,100)).on("scroll",b.onScrollHandler).scroll(a.debounceImmediate(j,250));if(b.isKeepDotDotDotButton){i.addClass("floating-action-menu");m.on("hover",b.onHoverActionMenuLinkHandler)}k.click(function(){f&&f.disconnect();b.onClickEditPageLinkHandler()});setTimeout(function(){d.scrollIfAnchor(window.location.hash)});c("body").on("click",'a[href^="#"]',d.scrollIfAnchor)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-like:content-like-resources', location = '/com/atlassian/confluence/plugins/like/js/like-namespace.js' */
define("confluence-like/like-namespace",["confluence/legacy"],function(a){return a.Likes||{}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-like/like-namespace","Confluence.Likes");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-like:content-like-resources', location = '/com/atlassian/confluence/plugins/like/js/like.js' */
define("confluence-like/like",["ajs","confluence/legacy","jquery","confluence/meta"],function(d,h,c,g){function o(b){return d.contextPath()+"/rest/likes/1.0/content/"+b+"/likes"}function r(){return 0<(g.get("remote-user")||"").length&&!1!==g.get("remote-user-has-licensed-access")}function p(b,a,e){var c=g.get("remote-user")||"",a=h.Likes.LikeSummaryFactory.getLikeSummary(b.likes,a,c);if(!a.key&&i()&&("page"==b.content_type||"blogpost"==b.content_type))a.text="Be the first to like this";c=[];
c.push(a.text);c=c.concat(a.args);(a=d.format.apply(d,c))&&0<a.length?e.html(a):e.empty();a&&(e.find(".likes").click(m.showLikeUsers),h.Binder.userHover(),"comment"==b.content_type&&e.prepend("<span class='comment-action-separator'>\u2022</span><span class='aui-icon aui-icon-small aui-iconfont-like-small'></span>"))}function l(b,a,e){var n=g.get("remote-user")||"";if(void 0===b)throw Error("type is required");if(void 0===a)throw Error("contentId is required");if(void 0===e)throw Error("contentType is required");
return function(){if("object"!==typeof this||!this.nodeType||1!==this.nodeType||"A"!==this.nodeName)throw Error("this handler should be bound to a DOM anchor element");var f=c(this),h=arguments.callee,i=f.next(".like-summary");c.ajax({type:b===j?"POST":"DELETE",url:o(a),contentType:"application/json",data:{"atlassian-token":g.get("atlassian-token")},dataType:"json",timeout:5E3}).fail(function(){var a=i.siblings(".like-error"),c;c=b===j?"Like failed":"Unlike failed";
0===a.length?i.after('<span class="like-error" title="'+c+'"></span>'):a.attr("title",c)}).success(function(){i.attr("data-liked",b===j);i.parent().find(".like-error").remove()});f.unbind("click",h).bind("click",b===j?l(q,a,e):l(j,a,e)).find(".like-button-text").html(b===j?"Unlike":"Like");k[a]=k[a]||{content_type:e,likes:[]};b===j?k[a].likes.push({user:{name:n}}):k[a].likes=c.grep(k[a].likes,function(a){return a.user.name!=n});b===j&&d.trigger("analytics",
{name:"confluence."+e+".like.create",data:{pageID:g.get("page-id")}});p(k[a],a,i);return!1}}var j=0,q=1,f,k={},i=r,s=c.Deferred(),m={getLikesCache:function(){return s.promise()},showLikeUsers:function(b){b&&b.preventDefault();b=c(this).data("content-id");f&&(f.remove(),f=void 0);f=new d.Dialog(400,365,"likes-dialog");f.addHeader("People who like this");f.addPanel("Panel 1","<div class='spinner-container'></div>");f.addCancel("Close",function(a){a.remove();f=
void 0});f.getCurrentPanel().setPadding(0);var a=f,e=f.show,n=d.dim;d.dim=function(){};try{e.apply(a,[])}finally{d.dim=n}c.ajax({type:"GET",url:o(b),data:{expand:"user",max:50},dataType:"json"}).done(function(a){if(f.popup.element.is(":visible")){a.showFollowActions=r();f.getCurrentPanel().html(h.Templates.Likes.likesDialog(a));c("#likes-dialog").find(".likes-dialog-follow-button").click(function(){var a=c(this);c.ajax({type:"PUT",url:d.contextPath()+"/rest/likes/1.0/user/"+g.get("remote-user")+"/following?username="+
a.data("username"),contentType:"application/json",dataType:"json"}).done(function(){a.replaceWith("Following")})})}})},appendAction:function(b){var b=b.find(".comment-actions-primary"),a=b.find("li[class~='comment-date']"),e=c(h.Templates.Likes.commentLikeSection({showLikeButton:i()}));0===a.length?b.find("li:last-child").after(e):a.before(e)},reload:function(b){c.each(b,function(a,b){var d=c("#comment-"+a).find(".like-summary");p(b,a,d);k[a]=b});!i()&&c("#page-comments").find(".like-summary:empty").each(function(){c(this).closest(".comment-action-like").hide()});
c("#page-comments .comment").each(function(){m.updateComment(c(this),b)});s.resolve(k)},updateComment:function(b,a){var e=b.attr("id");if(!e)return!0;var f=(/^comment-(\d+)$/.exec(e)||[])[1];if(!f)throw Error('Expecting ID attribute of comment to be in format "comment-XXX", found: '+e);e=a[f]&&g.get("remote-user")&&0<c.grep(a[f].likes,function(a){return a.user.name==g.get("remote-user")}).length;b.find(".like-button").click(e?l(q,f,"comment"):l(j,f,"comment")).find(".like-button-text").html(e?"Unlike":
"Like")},init:function(){var b=c(h.Templates.Likes.likeSection({showLikeButton:i()}));g.get("page-id")&&c.ajax({type:"GET",url:o(g.get("page-id")),data:{commentLikes:!0},dataType:"json"}).done(function(a){if(g.get("remote-user")){var e=0<c.grep(a.likes,function(a){return a.user.name==g.get("remote-user")}).length,f=a.content_type;b.find(".like-button").click(e?l(q,g.get("page-id"),f):l(j,g.get("page-id"),f)).find(".like-button-text").html(e?"Unlike":"Like")}e=
b.find(".like-summary");p(a,a.content_id,e);""==e.html()&&!i()&&b.hide();c("<div id='likes-and-labels-container' />").insertBefore("#labels-section").append(b).append(c("#labels-section"));k[a.content_id]=a;m.reload(a.commentLikes)});m.appendAction(c("#page-comments"))}};return m});
require("confluence/module-exporter").safeRequire("confluence-like/like",function(d){var h=require("confluence/legacy"),c=require("ajs");h.Likes.getLikesCache=d.getLikesCache;c.PageGadget||window.parent.AJS&&window.parent.AJS.PageGadget||(c.toInit(d.init),h.Likes.showLikeUsers=d.showLikeUsers,h.Likes.appendAction=d.appendAction,h.Likes.reload=d.reload,h.Likes.updateComment=d.updateComment)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-like:content-like-resources', location = '/com/atlassian/confluence/plugins/like/js/like-summary-factory.js' */
define("confluence-like/like-summary-factory",["ajs","confluence/templates","jquery"],function(a,g,h){var i={"likes.summary.you":"You like this","likes.summary.1.promoted":"{0} likes this","likes.summary.2.promoted":"{0} and {1} like this","likes.summary.3.promoted":"{0}, {1} and {2} like this","likes.summary.1.non-promoted":"{0} likes this","likes.summary.x.non-promoted":"\u003ca href=\"\" {1}\u003e{0} people\u003c/a\u003e like this",
"likes.summary.you.1.promoted":"You and {0} like this","likes.summary.you.2.promoted":"You, {0} and {1} like this","likes.summary.you.3.promoted":"You, {0}, {1} and {2} like this","likes.summary.you.1.non-promoted":"You and {0} like this","likes.summary.you.x.non-promoted":"You and \u003ca href=\"\" {1}\u003e{0} others\u003c/a\u003e like this","likes.summary.1.promoted.1.non-promoted":"{0} and {1} like this",
"likes.summary.1.promoted.x.non-promoted":"{0} and \u003ca href=\"\" {2}\u003e{1} others\u003c/a\u003e like this","likes.summary.2.promoted.1.non-promoted":"{0}, {1} and {2} like this","likes.summary.2.promoted.x.non-promoted":"{0}, {1} and \u003ca href=\"\" {3}\u003e{2} others\u003c/a\u003e like this","likes.summary.3.promoted.1.non-promoted":"{0}, {1}, {2} and {3} like this","likes.summary.3.promoted.x.non-promoted":"{0}, {1}, {2} and \u003ca href=\"\" {4}\u003e{3} others\u003c/a\u003e like this","likes.summary.you.1.promoted.1.non-promoted":"You, {0} and {1} like this",
"likes.summary.you.1.promoted.x.non-promoted":"You, {0} and \u003ca href=\"\" {2}\u003e{1} others\u003c/a\u003e like this","likes.summary.you.2.promoted.1.non-promoted":"You, {0}, {1} and {2} like this","likes.summary.you.2.promoted.x.non-promoted":"You, {0}, {1} and \u003ca href=\"\" {3}\u003e{2} others\u003c/a\u003e like this","likes.summary.you.3.promoted.1.non-promoted":"You, {0}, {1}, {2} and {3} like this","likes.summary.you.3.promoted.x.non-promoted":"You, {0}, {1}, {2} and \u003ca href=\"\" {4}\u003e{3} others\u003c/a\u003e like this"};
return{getLikeSummary:function(a,c,k){if(!a||0===a.length)return{key:"",text:""};if(!c)throw Error("contentId is required.");var j,e=[],f=[];h.each(a,function(a,b){b.user&&b.user.name==k?j=b:3>e.length&&b.user.followedByRemoteUser?e.push(b):f.push(b)});var a=["likes.summary"],d=[];null!=j&&a.push(".you");0<e.length&&(a.push("."),a.push(e.length),a.push(".promoted"),h.each(e,function(a,b){d.push(g.Likes.userLink(b))}));1===f.length?(a.push(".1.non-promoted"),d.push(g.Likes.userLink(f[0]))):1<f.length&&
(a.push(".x.non-promoted"),d.push(f.length),d.push('class="likes" data-content-id="'+c+'"'));c=a.join("");return{key:c,args:0===d.length?void 0:d,text:c in i?i[c]:""}}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-like/like-summary-factory","Confluence.Likes.LikeSummaryFactory");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-like:content-like-resources', location = '/templates/com/atlassian/confluence/plugins/like/soy/like.soy' */
// This file was automatically generated from like.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Likes.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Likes == 'undefined') { Confluence.Templates.Likes = {}; }


Confluence.Templates.Likes.likeButton = function(opt_data, opt_ignored) {
  return '<a href="" class="like-button">' + ((opt_data.useIcon) ? '<span class="aui-icon aui-icon-small aui-iconfont-like"></span>' : '') + '<span class="like-button-text">' + soy.$$escapeHtml("Like") + '</span></a>';
};
if (goog.DEBUG) {
  Confluence.Templates.Likes.likeButton.soyTemplateName = 'Confluence.Templates.Likes.likeButton';
}


Confluence.Templates.Likes.likeSection = function(opt_data, opt_ignored) {
  return '<div id="likes-section">' + ((opt_data.showLikeButton) ? Confluence.Templates.Likes.likeButton({useIcon: true}) : '') + '<span class="like-summary"></span></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Likes.likeSection.soyTemplateName = 'Confluence.Templates.Likes.likeSection';
}


Confluence.Templates.Likes.commentLikeSection = function(opt_data, opt_ignored) {
  return '<li class="comment-action-like">' + ((opt_data.showLikeButton) ? Confluence.Templates.Likes.likeButton({useIcon: false}) : '') + '<span class="like-summary"></span></li>';
};
if (goog.DEBUG) {
  Confluence.Templates.Likes.commentLikeSection.soyTemplateName = 'Confluence.Templates.Likes.commentLikeSection';
}


Confluence.Templates.Likes.likesDialog = function(opt_data, opt_ignored) {
  var output = '<div id="likes-dialog-body"><ol>';
  var likeList26 = opt_data.likes;
  var likeListLen26 = likeList26.length;
  for (var likeIndex26 = 0; likeIndex26 < likeListLen26; likeIndex26++) {
    var likeData26 = likeList26[likeIndex26];
    output += '<li><div class="avatar-container"><a href="' + soy.$$escapeHtml(likeData26.user.url) + '"><img class="like-user-avatar" src="' + soy.$$escapeHtml(likeData26.user.avatarUrl) + '"></a></div><div class="like-user"><a class="like-user-link" href="' + soy.$$escapeHtml(likeData26.user.url) + '">' + soy.$$escapeHtml(likeData26.user.fullName) + '</a></div>' + ((opt_data.showFollowActions) ? '<div class="follow-button-container aui-toolbar"><ul class="toolbar-group"><li class="toolbar-item">' + ((likeData26.user.followedByRemoteUser) ? soy.$$escapeHtml("Following") : '<button data-username="' + soy.$$escapeHtml(likeData26.user.name) + '" class="likes-dialog-follow-button toolbar-trigger">' + soy.$$escapeHtml("Follow") + '</button>') + '</li></ul></div>' : '') + '</li>';
  }
  output += '</ol></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Likes.likesDialog.soyTemplateName = 'Confluence.Templates.Likes.likesDialog';
}


Confluence.Templates.Likes.userLink = function(opt_data, opt_ignored) {
  return '<a href="' + soy.$$escapeHtml(opt_data.user.url) + '" class="confluence-userlink" data-username="' + soy.$$escapeHtml(opt_data.user.name) + '">' + soy.$$escapeHtml(opt_data.user.fullName) + '</a>';
};
if (goog.DEBUG) {
  Confluence.Templates.Likes.userLink.soyTemplateName = 'Confluence.Templates.Likes.userLink';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:shared-templates', location = '/includes/soy/user.soy' */
// This file was automatically generated from user.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.User.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.User == 'undefined') { Confluence.Templates.User = {}; }


Confluence.Templates.User.userLinkUrl = function(opt_data, opt_ignored) {
  return soy.$$escapeHtml("/confluence") + '/display/~' + soy.$$escapeUri(opt_data.username);
};
if (goog.DEBUG) {
  Confluence.Templates.User.userLinkUrl.soyTemplateName = 'Confluence.Templates.User.userLinkUrl';
}


Confluence.Templates.User.logo = function(opt_data, opt_ignored) {
  return '' + ((opt_data.profilePictureInfo['default'] && opt_data.username == opt_data.currentUsername) ? '<a ' + ((opt_data.canView) ? ' ' + ((! opt_data.disableUserHover) ? 'class="userLogoLink"' : '') + ' data-username="' + soy.$$escapeHtml(opt_data.username) + '"' : '') + ' href="' + soy.$$escapeHtml("/confluence") + '/users/profile/editmyprofilepicture.action" title="' + soy.$$escapeHtml("Add a picture of yourself") + '"><img class="userLogo logo defaultLogo" src="' + soy.$$escapeHtml("/confluence/s/en_GB/6220/de9b463eb65c5ca13c0266eed77e2bf49f4c6fe8.70/_") + '/images/icons/profilepics/add_profile_pic.png" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml("Add a picture of yourself") + '"></a>' : (opt_data.profilePictureInfo.anonymous) ? '<img class="userLogo logo anonymous" src="' + soy.$$escapeHtml("/confluence/s/en_GB/6220/de9b463eb65c5ca13c0266eed77e2bf49f4c6fe8.70/_") + '/images/icons/profilepics/anonymous.png" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml("Anonymous") + '" title="' + soy.$$escapeHtml("Anonymous") + '">' : (opt_data.canView) ? '<a ' + ((! opt_data.disableUserHover) ? 'class="userLogoLink"' : '') + ' data-username="' + soy.$$escapeHtml(opt_data.username) + '" href="' + Confluence.Templates.User.userLinkUrl(opt_data) + '"><img class="userLogo logo" src="' + soy.$$escapeHtml("/confluence") + soy.$$escapeHtml(opt_data.profilePictureInfo.downloadPath) + '" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml(opt_data.username) + '" title="' + soy.$$escapeHtml(opt_data.username) + '"></a>' : '<img class="userLogo logo anonymous" src="' + soy.$$escapeHtml("/confluence/s/en_GB/6220/de9b463eb65c5ca13c0266eed77e2bf49f4c6fe8.70/_") + '/images/icons/profilepics/anonymous.png" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml(opt_data.username) + '" title="' + soy.$$escapeHtml(opt_data.username) + '">');
};
if (goog.DEBUG) {
  Confluence.Templates.User.logo.soyTemplateName = 'Confluence.Templates.User.logo';
}


Confluence.Templates.User.usernameLink = function(opt_data, opt_ignored) {
  return '' + ((opt_data.username && opt_data.username != '') ? '<a href="' + Confluence.Templates.User.userLinkUrl(opt_data) + '"' + ((opt_data.canView) ? 'class="url fn confluence-userlink" data-username="' + soy.$$escapeHtml(opt_data.username) + '"' : 'class="url fn"') + '>' + ((opt_data.fullName && opt_data.fullName != '') ? soy.$$escapeHtml(opt_data.fullName) : soy.$$escapeHtml(opt_data.username)) + '</a>' : soy.$$escapeHtml("Anonymous"));
};
if (goog.DEBUG) {
  Confluence.Templates.User.usernameLink.soyTemplateName = 'Confluence.Templates.User.usernameLink';
}


Confluence.Templates.User.fullNameOrAnonymous = function(opt_data, opt_ignored) {
  return '' + ((opt_data.user && opt_data.user.fullName) ? soy.$$escapeHtml(opt_data.user.fullName) : soy.$$escapeHtml("Anonymous"));
};
if (goog.DEBUG) {
  Confluence.Templates.User.fullNameOrAnonymous.soyTemplateName = 'Confluence.Templates.User.fullNameOrAnonymous';
}


Confluence.Templates.User.usernameOrAnonymous = function(opt_data, opt_ignored) {
  return '' + ((opt_data.user && opt_data.user.name) ? soy.$$escapeHtml(opt_data.user.name) : soy.$$escapeHtml("Anonymous"));
};
if (goog.DEBUG) {
  Confluence.Templates.User.usernameOrAnonymous.soyTemplateName = 'Confluence.Templates.User.usernameOrAnonymous';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:shared-templates', location = '/includes/soy/icons.soy' */
// This file was automatically generated from icons.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Icons.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Icons == 'undefined') { Confluence.Templates.Icons = {}; }


Confluence.Templates.Icons.contentIcon = function(opt_data, opt_ignored) {
  return '' + ((opt_data.content.type == 'trackback') ? '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="icon icon-trackback" title="' + soy.$$escapeHtml("Track back") + '">' + soy.$$escapeHtml("Track back") + ':</a>' : '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="icon ' + soy.$$escapeHtml(opt_data.iconCss) + '" title="' + soy.$$escapeHtml(opt_data.iconTitle) + '">' + soy.$$escapeHtml(opt_data.iconTitle) + '</a>');
};
if (goog.DEBUG) {
  Confluence.Templates.Icons.contentIcon.soyTemplateName = 'Confluence.Templates.Icons.contentIcon';
}


Confluence.Templates.Icons.contentIconFont = function(opt_data, opt_ignored) {
  return '' + ((opt_data.content.type == 'trackback') ? '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="icon icon-trackback" title="' + soy.$$escapeHtml("Track back") + '">' + soy.$$escapeHtml("Track back") + ':</a>' : '<a' + ((opt_data.linkColour) ? ' ' + soy.$$escapeHtml(opt_data.linkColour) : '') + ' href="' + soy.$$escapeHtml(opt_data.linkHref) + '" title="' + soy.$$escapeHtml(opt_data.iconTitle) + '"><span class="icon ' + soy.$$escapeHtml(opt_data.iconCss) + '">' + soy.$$escapeHtml(opt_data.iconTitle) + '</span></a>');
};
if (goog.DEBUG) {
  Confluence.Templates.Icons.contentIconFont.soyTemplateName = 'Confluence.Templates.Icons.contentIconFont';
}


Confluence.Templates.Icons.iconSpan = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<span class="icon' + ((opt_data.type) ? ' icon-' + soy.$$escapeHtml(opt_data.type) : '') + ' ' + ((opt_data.additionalClasses) ? soy.$$escapeHtml(opt_data.additionalClasses) : '') + '">' + ((opt_data.text) ? soy.$$escapeHtml(opt_data.text) : '') + '</span>';
};
if (goog.DEBUG) {
  Confluence.Templates.Icons.iconSpan.soyTemplateName = 'Confluence.Templates.Icons.iconSpan';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:shared-templates', location = '/includes/soy/captcha.soy' */
// This file was automatically generated from captcha.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Captcha.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Captcha == 'undefined') { Confluence.Templates.Captcha = {}; }


Confluence.Templates.Captcha.form = function(opt_data, opt_ignored) {
  var output = '<div class="captcha field-group"><label id="captcha-response-label" for="captcha-response"><span class="assistive">' + soy.$$escapeHtml("If you are unable to use this CAPTCHA please \x3ca href\x3d\x22administrators.action\x22 tabindex\x3d\x225\x22\x3econtact your administrator\x3c/a\x3e for assistance.") + '</span></label>' + Confluence.Templates.Captcha.image(opt_data) + '<input type="text" id="captcha-response" name="captchaResponse" value="" class="text" placeholder="' + soy.$$escapeHtml("Type the word above") + '">';
  if (opt_data.captchaErrors && opt_data.captchaErrors.length) {
    var errorList13 = opt_data.captchaErrors;
    var errorListLen13 = errorList13.length;
    for (var errorIndex13 = 0; errorIndex13 < errorListLen13; errorIndex13++) {
      var errorData13 = errorList13[errorIndex13];
      output += aui.message.warning({content: errorData13});
    }
  }
  output += '</div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Captcha.form.soyTemplateName = 'Confluence.Templates.Captcha.form';
}


Confluence.Templates.Captcha.image = function(opt_data, opt_ignored) {
  return '<img src="' + soy.$$escapeHtml("/confluence") + '/jcaptcha?id=' + soy.$$escapeHtml(opt_data.captchaId) + '" class="captcha-image" alt="' + soy.$$escapeHtml("CAPTCHA image") + '"><input type="hidden" name="captchaId" value="' + soy.$$escapeHtml(opt_data.captchaId) + '" placeholder="' + soy.$$escapeHtml("Type the word above") + '">';
};
if (goog.DEBUG) {
  Confluence.Templates.Captcha.image.soyTemplateName = 'Confluence.Templates.Captcha.image';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:shared-templates', location = '/includes/soy/notifications.soy' */
// This file was automatically generated from notifications.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Notifications.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Notifications == 'undefined') { Confluence.Templates.Notifications = {}; }


Confluence.Templates.Notifications.notLoggedIn = function(opt_data, opt_ignored) {
  return '' + ((! opt_data.isUserAuthenticated) ? '<div id="anonymous-warning" class="aui-message warning closeable">' + soy.$$filterNoAutoescape("You are not logged in. Any changes you make will be marked as \x3cspan class\x3d\x22smalltext\x22\x3eanonymous\x3c/span\x3e.") + ((! opt_data.isExternalUserManagementEnabled) ? ' ' + soy.$$filterNoAutoescape(AJS.format("You may want to \x3ca href\x3d\x22{0}\x22\x3eLog In\x3c/a\x3e if you already have an account.",opt_data.loginURL)) : '') + '</div>' : '');
};
if (goog.DEBUG) {
  Confluence.Templates.Notifications.notLoggedIn.soyTemplateName = 'Confluence.Templates.Notifications.notLoggedIn';
}


Confluence.Templates.Notifications.actionErrors = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.actionErrors.length > 0) {
    output += '<div class="aui-message aui-message-error ' + ((opt_data.closeable) ? 'closeable' : '') + '"><p class="title">' + soy.$$escapeHtml("The following error(s) occurred:") + '</p><span class="aui-icon icon-error"></span><ul>';
    var errorHtmlList24 = opt_data.actionErrors;
    var errorHtmlListLen24 = errorHtmlList24.length;
    for (var errorHtmlIndex24 = 0; errorHtmlIndex24 < errorHtmlListLen24; errorHtmlIndex24++) {
      var errorHtmlData24 = errorHtmlList24[errorHtmlIndex24];
      output += '<li>' + soy.$$filterNoAutoescape(errorHtmlData24) + '</li>';
    }
    output += '</ul></div>';
  }
  output += '<div id="action-messages"></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Notifications.actionErrors.soyTemplateName = 'Confluence.Templates.Notifications.actionErrors';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.browser.metrics.browser-metrics-plugin:api', location = 'browser-metrics.js' */
(function(){
/*!
 * @overview es6-promise - a tiny implementation of Promises/A+.
 * @copyright Copyright (c) 2014 Yehuda Katz, Tom Dale, Stefan Penner and contributors (Conversion to ES6 API by Jake Archibald)
 * @license   Licensed under MIT license
 *            See https://raw.githubusercontent.com/jakearchibald/es6-promise/master/LICENSE
 * @version   2.0.0
 */
var j,y,e,r,p,x,F,G,u,q,H,K,J,s,i,f,m,D,v,n,L,B,O,l,z,h,g,C,o,d,w,c,Q,I,a,E,b,M,N,t,P;(function(){function aL(a3){return typeof a3==="function"||typeof a3==="object"&&a3!==null}function aj(a3){return typeof a3==="function"}function a1(a3){return typeof a3==="object"&&a3!==null}var aY;if(!Array.isArray){aY=function(a3){return Object.prototype.toString.call(a3)==="[object Array]"}}else{aY=Array.isArray}var aD=aY;var ao=Date.now||function(){return new Date().getTime()};function ar(){}var W=Object.create||function(a3){if(arguments.length>1){throw new Error("Second argument not supported")}if(typeof a3!=="object"){throw new TypeError("Argument must be an object")}ar.prototype=a3;return new ar()};var aW=0;var af=function aJ(a4,a3){aV[aW]=a4;aV[aW+1]=a3;aW+=2;if(aW===2){T()}};var aC=typeof window!=="undefined"?window:{};var am=aC.MutationObserver||aC.WebKitMutationObserver;var ae=typeof Uint8ClampedArray!=="undefined"&&typeof importScripts!=="undefined"&&typeof MessageChannel!=="undefined";function aG(){return function(){process.nextTick(aX)}}function aR(){var a5=0;var a3=new am(aX);var a4=document.createTextNode("");a3.observe(a4,{characterData:true});return function(){a4.data=a5=++a5%2}}function aH(){var a3=new MessageChannel();a3.port1.onmessage=aX;return function(){a3.port2.postMessage(0)}}function aN(){return function(){setTimeout(aX,1)}}var aV=new Array(1000);function aX(){for(var a4=0;a4<aW;a4+=2){var a5=aV[a4];var a3=aV[a4+1];a5(a3);aV[a4]=undefined;aV[a4+1]=undefined}aW=0}var T;if(typeof process!=="undefined"&&{}.toString.call(process)==="[object process]"){T=aG()}else{if(am){T=aR()}else{if(ae){T=aH()}else{T=aN()}}}function ah(){}var at=void 0;var aO=1;var au=2;var aU=new a0();function aS(){return new TypeError("You cannot resolve a promise with itself")}function aB(){return new TypeError("A promises callback cannot return that same promise.")}function aK(a4){try{return a4.then}catch(a3){aU.error=a3;return aU}}function V(a7,a5,a4,a3){try{a7.call(a5,a4,a3)}catch(a6){return a6}}function aM(a5,a3,a4){af(function(a8){var a7=false;var a6=V(a4,a3,function(a9){if(a7){return}a7=true;if(a3!==a9){ac(a8,a9)}else{ab(a8,a9)}},function(a9){if(a7){return}a7=true;aA(a8,a9)},"Settle: "+(a8._label||" unknown promise"));if(!a7&&a6){a7=true;aA(a8,a6)}},a5)}function X(a4,a3){if(a3._state===aO){ab(a4,a3._result)}else{if(a4._state===au){aA(a4,a3._result)}else{a2(a3,undefined,function(a5){ac(a4,a5)},function(a5){aA(a4,a5)})}}}function Y(a5,a3){if(a3.constructor===a5.constructor){X(a5,a3)}else{var a4=aK(a3);if(a4===aU){aA(a5,aU.error)}else{if(a4===undefined){ab(a5,a3)}else{if(aj(a4)){aM(a5,a3,a4)}else{ab(a5,a3)}}}}}function ac(a4,a3){if(a4===a3){aA(a4,aS())}else{if(aL(a3)){Y(a4,a3)}else{ab(a4,a3)}}}function aF(a3){if(a3._onerror){a3._onerror(a3._result)}aa(a3)}function ab(a4,a3){if(a4._state!==at){return}a4._result=a3;a4._state=aO;if(a4._subscribers.length===0){}else{af(aa,a4)}}function aA(a4,a3){if(a4._state!==at){return}a4._state=au;a4._result=a3;af(aF,a4)}function a2(a3,a8,a7,a6){var a5=a3._subscribers;var a4=a5.length;a3._onerror=null;a5[a4]=a8;a5[a4+aO]=a7;a5[a4+au]=a6;if(a4===0&&a3._state){af(aa,a3)}}function aa(a7){var a6=a7._subscribers;var a3=a7._state;if(a6.length===0){return}var a9,a8,a5=a7._result;for(var a4=0;a4<a6.length;a4+=3){a9=a6[a4];a8=a6[a4+a3];if(a9){aQ(a3,a9,a8,a5)}else{a8(a5)}}a7._subscribers.length=0}function a0(){this.error=null}var ai=new a0();function az(a5,a3){try{return a5(a3)}catch(a4){ai.error=a4;return ai}}function aQ(a9,bb,a8,a5){var a3=aj(a8),a7,a6,ba,a4;if(a3){a7=az(a8,a5);if(a7===ai){a4=true;a6=a7.error;a7=null}else{ba=true}if(bb===a7){aA(bb,aB());return}}else{a7=a5;ba=true}if(bb._state!==at){}else{if(a3&&ba){ac(bb,a7)}else{if(a4){aA(bb,a6)}else{if(a9===aO){ab(bb,a7)}else{if(a9===au){aA(bb,a7)}}}}}}function Z(a7,a6){try{a6(function a3(a8){ac(a7,a8)},function a5(a8){aA(a7,a8)})}catch(a4){aA(a7,a4)}}function aZ(a5,a3,a4){if(a5===aO){return{state:"fulfilled",value:a4}}else{return{state:"rejected",reason:a4}}}function aT(a5,a3,a6,a4){this._instanceConstructor=a5;this.promise=new a5(ah,a4);this._abortOnReject=a6;if(this._validateInput(a3)){this._input=a3;this.length=a3.length;this._remaining=a3.length;this._init();if(this.length===0){ab(this.promise,this._result)}else{this.length=this.length||0;this._enumerate();if(this._remaining===0){ab(this.promise,this._result)}}}else{aA(this.promise,this._validationError())}}aT.prototype._validateInput=function(a3){return aD(a3)};aT.prototype._validationError=function(){return new Error("Array Methods must be provided an Array")};aT.prototype._init=function(){this._result=new Array(this.length)};var aE=aT;aT.prototype._enumerate=function(){var a5=this.length;var a6=this.promise;var a3=this._input;for(var a4=0;a6._state===at&&a4<a5;a4++){this._eachEntry(a3[a4],a4)}};aT.prototype._eachEntry=function(a4,a3){var a5=this._instanceConstructor;if(a1(a4)){if(a4.constructor===a5&&a4._state!==at){a4._onerror=null;this._settledAt(a4._state,a3,a4._result)}else{this._willSettleAt(a5.resolve(a4),a3)}}else{this._remaining--;this._result[a3]=this._makeResult(aO,a3,a4)}};aT.prototype._settledAt=function(a5,a3,a4){var a6=this.promise;if(a6._state===at){this._remaining--;if(this._abortOnReject&&a5===au){aA(a6,a4)}else{this._result[a3]=this._makeResult(a5,a3,a4)}}if(this._remaining===0){ab(a6,this._result)}};aT.prototype._makeResult=function(a5,a3,a4){return a4};aT.prototype._willSettleAt=function(a4,a3){var a5=this;a2(a4,undefined,function(a6){a5._settledAt(aO,a3,a6)},function(a6){a5._settledAt(au,a3,a6)})};var ap=function an(a3,a4){return new aE(this,a3,true,a4).promise};var av=function ad(a3,a4){var ba=this;var a9=new ba(ah,a4);if(!aD(a3)){aA(a9,new TypeError("You must pass an array to race."));return a9}var a6=a3.length;function a8(bb){ac(a9,bb)}function a7(bb){aA(a9,bb)}for(var a5=0;a9._state===at&&a5<a6;a5++){a2(ba.resolve(a3[a5]),undefined,a8,a7)}return a9};var al=function aq(a4,a3){var a6=this;if(a4&&typeof a4==="object"&&a4.constructor===a6){return a4}var a5=new a6(ah,a3);ac(a5,a4);return a5};var S=function ax(a4,a3){var a6=this;var a5=new a6(ah,a3);aA(a5,a4);return a5};var ay=0;function aP(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function ag(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}var aI=U;function U(a3){this._id=ay++;this._state=undefined;this._result=undefined;this._subscribers=[];if(ah!==a3){if(!aj(a3)){aP()}if(!(this instanceof U)){ag()}Z(this,a3)}}U.all=ap;U.race=av;U.resolve=al;U.reject=S;U.prototype={constructor:U,then:function(a7,a6){var a4=this;var a5=a4._state;if(a5===aO&&!a7||a5===au&&!a6){return this}var a9=new this.constructor(ah);var a3=a4._result;if(a5){var a8=arguments[a5-1];af(function(){aQ(a5,a9,a8,a3)})}else{a2(a4,a9,a7,a6)}return a9},"catch":function(a3){return this.then(null,a3)}};var ak=function R(){var a4;if(typeof global!=="undefined"){a4=global}else{if(typeof window!=="undefined"&&window.document){a4=window}else{a4=self}}var a3="Promise" in a4&&"resolve" in a4.Promise&&"reject" in a4.Promise&&"all" in a4.Promise&&"race" in a4.Promise&&function(){var a5;new a4.Promise(function(a6){a5=a6});return aj(a5)}();if(!a3){a4.Promise=aI}};var aw={Promise:aI,polyfill:ak};if(true){j=function(){return aw}()}else{if(typeof module!=="undefined"&&module.exports){module.exports=aw}else{if(typeof this!=="undefined"){this["ES6Promise"]=aw}}}}.call(this));y=function(S){var R=S.Promise;return R}(j);e=function(){return window}();r=function(T){var S=T.HTMLElement.prototype;var R=S.matches||S.msMatchesSelector||S.webkitMatchesSelector||S.mozMatchesSelector||S.oMatchesSelector;return R}(e);p=function k(R){var S=false;return function(){if(!S){S=true;setTimeout(function(){S=false;R()},1)}}};x=function(R,U){function T(X){this.callback=X;this.elements=[]}T.prototype={observe:function(ae,am){function Y(an){al.push(an);X()}function ak(ap){var ao=ap.target;if(!ao){return}var an=ao.parentNode;if(!af(an)){return}if(aj&&W(aj,ao)){return}if(!ah||ah.target!==an){ag.push(ah=V(an))}if(an){if(!ah.addedNodes){ah.addedNodes=[]}ah.addedNodes.push(ao)}else{if(!ah.removedNodes){ah.removedNodes=[]}ah.removedNodes.push(ao)}aj=ao}function ad(an){return am.attributes&&(am.subtree||an===ae)}function af(an){return am.childList&&(am.subtree||an===ae)}var ab=this;var aj;var ah;var al=[];var ag=[];var X=R(function(){var an=al.length;for(var ao=0;ao<an;ao++){ak(al[ao])}ab.callback(ag);al=[];ag=[];aj=undefined;ah=undefined});var ai={};var aa=[];var ac=R(function(){var an=aa.length;ab.callback(aa);aa.splice(0,an)});var Z={target:ae,options:am,insertHandler:Y,removeHandler:Y,attributeHandler:function(at){var aq=at.target;if(!ad(aq)){return}var ao=at.attrName;var ap=at.prevValue;var ar=at.newValue;var an=V(aq,"attributes");an.attributeName=ao;if(am.attributeOldValue){an.oldValue=ai[ao]||ap||null}aa.push(an);if(am.attributeOldValue){ai[ao]=ar}ac()}};this.elements.push(Z);if(am.childList){ae.addEventListener("DOMNodeInserted",Z.insertHandler);ae.addEventListener("DOMNodeRemoved",Z.removeHandler)}if(am.attributes){ae.addEventListener("DOMAttrModified",Z.attributeHandler)}return this},disconnect:function(){this.elements.forEach(function(X){X.target.removeEventListener("DOMNodeInserted",X.insertHandler);X.target.removeEventListener("DOMNodeRemoved",X.removeHandler);X.target.removeEventListener("DOMAttrModified",X.attributeHandler)});this.elements=[];return this}};function V(Y,X){return{addedNodes:null,attributeName:null,attributeNamespace:null,nextSibling:null,oldValue:null,previousSibling:null,removedNodes:null,target:Y,type:X||"childList"}}var S=U.HTMLElement.prototype.contains;function W(X,Y){if(X.nodeType!==1){return false}return X.contains?X.contains(Y):S.call(X,Y)}return T}(p,e);F=function(S,R){return R.MutationObserver||R.WebkitMutationObserver||R.MozMutationObserver||S}(x,e);G=function(){function R(){this._items={};this.length=0}R.prototype.add=function(T,S){if(!this._items.hasOwnProperty(T)){this.length++;this._items[T]=[]}this._items[T].push(S)};R.prototype.remove=function(V,T){var S,U=false;if(this._items.hasOwnProperty(V)){if(arguments.length===1){delete this._items[V];U=true}else{S=this._items[V].indexOf(T);if(S>-1){this._items[V].splice(S,1);if(this._items[V].length===0){delete this._items[V]}U=true}}}return U};R.prototype.get=function(S){if(this._items.hasOwnProperty(S)){return this._items[S]}return[]};R.prototype.forEach=function(T){var S=this._items;Object.keys(S).forEach(function(U){T(S[U],U)})};return R}();u=function(aa,ab,T,V,X){var Z,U=false,W;W=new V();function S(ac,ad){if(!U){Z.observe(X.document,{attributes:true,childList:true,subtree:true});U=true}W.add(ac,ad)}function Y(ac,ad){W.remove.apply(W,arguments);if(W.length===0){Z.disconnect();U=false}}Z=new T(function(ac){ac.forEach(function(ae){var ad=ae.type==="childList"&&ae.addedNodes&&ae.addedNodes.length>0;var af=ae.type==="attributes";if(!ad&&!af){return}W.forEach(function(ah,ag){if(ae.target.querySelector(ag)||ab.call(ae.target,ag)){ah.forEach(function(ai){ai()});Y(ag)}})})});function R(ad){var ae;if(!ad.forEach){ad=[ad]}var ac=new aa(function(ai,ah){var aj=[];var af=[];ad.forEach(function(ak){var am;var al;if(!X.document.querySelector(ak)){am=new aa(function(an){S(ak,an);al=function(){Y(ak,an)}});aj.push(am);af.push(al)}});function ag(){af.forEach(function(ak){ak()})}aa.all(aj).then(ag).then(ai,ah);ae=function(){ag();ah()}});ac.dismiss=ae;return ac}return R}(y,r,F,G,e);q=function(aa,ab,S,U,X){var Z,T=false,W;W=new U();function R(ac,ad){if(!T){Z.observe(X.document,{childList:true,subtree:true});T=true}W.add(ac,ad)}function Y(ac,ad){W.remove.apply(W,arguments);if(W.length===0){Z.disconnect();T=false}}Z=new S(function(ac){ac.forEach(function(ad){var ae=ad.type==="childList"&&ad.removedNodes&&ad.removedNodes.length>0;if(ae){W.forEach(function(ai,af){var aj;for(var ah=0;ah<ad.removedNodes.length;ah++){aj=ad.removedNodes[ah];if(aj.querySelector&&(aj.querySelector(af)||ab.call(aj,af))){for(var ag=0;ag<ai.length;ag++){ai[ag]()}Y(af)}}})}})});function V(ad){var ae;if(!ad.forEach){ad=[ad]}var ac=new aa(function(ai,ah){var aj=[];var af=[];ad.forEach(function(ak){var am;var al;if(X.document.querySelector(ak)){am=new aa(function(an){R(ak,an);al=function(){Y(ak,an)}});aj.push(am);af.push(al)}});function ag(){af.forEach(function(ak){ak()})}aa.all(aj).then(ag).then(ai,ah);ae=function(){ag();ah()}});ac.dismiss=ae;return ac}return V}(y,r,F,G,e);H=function(){var S={};var T={};var R=function(U,W,V){if(!T.hasOwnProperty(U)){T[U]=[]}if(W){T[U].push({callback:W,once:V})}};S.on=function(U,V){R(U,V,false)};S.one=function(U,V){R(U,V,true)};S.trigger=function(U,V){var W=[];(T[U]||[]).forEach(function(X){X.callback.apply(undefined,[V]);if(!X.once){W.push(X)}});if(W.length===0){delete T[U]}else{T[U]=W}};return S}();K=function(R){return function S(){return R.performance&&R.performance.navigation&&R.performance.timing&&typeof R.performance.timing.navigationStart!=="undefined"}}(e);J=function(S){function R(U,T){return new S(function(W){var X;function V(){var Y=U();if(Y!==undefined){clearInterval(X);W(Y)}}X=setInterval(V,T);V()})}return R}(y);s=function(V,Y,W,T){var U=["unloadEventStart","unloadEventEnd","redirectStart","redirectEnd","fetchStart","domainLookupStart","domainLookupEnd","connectStart","connectEnd","secureConnectionStart","requestStart","responseStart","responseEnd","domLoading","domInteractive","domContentLoadedEventStart","domContentLoadedEventEnd","domComplete","loadEventStart","loadEventEnd"];function R(){var Z=V.performance.timing.loadEventEnd>0;var aa={};if(Z){U.forEach(function ab(ac){var ad=V.performance.timing[ac];var ae=ad>0;if(ae){aa[ac]=ad-V.performance.timing.navigationStart}});return aa}}var X;function S(){if(!Y()){return W.reject("The navigation timing API is required to produce a report for this navigation.")}if(typeof X==="undefined"){X=T(R,250)}return X}return S}(e,K,y,J);i=function(T,S,U){function R(V){return S().then(function(){var W=V.isInitial?T.performance.timing.navigationStart:V.start;return{readyForUser:Math.round(V.end-W)}})}return R}(e,s,y);f=function(S){return function R(T){return S(T).then(function(U){var V;var X=T.threshold;var W=T.threshold*4;if(U.readyForUser<X){V=1}else{if(U.readyForUser<W){V=0.5}else{V=0}}return{apdex:V}})}}(i);m=function(V,U,Y){function X(){return T().then(function(Z){return{firstPaint:Math.round(Z)}},function(){return{}})}function R(){return V.chrome&&V.chrome.loadTimes}function W(){return typeof V.performance.timing.msFirstPaint!=="undefined"}function S(){if(R()&&V.chrome.loadTimes().firstPaintTime>0){return V.chrome.loadTimes().firstPaintTime*1000-V.performance.timing.navigationStart}else{if(W()&&V.performance.timing.msFirstPaint>0){return V.performance.timing.msFirstPaint-V.performance.timing.navigationStart}}}function T(){if(R()||W()){return U(S,250)}else{return Y.reject("The browser does not have a first paint metric")}}return X}(e,J,y);D=function A(R){return{isInitial:R.isInitial}};v=function(T,U){var V="browser-metrics-journey";function S(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(Y){var X=T.Math.random()*16|0;var W=Y==="x"?X:X&3|8;return W.toString(16)})}function R(){if(typeof T.sessionStorage==="undefined"){return U.reject("sessionStorage is required to produce a report for this navigation.")}if(T.sessionStorage.getItem(V)===null){T.sessionStorage.setItem(V,S())}return U.resolve({journeyId:T.sessionStorage.getItem(V)})}return R}(e,y);n=function(){function R(S){return{key:S.key}}return R}();L=function(S,T){function R(V){var U={};if(V.isInitial&&T()){U.navigationType=S.performance.navigation.type}return U}return R}(e,K);B=function(S,U,T){function R(W){var V={};if(W.isInitial){if(!U()){return T.reject("The navigation timing API is required to produce a report for this navigation.")}if(S.performance.navigation.redirectCount>0){V.redirectCount=S.performance.navigation.redirectCount}}return T.resolve(V)}return R}(e,K,y);O=function(R){function S(U){var T=R.document.createElement("a");T.href=U;return T.href}return S}(e);l=function(V,S,U){function R(){var W=U.document.querySelectorAll("script[src][async]");return Array.prototype.map.call(W,function(X){return V(X.src)})}function T(){var W=R();function X(Z){return U.performance.getEntriesByType("resource").filter(function ab(ac){return ac.initiatorType==="link"||ac.initiatorType==="script"}).filter(function aa(ac){return ac.responseEnd<Z.domContentLoadedEventStart}).filter(function Y(ac){return ac.initiatorType!=="script"||W.indexOf(ac.name)===-1})}return S().then(X)}return T}(O,s,e);z=function(T,U,S){function R(W){if(!W.isInitial){return{}}return S().then(function V(ac){var ab=ac.map(function Y(ae){return ae.responseEnd}).map(function aa(ae){return Math.round(ae)}).reduce(function Z(af,ae){return Math.max(af,ae)},0);var ad=ac.map(function X(ae){return ae.duration}).map(function aa(ae){return Math.round(ae)});return{resourceLoadedEnd:ab,resourceDurations:JSON.stringify(ad)}})}return R}(e,y,l);h=function(){function R(S){return{threshold:S.threshold}}return R}();g=function(R){function S(T){if(!T.isInitial){return{}}return R()}return S}(s);C=function(R){function S(){return{userAgent:R.navigator.userAgent}}return S}(e);o=function(Y,ab,Z,V,T,aa,ac,S,ad,X,U,W){var R=[Y,ab,Z,V,T,aa,ac,S,ad,X,U,W];return{get:function(){return R.concat()},add:function(ae){R.push(ae)}}}(f,m,D,v,n,L,i,B,z,h,g,C);d=function(){var R=Object.prototype.hasOwnProperty;function S(){var W={};var V,X;for(var T=0,U=arguments.length;T<U;T++){V=arguments[T];for(X in V){if(R.call(V,X)){W[X]=V[X]}}}return W}return S}();w=function(S){var R=S.document.readyState!=="loading";if(!R){S.document.addEventListener("DOMContentLoaded",function(){S.setTimeout(function(){R=true},0)})}function T(){return R}return T}(e);c=function(S,W,ab,Z,R,aa,U){var Y={};function X(ad,ac){if(!Array.isArray(ad)){ad=[ad]}return ad.map(function(ae){if(typeof ae==="string"){ae={selector:ae}}return aa(ac,ae)})}function V(ad){var ac;ac=ad.map(function(af){var ae;if(af.requireUpdate){ae=new W(af.selector);ab.one("start",function(){ae.dismiss()})}else{ae=Z.resolve()}return ae.then(function(){var ag=new S(af.selector);ab.one("start",function(){ag.dismiss()});return ag})});return Z.all(ac)}Y.start=function(ad){var af;var ae="isInitial" in ad?ad.isInitial:U()===false;var ac="threshold" in ad?ad.threshold:1000;ab.trigger("start",{key:ad.key,isInitial:ae,threshold:ac});if(ad.ready){af=X(ad.ready,{requireUpdate:!ae});V(af).then(function(){Y.end({key:ad.key})})}};Y.end=function(ac){ab.trigger("end",{key:ac.key})};Y.addReporter=function T(ac){R.add(ac)};return Y}(u,q,H,y,o,d,w);Q=function(R){return R.AJS||(R.AJS={})}(e);I=function(R){R.EventQueue=R.EventQueue||[];function S(T,U){R.EventQueue.push({name:T,properties:U})}return S}(Q);a=function(S){function R(T){(S.console.error||S.console.log).call(S.console,T.stack||T)}return R}(e);E=function(Z,V,W,U,X,R){function S(aa){return V.all([aa]).then(function(ab){return ab[0]})}function Y(aa){return S(aa).then(null,function(){return{}})}function T(ac){var ad=R.get().map(function ab(af){var ae;try{ae=af(ac)}catch(ag){X(ag);ae={}}return Y(ae)});return V.all(ad).then(function aa(ae){return W.apply(undefined,ae)})}return T}(J,y,d,e,a,o);b=function(S){var R;if(S.performance&&S.performance.now){R=function(){return S.performance.timing.navigationStart+S.performance.now()}}else{R=S.Date.now.bind(S.Date)}return R}(e);M=function(V,S,T){function R(W){if(!(this instanceof R)){return new R(W)}this.isInitial="isInitial" in W?W.isInitial:false;this.start=T();this.end=null;this.key=W.key;this.threshold=W.threshold}function U(W){var X;W.on("start",function(Y){X=new R(Y)});W.on("end",function(Y){if(X&&X.key===Y.key){X.end=T();S(X).then(function(Z){V("browser.metrics.navigation",Z)});X=null}})}return U}(I,E,b);N=function(R){return R.WRM||(R.WRM={})}(e);t=function(R){var W="com.atlassian.plugins.browser.metrics.browser-metrics-plugin:api.feature-data-provider",S;function V(X){return !!(X&&X.constructor&&X.call&&X.apply)}function U(X,Y){if(R&&R.data&&R.data.claim&&V(R.data.claim)){return R.data.claim(X)}else{if(R&&R.data&&V(R.data)){return R.data(X)}else{return Y}}}function T(){if(S===undefined){S=U(W,true)}return S}return T}(N);P=function(U,T,R,S){if(!S()){return{start:function(){},end:function(){}}}T(R);return U}(c,M,H,t);window["browser-metrics"]=P;if(window.define){window.define("internal/browser-metrics",[],function(){return P})}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.browser.metrics.browser-metrics-plugin:api', location = 'main.js' */
define("internal/browser-metrics-plugin/lib/window",["require","exports"],function(b,a){return window});define("internal/browser-metrics-plugin/lib/jquery",["require","exports","./window"],function(b,a,c){var d;try{d=c.require("jquery")}catch(f){d=c.jQuery}return d});define("internal/browser-metrics-plugin/reporters/experiments",["require","exports","../lib/jquery","../lib/window"],function(a,d,f,i){var h=i.AJS.contextPath()+"/experimental/main.js";function c(){return Array.prototype.slice.call(i.document.getElementsByTagName("script"))}function j(){return(i.GROW&&i.GROW.experimentId)||[]}function e(){var m=f.Deferred();f(function n(){var o=c().some(function p(q){return q.getAttribute("src")===h});m.resolve(o)});return m.promise()}var g=e().pipe(function l(n){var m={};if(n){m.experiments=JSON.stringify(j())}return m});var b=function k(){return g};return b});define("internal/browser-metrics-plugin/lib/wrm",["require","exports","./window"],function(c,b,d){var a;a=d.require("wrm");return a});define("internal/browser-metrics-plugin/reporters/rack",["require","exports","../lib/wrm"],function(f,e,d){var g=false;var h;function c(){if(g===false){h=d.data.claim("com.atlassian.plugins.browser.metrics.browser-metrics-plugin:api.rack-data-provider");g=true}return typeof h==="undefined"?null:h}var b=function a(){return{rack:c()}};return b});define("internal/browser-metrics-plugin/main",["require","exports","./reporters/experiments","./reporters/rack","internal/browser-metrics"],function(d,b,c,a,e){e.addReporter(c);e.addReporter(a)});require(["internal/browser-metrics-plugin/main"]);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-browser-metrics:viewcontent', location = '/js/viewcontent.js' */
require(["internal/browser-metrics","ajs","jquery","confluence-browser-metrics/spa-transitions","confluence-browser-metrics/defer-js","confluence-browser-metrics/server-duration","confluence-browser-metrics/bigpipe-reporter"],function(g,h,c,e,f,b,d){function i(j){if(!c(j.target).hasClass("full-load")){g.start({key:"confluence."+j.data.type+".edit.quick-view",ready:".active-richtext"})}}function a(){g.addReporter(e);g.addReporter(f);g.addReporter(b);g.addReporter(d);var j=h.Meta.get("content-type");if(j){g.start({key:"confluence."+j+".view",ready:".wiki-content",isInitial:true});c("#editPageLink").on("click",{type:j},i)}}h.toInit(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-browser-metrics:server-duration', location = '/js/server-duration.js' */
define("confluence-browser-metrics/server-duration",["internal/browser-metrics","jquery"],function(c,d){var b=d.Deferred();d(function(){var e=JSON.parse(d("#confluence-server-performance").html());if(e!==null&&e.serverDuration){b.resolve(e)}else{b.resolve({})}});var a=function(e){if(e.isInitial){return b.promise()}else{return{}}};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-browser-metrics:bigpipe-reporter', location = '/js/bigpipe-reporter.js' */
define("confluence-browser-metrics/bigpipe-reporter",["jquery"],function(c){var a=c.Deferred();c(function(){if(typeof(AJS.BigPipe)!=="undefined"&&AJS.BigPipe.metrics){a.resolve(AJS.BigPipe.metrics)}else{a.resolve({})}});var b=function(d){if(d.isInitial){return a.promise()}else{return{}}};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-browser-metrics:spa-transitions', location = '/js/spa-transitions.js' */
define("confluence-browser-metrics/spa-transitions",["jquery","ajs","confluence/storage-manager"],function(c,i,k){var d=c.Deferred();var l="page-page";var j="dashboard-page";var a=k("confluence","spa-transition");i.toInit(function(){c(document).on("click","a",g);var n=null;if(a.doesContain(l)){n=l}else{if(a.doesContain(j)){n=j}}if(n){d.resolve({"confluence-spa-transition":n});a.removeItem(n)}else{d.resolve({})}});function g(o){var n=c(this).attr("href");if(n&&e(o)&&b(n)){a.setItemQuietly(h()?j:l,true,300)}return true}function e(n){return n.which===1&&!n.metaKey&&!n.ctrlKey&&!n.shiftKey}function b(n){return(n.indexOf("/display/")!==-1||n.indexOf("/viewpage.action")!==-1)&&(n.indexOf("~")===-1||m(n))}function m(n){return(n.indexOf("/",n.indexOf("~")+1)!==-1)&&n.slice(-1)!=="/"}function h(){return c("body").hasClass("dashboard")}var f=function(n){if(n.isInitial){return d.promise()}else{return{}}};return f});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-browser-metrics:defer-js', location = '/js/defer-js.js' */
define("confluence-browser-metrics/defer-js",["confluence/dark-features","jquery"],function(a,c){return function b(d){if(d.isInitial&&a.isEnabled("defer.js.enable")&&c("#doctheme-anchor").length===0){return{deferJs:"true"}}else{return{}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.ext.newcode-macro-plugin:syntaxhighlighter-init', location = 'sh/asyncLoader.js' */
define("confluence/code-macro/async-loader",["jquery","wrm","underscore"],function(c,a,b){return function(){b.defer(function(){var h=c(".codeHeader .collapse-source");d(h);var i=c("#content").find("pre.syntaxhighlighter-pre");if(i.length>0){var g="wr!com.atlassian.confluence.ext.newcode-macro-plugin:sh-theme-";var f=["wrc!code-macro"];i.each(function(){f.push(g+c(this).data("theme").toLowerCase())});a.require(f).done(function(){window.SyntaxHighlighter.highlight();e(h)})}});function d(f){f.hide();b.forEach(f,function(g){c(g).next(".collapse-spinner-wrapper").spin()})}function e(f){f.show();f.next(".collapse-spinner-wrapper").remove()}}});require("confluence/module-exporter").safeRequire("confluence/code-macro/async-loader",function(a){AJS.toInit(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-page-banner:page-banner-common-resources', location = 'js/page-banner.js' */
AJS.toInit(function(e){d();AJS.bind("system-content-metadata.toggled-restrictions",function(i,k){var j=e("#content-metadata-page-restrictions");var g="";j.removeClass();var h=k.hasRestrictions&&!(k.hasExplicitRestrictions||k.hasInheritedRestrictions);if(k.hasExplicitRestrictions||h){j.addClass("aui-icon aui-icon-small aui-iconfont-locked restricted");g="Restrictions apply"}else{if(k.hasInheritedRestrictions){j.addClass("aui-icon aui-icon-small aui-iconfont-unlocked restricted");g="Restrictions apply"}else{j.addClass("aui-icon aui-icon-small aui-iconfont-unlocked");g=k.hasAnyExplicitRestrictions?"Restrictions apply":"Unrestricted"}}j.attr("title",g);a(j);d()});AJS.bind("breadcrumbs.expanded",f);e("#page-metadata-banner").css("visibility","visible");b();e("#content-metadata-page-restrictions").click(function(g){g.preventDefault();AJS.trigger("system-content-metadata.open-restrictions-dialog")});function d(){if(e("#system-content-items").children(":not(.hidden)").length==0){e("#system-content-items").addClass("hidden")}else{e("#system-content-items").removeClass("hidden")}}function f(){e("#page-metadata-banner").hide()}function b(){var g=e("#system-content-items a:not(.tipsy-disabled), .page-metadata-item a:not(.tipsy-disabled), .page-metadata-modification-info a.last-modified:not(tipsy-disabled)");a(g);g.click(function(h){c(e(h.target).closest("a"))});e(window).on("click scroll resize",c)}function a(g){e(g).tooltip({live:true,gravity:e("#com-atlassian-confluence").hasClass("theme-documentation view-blog-post")?"nw":"n",title:"title",delayIn:500})}function c(g){e(".tipsy").remove();if(g){var h=e(g).data("tipsy");if(h){h.hoverState="out"}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-page-banner:page-banner-common-resources', location = 'js/page-banner-analytics.js' */
AJS.toInit(function(c){function b(){if(!AJS.Confluence.Analytics||!AJS.Confluence.Analytics.setAnalyticsSource){AJS.log("WARNING: Could not initialise analytics for the page banner: AJS.Confluence.Analytics.setAnalyticsSource is not defined.");return}var e=AJS.Confluence.Analytics.setAnalyticsSource;var f=c("#breadcrumbs > li");e(f.filter(":not(#ellipsis)").find("a"),"breadcrumbs");e(f.filter(".hidden-crumb").find("a"),"breadcrumbs-expanded");e(f.filter(":last").find("a"),"breadcrumbs-parent");var d=c("#com-atlassian-confluence").hasClass("theme-documentation")?"breadcrumbs-homepage":"breadcrumbs-collector";e(f.filter(".first").find("a"),d)}function a(e,d,g){var f=null;e.mouseover(function(){f=setTimeout(g,d)});e.mouseout(function(){clearTimeout(f)})}AJS.bind("breadcrumbs.expanded",function(){AJS.trigger("analyticsEvent",{name:"breadcrumbs-expanded"})});b()});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-page-banner:soy-resources', location = 'soy/page-banner.soy' */
// This file was automatically generated from page-banner.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.PageBanner.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.PageBanner == 'undefined') { Confluence.Templates.PageBanner = {}; }


Confluence.Templates.PageBanner.banner = function(opt_data, opt_ignored) {
  var output = '<div id="page-metadata-banner"><ul class="banner">' + Confluence.Templates.PageBanner.renderSystemContentItems(opt_data);
  var itemList6 = opt_data.pageBannerItems;
  var itemListLen6 = itemList6.length;
  for (var itemIndex6 = 0; itemIndex6 < itemListLen6; itemIndex6++) {
    var itemData6 = itemList6[itemIndex6];
    output += Confluence.Templates.PageBanner.renderPageBannerItem(itemData6);
  }
  output += '</ul></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.PageBanner.banner.soyTemplateName = 'Confluence.Templates.PageBanner.banner';
}


Confluence.Templates.PageBanner.renderSystemContentItems = function(opt_data, opt_ignored) {
  var output = '<li id="system-content-items" class="noprint">';
  var itemList12 = opt_data.systemContentItems;
  var itemListLen12 = itemList12.length;
  for (var itemIndex12 = 0; itemIndex12 < itemListLen12; itemIndex12++) {
    var itemData12 = itemList12[itemIndex12];
    output += Confluence.Templates.PageBanner.itemAnchor(soy.$$augmentMap(itemData12, {isSystemContentItem: true}));
  }
  output += '</li>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.PageBanner.renderSystemContentItems.soyTemplateName = 'Confluence.Templates.PageBanner.renderSystemContentItems';
}


Confluence.Templates.PageBanner.renderPageBannerItem = function(opt_data, opt_ignored) {
  return '<li class="page-metadata-item noprint ' + ((opt_data.isAuiButton) ? 'has-button' : '') + '" ' + ((opt_data.linkId) ? ' id="' + soy.$$escapeHtml(opt_data.linkId) + '-wrapper"' : '') + '>' + Confluence.Templates.PageBanner.itemAnchor(soy.$$augmentMap(opt_data, {isSystemContentItem: false})) + '</li>';
};
if (goog.DEBUG) {
  Confluence.Templates.PageBanner.renderPageBannerItem.soyTemplateName = 'Confluence.Templates.PageBanner.renderPageBannerItem';
}


Confluence.Templates.PageBanner.itemAnchor = function(opt_data, opt_ignored) {
  return '<a href="' + soy.$$escapeHtml(opt_data.href) + '" title="' + soy.$$escapeHtml(opt_data.tooltip) + '" ' + ((opt_data.linkId) ? 'id="' + soy.$$escapeHtml(opt_data.linkId) + '"' : '') + ' ' + ((opt_data.styleClasses) ? 'class="' + soy.$$escapeHtml(opt_data.styleClasses) + '"' : '') + '>' + Confluence.Templates.PageBanner.itemIcon(opt_data) + ((! opt_data.isSystemContentItem) ? '<span>' + soy.$$escapeHtml(opt_data.label) + '</span>' : '') + '</a>';
};
if (goog.DEBUG) {
  Confluence.Templates.PageBanner.itemAnchor.soyTemplateName = 'Confluence.Templates.PageBanner.itemAnchor';
}


Confluence.Templates.PageBanner.itemIcon = function(opt_data, opt_ignored) {
  return '' + ((opt_data.icon) ? '<img class="page-banner-item-icon" src="' + soy.$$escapeHtml(opt_data.icon.url) + '" style="height: ' + soy.$$escapeHtml(opt_data.icon.height) + 'px; width: ' + soy.$$escapeHtml(opt_data.icon.width) + 'px;"/>' : '');
};
if (goog.DEBUG) {
  Confluence.Templates.PageBanner.itemIcon.soyTemplateName = 'Confluence.Templates.PageBanner.itemIcon';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:view-comment', location = '/includes/js/comments.js' */
define("confluence/comments",["ajs","jquery","confluence/storage-manager"],function(b,g,h){function f(){return confirm("Are you sure you want to delete the comment?")?(this.href+="&confirm=yes",!0):!1}return{binder:{bindRemoveConfirmation:function(a){g("#comment-"+a+" .comment-action-remove a").click(f)}},initialiser:function(a){var d=h("confluence","comments");if(a("#comments-section").length){a("#comments-section .comment:odd").addClass("odd");a(".comment-action-remove a").click(f);var e=
a("#addcomment.comment-text"),c=a("#comments-text-editor textarea");c.focus(function(){e.addClass("active")}).blur(function(){a.trim(c.val()).length||e.removeClass("active")}).bind("reset.default-text",function(){e.removeClass("active")});a("form[name='textcommentform']").submit(function(){var d=c.val();return!a.trim(d)?(alert("Comment text is empty. Cannot create empty comments."),!1):!0});a("#add-comment-rte").click(function(){c.hasClass("placeholded")||d.setItem("text-comment",a.trim(c.val()))});a("#addcomment #rte").length&&
b.bind("init.rte",function(a,b){var c=d.getItem("text-comment");c&&(b.editor.setContent(c),d.setItem("text-comment",""))})}}}});require("confluence/module-exporter").safeRequire("confluence/comments",function(b){require("confluence/legacy").Comments=b.binder;require("ajs").toInit(b.initialiser)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-flag', location = 'js/aui/flag.js' */
(function(A){define("aui/flag",[],function(){return A(AJS,AJS.$,AJS.template)})})(function(L,F,N){var O=5000;var A="aui-flag-container";var E={body:"",persistent:false,close:"",title:"",type:"info"};function J(R){if(R.hasOwnProperty("persistent")){var P;if(R.persistent){P=L.deprecate.getMessageLogger("persistent: true","5.8.0",{alternativeName:"close: never",extraInfo:"See https://ecosystem.atlassian.net/browse/AUI-2893."})}else{if(!R.persistent){P=L.deprecate.getMessageLogger("persistent: false","5.8.0",{alternativeName:"close: manual",extraInfo:"See https://ecosystem.atlassian.net/browse/AUI-2893."})}}P()}R=F.extend({},E,R);var Q=R.close!=="never"&&(R.close||(R.persistent!==true));var S=D(R,Q);G(S);if(R.close==="auto"){M(S);C(S)}else{if(R.close==="manual"){M(S)}else{if(R.close==="never"){}else{if(!R.persistent){M(S)}}}}H();return K(S)}function G(Q){var P=Q[0];P.close=function(){B(Q)}}function D(Q,P){var R='<div class="aui-flag"><div class="aui-message aui-message-{type} {type} {closeable} shadowed"><p class="title"><strong>{title}</strong></p>{body}<!-- .aui-message --></div></div>';var S=N(R).fill({"body:html":Q.body||"",closeable:P?"closeable":"",title:Q.title||"",type:Q.type}).toString();return F(S)}function M(Q){var P=F('<span class="aui-icon icon-close" role="button" tabindex="0"></span>');P.click(function(){B(Q)});P.keypress(function(R){if((R.which===L.keyCode.ENTER)||(R.which===L.keyCode.SPACE)){B(Q);R.preventDefault()}});return Q.find(".aui-message").append(P)[0]}function C(P){P.find(".aui-message").addClass("aui-will-close");setTimeout(function(){P[0].close()},O)}function B(Q){var P=Q.get(0);P.setAttribute("aria-hidden","true");P.dispatchEvent(new CustomEvent("aui-flag-close",{bubbles:true}));return P}function H(){var Q=I();var P=Q.find(".aui-flag");P.get().forEach(function(R){var S=R.getAttribute("aria-hidden")==="true";if(S){F(R).remove()}})}function I(){return F("#"+A)}function K(Q){var P=I();if(!P.length){P=F('<div id="'+A+'"></div>');F("body").prepend(P)}Q.appendTo(P);L._internal.animation.recomputeStyle(Q);return Q.attr("aria-hidden","false")[0]}return J});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.aui.staging:confluence-flags', location = 'flag/confluence-flag.js' */
define("confluence/flag",["ajs","jquery"],function(f,d){function h(a){var b=d('<span class="aui-icon icon-close" role="button" tabindex="0"></span>');b.click(function(){g(a)});b.keypress(function(b){if(b.which===f.keyCode.ENTER||b.which===f.keyCode.SPACE)g(a),b.preventDefault()});return a.find(".aui-message").append(b)[0]}function g(a){var b=a.get(0);b.setAttribute("aria-hidden","true");a=a.parent();i(a);b.dispatchEvent(new CustomEvent("aui-flag-close",{bubbles:!0}));return b}function i(a){a.hasClass("aui-flag-stack")&&
a.children('.aui-flag:not([aria-hidden="true"])').length&&(a.children(".aui-flag-stack-top-item").removeClass("aui-flag-stack-top-item"),a.children('.aui-flag:not([aria-hidden="true"])').last().addClass("aui-flag-stack-top-item"))}var j={body:"",close:"manual",title:"",type:"info",fifo:!1};return function(a){var a=d.extend({},j,a),b,c=a,c=f.template('<div class="aui-flag {extraClasses}"><div class="aui-message aui-message-{type} {type} {closeable} shadowed"><p class="title"><strong>{title}</strong></p>{body}<\!-- .aui-message --\></div></div>').fill({"body:html":c.body||
"",closeable:"never"===c.close?"":"closeable",title:c.title||"",type:c.type,extraClasses:c.extraClasses||""}).toString();b=d(c);b[0].close=function(){g(b)};"auto"===a.close?(h(b),b.find(".aui-message").addClass("aui-will-close"),setTimeout(function(){b[0].close()},5E3)):"manual"===a.close&&h(b);d("#aui-flag-container").find(".aui-flag").get().forEach(function(a){a.getAttribute("aria-hidden")==="true"&&d(a).remove()});c=d("#aui-flag-container");c.length||(c=d('<div id="aui-flag-container"></div>'),
d("body").prepend(c));if(a.stack){var e=d('[data-aui-flag-stack="'+a.stack+'"]');e.length||(e=d('<div data-aui-flag-stack="'+a.stack+'" class="aui-flag-stack"></div>'),e.appendTo(c));e.find('[aria-hidden="false"]').length||e.detach().appendTo(c);a.fifo?b.appendTo(e):b.prependTo(e);i(e)}else b.appendTo(c);f._internal.animation.recomputeStyle(b);a=b.attr("aria-hidden","false")[0];a.dispatchEvent(new CustomEvent("aui-flag-show",{bubbles:!0}));return a}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.aui.staging:confluence-flags', location = 'flag/confluence-flag-scroll.js' */
define("confluence/flag-scroll",["jquery","ajs","confluence/meta","document"],function(c,j,k,l){function f(){var a=c("#"+g);if(a.find('.aui-flag[aria-hidden="false"]').length){var b;b=0;h?b=c("#header").height()+d:(b=e.scrollTop(),b=b<=i-d?i-Math.max(b,0):d);a.css("top",b)}}var d=20,i=71,g="aui-flag-container",h=!1,e;return function(a){e=(h=a("body").hasClass("theme-documentation"))?a("#splitter-content"):a(window);e.on("scroll",f);l.addEventListener("aui-flag-show",f);j.bind("rte-ready",function(){"page"===
k.get("content-type")&&a("#"+g).find('.aui-flag[aria-hidden="false"]').each(function(){this.close()})})}});require("confluence/module-exporter").safeRequire("confluence/flag-scroll",function(c){require("ajs").toInit(c)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-page', location = 'soy/comments.soy' */
// This file was automatically generated from comments.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Comments.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Comments == 'undefined') { Confluence.Templates.Comments = {}; }


Confluence.Templates.Comments.displayReplyEditorLoadingContainer = function(opt_data, opt_ignored) {
  return '<ol class="comment-threads"><li class="comment-thread">' + Confluence.Templates.Comments.displayCommentEditorCommon({comment: {ownerId: opt_data.contentId, parentId: opt_data.parentCommentId}, commenter: opt_data.commenter, state: 'loading', mode: 'reply'}) + '</li></ol>';
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.displayReplyEditorLoadingContainer.soyTemplateName = 'Confluence.Templates.Comments.displayReplyEditorLoadingContainer';
}


Confluence.Templates.Comments.displayTopLevelCommentEditorPlaceholder = function(opt_data, opt_ignored) {
  return '' + Confluence.Templates.Comments.displayCommentEditorCommon({comment: {ownerId: opt_data.contentId}, commenter: opt_data.commenter, state: 'placeholder', mode: 'add'});
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.displayTopLevelCommentEditorPlaceholder.soyTemplateName = 'Confluence.Templates.Comments.displayTopLevelCommentEditorPlaceholder';
}


Confluence.Templates.Comments.displayEditEditorContainer = function(opt_data, opt_ignored) {
  return '' + Confluence.Templates.Comments.displayCommentEditorCommon({comment: {ownerId: opt_data.contentId, id: opt_data.commentId}, commenter: opt_data.commenter, state: 'placeholder', mode: 'edit'});
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.displayEditEditorContainer.soyTemplateName = 'Confluence.Templates.Comments.displayEditEditorContainer';
}


Confluence.Templates.Comments.editorLoadErrorMessage = function(opt_data, opt_ignored) {
  return '<p>' + soy.$$escapeHtml(opt_data.message) + '</p><p><a href="' + soy.$$escapeHtml(opt_data.fallbackUrl) + '">' + soy.$$escapeHtml("Try again") + '</a></p>';
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.editorLoadErrorMessage.soyTemplateName = 'Confluence.Templates.Comments.editorLoadErrorMessage';
}


Confluence.Templates.Comments.displayCommentEditorCommon = function(opt_data, opt_ignored) {
  var output = '<div class="quick-comment-container comment ' + soy.$$escapeHtml(opt_data.mode) + '">' + Confluence.Templates.Comments.userLogo({userInfo: opt_data.commenter}) + '<div class="quick-comment-body"><div class="quick-comment-loading-container" style="display:' + ((opt_data.state == 'loading') ? 'block' : 'none') + ';"></div><div id="editor-messages"></div><div id="all-messages"></div><form style="display:' + ((opt_data.state == 'loading') ? 'none' : 'block') + ';" class="quick-comment-form aui" method="post" ';
  switch (opt_data.mode) {
    case 'add':
      output += 'name="inlinecommentform" action="' + soy.$$escapeHtml("/confluence") + '/pages/doaddcomment.action?pageId=' + soy.$$escapeHtml(opt_data.comment.ownerId) + '"';
      break;
    case 'edit':
      output += 'name="editcommentform" action="' + soy.$$escapeHtml("/confluence") + '/pages/doeditcomment.action?pageId=' + soy.$$escapeHtml(opt_data.comment.ownerId) + '&commentId=' + soy.$$escapeHtml(opt_data.comment.id) + '"';
      break;
    case 'reply':
      output += 'name="threadedcommentform"  action="' + soy.$$escapeHtml("/confluence") + '/pages/doaddcomment.action?pageId=' + soy.$$escapeHtml(opt_data.comment.ownerId) + '&parentId=' + soy.$$escapeHtml(opt_data.comment.parentId) + '"';
      break;
  }
  output += ' >' + ((opt_data.mode == 'add') ? '<div title="' + soy.$$escapeHtml("Add a Comment") + '" class="quick-comment-prompt"><span>' + soy.$$escapeHtml("Write a comment\u2026") + '</span></div>' : '') + '</form></div></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.displayCommentEditorCommon.soyTemplateName = 'Confluence.Templates.Comments.displayCommentEditorCommon';
}


Confluence.Templates.Comments.userLogo = function(opt_data, opt_ignored) {
  return '<p class="comment-user-logo">' + ((opt_data.userInfo.userName == null) ? '<img class="userLogo logo anonymous" src="' + soy.$$escapeHtml("/confluence/s/en_GB/6220/de9b463eb65c5ca13c0266eed77e2bf49f4c6fe8.70/_") + '/images/icons/profilepics/anonymous.png" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml("Anonymous") + '" title="' + soy.$$escapeHtml("Anonymous") + '">' : (opt_data.userInfo.profilePicture.isDefault) ? '<a class="userLogoLink" data-username="' + soy.$$escapeHtml(opt_data.userInfo.userName) + '" href="' + soy.$$escapeHtml("/confluence") + '/users/profile/editmyprofilepicture.action" title="' + soy.$$escapeHtml("Add a picture of yourself") + '"><img class="userLogo logo defaultLogo" src="' + soy.$$escapeHtml("/confluence/s/en_GB/6220/de9b463eb65c5ca13c0266eed77e2bf49f4c6fe8.70/_") + '/images/icons/profilepics/add_profile_pic.png" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml("Add a picture of yourself") + '"></a>' : '<a class="userLogoLink" data-username="' + soy.$$escapeHtml(opt_data.userInfo.userName) + '" href="' + Confluence.Templates.User.userLinkUrl({username: opt_data.userInfo.userName}) + '"><img class="userLogo logo" src="' + soy.$$escapeHtml(opt_data.userInfo.profilePicture.path) + '" alt="' + soy.$$escapeHtml("User icon") + ': ' + soy.$$escapeHtml(opt_data.userInfo.userName) + '" title="' + soy.$$escapeHtml(opt_data.userInfo.userName) + '"></a>') + '</p>';
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.userLogo.soyTemplateName = 'Confluence.Templates.Comments.userLogo';
}


Confluence.Templates.Comments.displayComment = function(opt_data, opt_ignored) {
  return '' + ((opt_data.comment.parentId == 0 && opt_data.firstReply) ? '<div id="comments-section" class="pageSection group"><div class="section-header"><h2 id="comments-section-title" class="section-title">' + soy.$$escapeHtml("1 Comment") + '</h2>' + Confluence.Templates.Comments.commentThread({comment: opt_data.comment, commenter: opt_data.commenter, highlight: opt_data.highlight, topLevel: true}) + '</div></div>' : (opt_data.firstReply) ? Confluence.Templates.Comments.commentThread({comment: opt_data.comment, commenter: opt_data.commenter, highlight: opt_data.highlight, topLevel: false}) : Confluence.Templates.Comments.commentThreadItem({comment: opt_data.comment, commenter: opt_data.commenter, highlight: true}));
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.displayComment.soyTemplateName = 'Confluence.Templates.Comments.displayComment';
}


Confluence.Templates.Comments.commentThread = function(opt_data, opt_ignored) {
  return '<ol class="comment-threads' + ((opt_data.topLevel) ? ' top-level" id="page-comments' : '') + '">' + Confluence.Templates.Comments.commentThreadItem(opt_data) + '</ol>';
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.commentThread.soyTemplateName = 'Confluence.Templates.Comments.commentThread';
}


Confluence.Templates.Comments.commentThreadItem = function(opt_data, opt_ignored) {
  return '<li id="comment-thread-' + soy.$$escapeHtml(opt_data.comment.id) + '" class="comment-thread">' + Confluence.Templates.Comments.commentView(opt_data) + '</li>';
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.commentThreadItem.soyTemplateName = 'Confluence.Templates.Comments.commentThreadItem';
}


Confluence.Templates.Comments.commentView = function(opt_data, opt_ignored) {
  return '<div class="comment' + ((opt_data.highlight == true) ? ' focused' : '') + '" id="comment-' + soy.$$escapeHtml(opt_data.comment.id) + '">' + Confluence.Templates.Comments.userLogo({userInfo: opt_data.commenter}) + '<div class="comment-header"><h4 class="author">' + ((opt_data.commenter.userName == null) ? soy.$$escapeHtml("Anonymous") : '<a href="' + soy.$$escapeHtml("/confluence") + '/display/~' + soy.$$escapeUri(opt_data.commenter.userName) + '" class="url fn confluence-userlink" data-username="' + soy.$$escapeHtml(opt_data.commenter.userName) + '">' + soy.$$escapeHtml(opt_data.commenter.displayName) + '</a>') + '</h4></div><div class="comment-body"><div class="comment-content wiki-content">' + soy.$$filterNoAutoescape(opt_data.comment.html) + '</div><div class="comment-actions">' + Confluence.Templates.Comments.displayCommentActions({section: 'secondary', actions: opt_data.comment.secondaryActions, commentId: opt_data.comment.id}) + Confluence.Templates.Comments.displayCommentActions({section: 'primary', actions: opt_data.comment.primaryActions, commentId: opt_data.comment.id}) + '</div></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.commentView.soyTemplateName = 'Confluence.Templates.Comments.commentView';
}


Confluence.Templates.Comments.displayCommentActions = function(opt_data, opt_ignored) {
  var output = '<ul class="comment-actions-' + soy.$$escapeHtml(opt_data.section) + '">';
  if (opt_data.actions != null) {
    var itemList211 = opt_data.actions;
    var itemListLen211 = itemList211.length;
    for (var itemIndex211 = 0; itemIndex211 < itemListLen211; itemIndex211++) {
      var itemData211 = itemList211[itemIndex211];
      output += '<li ' + ((itemData211.style != null) ? ' class="' + soy.$$escapeHtml(itemData211.style) + '"' : '') + '><a ' + ((itemData211.tooltip != null) ? ' title="' + soy.$$escapeHtml(itemData211.tooltip) + '"' : '') + ' href="' + soy.$$escapeHtml(itemData211.url) + '" ' + ((itemData211.id) ? ' id="' + soy.$$escapeHtml(itemData211.id) + '-' + soy.$$escapeHtml(opt_data.commentId) + '"' : '') + '><span>' + soy.$$escapeHtml(itemData211.label) + '</span></a></li>\n';
    }
  }
  output += '</ul>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Comments.displayCommentActions.soyTemplateName = 'Confluence.Templates.Comments.displayCommentActions';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-page', location = 'jscripts/comment-display-manager.js' */
define("confluence-quick-edit/comment-display-manager",["ajs","confluence/legacy","confluence/templates","jquery"],function(g,j,h,c){var i={_updateCommentSectionTitle:function(){var a=c("#comments-section-title");if(0!==a.length){var b=this.commentCount();1===b?a.text("1 Comment"):a.text(g.format("{0} Comments",b))}},addComment:function(a,b,f,d){a={comment:b,commenter:a,highlight:f,context:{contextPath:g.Meta.get("context-path"),staticResourceUrlPrefix:g.Meta.get("static-resource-url-prefix")}};
if(this.hasComments()){if(0==b.parentId)a.firstReply=!1,f=c("#comments-section .comment-threads.top-level");else{var f=c("#comment-thread-"+b.parentId),e=f.children(".commentThreads");e.length?(a.firstReply=!1,f=e):a.firstReply=!0}d||this.clearFocus();d=c(h.Comments.displayComment(a));d.addClass("fadeInComment");f.append(d);this._updateCommentSectionTitle()}else a.firstReply=!0,d=c(h.Comments.displayComment(a)),d.addClass("fadeInComment"),c("#comments-section").prepend(d);j.Comments.bindRemoveConfirmation(b.id);
b=this.getCommentNode(b.id);b.scrollToElement();return b},addOrUpdateComment:function(a,b,c,d){var e=this.getCommentNode(b.id);return e?(e.find(".comment-content").html(b.html),d||this.clearFocus(),c&&e.addClass("focused"),e.addClass("fadeInComment"),e.scrollToElement(),e):this.addComment.apply(this,arguments)},isVisible:function(){return!c("#page-comments").hasClass("hidden")},hasComments:function(){return 0<this.commentCount()},commentCount:function(){return c("#comments-section .comment").not(".quick-comment-container").length},
clearFocus:function(){c(".comment").removeClass("focused")},getCommentNode:function(a){a=c("#comment-"+a);return a.length?a:null},getParentId:function(a){a=i.getCommentNode(a);return null!=a&&(a=a.closest("div.comment"),a.length)?(a=a.attr("id"),a=/\d+/.exec(a),parseInt(a)):0}};return i});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/comment-display-manager","Confluence.CommentDisplayManager");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-page', location = 'jscripts/scroll-util.js' */
define("confluence-quick-edit/scroll-util",["window","document","jquery"],function(a,c,e){return{scrollToElement:function(){this.scrollWindowToElement()||this.scrollOverflowContainerToElement();return this},scrollWindowToElement:function(){function b(){return"pageYOffset"in a?a.pageYOffset:c.documentElement.scrollTop}var f=b(),d;if("number"===typeof a.innerWidth)d=a.innerHeight;else if(c.documentElement&&c.documentElement.clientWidth)d=c.documentElement.clientHeight;else return this[0].scrollIntoView(!1),
!0;var g=this.offset().top,h=this.height();return g+h+40>f+d?(this[0].scrollIntoView(!1),a.scrollBy(0,40),f!=b()):!0},scrollOverflowContainerToElement:function(){var b=null;this.parents().each(function(){var a=e(this).css("overflow");if("auto"==a||"scroll"==a)return b=e(this),!1});if(!b)return!1;var a=b.height(),d=this.offset().top,c=this.height(),a=a-(d+c+40);0>a&&(b[0].scrollTop-=a);return!0}}});require("confluence/module-exporter").safeRequire("confluence-quick-edit/scroll-util",function(a){require("jquery").fn.extend(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'main/quick-reload.soy' */
// This file was automatically generated from quick-reload.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace QuickReload.Templates.
 */

if (typeof QuickReload == 'undefined') { var QuickReload = {}; }
if (typeof QuickReload.Templates == 'undefined') { QuickReload.Templates = {}; }


QuickReload.Templates.pageEdit = function(opt_data, opt_ignored) {
  return '' + QuickReload.Templates.container({content: '<div class="qr-notice-authors">' + QuickReload.Templates.noticeHeader({users: opt_data.pageEditors}) + '</div><div class="qr-notice-summary">' + aui.buttons.button({text: "Reload page", type: 'text', extraClasses: 'qr-notice-show aui-button-text'}) + QuickReload.Templates.summaryText({users: opt_data.pageEditors}) + '</div>'});
};
if (goog.DEBUG) {
  QuickReload.Templates.pageEdit.soyTemplateName = 'QuickReload.Templates.pageEdit';
}


QuickReload.Templates.pageComment = function(opt_data, opt_ignored) {
  return '' + QuickReload.Templates.container({content: '<div class="qr-notice-authors">' + QuickReload.Templates.noticeHeader({users: opt_data.commentUsers}) + ((opt_data.commentUsers.length == 1) ? '<span class="qr-notice-text">"' + soy.$$escapeHtml(opt_data.noticeText) + '"</span>' : '') + '</div><div class="qr-notice-summary">' + aui.buttons.button({text: '' + ((opt_data.commentUsers.length > 1) ? soy.$$escapeHtml("Show all") : soy.$$escapeHtml("Show")), type: 'text', extraClasses: 'qr-notice-show aui-button-text'}) + QuickReload.Templates.summaryText({users: opt_data.commentUsers}) + '</div>'});
};
if (goog.DEBUG) {
  QuickReload.Templates.pageComment.soyTemplateName = 'QuickReload.Templates.pageComment';
}


QuickReload.Templates.inlineComment = function(opt_data, opt_ignored) {
  return '' + QuickReload.Templates.container({content: '<div class="qr-notice-authors">' + QuickReload.Templates.noticeHeader({users: opt_data.user}) + '<span class="qr-notice-text">"' + soy.$$escapeHtml(opt_data.noticeText) + '"</span></div><div class="qr-notice-summary">' + aui.buttons.button({text: '' + ((opt_data.reloadRequired) ? soy.$$escapeHtml("Reload page") : soy.$$escapeHtml("Show")), type: 'text', extraClasses: 'qr-notice-show aui-button-text', extraAttributes: ['data-reload-required', opt_data.reloadRequired]}) + QuickReload.Templates.summaryText({users: opt_data.user}) + '</div>'});
};
if (goog.DEBUG) {
  QuickReload.Templates.inlineComment.soyTemplateName = 'QuickReload.Templates.inlineComment';
}


QuickReload.Templates.container = function(opt_data, opt_ignored) {
  return '<div class="qr-container">' + soy.$$filterNoAutoescape(opt_data.content) + '</div>';
};
if (goog.DEBUG) {
  QuickReload.Templates.container.soyTemplateName = 'QuickReload.Templates.container';
}


QuickReload.Templates.noticeHeader = function(opt_data, opt_ignored) {
  var output = '';
  var userList68 = opt_data.users;
  var userListLen68 = userList68.length;
  for (var userIndex68 = 0; userIndex68 < userListLen68; userIndex68++) {
    var userData68 = userList68[userIndex68];
    output += (userIndex68 < 8) ? aui.avatar.avatar({size: 'small', avatarImageUrl: userData68.profilePicture.path, title: userData68.displayName != '' ? userData68.displayName : "Anonymous", extraClasses: 'qr-author-avatar'}) : '';
  }
  return output;
};
if (goog.DEBUG) {
  QuickReload.Templates.noticeHeader.soyTemplateName = 'QuickReload.Templates.noticeHeader';
}


QuickReload.Templates.summaryText = function(opt_data, opt_ignored) {
  var output = '';
  var lastModifier__soy78 = opt_data.users[0];
  var others__soy79 = opt_data.users.length - 1;
  output += '<span class="qr-notice-summary-text">' + soy.$$escapeHtml("by") + ' ' + Confluence.Templates.User.usernameLink({canView: false, username: lastModifier__soy78.userName, fullName: lastModifier__soy78.displayName != '' ? lastModifier__soy78.displayName : "Anonymous"}) + ((others__soy79 == 1) ? ' ' + soy.$$escapeHtml("and 1 other") : '') + ((others__soy79 > 1) ? ' ' + soy.$$escapeHtml(AJS.format("and {0} others",others__soy79)) : '') + '</span>';
  return output;
};
if (goog.DEBUG) {
  QuickReload.Templates.summaryText.soyTemplateName = 'QuickReload.Templates.summaryText';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'utils/quick-reload-timer.js' */
define("confluence-quick-reload/utils/quick-reload-timer",["jquery","underscore"],function(c,d){function a(b,a){this.options=c.extend({min:3E4,max:36E5,inactivity:12E4},a);d.bindAll(this,"start","stop","_now","_timeSinceLastSeen","_setActive","_setActivityTrigger","_clamp","_intervalMultiplier");this.callback=b;this._timer=null;this._setActivityTrigger(this._setActive)}a.prototype.start=function(b){this.lastSeenTimestamp=this._now();this.stop();b&&this.callback();var a=function(){this.callback();
c.call(this)},c=function(){this.stop();this._timer=setTimeout(d.bind(a,this),this.options.min*this._intervalMultiplier())};c.call(this)};a.prototype.stop=function(){null!==this._timer&&(clearTimeout(this._timer),this._timer=null)};a.prototype._setActive=function(){if(null!==this._timer){var b=this._timeSinceLastSeen()>this.options.inactivity;this.lastSeenTimestamp=this._now();b&&this.start(!0)}};a.prototype._setActivityTrigger=function(b){document.addEventListener("visibilitychange",function(){document.hidden||
b()},!1);c(window).focus(b);c("body").click(b);c(window).scroll(b)};a.prototype._now=function(){return(new Date).getTime()};a.prototype._timeSinceLastSeen=function(){return this._now()+1-this.lastSeenTimestamp};a.prototype._clamp=function(b,a,c){a=Math.max(Math.min(a,c),b);return isNaN(a)?b:a};a.prototype._intervalMultiplier=function(){var a=(document.hidden?3:1)*Math.ceil(this._timeSinceLastSeen()/this.options.inactivity);return this._clamp(1,this.options.max/this.options.min,a)};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'utils/quick-reload-count.js' */
define("confluence-quick-reload/utils/quick-reload-count",function(){function a(){this.count=0}var b=document.title;a.prototype.getCount=function(){return this.count};a.prototype.setCount=function(a){this.count=a;this._displayCount()};a.prototype._displayCount=function(){document.title=(0<this.count?"("+this.count+") ":"")+b};return new a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'handlers/quick-reload-comments.js' */
define("confluence-quick-reload/handlers/quick-reload-comments","ajs underscore jquery confluence/flag confluence-quick-reload/utils/quick-reload-count confluence/legacy".split(" "),function(i,c,e,k,g,d){function h(c){return c.comment.id}var a,f=[];return{results:[],property:"comments",ignoreOnce:function(c){f.push(c)},filterNewResults:function(d,a){if(a.length===0)return a;var b=c.map(d,h);return c.filter(a,function(a){if(a.comment.isInlineComment)return false;a=h(a);if(c.contains(b,a))return false;
a=e.inArray(a,f);if(a>=0){f.splice(a,1);return false}return true})},render:function(f){g.setCount(g.getCount()+f.length);var f={close:"manual",type:"info",extraClasses:"qr-flag",fifo:true,stack:"quickreload"},j=this.results.length>1?i.format("{0} New comments",this.results.length):"New comment",b;b=c.clone(this.results);b.reverse();b=c.uniq(b,function(a){return a.commenter.userName});b=c.map(b,function(a){return a.commenter});var l=e("<div>").html(this.results[this.results.length-
1].comment.html).text();b=QuickReload.Templates.pageComment({commentUsers:b,noticeText:l});if(a===void 0||a.getAttribute("aria-hidden")==="true"){a=new k(e.extend({},{body:b,title:j},f));e(a).on("click",".qr-notice-show",c.bind(function(){var b=this.results;if(d&&d.CommentDisplayManager){d.CommentDisplayManager.clearFocus();c.map(b,function(a){var b=d.CommentDisplayManager.getCommentNode(h(a))!==null,a=d.CommentDisplayManager.addOrUpdateComment(a.commenter,a.comment,true,true);if(d.Likes&&!b){d.Likes.appendAction(e(a));
d.Likes.updateComment(e(a),{})}});d.CommentDisplayManager._updateCommentSectionTitle()}a.close()},this));e(a).on("aui-flag-close",c.bind(function(){g.setCount(g.getCount()-this.results.length);this.results=[]},this))}else{e(a).find(".qr-container").replaceWith(b);e(a).find(".title").text(j)}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'handlers/quick-reload-inline-comments.js' */
define("confluence-quick-reload/handlers/quick-reload-inline-comments",["underscore","jquery","ajs","confluence/flag","confluence-quick-reload/utils/quick-reload-count"],function(b,f,h,q,l){function o(a,d,b,e,c){a=QuickReload.Templates.inlineComment({user:[a.commenter],noticeText:a&&a.comment&&f("<div>").text(a.comment.html).text(),reloadRequired:d});c=1<c?"New inline comments":"New inline comment";c=new q(f.extend({},{title:c,body:a},{close:"manual",
type:"info",extraClasses:"qr-flag",fifo:!0,stack:"quickreload"}));f(c).find(".qr-notice-show").click(b);d||f(c).find(".qr-notice-show").click(c.close);f(c).on("aui-flag-close",e)}function n(a){return 0===a.comment.parentId}function i(a){return n(a)?a.comment.id:a.comment.parentId}return{results:[],property:"comments",filterNewResults:function(a,d){d=b.clone(d);d=b.filter(d,function(a){return a.comment.isInlineComment&&a.commenter.userName!==h.Meta.get("remote-user")});if(0<d.length)var f=b.map(a,
i),e=b.filter(d,n),c=b.filter(d,function(a){return!n(a)}),g=b.map(e,i),j=b.map(c,i),k=b.difference(j,g),p=[],c=b.filter(c,function(a){return-1!==k.indexOf(a.comment.parentId)&&-1===p.indexOf(a.comment.parentId)?(p.push(a.comment.parentId),!0):!1}),e=e.concat(c),d=b.filter(e,function(a){return-1===f.indexOf(i(a))});return d},render:function(a){l.setCount(l.getCount()+a.length);b.each(a,function(a){var m=i(a),e=function(){h.trigger("qr:show-new-thread",m)},c=function(){var a=h.Meta.Links.canonical(),
b=-1===a.indexOf("?")?"?":"&";window.location=a+b+"focusedCommentId="+m+"#comment-"+m},g=function(){this.results=b.filter(this.results,function(a){return i(a)!==m});l.setCount(l.getCount()-1)},g=b.bind(g,this),j=this.results.length;if(n(a)){var k=new f.Deferred;k.fail(function(a){o(a,!0,c,g,j)});k.done(function(a){o(a,!1,e,g,j)});h.trigger("qr:add-new-highlight",[a,k])}else o(a,!1,e,g,j)},this)}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'handlers/quick-reload-page.js' */
define("confluence-quick-reload/handlers/quick-reload-page",["underscore","jquery","ajs","confluence/flag","confluence-quick-reload/utils/quick-reload-count"],function(d,a,g,i,e){var c;return{results:[],property:"page",filterNewResults:function(c,a){return 0<a.length&&"string"!==typeof a[0]?a:[]},render:function(f){e.setCount(e.getCount()+f.length);var f={close:"manual",type:"info",extraClasses:"qr-flag",fifo:!0,stack:"quickreload"},h=1<this.results.length?g.format("{0} new edits",this.results.length):
"New page edits",b;b=d.clone(this.results);b.reverse();b=d.uniq(b,function(a){return a.editor.userName});b=d.map(b,function(a){return a.editor});b=QuickReload.Templates.pageEdit({pageEditors:b});void 0===c||"true"===c.getAttribute("aria-hidden")?(c=new i(a.extend({},{body:b,title:h},f)),a(c).on("click",".qr-notice-show",function(){a(this).prop("disabled",!0).prepend('<span class="aui-icon aui-icon-wait"></span>&nbsp;');window.location.reload()}),a(c).on("aui-flag-close",d.bind(function(){e.setCount(e.getCount()-
this.results.length);this.results=[]},this))):(a(c).find(".qr-container").replaceWith(b),a(c).find(".title").text(h))}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-resources', location = 'main/quick-reload-manager.js' */
define("confluence-quick-reload/main/quick-reload-manager",["underscore","jquery","ajs","confluence-quick-reload/utils/quick-reload-timer"],function(h,f,g,i){function a(){this._isEnabled=!1;this.handlers=[];this.lastFetchTime=f('meta[name="confluence-request-time"]').attr("content")||(new Date).getTime();this._timer=null;h.bindAll(this,"addHandler","removeHandler","update","enable","disable","_onUpdateSuccess","_onUpdateError")}a.prototype.addHandler=function(d){for(var a=!1,e=0;e<this.handlers.length;e++)this.handlers[e]===
d&&(a=!0);!0!==a&&this.handlers.push(d)};a.prototype.removeHandler=function(d){if(d)for(var a=0;a<this.handlers.length;a++)if(this.handlers[a]===d){this.handlers.splice(a,1);break}};a.prototype.update=function(){f("body").hasClass("contenteditor")?this.disable():f.ajax({type:"GET",url:g.contextPath()+"/rest/quickreload/latest/"+g.Meta.get("page-id")+"?since="+encodeURIComponent(this.lastFetchTime),dataType:"json"}).done(this._onUpdateSuccess).fail(this._onUpdateError)};a.prototype.enable=function(){null===
this._timer&&(this._timer=new i(this.update));this._timer.start();this._isEnabled=!0};a.prototype.disable=function(){null!==this._timer&&this._timer.stop();this._isEnabled=!1};a.prototype.isEnabled=function(){return this._isEnabled};a.prototype._onUpdateSuccess=function(a,f,e){204!==e.status&&(this.lastFetchTime=a.time,h.map(this.handlers,function(c){var b=a[c.property];Array.isArray(b)||(b=[b]);b=c.filterNewResults(c.results,b);0<b.length&&(c.results=c.results.concat(b),c.render(b))},this))};a.prototype._onUpdateError=
function(a){a=a||{};if(a={404:"not found - the plugin has been probably been removed or disabled from Confluence",500:"generic server error",503:"service unavailable",504:"gateway timeout"}[a.status])this.disable(),g.log('Quick comment reload plugin has been disabled in this page due to a server error: "'+a+'". Please refresh the page to get it back.')};return new a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickreload:quick-reload-bootstrap', location = 'main/quick-reload-main.js' */
require("ajs confluence-quick-reload/main/quick-reload-manager confluence-quick-reload/handlers/quick-reload-comments confluence-quick-reload/handlers/quick-reload-inline-comments confluence-quick-reload/handlers/quick-reload-page confluence/legacy".split(" "),function(b,a,c,d,e,f){b.toInit(function(){if(!(b.DarkFeatures.isEnabled("quickreload.disabled")||!f.CommentDisplayManager||b.Meta.get("page-id")===void 0)){a.addHandler(c);a.addHandler(d);a.addHandler(e);a.enable();b.bind("page.commentAddedOrUpdated",
function(b,a){c.ignoreOnce(a.commentId)})}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-content-report-plugin:resources', location = 'com/atlassian/confluence/plugins/content_report/js/tablesorter-date-parser.js' */
(function(A){A(function(){A.tablesorter.addParser({id:"dateAttributeParser",is:function(B,D,C){return A(C).is(".content-report-table-macro .modified")
},format:function(B,D,C,E){return A(C).attr("data-sortable-date")
},type:"numeric"})
})
})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-content-report-plugin:resources', location = 'com/atlassian/confluence/plugins/content_report/soy/content-report-table.soy' */
// This file was automatically generated from content-report-table.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Plugins.ContentReport.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Plugins == 'undefined') { Confluence.Templates.Plugins = {}; }
if (typeof Confluence.Templates.Plugins.ContentReport == 'undefined') { Confluence.Templates.Plugins.ContentReport = {}; }


Confluence.Templates.Plugins.ContentReport.contentReportTable = function(opt_data, opt_ignored) {
  var output = '';
  var hasSocialColumn__soy3 = opt_data.showCommentsCount || opt_data.showLikesCount;
  if (opt_data.results.length == 0 && opt_data.blueprintKey) {
    output += '<div class="blueprint-blank-experience ' + soy.$$escapeHtml(opt_data.blueprintKey) + '"><div class="content"><h2>' + soy.$$escapeHtml(opt_data.blankTitle) + '</h2><p>' + soy.$$escapeHtml(opt_data.blankDescription) + '</p></div>' + ((opt_data.createButtonLabel) ? '<p><button class="create-from-template-button aui-button aui-button-primary" data-space-key="' + soy.$$escapeHtml(opt_data.dataSpaceKey) + '" data-content-blueprint-id="' + soy.$$escapeHtml(opt_data.contentBlueprintId) + '" href="' + soy.$$escapeHtml(opt_data.createContentUrl) + '" >' + soy.$$escapeHtml(opt_data.createButtonLabel) + '</button></p>' : '') + '</div>';
  } else {
    output += '<table class="aui content-report-table-macro' + ((hasSocialColumn__soy3) ? ' with-extra-columns' : '') + '"' + ((opt_data.analyticsKey) ? ' data-analytics-key="' + soy.$$escapeHtml(opt_data.analyticsKey) + '"' : '') + '><thead><tr><th>' + soy.$$escapeHtml("Title") + '</th><th>' + soy.$$escapeHtml("Creator") + '</th><th>' + soy.$$escapeHtml("Modified") + '</th></tr></thead><tbody>';
    var resultList43 = opt_data.results;
    var resultListLen43 = resultList43.length;
    if (resultListLen43 > 0) {
      for (var resultIndex43 = 0; resultIndex43 < resultListLen43; resultIndex43++) {
        var resultData43 = resultList43[resultIndex43];
        output += '<tr><td class="title"><a href="' + soy.$$escapeHtml(resultData43.urlPath) + '">' + soy.$$escapeHtml(resultData43.title) + '</a></td><td class="creator">' + Confluence.Templates.User.usernameLink({canView: opt_data.canViewProfiles, username: resultData43.creatorName, fullName: resultData43.creatorFullName, contextPath: opt_data.contextPath}) + '</td><td class="modified" data-sortable-date="' + soy.$$escapeHtml(resultData43.sortableDate) + '">' + soy.$$escapeHtml(resultData43.friendlyModificationDate) + '</td>' + ((hasSocialColumn__soy3) ? '<td class="social">' + ((opt_data.showCommentsCount && resultData43.commentCount != 0) ? '<span class="icon icon-comment"></span> <span class="count">' + soy.$$escapeHtml(resultData43.commentCount) + '</span>' : '') + ((opt_data.showLikesCount && resultData43.likeCount != 0) ? '<span class="icon icon-like"></span> <span class="count">' + soy.$$escapeHtml(resultData43.likeCount) + '</span>' : '') + '</td>' : '') + '</tr>';
      }
    } else {
      output += '<tr><td colspan="3">' + soy.$$escapeHtml("No content found.") + '</td></tr>';
    }
    output += '</tbody></table>' + ((opt_data.searchMoreResultsLinkUrl) ? '<div class="more-results"><a href="' + soy.$$escapeHtml("/confluence") + soy.$$escapeHtml(opt_data.searchMoreResultsLinkUrl) + '">' + soy.$$escapeHtml("Find more results") + '</a></div>' : '');
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Plugins.ContentReport.contentReportTable.soyTemplateName = 'Confluence.Templates.Plugins.ContentReport.contentReportTable';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-content-report-plugin:resources', location = 'com/atlassian/confluence/plugins/content_report/js/content-report-analytics.js' */
AJS.$(function(A){A(".content-report-table-macro").on("click",".title a",function(D){var B=A(D.delegateTarget).data("analytics-key");
if(B){var C="content-report-table-macro.content-click."+B;
AJS.trigger("analytics",{name:C})
}})
});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-experimental-table-sortable', location = 'js-vendor/jquery/jquery.tablesorter.js' */
/*
 * TableSorter 2.10.8 - Client-side table sorting with ease!
 * @requires jQuery v1.2.6+
 *
 * Copyright (c) 2007 Christian Bach
 * Examples and docs at: http://tablesorter.com
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * @type jQuery
 * @name tablesorter
 * @cat Plugins/Tablesorter
 * @author Christian Bach/christian.bach@polyester.se
 * @contributor Rob Garrison/https://github.com/Mottie/tablesorter
 */
!(function(B){B.extend({tablesorter:new function(){var C=this;C.version="2.10.8";C.parsers=[];C.widgets=[];C.defaults={theme:"default",widthFixed:false,showProcessing:false,headerTemplate:"{content}",onRenderTemplate:null,onRenderHeader:null,cancelSelection:true,dateFormat:"mmddyyyy",sortMultiSortKey:"shiftKey",sortResetKey:"ctrlKey",usNumberFormat:true,delayInit:false,serverSideSorting:false,headers:{},ignoreCase:true,sortForce:null,sortList:[],sortAppend:null,sortInitialOrder:"asc",sortLocaleCompare:false,sortReset:false,sortRestart:false,emptyTo:"bottom",stringTo:"max",textExtraction:"simple",textSorter:null,widgets:[],widgetOptions:{zebra:["even","odd"]},initWidgets:true,initialized:null,tableClass:"tablesorter",cssAsc:"tablesorter-headerAsc",cssChildRow:"tablesorter-childRow",cssDesc:"tablesorter-headerDesc",cssHeader:"tablesorter-header",cssHeaderRow:"tablesorter-headerRow",cssIcon:"tablesorter-icon",cssInfoBlock:"tablesorter-infoOnly",cssProcessing:"tablesorter-processing",selectorHeaders:"> thead th, > thead td",selectorSort:"th, td",selectorRemove:".remove-me",debug:false,headerList:[],empties:{},strings:{},parsers:[]};function O(Y){if(typeof console!=="undefined"&&typeof console.log!=="undefined"){console.log(Y)}else{alert(Y)}}function I(Y,Z){O(Y+" ("+(new Date().getTime()-Z.getTime())+"ms)")}C.log=O;C.benchmark=I;function F(b,a,Y){if(!a){return""}var e=b.config,Z=e.textExtraction,d="";if(Z==="simple"){if(e.supportsTextContent){d=a.textContent}else{d=B(a).text()}}else{if(typeof Z==="function"){d=Z(a,b,Y)}else{if(typeof Z==="object"&&Z.hasOwnProperty(Y)){d=Z[Y](a,b,Y)}else{d=e.supportsTextContent?a.textContent:B(a).text()}}}return B.trim(d)}function J(e,g,c,b){var d,Z=C.parsers.length,Y=false,a="",f=true;while(a===""&&f){c++;if(g[c]){Y=g[c].cells[b];a=F(e,Y,b);if(e.config.debug){O("Checking if value was empty on row "+c+", column: "+b+': "'+a+'"')}}else{f=false}}while(--Z>=0){d=C.parsers[Z];if(d&&d.id!=="text"&&d.is&&d.is(a,e,Y)){return d}}return C.getParserById("text")}function K(k){var j=k.config,d=j.$tbodies=j.$table.children("tbody:not(."+j.cssInfoBlock+")"),m,g,b,e,f,Y,a,Z="";if(d.length===0){return j.debug?O("*Empty table!* Not building a parser cache"):""}m=d[0].rows;if(m[0]){g=[];b=m[0].cells.length;for(e=0;e<b;e++){f=j.$headers.filter(":not([colspan])");f=f.add(j.$headers.filter('[colspan="1"]')).filter('[data-column="'+e+'"]:last');Y=j.headers[e];a=C.getParserById(C.getData(f,Y,"sorter"));j.empties[e]=C.getData(f,Y,"empty")||j.emptyTo||(j.emptyToBottom?"bottom":"top");j.strings[e]=C.getData(f,Y,"string")||j.stringTo||"max";if(!a){a=J(k,m,-1,e)}if(j.debug){Z+="column:"+e+"; parser:"+a.id+"; string:"+j.strings[e]+"; empty: "+j.empties[e]+"\n"}g.push(a)}}if(j.debug){O(Z)}j.parsers=g}function X(q){var l=q.tBodies,d=q.config,n,Y,o=d.parsers,r,p,f,e,a,g,h,m,Z=[];d.cache={};if(!o){return d.debug?O("*Empty table!* Not building a cache"):""}if(d.debug){m=new Date()}if(d.showProcessing){C.isProcessing(q,true)}for(a=0;a<l.length;a++){d.cache[a]={row:[],normalized:[]};if(!B(l[a]).hasClass(d.cssInfoBlock)){n=(l[a]&&l[a].rows.length)||0;Y=(l[a].rows[0]&&l[a].rows[0].cells.length)||0;for(f=0;f<n;++f){g=B(l[a].rows[f]);h=[];if(g.hasClass(d.cssChildRow)){d.cache[a].row[d.cache[a].row.length-1]=d.cache[a].row[d.cache[a].row.length-1].add(g);continue}d.cache[a].row.push(g);for(e=0;e<Y;++e){r=F(q,g[0].cells[e],e);p=o[e].format(r,q,g[0].cells[e],e);h.push(p);if((o[e].type||"").toLowerCase()==="numeric"){Z[e]=Math.max(Math.abs(p)||0,Z[e]||0)}}h.push(d.cache[a].normalized.length);d.cache[a].normalized.push(h)}d.cache[a].colMax=Z}}if(d.showProcessing){C.isProcessing(q)}if(d.debug){I("Building cache for "+n+" rows",m)}}function V(u,s){var v=u.config,w=u.tBodies,d=[],g=v.cache,f,h,a,e,x,Z,t,q,p,o,Y,m;if(!g[0]){return }if(v.debug){m=new Date()}for(p=0;p<w.length;p++){x=B(w[p]);if(x.length&&!x.hasClass(v.cssInfoBlock)){Z=C.processTbody(u,x,true);f=g[p].row;h=g[p].normalized;a=h.length;e=a?(h[0].length-1):0;for(t=0;t<a;t++){Y=h[t][e];d.push(f[Y]);if(!v.appender||!v.removeRows){o=f[Y].length;for(q=0;q<o;q++){Z.append(f[Y][q])}}}C.processTbody(u,Z,false)}}if(v.appender){v.appender(u,d)}if(v.debug){I("Rebuilt table",m)}if(!s){C.applyWidget(u)}B(u).trigger("sortEnd",u)}function Q(u){var r=[],a={},q=0,h=B(u).find("thead:eq(0), tfoot").children("tr"),f,e,d,b,o,s,p,Y,n,g,m,Z;for(f=0;f<h.length;f++){s=h[f].cells;for(e=0;e<s.length;e++){o=s[e];p=o.parentNode.rowIndex;Y=p+"-"+o.cellIndex;n=o.rowSpan||1;g=o.colSpan||1;if(typeof (r[p])==="undefined"){r[p]=[]}for(d=0;d<r[p].length+1;d++){if(typeof (r[p][d])==="undefined"){m=d;break}}a[Y]=m;q=Math.max(m,q);B(o).attr({"data-column":m});for(d=p;d<p+n;d++){if(typeof (r[d])==="undefined"){r[d]=[]}Z=r[d];for(b=m;b<m+g;b++){Z[b]="x"}}}}u.config.columns=q;return a}function H(Y){return(/^d/i.test(Y)||Y===1)}function S(j){var a=Q(j),Y,b,e,d,k,g,Z,f=j.config;f.headerList=[];f.headerContent=[];if(f.debug){Z=new Date()}d=f.cssIcon?'<i class="'+f.cssIcon+'"></i>':"";f.$headers=B(j).find(f.selectorHeaders).each(function(c){b=B(this);Y=f.headers[c];f.headerContent[c]=this.innerHTML;k=f.headerTemplate.replace(/\{content\}/g,this.innerHTML).replace(/\{icon\}/g,d);if(f.onRenderTemplate){e=f.onRenderTemplate.apply(b,[c,k]);if(e&&typeof e==="string"){k=e}}this.innerHTML='<div class="tablesorter-header-inner">'+k+"</div>";if(f.onRenderHeader){f.onRenderHeader.apply(b,[c])}this.column=a[this.parentNode.rowIndex+"-"+this.cellIndex];this.order=H(C.getData(b,Y,"sortInitialOrder")||f.sortInitialOrder)?[1,0,2]:[0,1,2];this.count=-1;this.lockedOrder=false;g=C.getData(b,Y,"lockedOrder")||false;if(typeof g!=="undefined"&&g!==false){this.order=this.lockedOrder=H(g)?[1,1,1]:[0,0,0]}b.addClass(f.cssHeader);f.headerList[c]=this;b.parent().addClass(f.cssHeaderRow);b.attr("tabindex",0)});L(j);if(f.debug){I("Built headers:",Z);O(f.$headers)}}function P(Z,Y,b){var a=Z.config;a.$table.find(a.selectorRemove).remove();K(Z);X(Z);W(a.$table,Y,b)}function L(Z){var Y,a=Z.config;a.$headers.each(function(b,c){Y=C.getData(c,a.headers[b],"sorter")==="false";c.sortDisabled=Y;B(c)[Y?"addClass":"removeClass"]("sorter-false")})}function D(k){var e,b,Z,Y,h=k.config,g=h.sortList,d=[h.cssAsc,h.cssDesc],a=B(k).find("tfoot tr").children().removeClass(d.join(" "));h.$headers.removeClass(d.join(" "));Y=g.length;for(b=0;b<Y;b++){if(g[b][1]!==2){e=h.$headers.not(".sorter-false").filter('[data-column="'+g[b][0]+'"]'+(Y===1?":last":""));if(e.length){for(Z=0;Z<e.length;Z++){if(!e[Z].sortDisabled){e.eq(Z).addClass(d[g[b][1]]);if(a.length){a.filter('[data-column="'+g[b][0]+'"]').eq(Z).addClass(d[g[b][1]])}}}}}}}function N(a){if(a.config.widthFixed&&B(a).find("colgroup").length===0){var Y=B("<colgroup>"),Z=B(a).width();B(a.tBodies[0]).find("tr:first").children("td").each(function(){Y.append(B("<col>").css("width",parseInt((B(this).width()/Z)*1000,10)/10+"%"))});B(a).prepend(Y)}}function T(b,d){var a,Z,e,f=b.config,Y=d||f.sortList;f.sortList=[];B.each(Y,function(g,c){a=[parseInt(c[0],10),parseInt(c[1],10)];e=f.headerList[a[0]];if(e){f.sortList.push(a);Z=B.inArray(a[1],e.order);e.count=Z>=0?Z:a[1]%(f.sortReset?3:2)}})}function M(Z,Y){return(Z&&Z[Y])?Z[Y].type||"":""}function U(n,m,f){var l,d,b,Y,p,h=n.config,Z=!f[h.sortMultiSortKey],g=B(n);g.trigger("sortStart",n);m.count=f[h.sortResetKey]?2:(m.count+1)%(h.sortReset?3:2);if(h.sortRestart){d=m;h.$headers.each(function(){if(this!==d&&(Z||!B(this).is("."+h.cssDesc+",."+h.cssAsc))){this.count=-1}})}d=m.column;if(Z){h.sortList=[];if(h.sortForce!==null){l=h.sortForce;for(b=0;b<l.length;b++){if(l[b][0]!==d){h.sortList.push(l[b])}}}Y=m.order[m.count];if(Y<2){h.sortList.push([d,Y]);if(m.colSpan>1){for(b=1;b<m.colSpan;b++){h.sortList.push([d+b,Y])}}}}else{if(h.sortAppend&&h.sortList.length>1){if(C.isValueInArray(h.sortAppend[0][0],h.sortList)){h.sortList.pop()}}if(C.isValueInArray(d,h.sortList)){for(b=0;b<h.sortList.length;b++){p=h.sortList[b];Y=h.headerList[p[0]];if(p[0]===d){p[1]=Y.order[Y.count];if(p[1]===2){h.sortList.splice(b,1);Y.count=-1}}}}else{Y=m.order[m.count];if(Y<2){h.sortList.push([d,Y]);if(m.colSpan>1){for(b=1;b<m.colSpan;b++){h.sortList.push([d+b,Y])}}}}}if(h.sortAppend!==null){l=h.sortAppend;for(b=0;b<l.length;b++){if(l[b][0]!==d){h.sortList.push(l[b])}}}g.trigger("sortBegin",n);setTimeout(function(){D(n);R(n);V(n)},1)}function R(p){var d=0,h=p.config,j=h.sortList,e=j.length,a=p.tBodies.length,r,n,g,o,f,Y,Z,q,b,m;if(h.serverSideSorting||!h.cache[0]){return }if(h.debug){r=new Date()}for(g=0;g<a;g++){f=h.cache[g].colMax;Y=h.cache[g].normalized;Z=Y.length;m=(Y&&Y[0])?Y[0].length-1:0;Y.sort(function(i,c){for(n=0;n<e;n++){o=j[n][0];b=j[n][1];q=/n/i.test(M(h.parsers,o))?"Numeric":"Text";q+=b===0?"":"Desc";if(/Numeric/.test(q)&&h.strings[o]){if(typeof (h.string[h.strings[o]])==="boolean"){d=(b===0?1:-1)*(h.string[h.strings[o]]?-1:1)}else{d=(h.strings[o])?h.string[h.strings[o]]||0:0}}var k=B.tablesorter["sort"+q](p,i[o],c[o],o,f[o],d);if(k){return k}}return i[m]-c[m]})}if(h.debug){I("Sorting on "+j.toString()+" and dir "+b+" time",r)}}function G(Y,Z){Y.trigger("updateComplete");if(typeof Z==="function"){Z(Y[0])}}function W(Z,Y,a){if(Y!==false&&!Z[0].isProcessing){Z.trigger("sorton",[Z[0].config.sortList,function(){G(Z,a)}])}else{G(Z,a)}}function E(Z){var d=Z.config,a=d.$table,Y,b;d.$headers.find(d.selectorSort).add(d.$headers.filter(d.selectorSort)).unbind("mousedown.tablesorter mouseup.tablesorter sort.tablesorter keypress.tablesorter").bind("mousedown.tablesorter mouseup.tablesorter sort.tablesorter keypress.tablesorter",function(g,h){if(((g.which||g.button)!==1&&!/sort|keypress/.test(g.type))||(g.type==="keypress"&&g.which!==13)){return false}if(g.type==="mouseup"&&h!==true&&(new Date().getTime()-b>250)){return false}if(g.type==="mousedown"){b=new Date().getTime();return g.target.tagName==="INPUT"?"":!d.cancelSelection}if(d.delayInit&&!d.cache){X(Z)}var f=/TH|TD/.test(this.tagName)?B(this):B(this).parents("th, td").filter(":first"),c=f[0];if(!c.sortDisabled){U(Z,c,g)}});if(d.cancelSelection){d.$headers.attr("unselectable","on").bind("selectstart",false).css({"user-select":"none",MozUserSelect:"none"})}a.unbind("sortReset update updateRows updateCell updateAll addRows sorton appendCache applyWidgetId applyWidgets refreshWidgets destroy mouseup mouseleave ".split(" ").join(".tablesorter ")).bind("sortReset.tablesorter",function(c){c.stopPropagation();d.sortList=[];D(Z);R(Z);V(Z)}).bind("updateAll.tablesorter",function(f,c,g){f.stopPropagation();C.refreshWidgets(Z,true,true);C.restoreHeaders(Z);S(Z);E(Z);P(Z,c,g)}).bind("update.tablesorter updateRows.tablesorter",function(f,c,g){f.stopPropagation();L(Z);P(Z,c,g)}).bind("updateCell.tablesorter",function(h,k,i,m){h.stopPropagation();a.find(d.selectorRemove).remove();var f,o,j,c=a.find("tbody"),n=c.index(B(k).parents("tbody").filter(":first")),g=B(k).parents("tr").filter(":first");k=B(k)[0];if(c.length&&n>=0){o=c.eq(n).find("tr").index(g);j=k.cellIndex;f=d.cache[n].normalized[o].length-1;d.cache[n].row[Z.config.cache[n].normalized[o][f]]=g;d.cache[n].normalized[o][j]=d.parsers[j].format(F(Z,k,j),Z,k,j);W(a,i,m)}}).bind("addRows.tablesorter",function(g,j,h,k){g.stopPropagation();var f,o=j.filter("tr").length,m=[],c=j[0].cells.length,n=a.find("tbody").index(j.parents("tbody").filter(":first"));if(!d.parsers){K(Z)}for(f=0;f<o;f++){for(Y=0;Y<c;Y++){m[Y]=d.parsers[Y].format(F(Z,j[f].cells[Y],Y),Z,j[f].cells[Y],Y)}m.push(d.cache[n].row.length);d.cache[n].row.push([j[f]]);d.cache[n].normalized.push(m);m=[]}W(a,h,k)}).bind("sorton.tablesorter",function(f,c,h,g){f.stopPropagation();a.trigger("sortStart",this);T(Z,c);D(Z);a.trigger("sortBegin",this);R(Z);V(Z,g);if(typeof h==="function"){h(Z)}}).bind("appendCache.tablesorter",function(c,g,f){c.stopPropagation();V(Z,f);if(typeof g==="function"){g(Z)}}).bind("applyWidgetId.tablesorter",function(c,f){c.stopPropagation();C.getWidgetById(f).format(Z,d,d.widgetOptions)}).bind("applyWidgets.tablesorter",function(c,f){c.stopPropagation();C.applyWidget(Z,f)}).bind("refreshWidgets.tablesorter",function(g,f,c){g.stopPropagation();C.refreshWidgets(Z,f,c)}).bind("destroy.tablesorter",function(g,h,f){g.stopPropagation();C.destroy(Z,h,f)})}C.construct=function(Y){return this.each(function(){if(!this.tHead||this.tBodies.length===0||this.hasInitialized===true){return(this.config&&this.config.debug)?O("stopping initialization! No thead, tbody or tablesorter has already been initialized"):""}var d=B(this),b=this,e,a="",Z=B.metadata;b.hasInitialized=false;b.isProcessing=true;b.config={};e=B.extend(true,b.config,C.defaults,Y);B.data(b,"tablesorter",e);if(e.debug){B.data(b,"startoveralltimer",new Date())}e.supportsTextContent=B("<span>x</span>")[0].textContent==="x";e.supportsDataObject=parseFloat(B.fn.jquery)>=1.4;e.string={max:1,min:-1,"max+":1,"max-":-1,zero:0,none:0,"null":0,top:true,bottom:false};if(!/tablesorter\-/.test(d.attr("class"))){a=(e.theme!==""?" tablesorter-"+e.theme:"")}e.$table=d.addClass(e.tableClass+a);e.$tbodies=d.children("tbody:not(."+e.cssInfoBlock+")");S(b);N(b);K(b);if(!e.delayInit){X(b)}E(b);if(e.supportsDataObject&&typeof d.data().sortlist!=="undefined"){e.sortList=d.data().sortlist}else{if(Z&&(d.metadata()&&d.metadata().sortlist)){e.sortList=d.metadata().sortlist}}C.applyWidget(b,true);if(e.sortList.length>0){d.trigger("sorton",[e.sortList,{},!e.initWidgets])}else{if(e.initWidgets){C.applyWidget(b)}}if(e.showProcessing){d.unbind("sortBegin.tablesorter sortEnd.tablesorter").bind("sortBegin.tablesorter sortEnd.tablesorter",function(c){C.isProcessing(b,c.type==="sortBegin")})}b.hasInitialized=true;b.isProcessing=false;if(e.debug){C.benchmark("Overall initialization time",B.data(b,"startoveralltimer"))}d.trigger("tablesorter-initialized",b);if(typeof e.initialized==="function"){e.initialized(b)}})};C.isProcessing=function(b,Z,a){b=B(b);var d=b[0].config,Y=a||b.find("."+d.cssHeader);if(Z){if(d.sortList.length>0){Y=Y.filter(function(){return this.sortDisabled?false:C.isValueInArray(parseFloat(B(this).attr("data-column")),d.sortList)})}Y.addClass(d.cssProcessing)}else{Y.removeClass(d.cssProcessing)}};C.processTbody=function(a,Y,Z){var b;if(Z){a.isProcessing=true;Y.before('<span class="tablesorter-savemyplace"/>');b=(B.fn.detach)?Y.detach():Y.remove();return b}b=B(a).find("span.tablesorter-savemyplace");Y.insertAfter(b);b.remove();a.isProcessing=false};C.clearTableBody=function(Y){B(Y)[0].config.$tbodies.empty()};C.restoreHeaders=function(Y){var Z=Y.config;Z.$table.find(Z.selectorHeaders).each(function(a){if(B(this).find(".tablesorter-header-inner").length){B(this).html(Z.headerContent[a])}})};C.destroy=function(d,Z,g){d=B(d)[0];if(!d.hasInitialized){return }C.refreshWidgets(d,true,true);var f=B(d),e=d.config,Y=f.find("thead:first"),a=Y.find("tr."+e.cssHeaderRow).removeClass(e.cssHeaderRow),b=f.find("tfoot:first > tr").children("th, td");Y.find("tr").not(a).remove();f.removeData("tablesorter").unbind("sortReset update updateAll updateRows updateCell addRows sorton appendCache applyWidgetId applyWidgets refreshWidgets destroy mouseup mouseleave keypress sortBegin sortEnd ".split(" ").join(".tablesorter "));e.$headers.add(b).removeClass(e.cssHeader+" "+e.cssAsc+" "+e.cssDesc).removeAttr("data-column");a.find(e.selectorSort).unbind("mousedown.tablesorter mouseup.tablesorter keypress.tablesorter");C.restoreHeaders(d);if(Z!==false){f.removeClass(e.tableClass+" tablesorter-"+e.theme)}d.hasInitialized=false;if(typeof g==="function"){g(d)}};C.regex=[/(^([+\-]?(?:0|[1-9]\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?)?$|^0x[0-9a-f]+$|\d+)/gi,/(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[\/\-]\d{1,4}[\/\-]\d{1,4}|^\w+, \w+ \d+, \d{4})/,/^0x[0-9a-f]+$/i];C.sortText=function(s,m,l,d){if(m===l){return 0}var k=s.config,j=k.string[(k.empties[d]||k.emptyTo)],Y=C.regex,p,f,h,q,Z,o,g,n;if(m===""&&j!==0){return typeof j==="boolean"?(j?-1:1):-j||-1}if(l===""&&j!==0){return typeof j==="boolean"?(j?1:-1):j||1}if(typeof k.textSorter==="function"){return k.textSorter(m,l,s,d)}p=m.replace(Y[0],"\\0$1\\0").replace(/\\0$/,"").replace(/^\\0/,"").split("\\0");h=l.replace(Y[0],"\\0$1\\0").replace(/\\0$/,"").replace(/^\\0/,"").split("\\0");f=parseInt(m.match(Y[2]),16)||(p.length!==1&&m.match(Y[1])&&Date.parse(m));q=parseInt(l.match(Y[2]),16)||(f&&l.match(Y[1])&&Date.parse(l))||null;if(q){if(f<q){return -1}if(f>q){return 1}}n=Math.max(p.length,h.length);for(g=0;g<n;g++){Z=isNaN(p[g])?p[g]||0:parseFloat(p[g])||0;o=isNaN(h[g])?h[g]||0:parseFloat(h[g])||0;if(isNaN(Z)!==isNaN(o)){return(isNaN(Z))?1:-1}if(typeof Z!==typeof o){Z+="";o+=""}if(Z<o){return -1}if(Z>o){return 1}}return 0};C.sortTextDesc=function(f,Z,Y,d){if(Z===Y){return 0}var h=f.config,g=h.string[(h.empties[d]||h.emptyTo)];if(Z===""&&g!==0){return typeof g==="boolean"?(g?-1:1):g||1}if(Y===""&&g!==0){return typeof g==="boolean"?(g?1:-1):-g||-1}if(typeof h.textSorter==="function"){return h.textSorter(Y,Z,f,d)}return C.sortText(f,Y,Z)};C.getTextValue=function(Z,e,c){if(e){var b,Y=Z?Z.length:0,f=e+c;for(b=0;b<Y;b++){f+=Z.charCodeAt(b)}return c*f}return 0};C.sortNumeric=function(g,Z,Y,f,j,i){if(Z===Y){return 0}var k=g.config,h=k.string[(k.empties[f]||k.emptyTo)];if(Z===""&&h!==0){return typeof h==="boolean"?(h?-1:1):-h||-1}if(Y===""&&h!==0){return typeof h==="boolean"?(h?1:-1):h||1}if(isNaN(Z)){Z=C.getTextValue(Z,j,i)}if(isNaN(Y)){Y=C.getTextValue(Y,j,i)}return Z-Y};C.sortNumericDesc=function(g,Z,Y,f,j,i){if(Z===Y){return 0}var k=g.config,h=k.string[(k.empties[f]||k.emptyTo)];if(Z===""&&h!==0){return typeof h==="boolean"?(h?-1:1):h||1}if(Y===""&&h!==0){return typeof h==="boolean"?(h?1:-1):-h||-1}if(isNaN(Z)){Z=C.getTextValue(Z,j,i)}if(isNaN(Y)){Y=C.getTextValue(Y,j,i)}return Y-Z};C.characterEquivalents={a:"\u00e1\u00e0\u00e2\u00e3\u00e4\u0105\u00e5",A:"\u00c1\u00c0\u00c2\u00c3\u00c4\u0104\u00c5",c:"\u00e7\u0107\u010d",C:"\u00c7\u0106\u010c",e:"\u00e9\u00e8\u00ea\u00eb\u011b\u0119",E:"\u00c9\u00c8\u00ca\u00cb\u011a\u0118",i:"\u00ed\u00ec\u0130\u00ee\u00ef\u0131",I:"\u00cd\u00cc\u0130\u00ce\u00cf",o:"\u00f3\u00f2\u00f4\u00f5\u00f6",O:"\u00d3\u00d2\u00d4\u00d5\u00d6",ss:"\u00df",SS:"\u1e9e",u:"\u00fa\u00f9\u00fb\u00fc\u016f",U:"\u00da\u00d9\u00db\u00dc\u016e"};C.replaceAccents=function(b){var Z,c="[",Y=C.characterEquivalents;if(!C.characterRegex){C.characterRegexArray={};for(Z in Y){if(typeof Z==="string"){c+=Y[Z];C.characterRegexArray[Z]=new RegExp("["+Y[Z]+"]","g")}}C.characterRegex=new RegExp(c+"]")}if(C.characterRegex.test(b)){for(Z in Y){if(typeof Z==="string"){b=b.replace(C.characterRegexArray[Z],Z)}}}return b};C.isValueInArray=function(b,Z){var c,Y=Z.length;for(c=0;c<Y;c++){if(Z[c][0]===b){return true}}return false};C.addParser=function(c){var b,Z=C.parsers.length,Y=true;for(b=0;b<Z;b++){if(C.parsers[b].id.toLowerCase()===c.id.toLowerCase()){Y=false}}if(Y){C.parsers.push(c)}};C.getParserById=function(Z){var a,Y=C.parsers.length;for(a=0;a<Y;a++){if(C.parsers[a].id.toLowerCase()===(Z.toString()).toLowerCase()){return C.parsers[a]}}return false};C.addWidget=function(Y){C.widgets.push(Y)};C.getWidgetById=function(a){var b,Z,Y=C.widgets.length;for(b=0;b<Y;b++){Z=C.widgets[b];if(Z&&Z.hasOwnProperty("id")&&Z.id.toLowerCase()===a.toLowerCase()){return Z}}};C.applyWidget=function(h,g){h=B(h)[0];var b=h.config,d=b.widgetOptions,e=[],Z,a,f,Y;if(b.debug){Z=new Date()}if(b.widgets.length){b.widgets=B.grep(b.widgets,function(i,c){return B.inArray(i,b.widgets)===c});B.each(b.widgets||[],function(c,j){Y=C.getWidgetById(j);if(Y&&Y.id){if(!Y.priority){Y.priority=10}e[c]=Y}});e.sort(function(i,c){return i.priority<c.priority?-1:i.priority===c.priority?0:1});B.each(e,function(j,c){if(c){if(g){if(c.hasOwnProperty("options")){d=h.config.widgetOptions=B.extend(true,{},c.options,d)}if(c.hasOwnProperty("init")){c.init(h,c,b,d)}}else{if(!g&&c.hasOwnProperty("format")){c.format(h,b,d,false)}}}})}if(b.debug){f=b.widgets.length;I("Completed "+(g===true?"initializing ":"applying ")+f+" widget"+(f!==1?"s":""),Z)}};C.refreshWidgets=function(f,e,Y){f=B(f)[0];var d,g=f.config,b=g.widgets,a=C.widgets,Z=a.length;for(d=0;d<Z;d++){if(a[d]&&a[d].id&&(e||B.inArray(a[d].id,b)<0)){if(g.debug){O("Refeshing widgets: Removing "+a[d].id)}if(a[d].hasOwnProperty("remove")){a[d].remove(f,g,g.widgetOptions)}}}if(Y!==true){C.applyWidget(f,e)}};C.getData=function(d,c,b){var e="",Z=B(d),Y,a;if(!Z.length){return""}Y=B.metadata?Z.metadata():false;a=" "+(Z.attr("class")||"");if(typeof Z.data(b)!=="undefined"||typeof Z.data(b.toLowerCase())!=="undefined"){e+=Z.data(b)||Z.data(b.toLowerCase())}else{if(Y&&typeof Y[b]!=="undefined"){e+=Y[b]}else{if(c&&typeof c[b]!=="undefined"){e+=c[b]}else{if(a!==" "&&a.match(" "+b+"-")){e=a.match(new RegExp("\\s"+b+"-([\\w-]+)"))[1]||""}}}}return B.trim(e)};C.formatFloat=function(a,b){if(typeof a!=="string"||a===""){return a}var Z,Y=b&&b.config?b.config.usNumberFormat!==false:typeof b!=="undefined"?b:true;if(Y){a=a.replace(/,/g,"")}else{a=a.replace(/[\s|\.]/g,"").replace(/,/g,".")}if(/^\s*\([.\d]+\)/.test(a)){a=a.replace(/^\s*\(/,"-").replace(/\)/,"")}Z=parseFloat(a);return isNaN(Z)?B.trim(a):Z};C.isDigit=function(Y){return isNaN(Y)?(/^[\-+(]?\d+[)]?$/).test(Y.toString().replace(/[,.'"\s]/g,"")):true}}()});var A=B.tablesorter;B.fn.extend({tablesorter:A.construct});A.addParser({id:"text",is:function(){return true},format:function(C,D){var E=D.config;if(C){C=B.trim(E.ignoreCase?C.toLocaleLowerCase():C);C=E.sortLocaleCompare?A.replaceAccents(C):C}return C},type:"text"});A.addParser({id:"digit",is:function(C){return A.isDigit(C)},format:function(C,D){var E=A.formatFloat((C||"").replace(/[^\w,. \-()]/g,""),D);return C&&typeof E==="number"?E:C?B.trim(C&&D.config.ignoreCase?C.toLocaleLowerCase():C):C},type:"numeric"});A.addParser({id:"currency",is:function(C){return(/^\(?\d+[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]|[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]\d+\)?$/).test((C||"").replace(/[,. ]/g,""))},format:function(C,D){var E=A.formatFloat((C||"").replace(/[^\w,. \-()]/g,""),D);return C&&typeof E==="number"?E:C?B.trim(C&&D.config.ignoreCase?C.toLocaleLowerCase():C):C},type:"numeric"});A.addParser({id:"ipAddress",is:function(C){return(/^\d{1,3}[\.]\d{1,3}[\.]\d{1,3}[\.]\d{1,3}$/).test(C)},format:function(F,H){var E,D=F?F.split("."):"",G="",C=D.length;for(E=0;E<C;E++){G+=("00"+D[E]).slice(-3)}return F?A.formatFloat(G,H):F},type:"numeric"});A.addParser({id:"url",is:function(C){return(/^(https?|ftp|file):\/\//).test(C)},format:function(C){return C?B.trim(C.replace(/(https?|ftp|file):\/\//,"")):C},type:"text"});A.addParser({id:"isoDate",is:function(C){return(/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/).test(C)},format:function(C,D){return C?A.formatFloat((C!=="")?(new Date(C.replace(/-/g,"/")).getTime()||""):"",D):C},type:"numeric"});A.addParser({id:"percent",is:function(C){return(/(\d\s*?%|%\s*?\d)/).test(C)&&C.length<15},format:function(C,D){return C?A.formatFloat(C.replace(/%/g,""),D):C},type:"numeric"});A.addParser({id:"usLongDate",is:function(C){return(/^[A-Z]{3,10}\.?\s+\d{1,2},?\s+(\d{4})(\s+\d{1,2}:\d{2}(:\d{2})?(\s+[AP]M)?)?$/i).test(C)||(/^\d{1,2}\s+[A-Z]{3,10}\s+\d{4}/i).test(C)},format:function(C,D){return C?A.formatFloat((new Date(C.replace(/(\S)([AP]M)$/i,"$1 $2")).getTime()||""),D):C},type:"numeric"});A.addParser({id:"shortDate",is:function(C){return(/(^\d{1,2}[\/\s]\d{1,2}[\/\s]\d{4})|(^\d{4}[\/\s]\d{1,2}[\/\s]\d{1,2})/).test((C||"").replace(/\s+/g," ").replace(/[\-.,]/g,"/"))},format:function(F,G,C,D){if(F){var I=G.config,E=I.headerList[D],H=E.dateFormat||A.getData(E,I.headers[D],"dateFormat")||I.dateFormat;F=F.replace(/\s+/g," ").replace(/[\-.,]/g,"/");if(H==="mmddyyyy"){F=F.replace(/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,"$3/$1/$2")}else{if(H==="ddmmyyyy"){F=F.replace(/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,"$3/$2/$1")}else{if(H==="yyyymmdd"){F=F.replace(/(\d{4})[\/\s](\d{1,2})[\/\s](\d{1,2})/,"$1/$2/$3")}}}}return F?A.formatFloat((new Date(F).getTime()||""),G):F},type:"numeric"});A.addParser({id:"time",is:function(C){return(/^(([0-2]?\d:[0-5]\d)|([0-1]?\d:[0-5]\d\s?([AP]M)))$/i).test(C)},format:function(C,D){return C?A.formatFloat((new Date("2000/01/01 "+C.replace(/(\S)([AP]M)$/i,"$1 $2")).getTime()||""),D):C},type:"numeric"});A.addParser({id:"metadata",is:function(){return false},format:function(D,E,C){var G=E.config,F=(!G.parserMetadataName)?"sortValue":G.parserMetadataName;return B(C).metadata()[F]},type:"numeric"});A.addWidget({id:"zebra",priority:90,format:function(N,K,M){var D,H,J,O,I,E,G,F,C=new RegExp(K.cssChildRow,"i"),L=K.$tbodies;if(K.debug){E=new Date()}for(G=0;G<L.length;G++){D=L.eq(G);F=D.children("tr").length;if(F>1){O=0;H=D.children("tr:visible");H.each(function(){J=B(this);if(!C.test(this.className)){O++}I=(O%2===0);J.removeClass(M.zebra[I?1:0]).addClass(M.zebra[I?0:1])})}}if(K.debug){A.benchmark("Applying Zebra widget",E)}},remove:function(H,I,F){var E,D,C=I.$tbodies,G=(F.zebra||["even","odd"]).join(" ");for(E=0;E<C.length;E++){D=B.tablesorter.processTbody(H,C.eq(E),true);D.children().removeClass(G);B.tablesorter.processTbody(H,D,false)}}})})(jQuery);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-experimental-table-sortable', location = 'js/aui-experimental-tables-sortable.js' */
(function(){var B={sortMultiSortKey:"",headers:{},debug:false};function A(D){var C=B;D.find("th").each(function(F,G){var E=AJS.$(G);C.headers[F]={};if(E.hasClass("aui-table-column-unsortable")){C.headers[F].sorter=false}else{E.attr("tabindex","0");E.wrapInner("<span class='aui-table-header-content'/>");if(E.hasClass("aui-table-column-issue-key")){C.headers[F].sorter="issue-key"}}});D.tablesorter(C)}AJS.tablessortable={setup:function(){AJS.$.tablesorter.addParser({id:"issue-key",is:function(){return false},format:function(G){var C=G.split("-");var D=C[0];var F=C[1];var I="..........";var H="000000";var E=(D+I).slice(0,I.length);E+=(H+F).slice(-H.length);return E},type:"text"});AJS.$.tablesorter.addParser({id:"textSortAttributeParser",is:function(C,E,D){return D.hasAttribute("data-sort-value")&&(!D.hasAttribute("data-sort-type")||D.getAttribute("data-sort-type")==="text")},format:function(C,E,D,F){return D.getAttribute("data-sort-value")},type:"text"});AJS.$.tablesorter.addParser({id:"numericSortAttributeParser",is:function(C,E,D){return D.getAttribute("data-sort-type")==="numeric"&&D.hasAttribute("data-sort-value")},format:function(C,E,D,F){return D.getAttribute("data-sort-value")},type:"numeric"});AJS.$(".aui-table-sortable").each(function(){A(AJS.$(this))})},setTableSortable:function(C){A(C)}};AJS.$(AJS.tablessortable.setup)})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-sortable-tables:sortable-table-resources', location = 'js/SortableTables.js' */
define("confluence-sortable-tables/sortable-tables",["jquery","ajs","document"],function(b,g,h){function i(){var a=g.Meta.get("date.format"),b;a&&0!==a.length&&(a=a.toLowerCase()[0],"m"===a?b="mmddyyyy":"d"===a?b="ddmmyyyy":"y"===a&&(b="yyyymmdd"));return b}var f;return{init:function(){f=b("table").filter(function(){var a=b(this),e=a.find("td, th"),d=this.rows.length&&b(this.rows[0].cells),c;if("false"===a.attr("data-sortable")||-1<this.className.indexOf("tablesorter"))return!1;c=b.Event("makeSortable.SortableTables");
a.trigger(c);if(c.isDefaultPrevented()||!d||0===d.length)return!1;c=0;for(var f=e.length;c<f;c++)if(a=e[c],1!=a.rowSpan||1!=a.colSpan)return!1;return b(this.rows[0]).find("table").length||d.filter("th").length!==d.length||d.hasClass("nohighlight")?!1:this.rows[1]})},enable:function(){f.each(function(){if(-1<this.className.indexOf("tablesorter")||b(this).find("> :first-child").is("thead"))return!0;var a=this.removeChild(this.tBodies[0]),e=b(a.children),e=Array.prototype.shift.call(e),d=h.createDocumentFragment(),
c=h.createElement("thead");d.appendChild(c);c.appendChild(e);d.appendChild(a);this.appendChild(d)});f.tablesorter({cssHeader:"sortableHeader",delayInit:!0,textExtraction:function(a){return g.trim(b(a).text())},dateFormat:i()})},refresh:function(){this.init();this.enable()}}});require("confluence/module-exporter").safeRequire("confluence-sortable-tables/sortable-tables",function(b){require("ajs").toInit(function(){b.init();setTimeout(b.enable,100)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/doctheme-utils.js' */
Confluence.DocThemeUtils=Confluence.DocThemeUtils||(function(f){var e;function c(){return(a().length)?true:false}function a(){if(!e){e=f("#splitter-content")}return e}function g(i){var h=f(i);f(i).appendTo(c()?a():f("body"));return h}function b(){return c()?a().scrollTop():f(document).scrollTop()}function d(){return c()?a().scrollLeft():f(document).scrollLeft()}return{isDocTheme:c,appendAbsolutePositionedElement:g,getMainContentScrollTop:b,getMainContentScrollLeft:d,getDocThemeContentElement:a}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/scrolling-inline-dialog.js' */
Confluence.ScrollingInlineDialog=function(a,d,c,b){var g=Confluence.DocThemeUtils.getDocThemeContentElement();var e=Confluence.DocThemeUtils.isDocTheme();b=b||{};if(!b.container&&e){b.container=g}var f=function(k,s,J,z){var v;var L="auto";var G;var p=-7;var q;var w;var u=e?g.width():AJS.$(window).width();var K=s.target.position();K.top+=e?g.scrollTop():0;K.left+=e?g.scrollLeft():0;var i=s.target.outerWidth();var m=K.left+i/2;var C=e?g.scrollTop()+AJS.$(window).height()-AJS.$("#footer").outerHeight():(window.pageYOffset||document.documentElement.scrollTop)+AJS.$(window).height();var n=10;var o=20;G=K.top+s.target.outerHeight()+z.offsetY;var H=k.find(".arrow").outerWidth();var j=k.outerWidth();var D=s.target.outerWidth();if(z.centerOnHighlight){if(j>D){v=K.left-(j-D)/2;q=m-v-H/2}else{v=K.left+z.offsetX;q=(j-H)/2}}else{v=K.left+z.offsetX;if(j>D){q=m-v-H/2}else{q=(j-H)/2}}q=(q<0)?0:q;var h=(e)?(K.top-g.scrollTop()):(K.top-(window.pageYOffset||document.documentElement.scrollTop));var A=z.maxHeight||0;var t=k.height();var r=h>Math.max(t,A);var l=(G+k.height())<C;w=(!l&&r)||z.onTop;z.onTop=w;var y=u-(v+j+n);if(w){G=K.top-t-8;p=t}if(w===false&&l===false){var x=(G+t)-C;var E=e?g.scrollTop()+x+AJS.$("#footer").outerHeight():(window.pageYOffset||document.documentElement.scrollTop)+x+o;var F=e?g:AJS.$("html, body");F.stop().animate({scrollTop:E},500)}if(z.isRelativeToMouse){if(y<0){L=n;v="auto";q=J.x-(AJS.$(window).width()-z.width)}else{v=J.x-20;q=J.x-v}}else{if(y<0){L=n;v="auto";var I=u-L;var B=I-j;q=m-B-H/2}}return{displayAbove:w,popupCss:{left:v,right:L,top:G},arrowCss:{position:"absolute",left:q,right:"auto",top:p}}};if(!b.calculatePositions){b.calculatePositions=f}return AJS.InlineDialog.call(this,a,d,c,b)};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/highlight-panel.js' */
Confluence.HighlightAction=(function(f){var d={};var c;var b={MAINCONTENT_AND_COMMENT:function(o){return Confluence.HighlightAction.RangeHelper.isSelectionInsideContent(f(".wiki-content"),o)},MAINCONTENT_ONLY:function(o){c=c||f(".wiki-content").first();return Confluence.HighlightAction.RangeHelper.isSelectionInsideContent(c,o)},COMMENT_ONLY:function(o){return Confluence.HighlightAction.RangeHelper.isSelectionInsideContent(f(".comment-content"),o)}};function a(p,q){var o={onClick:function(){},shouldDisplay:b.MAINCONTENT_AND_COMMENT};d[p]=f.extend(o,q)}function l(o){var p=d[o];if(!p){p=function(){AJS.logError("The button with key "+o+" doesn't have a registered handler")}}return p}function e(p){var o=Confluence.getContextPath()+"/rest/highlighting/1.0/insert-storage-fragment";return f.ajax({type:"POST",contentType:"application/json",url:o,data:JSON.stringify(p)})}function g(o){var p=Confluence.getContextPath()+"/rest/highlighting/1.0/insert-storage-column-table";return f.ajax({type:"POST",contentType:"application/json",url:p,data:JSON.stringify(o)})}function k(q,p,r){var o=i(r);o.tableColumnIndex=p;o.cellModifications=q;return o}function h(o,q){var p=i(q);p.xmlModification=o[0].xmlInsertion;return p}function j(o,q){var p=i(q);p.xmlModification=o;return p}function m(){if(window.getSelection){window.getSelection().empty&&window.getSelection().empty();window.getSelection().removeAllRanges&&window.getSelection().removeAllRanges()}else{window.document.selection&&window.document.selection.empty()}}function i(p){var o={};o.pageId=p.pageId;o.selectedText=p.selectedText;o.index=p.index;o.numMatches=p.numMatches;o.lastFetchTime=n();return o}function n(){return f("meta[name='confluence-request-time']").attr("content")}return{registerButtonHandler:a,getButtonHandler:l,insertContentAtSelectionEnd:e,insertContentsInTableColumnCells:g,createTableInsertionBean:k,createInsertionBean:h,createXMLModificationBean:j,clearTextSelection:m,WORKING_AREA:b}})(AJS.$);Confluence.HighlightAction.RangeHelper=(function(h){function j(p){return{area:c(p),text:k(p),html:n(p),containingElement:d(p),range:p}}function c(q){var r=Confluence.DocThemeUtils.getMainContentScrollTop();var s=Confluence.DocThemeUtils.getMainContentScrollLeft();var w=q.getClientRects();if(!w.length&&q.parentElement()){var x=h(q.parentElement());var p=x.offset();w=[{top:p.top-((Confluence.DocThemeUtils.isDocTheme())?0:r),left:p.left-((Confluence.DocThemeUtils.isDocTheme())?0:s),bottom:p.top+x.height(),right:p.left+x.width()}]}var z=g(q,w);var u=function(E,D){var C={};C.top=E.top;C.left=E.left+s;C.bottom=D.bottom;if(E.left>=D.right){C.right=E.right}else{C.right=D.right}C.right=C.right+s;C.top=C.top+r;C.bottom=C.bottom+r;C.width=C.right-C.left;C.height=C.bottom-C.top;return C};var t=function(D){var C={};C.width=D.right-D.left;C.height=D.bottom-D.top;C.left=D.left+s;C.right=D.right+s;C.top=D.top+r;C.bottom=D.bottom+r;return C};var B=function(C){if(Confluence.DocThemeUtils.isDocTheme()){var D=Confluence.DocThemeUtils.getDocThemeContentElement().offset();C.left=C.left-D.left;C.right=C.right-D.left;C.top=C.top-D.top;C.bottom=C.bottom-D.top}return C};var A=B(u(z.first,z.last));var v=B(t(z.first));if(Confluence.HighlightAction.debug){var y=h("<div>").attr("id","highlight-actions-debug-helper");Confluence.DocThemeUtils.appendAbsolutePositionedElement(y).css(h.extend({position:"absolute",outline:"1px solid red"},A))}return{first:v,average:A}}function k(q){var p=(q.text!=undefined)?q.text:q.toString();return i(p)}function n(p){return(p.cloneContents)?h("<div>").append(p.cloneContents()).html():p.htmlText}function d(q){if(q.commonAncestorContainer){var p=q.commonAncestorContainer;if(p.nodeType==3){return p.parentNode}return p}else{if(q.parentElement){return q.parentElement()}}}function g(r,q){var p={};p.first=q[0];p.last=q[q.length-1];if(r.endOffset!=="undefined"){if(r.endOffset==0&&q.length>1){p.last=q[q.length-2]}}return p}function e(){if(window.getSelection&&window.getSelection().isCollapsed){return false}if(document.selection&&(document.selection.type=="None"||document.selection.createRange().htmlText=="")){return false}var s;if(window.getSelection){var p=window.getSelection();s=p.getRangeAt(p.rangeCount-1)}else{if(document.selection){s=document.selection.createRange()}}if(/^\s*$/.test(k(s))){var q=n(s);if(!q){return false}var r=q.toLowerCase().indexOf("<img ")!=-1;if(!r){return false}}if(!m(h(".wiki-content"),s)){return false}return s}function m(p,s){var q=d(s);var r=function(){var t=false;h.each(p,function(u,v){if(v===q||h.contains(v,q)){t=true;return false}});return t};return r()}function b(r,q){var p=k(o(r,q));var t=h.trim(k(q));var s=a(t,r);p=p.replace(/\s*$/,"");return{pageId:AJS.Meta.get("page-id"),selectedText:t,index:h.inArray(p.length-t.length,s),numMatches:s.length}}function f(p){if(document.createRange){return p.text()}else{range=document.body.createTextRange();range.moveToElementText(p.get(0));return range.text}}function o(r,q){var p;if(document.createRange){p=document.createRange();p.setStart(r.get(0),0);p.setEnd(q.endContainer,q.originalEndOffset)}else{p=document.body.createTextRange();p.moveToElementText(r.get(0));p.setEndPoint("EndToEnd",q)}return p}function a(u,s){var q=f(s);q=l(u,s.clone(),q);q=i(q);var t=0;var r=-1;var p=[];while((r=q.indexOf(u,t))>-1){p.push(r);t=r+1}return p}function l(u,t,r){var s=t.find('.user-mention, a[href^="/"]');t.find('.conf-macro[data-hasbody="false"]').each(function(){if(h(this).text().indexOf(u)>-1){s=s.add(this)}});if(s.length>0){var p=u.replace(/\S/g," ");var q=new RegExp(u.replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&"),"g");s.each(function(){var v=h(this).text();h(this).text(v.replace(q,p))});return f(t)}return r}function i(p){return p.replace(/\u00a0/g,"\u0020")}return{getRangeOption:j,getUserSelectionRange:e,getSelectionRects:c,getSelectionText:k,getSelectionHTML:n,getContainingElement:d,getFirstAndLastSelectionRect:g,isSelectionInsideContent:m,computeSearchTextObject:b}})(AJS.$);AJS.toInit(function(f){var i=f(".wiki-content").first();var g={ELEMENT_NODE:1,TEXT_NODE:3};var k={IMAGE:"IMG"};var a=f("<div>").attr("id","action-dialog-target");var d;var j="selection-action-panel";var b;var e;function o(){var r=Confluence.getContextPath()+"/rest/highlighting/1.0/panel-items";var q=AJS.Meta.get("page-id");if(q!=undefined){r=r+"?pageId="+q}var s=f.get(r,function(t){if(t.length){m(t)}});h(s)}function m(v){var y=c();var q=29;var z=false;var B=v.length*q;var A=Confluence.HighlightPanel.Templates.panelContent({webItems:v});var x=false;var s=function(D,C,E){if(!x){D.append(A);D.find(".aui-button").tooltip({gravity:"s"});l(D.parent());D.find("button").click(function(H){var F=f(this).attr("data-key");var I=Confluence.HighlightAction.getButtonHandler(F);z=true;d.hide();var G=Confluence.HighlightAction.RangeHelper.getRangeOption(b);if(f.trim(G.text)!==""){G.searchText=Confluence.HighlightAction.RangeHelper.computeSearchTextObject(i,b)}I.onClick(G)})}E();x=true;return false};var w=function(C){var D=false;C.find("button").each(function(E){var G=f(this);var F=G.attr("data-key");var I=Confluence.HighlightAction.getButtonHandler(F);var H=I.shouldDisplay(b);G.css("display",H?"inline-block":"none");D=D||H});if(!D){d.hide()}else{C.find(".contents").width("auto")}};var r=function(){Confluence.HighlightAction.Analytics.sendAnalyticsForOpeningHighlightOptionPanel();w(this.popup);y.bindHideEvents();a.show()};var u=function(){y.unbindHideEvents();a.hide()};var t={centerOnHighlight:true,onTop:true,fadeTime:0,width:B,persistent:true,initCallback:r,hideCallback:u};d=Confluence.ScrollingInlineDialog(a,j,s,t)}function l(q){q.children().attr("unselectable","on").on("selectstart",false)}function h(s){var q;var r=0;var t=1000;f(document).on("mouseup",function(u){s.done(function(w){if(!(w&&w.length>0)){return}var v=f(u.target);if(v.closest(".aui-inline-dialog").length!==0){return}setTimeout(function(){clearTimeout(q);var x=t;if(f(d[0]).is(":visible")){x=r}q=setTimeout(function(){n()},x)},r)})});s.done(function(){AJS.bind("quickedit.success",function(){d.hide()})})}function n(){b=Confluence.HighlightAction.RangeHelper.getUserSelectionRange();var q=function(t){return f.trim(t.toString())!==""};b.originalEndOffset=b.endOffset;if(!b||!q(b)){d.hide();return}var s=Confluence.HighlightAction.RangeHelper.getSelectionRects(b);if(!s){return}var r=p(s);if(r||!f(d[0]).is(":visible")){f(d[0]).hide();d.show()}}function c(){var t=function(){v();s()};var w=function(){q();y()};var r=false;var x=j+".inline-dialog-check";var v=function(){if(!r){f("body").bind("click."+x,function(A){var z=f(A.target);if(z.closest("#inline-dialog-"+j+" .contents").length===0){if(!b){d.hide()}}});r=true}};var q=function(){if(r){f("body").unbind("click."+x)}r=false};var u=function(z){if(z.keyCode===27){d.hide()}};var s=function(){f(document).on("keydown",u)};var y=function(){f(document).off("keydown",u)};return{bindHideEvents:t,unbindHideEvents:w}}function p(r){Confluence.DocThemeUtils.appendAbsolutePositionedElement(a);var q=false;if(!e||r.first.top!=e.first.top||r.first.height!=e.first.height||r.first.left!=e.first.left||r.first.width!=e.first.width){a.css({top:r.first.top,height:r.first.height,left:r.first.left,width:r.first.width});e=r;q=true}return q}o()});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/quote-in-comment.js' */
AJS.toInit(function(f){var a=true;var h=false;var d="com.atlassian.confluence.plugins.confluence-highlight-actions:quote-comment";function b(l){var k=l.getBody().createTextRange();k.moveToElementText(l.getBody());k.collapse(false);k.select()}function e(){var k=40;if(Confluence.DocThemeUtils.isDocTheme()){var l=Confluence.DocThemeUtils.getDocThemeContentElement();var m=l.scrollTop()-f("#header").height()+f("#rte-toolbar").offset().top;l.scrollTop(m-k)}else{var m=f("#rte-toolbar").offset().top;f(document).scrollTop(m-k)}}function j(l,m){var n="<p><br/></p>";if(f.browser.msie&&!h){b(l);n="<p></p>"}var k="<blockquote><p>"+m.html+"</p></blockquote>"+n;l.execCommand("mceInsertContent",false,k);h=false}function i(k){Confluence.HighlightAction.clearTextSelection();setTimeout(function(){var l=AJS&&AJS.Rte&&AJS.Rte.getEditor&&AJS.Rte.getEditor();if(l){Confluence.HighlightAction.Analytics.sendAnalyticsForQuoteInComment();e();j(l,k)}else{Confluence.HighlightAction.Analytics.sendAnalyticsForQuoteInComment(a);h=true;var m=function(){j(AJS.Rte.getEditor(),k);AJS.unbind("quickedit.visible",m)};AJS.bind("quickedit.visible",m);c(g(k.containingElement))}},0)}function g(k){var l=f(k).closest("div.comment");return l}function c(k){if(!k.length>0){f(".quick-comment-prompt").click()}else{k.find(".comment-actions .action-reply-comment").click()}}Confluence&&Confluence.HighlightAction&&Confluence.HighlightAction.registerButtonHandler(d,{onClick:i,shouldDisplay:Confluence.HighlightAction.WORKING_AREA.MAINCONTENT_AND_COMMENT})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/js/highlight-analytics.js' */
Confluence.HighlightAction.Analytics=(function(c){var b="confluence.highlight.actions.open";var e="confluence.quote.in.comment.insert";var g="confluence.quote.in.comment.append";function d(h,i){AJS.trigger("analytics",{name:h,data:i})}function a(){d(b)}function f(h){if(h){d(e)}else{d(g)}}return{sendAnalyticsForOpeningHighlightOptionPanel:a,sendAnalyticsForQuoteInComment:f}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-highlight-actions:highlighting-experiment-resources', location = '/soy/templates.soy' */
// This file was automatically generated from templates.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.HighlightPanel.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.HighlightPanel == 'undefined') { Confluence.HighlightPanel = {}; }
if (typeof Confluence.HighlightPanel.Templates == 'undefined') { Confluence.HighlightPanel.Templates = {}; }


Confluence.HighlightPanel.Templates.panelContent = function(opt_data, opt_ignored) {
  var output = '';
  var webItemList3 = opt_data.webItems;
  var webItemListLen3 = webItemList3.length;
  for (var webItemIndex3 = 0; webItemIndex3 < webItemListLen3; webItemIndex3++) {
    var webItemData3 = webItemList3[webItemIndex3];
    output += '<button data-key="' + soy.$$escapeHtml(webItemData3.key) + '" class="aui-button aui-button-compact aui-button-subtle" title="' + soy.$$escapeHtml(webItemData3.label) + '"><span class="aui-icon aui-icon-small ' + soy.$$escapeHtml(webItemData3.styleClass) + '"/></button>';
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.HighlightPanel.Templates.panelContent.soyTemplateName = 'Confluence.HighlightPanel.Templates.panelContent';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.expand-macro:expand-macro-core', location = 'com/atlassian/confluence/plugins/expand/js/expand-macro-core.js' */
(function(){var a=function(b){this.$=b;this.createToggleFunction=function(e){var d=this.$;return function c(i){if(typeof e!="undefined"&&!e(i)){return}var f=d(this),g=d(".expand-control-icon",f),h=d(".expand-content",f.closest(".expand-container")).first();var j;if(h.hasClass("expand-hidden")){h.css("display","block");h.animate({opacity:1});j="expand"}else{h.animate({opacity:0},{complete:function(){h.hide()}});j="collapse"}h.toggleClass("expand-hidden");g.toggleClass("expanded");AJS.trigger("analyticsEvent",{name:"confluence.expand-macro.expand-click",data:{userAction:j}})}};this.getExpandElements=function(c){return this.$(".expand-control",c)}};Confluence=Confluence||{};Confluence.Plugins=Confluence.Plugins||{};Confluence.Plugins.ExpandMacro={bind:function(b,c,g,f){var e=new a(b);var d=e.getExpandElements(c);d.length&&d.bind(g,e.createToggleFunction(f))}}})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.expand-macro:expand-macro-desktop-resources', location = 'com/atlassian/confluence/plugins/expand/js/expand-macro.js' */
AJS.toInit(function(a){Confluence.Plugins.ExpandMacro.bind(a,a("body"),"click keyup",function(b){return !(b.type=="keyup"&&b.keyCode!=13)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-urlmacro-resources', location = 'com/atlassian/confluence/plugins/sharelinksurlmacro/soy/sharelinks-urlmacro-templates.soy' */
// This file was automatically generated from sharelinks-urlmacro-templates.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Blueprints.SharelinksUrlMacro.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.SharelinksUrlMacro == 'undefined') { Confluence.Blueprints.SharelinksUrlMacro = {}; }


Confluence.Blueprints.SharelinksUrlMacro.bookmarkletLink = function(opt_data, opt_ignored) {
  return '<a class="aui-button sharelinks-urlmacro-button" href="' + Confluence.Blueprints.SharelinksUrlMacro.bookmarkletScript(opt_data) + '"><span>' + soy.$$escapeHtml("Share on Confluence") + '</span></a>';
};
if (goog.DEBUG) {
  Confluence.Blueprints.SharelinksUrlMacro.bookmarkletLink.soyTemplateName = 'Confluence.Blueprints.SharelinksUrlMacro.bookmarkletLink';
}


Confluence.Blueprints.SharelinksUrlMacro.bookmarkletScript = function(opt_data, opt_ignored) {
  return 'javascript:(function(){var screenWidth=screen.width,screenHeight=screen.height,popupWidth=640,popupHeight=580,popupLeft=0,popupTop=0; if(screenWidth>popupWidth){popupLeft=Math.round((screenWidth/2)-(popupWidth/2));}if(screenHeight>popupHeight){popupTop=Math.round((screenHeight/2)-(popupHeight/2));}window.open(\'' + soy.$$filterNoAutoescape(opt_data.bookmarkletActionURL) + '?bookmarkedURL=\'+encodeURIComponent(window.location.href), \'\',\'left=\'+popupLeft+\',top=\'+popupTop+\',width=\'+popupWidth+\',height=\'+popupHeight+\',personalbar=0,toolbar=0,scrollbars=1,resizable=1\');}());';
};
if (goog.DEBUG) {
  Confluence.Blueprints.SharelinksUrlMacro.bookmarkletScript.soyTemplateName = 'Confluence.Blueprints.SharelinksUrlMacro.bookmarkletScript';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:sharelinks-urlmacro-resources', location = 'com/atlassian/confluence/plugins/sharelinksurlmacro/js/sharelinks-urlmacro.js' */
AJS.toInit(function(a){a(".sharelinks-urlmacro-button").click(function(){alert("Drag this link to your toolbar");return false})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:jsUri', location = '/includes/js/third-party/jsUri.js' */
(function(){function g(a){a=decodeURIComponent(a);return a=a.replace("+"," ")}function h(a){var c,b,f,e,d=[];if("undefined"===typeof a||null===a||""===a)return d;0===a.indexOf("?")&&(a=a.substring(1));c=a.toString().split(/[&;]/);for(a=0;a<c.length;a++)b=c[a],f=b.split("="),e=f[0],b=-1===b.indexOf("=")?null:null===f[1]?"":f[1],d.push([e,b]);return d}function d(a){var c=/^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@\/]*)(?::([^:@\/]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/.exec(a||
""),b={};"source protocol authority userInfo user password host port relative path directory file query anchor".split(" ").forEach(function(a,e){b[a]=c[e]||""});this.uriParts=b;this.queryPairs=h(this.uriParts.query);this.hasAuthorityPrefixUserPref=null}Array.prototype.forEach||(Array.prototype.forEach=function(a,c){for(var b=0,f=this.length;b<f;++b)a.call(c||this,this[b],b,this)});"protocol userInfo host port path anchor".split(" ").forEach(function(a){d.prototype[a]=function(c){typeof c!=="undefined"&&
(this.uriParts[a]=c);return this.uriParts[a]}});d.prototype.hasAuthorityPrefix=function(a){if(typeof a!=="undefined")this.hasAuthorityPrefixUserPref=a;return this.hasAuthorityPrefixUserPref===null?this.uriParts.source.indexOf("//")!==-1:this.hasAuthorityPrefixUserPref};d.prototype.query=function(a){var c="",b;if(typeof a!=="undefined")this.queryPairs=h(a);for(a=0;a<this.queryPairs.length;a++){b=this.queryPairs[a];c.length>0&&(c=c+"&");c=b[1]===null?c+b[0]:c+b.join("=")}return c.length>0?"?"+c:c};
d.prototype.getQueryParamValue=function(a){var c,b;for(b=0;b<this.queryPairs.length;b++){c=this.queryPairs[b];if(g(a)===g(c[0]))return c[1]}};d.prototype.getQueryParamValues=function(a){var c=[],b,f;for(b=0;b<this.queryPairs.length;b++){f=this.queryPairs[b];g(a)===g(f[0])&&c.push(f[1])}return c};d.prototype.deleteQueryParam=function(a,c){var b=[],f,e,d,h;for(f=0;f<this.queryPairs.length;f++){e=this.queryPairs[f];d=g(e[0])===g(a);h=g(e[1])===g(c);(arguments.length===1&&!d||arguments.length===2&&!d&&
!h)&&b.push(e)}this.queryPairs=b;return this};d.prototype.addQueryParam=function(a,c,b){if(arguments.length===3&&b!==-1){b=Math.min(b,this.queryPairs.length);this.queryPairs.splice(b,0,[a,c])}else arguments.length>0&&this.queryPairs.push([a,c]);return this};d.prototype.replaceQueryParam=function(a,c,b){var d=-1,e,h;if(arguments.length===3){for(e=0;e<this.queryPairs.length;e++){h=this.queryPairs[e];if(g(h[0])===g(a)&&decodeURIComponent(h[1])===g(b)){d=e;break}}this.deleteQueryParam(a,b).addQueryParam(a,
c,d)}else{for(e=0;e<this.queryPairs.length;e++){h=this.queryPairs[e];if(g(h[0])===g(a)){d=e;break}}this.deleteQueryParam(a);this.addQueryParam(a,c,d)}return this};"protocol hasAuthorityPrefix userInfo host port path query anchor".split(" ").forEach(function(a){var c="set"+a.charAt(0).toUpperCase()+a.slice(1);d.prototype[c]=function(b){this[a](b);return this}});d.prototype.scheme=function(){var a="";if(this.protocol()){a=a+this.protocol();this.protocol().indexOf(":")!==this.protocol().length-1&&(a=
a+":");a=a+"//"}else this.hasAuthorityPrefix()&&this.host()&&(a=a+"//");return a};d.prototype.origin=function(){var a=this.scheme();if(this.userInfo()&&this.host()){a=a+this.userInfo();this.userInfo().indexOf("@")!==this.userInfo().length-1&&(a=a+"@")}if(this.host()){a=a+this.host();this.port()&&(a=a+(":"+this.port()))}return a};d.prototype.toString=function(){var a=this.origin();if(this.path())a=a+this.path();else if(this.host()&&(this.query().toString()||this.anchor()))a=a+"/";if(this.query().toString()){this.query().toString().indexOf("?")!==
0&&(a=a+"?");a=a+this.query().toString()}if(this.anchor()){this.anchor().indexOf("#")!==0&&(a=a+"#");a=a+this.anchor()}return a};d.prototype.clone=function(){return new d(this.toString())};define("confluence/jsUri",function(){return d})})(this);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'js/inline-tasks.js' */
(function(g){function f(n){var i,o;if(n.offsetX===undefined){var m=0,l=0,k=n.target,j;do{if(k.scrollTop!=0||k.scrollLeft!=0){j=k}m+=k.offsetLeft;l+=k.offsetTop;k=k.offsetParent}while(k&&k!=k.offsetParent);i=n.pageX+(j?j.scrollLeft:0)-m;o=n.pageY+(j?j.scrollTop:0)-l}else{i=n.offsetX;o=n.offsetY}return i>=3&&i<=14&&o>=3&&o<=14}function e(i){return i.currentTarget===i.target}function d(j){var i="page";if(j.closest("table.tasks-report").length){i="report"}else{if(j.closest("#task-container").length){i="mytasks"}else{if(j.closest("ul.inline-task-list").length){i="task"}}}return i}function h(l,j){var i=l.attr("data-inline-task-id");var k=l.find(j).first();if(k.closest("li").attr("data-inline-task-id")===i){return k}else{return g()}}function c(j){var k=""+j.getFullYear();var l=""+(j.getMonth()+1);var i=""+j.getDate();if(l.length<2){l="0"+l}if(i.length<2){i="0"+i}return[k,l,i].join("-")}var a=false;g(window).bind("beforeunload",function(){a=true});var b=[];g(document).delegate("ul.inline-task-list > li[data-inline-task-id]",{click:function(n){if(e(n)&&f(n)){var l=g(n.target).toggleClass("checked"),i=l.hasClass("checked")?"CHECKED":"UNCHECKED",k=l.data("inline-task-id"),o=l.closest("ul").attr("data-inline-tasks-content-id")||AJS.params.pageId,j=AJS.contextPath()+"/rest/inlinetasks/1/task/"+o+"/"+k+"/";l.prop("disabled",true);var m=l.closest("tr");m.attr("aria-disabled",true);b.push(k);AJS.trigger("inline-tasks.status-update.start",{status:i,taskId:k,taskListQueue:b});g.ajax({type:"POST",url:j,data:{status:i,trigger:"VIEW_PAGE",atl_token:AJS.Meta.get("atl-token")},dataType:"text",timeout:30000,error:function(q,s,p){if(a||s==="timeout"){return}AJS.logError("Inline Task #"+k+" was not persisted to "+i+" because of "+p+" (status: "+s+")");l.toggleClass("checked");var r;if(q.status===403){r=new Confluence.InlineTasks.Notice({textMessage:"Oops! You can\'t update this task because you are not allowed to edit the page it appears on.",className:"forbidden-notice"})}else{r=new Confluence.InlineTasks.Notice()}r.show()},success:function(){var p={dueDate:h(l,"time").attr("datetime"),completionDate:c(new Date()),mode:"view",assigneeUsername:h(l,".user-mention").attr("data-username"),context:d(l)};if(i==="CHECKED"){AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.completed",data:p})}}}).always(function(){l.prop("disabled",false);var p=l.closest("tr");p.attr("aria-disabled",false);b.splice(AJS.indexOf(b,k),1);AJS.trigger("inline-tasks.status-update.complete",{status:i,taskId:k,taskListQueue:b})})}},mousemove:function(i){if(e(i)){if(f(i)){g(i.target).addClass("hover")}else{g(i.target).removeClass("hover")}}},mouseout:function(i){if(e(i)){g(i.target).removeClass("hover")}},mousedown:function(i){if(e(i)&&f(i)){g(i.target).addClass("task-active")}},mouseup:function(i){if(e(i)&&f(i)){g(i.target).removeClass("task-active")}}});g("ul.inline-task-list li:not(.checked) time.date-upcoming").tooltip({title:function(){return "This task is due in less than a week"},live:true});g("ul.inline-task-list li:not(.checked) time.date-past").tooltip({title:function(){return "This task is overdue"},live:true});g("span.emptycompletedate").tooltip({title:function(){return "A completion date wasn\'t recorded for this task"},live:true});g(document).on("click","time",function(){var j=g(this);var i={date:j.attr("datetime"),mode:"view",context:d(j)};AJS.trigger("analyticsEvent",{name:"confluence-spaces.date.clicked",data:i})})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'js/inline-tasks-alert.js' */
Confluence.InlineTasks=Confluence.InlineTasks||{};(function(b){var a=function(c){this.settings=b.extend({},a.DEFAULTS,c);this.template=Confluence.InlineTasks.Templates;b("#inline-tasks-notice").remove();var d=b(this.template.notice(this.settings));d.hide().appendTo("body");d.find(".notice-close").click(function(){d.hide()});this.$notice=d};a.DEFAULTS={textMessage:"Oops! Your task change couldn\'t be saved. \u003cbr/\u003eThere could be a few reasons for this.",className:"general-notice"};a.prototype.show=function(){this.$notice.show();return this};a.prototype.hide=function(){this.$notice.hide();return this};Confluence.InlineTasks.Notice=a}(AJS.$));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'templates/inline-tasks.soy' */
// This file was automatically generated from inline-tasks.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.InlineTasks.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.InlineTasks == 'undefined') { Confluence.InlineTasks = {}; }
if (typeof Confluence.InlineTasks.Templates == 'undefined') { Confluence.InlineTasks.Templates = {}; }


Confluence.InlineTasks.Templates.notice = function(opt_data, opt_ignored) {
  return '<div class="aui-message error' + ((opt_data.className) ? ' ' + soy.$$escapeHtml(opt_data.className) : '') + '" id="inline-tasks-notice">' + soy.$$filterNoAutoescape(opt_data.textMessage) + '&nbsp;&nbsp;<a href="#" class="notice-close">' + soy.$$escapeHtml("Dismiss") + '</a></div>';
};
if (goog.DEBUG) {
  Confluence.InlineTasks.Templates.notice.soyTemplateName = 'Confluence.InlineTasks.Templates.notice';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:inline-tasks-resources', location = 'js/inline-tasks-focus.js' */
AJS.$(document).ready(function(f){var d="focusedTaskId";var a=require("confluence/jsUri");var c=new a(window.location.href);var g=c.getQueryParamValue(d);if(g){var b=$("li[data-inline-task-id="+g+"]");if(b.length){b.addClass("focused");window.scrollTo(b.offset().left,(b.offset().top-($(window).height()/2)))}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:sortable-table-server-side', location = 'js/jquery.tablesorter.serveronly.js' */
(function(a){a.extend({tablesorterServerOnly:new function(){this.defaults={classNameDisableSorting:"aui-table-column-unsortable",classNameHeaderDesc:"tablesorter-headerDesc",classNameHeaderAsc:"tablesorter-headerAsc",reverseSort:false,sortColumn:"",onInit:function(){},onSort:function(){},events:{clickHeader:"click.sortServerOnly",refreshHeader:"refreshHeader.sortServerOnly",simulateClickHeader:"simulateClickHeader.sortServerOnly"}};var b=this;var d={updateCurrentHeaderSort:function(e,f){d.resetHeadersSort(e,f);f.$headers.each(function(){var h=a(this),g=h.attr("data-column-name");var i=f.reverseSort;if(g===f.sortColumn){i?h.addClass(f.classNameHeaderDesc):h.addClass(f.classNameHeaderAsc)}})},resetHeadersSort:function(e,f){f.$headers.removeClass(f.classNameHeaderDesc).removeClass(f.classNameHeaderAsc)},prepareHTMLHeader:function(e,f){f.$headers.not("."+f.classNameDisableSorting).attr("unselectable","on").bind("selectstart",false).addClass("tablesorter-header").wrapInner("<span class='aui-table-header-content'/>")},bindEvents:function(f,g){var e=a(f);e.on(g.events.refreshHeader,function(){d.updateCurrentHeaderSort(f,g)});e.on(g.events.simulateClickHeader,function(i,j,h){g.reverseSort=h;g.sortColumn=j})}};var c=function(f,g){var e=a(f);g.$table=e;g.$headers=e.find("thead th");g.$tbodies=e.find("tbody");d.prepareHTMLHeader(f,g);d.updateCurrentHeaderSort(f,g);if(typeof g.onInit==="function"){g.onInit.apply(f,[g])}g.$headers.on(g.events.clickHeader,function(){var h=a(this);if(h.hasClass(g.classNameDisableSorting)){return false}var i=h.attr("data-column-name");if(i===g.sortColumn){g.reverseSort=!g.reverseSort}else{g.reverseSort=false}g.sortColumn=i;if(typeof g.onSort==="function"){g.onSort.apply(f,[g])}return false});d.bindEvents(f,g)};b.construct=function(e){return this.each(function(){var f=this,g=a.extend(true,{},a.tablesorterServerOnly.defaults,e);if(this.config&&f.hasInitialized&&a.tablesorter){a.tablesorter.destroy(f,false,function(){c(f,g)})}else{c(f,g)}})}}()});a.fn.extend({tablesorterServerOnly:a.tablesorterServerOnly.construct})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:sortable-table-server-side', location = 'js/tasks-table-sortable.js' */
(function(a){var b=function(d){this.ajaxUrl=d.ajaxUrl;this.restUrlPagination=d.restUrlPagination;this.$wrapper=d.$wrapper;this.table=d.table;this.$table=a(this.table);this.analyticEventKey=d.analyticEventKey;this.sortColumnDefault=d.sortColumnDefault||"duedate";this.sortReverseSortDefault=d.sortReverseSortDefault||false;this.reportParametersDefault=d.reportParametersDefault;this.pageIndex=d.pageIndex||0;this.pageSize=d.pageSize||10;this.pageTotal=d.pageTotal||0;this.pageLimit=d.pageLimit||7;this.adaptive=d.adaptive;this.columns=d.columns;this.templates=d.templates;this.onRenderEmptyTable=d.onRenderEmptyTable;this.onBusySorting=d.onBusySorting};b.getColumnNameFromSortBy=function(e){var d={"due date":"duedate","page title":"location",assignee:"assignee"};return d[e]?d[e]:"duedate"};b.getSortByFromColumnName=function(d){var e={duedate:"due date",location:"page title"};return e[d]?e[d]:d};b.prototype.updateOptions=function(d){a.extend(this,d);this.$table=a(this.table)};b.prototype.getCurrentPageIndex=function(){var e=this.$wrapper.find(".macro-auto-pagination").last();var d=parseInt(e.attr("data-initial-page-index"),10);return isNaN(d)?0:d};b.prototype.renderPagination=function(e,g){var d=this;if(!e){e=d.$table}if(!g){g=d.reportParametersDefault}this.$wrapper.find(".macro-auto-pagination").remove();if(!(d.pageTotal>1)){return}c.UI.Components.Pagination.build({scope:e,pageSize:d.pageSize,totalPages:d.pageTotal,pageLimit:d.pageLimit,path:d.restUrlPagination,adaptive:d.adaptive,currentPage:d.pageIndex,data:{reportParameters:JSON.stringify(g)},success:function f(h,j){var k={task:h,columns:d.columns};var i=d.templates.tasksReportLine(k);j.append(i)}})};b.prototype.toggleBusyState=function(d){this.$wrapper.attr("data-loading",d);if(d){this.$wrapper.find(".task-blanket").show()}else{this.$wrapper.find(".task-blanket").hide()}if(typeof this.onBusySorting==="function"){this.onBusySorting.apply(this,[d])}};b.prototype.renderTable=function(e){var d=this;var f=_.map(e,function(g){return d.templates.tasksReportLine({task:g,columns:d.columns})}).join("");d.$table.find("tbody").html(f);c.Binder.userHover()};b.prototype._triggerAnalyticsSorting=function(){var d=this.analyticEventKey;var e={column:this.sortColumn,direction:this.reverseSort?"desc":"asc"};AJS.trigger("analyticsEvent",{name:d,data:e})};b.prototype._buildAjaxData=function(e){var d={url:this.ajaxUrl,cache:false,dataType:"json",data:{pageIndex:this.pageIndex,pageSize:this.pageSize,reportParameters:JSON.stringify(e)}};return d};b.prototype.init=function(){var d=this;d.sortColumn=d.sortColumnDefault;d.reverseSort=d.sortReverseSortDefault;this.$table.tablesorterServerOnly({sortColumn:d.sortColumn,reverseSort:d.reverseSort,onInit:function(){var e=a(this);e.addClass("aui-table-sortable")},onSort:function(i){var h=this,f=a(h);d.pageIndex=d.getCurrentPageIndex();d.sortColumn=i.sortColumn;d.reverseSort=i.reverseSort;d.toggleBusyState(true);var g=a.extend({},d.reportParametersDefault,{sortColumn:b.getSortByFromColumnName(d.sortColumn),reverseSort:d.reverseSort});var e=d._buildAjaxData(g);a.ajax(e).done(function(j){d.pageIndex=d.getCurrentPageIndex();d.pageTotal=j.totalPages;if(d.pageIndex===0&&d.pageTotal===0){if(typeof d.onRenderEmptyTable==="function"){d.$wrapper.find(".macro-auto-pagination").remove();f.remove();d.onRenderEmptyTable.apply(d)}return}d.renderTable(j.detailLines);d.renderPagination(null,g);f.trigger("refreshHeader.sortServerOnly");d._triggerAnalyticsSorting()}).fail(function(){var j=new c.InlineTasks.Notice({textMessage:"We can\'t sort your tasks right now. Refresh the page to try again.",className:"forbidden-notice"});j.show()}).always(function(){d.toggleBusyState(false)})}})};var c=window.Confluence||{};c.InlineTasks=c.InlineTasks||{};c.InlineTasks.TasksTableSortable=b})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:common', location = '/js/namespace.js' */
window.Confluence||(window.Confluence={});window.Confluence.UI||(window.Confluence.UI={});window.Confluence.UI.Components||(window.Confluence.UI.Components={});window.Confluence.UI.Components.Pagination||(window.Confluence.UI.Components.Pagination={});window.Confluence.UI.Components.SpacePagePicker||(window.Confluence.UI.Components.SpacePagePicker={});window.Confluence.UI.Components.PagePicker||(window.Confluence.UI.Components.PagePicker={});define("confluence-ui-components/js/page-picker",function(){return window.Confluence.UI.Components.PagePicker});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:common', location = '/js/internal/dark-features.js' */
define("confluence-ui-components/dark-features",["ajs"],function(a){return a.DarkFeatures});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:pagination', location = '/js/pagination.js' */
(function(e,c){var d=function(j,k,i){var h=j.find("a").attr("aria-disabled",i);if(i){h.attr("disabled","disabled")}else{h.removeAttr("disabled");var g=e(".aui-nav-selected",j).data("index")+1;j.find(".aui-nav-next > a").attr("aria-disabled",g==k);j.find(".aui-nav-previous > a").attr("aria-disabled",g==1)}};var b={scope:null,success:null,data:null,path:"",url:"#",pageLimit:7,currentPage:0,adaptive:false,totalPages:0,pageSize:0};var f=function(i,j,k){var g=Math.floor(k/2);var h=j-1;if(!k||j<=k||i-g<0){return 0}if(i+g>h){return j-k}return i-g};var a=function(l){var k=l.totalPages,j=l.currentPage,m=l.pageLimit,h=l.adaptive,g;if(m){if(h){k=j+m}g=m}else{g=k}var i=f(j,k,m);return Confluence.UI.Components.Pagination.Templates.paginationFooter({currentPage:j||0,startPage:i,itemsToRender:g,totalPages:k,pageSize:l.pageSize,url:l.url||"#"})};c.build=function(j){var h=_.extend({},b,j);if(typeof h.success!=="function"){h.success=function(){}}var k=a(h);h.scope.after(k);var i=h.scope.next();var g=i.data("initial-page-index");i.on("click","a",function(p){var o=e(this),r=o.parents("ol").prev(),n=r.is("table")?r:r.find("table");var l=n.data("pageIndex")||g,q=o.parent("li");if(q.hasClass("aui-nav-selected")||q.find("> a[aria-disabled=true]").length){return}if(q.hasClass("aui-nav-next")){l++}else{if(q.hasClass("aui-nav-previous")){l--}else{l=q.data("index")}}d(i,h.totalPages,true);var m=e.extend({},{pageSize:h.pageSize,pageIndex:l},h.data);e.getJSON(Confluence.getContextPath()+h.path,m).done(function(t){l=t.currentPage;var s=n.find("tbody");s.find("tr").remove();n.data("pageIndex",l);_.each(t.detailLines,function(v){h.success(v,s)});AJS.trigger("ui.components.pagination.updated",[t,h]);var u=e.extend({},h,{totalPages:t.totalPages,adaptive:t.adaptive,currentPage:l});i.html(a(u));d(i,u.totalPages,false)}).fail(function(){d(i,h.totalPages,false)});p.preventDefault()})}})(AJS.$,window.Confluence.UI.Components.Pagination);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:pagination', location = '/soy/pagination.soy' */
// This file was automatically generated from pagination.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.UI.Components.Pagination.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.UI == 'undefined') { Confluence.UI = {}; }
if (typeof Confluence.UI.Components == 'undefined') { Confluence.UI.Components = {}; }
if (typeof Confluence.UI.Components.Pagination == 'undefined') { Confluence.UI.Components.Pagination = {}; }
if (typeof Confluence.UI.Components.Pagination.Templates == 'undefined') { Confluence.UI.Components.Pagination.Templates = {}; }


Confluence.UI.Components.Pagination.Templates.paginationFooter = function(opt_data, opt_ignored) {
  var output = '<ol class="aui-nav aui-nav-pagination macro-auto-pagination" data-page-size="' + soy.$$escapeHtml(opt_data.pageSize) + '" data-initial-page-index="' + soy.$$escapeHtml(opt_data.currentPage) + '"><li class="aui-nav-previous"><a ' + ((opt_data.currentPage == 0) ? 'aria-disabled="true"' : 'href="#"') + '>' + soy.$$escapeHtml("Prev") + '</a></li>';
  var startIdx__soy16 = opt_data.startPage + 1;
  var currentIdx__soy17 = opt_data.currentPage + 1;
  var endIdx__soy18 = startIdx__soy16 + opt_data.itemsToRender;
  var totalRange__soy19 = opt_data.totalPages + 1;
  var indexInit20 = startIdx__soy16;
  var indexLimit20 = endIdx__soy18 < totalRange__soy19 ? endIdx__soy18 : totalRange__soy19;
  for (var index20 = indexInit20; index20 < indexLimit20; index20++) {
    output += (index20 == currentIdx__soy17) ? '<li class="aui-nav-selected" data-index="' + soy.$$escapeHtml(index20 - 1) + '">' + soy.$$escapeHtml(index20) + '</li>' : '<li data-index="' + soy.$$escapeHtml(index20 - 1) + '"><a href="#">' + soy.$$escapeHtml(index20) + '</a></li>';
  }
  output += '<li class="aui-nav-next"><a ' + ((currentIdx__soy17 == opt_data.totalPages) ? 'aria-disabled="true"' : 'href="' + soy.$$escapeHtml(opt_data.url) + '"') + '>' + soy.$$escapeHtml("Next") + '</a></li></ol>';
  return output;
};
if (goog.DEBUG) {
  Confluence.UI.Components.Pagination.Templates.paginationFooter.soyTemplateName = 'Confluence.UI.Components.Pagination.Templates.paginationFooter';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-ui-components:blank-placeholder-box', location = 'soy/blank-placeholder-box.soy' */
// This file was automatically generated from blank-placeholder-box.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.UI.Components.BlankPlaceholderBox.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.UI == 'undefined') { Confluence.UI = {}; }
if (typeof Confluence.UI.Components == 'undefined') { Confluence.UI.Components = {}; }
if (typeof Confluence.UI.Components.BlankPlaceholderBox == 'undefined') { Confluence.UI.Components.BlankPlaceholderBox = {}; }
if (typeof Confluence.UI.Components.BlankPlaceholderBox.Templates == 'undefined') { Confluence.UI.Components.BlankPlaceholderBox.Templates = {}; }


Confluence.UI.Components.BlankPlaceholderBox.Templates.blankBox = function(opt_data, opt_ignored) {
  return '<div class="blank-placeholder-box ' + ((opt_data.customClass) ? soy.$$escapeHtml(opt_data.customClass) : '') + '"><div class="content"><h2>' + soy.$$escapeHtml(opt_data.blankTitle) + '</h2><p>' + soy.$$escapeHtml(opt_data.blankDescription) + '</p></div>' + ((opt_data.customHtml) ? soy.$$filterNoAutoescape(opt_data.customHtml) : '') + '</div>';
};
if (goog.DEBUG) {
  Confluence.UI.Components.BlankPlaceholderBox.Templates.blankBox.soyTemplateName = 'Confluence.UI.Components.BlankPlaceholderBox.Templates.blankBox';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-report-resources', location = 'templates/tasks-report.soy' */
// This file was automatically generated from tasks-report.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.InlineTasks.Report.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.InlineTasks == 'undefined') { Confluence.InlineTasks = {}; }
if (typeof Confluence.InlineTasks.Report == 'undefined') { Confluence.InlineTasks.Report = {}; }
if (typeof Confluence.InlineTasks.Report.Templates == 'undefined') { Confluence.InlineTasks.Report.Templates = {}; }


Confluence.InlineTasks.Report.Templates.tasksReport = function(opt_data, opt_ignored) {
  var output = '<div class="table-wrapper" data-loading="false"><div class="task-blanket"></div><input type="hidden" name="reportParameters" value="' + soy.$$escapeHtml(opt_data.reportParameters) + '" /><table class="aui aui-table-interactive tasks-report" data-sortable="false" data-total-pages="' + soy.$$escapeHtml(opt_data.totalPages) + '" data-page-size="' + soy.$$escapeHtml(opt_data.pageSize) + '" data-adaptive="' + soy.$$escapeHtml(opt_data.adaptive) + '" data-page-limit="' + soy.$$escapeHtml(opt_data.pageLimit) + '"><thead><tr class="tablesorter-headerRow">';
  var headingList14 = opt_data.headings;
  var headingListLen14 = headingList14.length;
  for (var headingIndex14 = 0; headingIndex14 < headingListLen14; headingIndex14++) {
    var headingData14 = headingList14[headingIndex14];
    output += '<th class="header-' + soy.$$escapeHtml(headingData14) + ((headingData14 == 'description') ? ' aui-table-column-unsortable' : '') + '" data-column-name="' + soy.$$escapeHtml(headingData14) + '">' + soy.$$escapeHtml(opt_data.headingTexts[headingData14]) + '</th>';
  }
  output += '</tr></thead><tbody>';
  if (opt_data.tasks.length) {
    var taskList29 = opt_data.tasks;
    var taskListLen29 = taskList29.length;
    for (var taskIndex29 = 0; taskIndex29 < taskListLen29; taskIndex29++) {
      var taskData29 = taskList29[taskIndex29];
      output += Confluence.InlineTasks.Report.Templates.tasksReportLine({task: taskData29, columns: opt_data.headings});
    }
  } else {
    output += '<tr><td colspan="' + soy.$$escapeHtml(opt_data.headings.length) + '">' + soy.$$escapeHtml("Create a task list in a Confluence page to keep track of things you need to do.") + '</td></tr>';
  }
  output += '</tbody></table></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.InlineTasks.Report.Templates.tasksReport.soyTemplateName = 'Confluence.InlineTasks.Report.Templates.tasksReport';
}


Confluence.InlineTasks.Report.Templates.tasksFeatureDiscoveryNotification = function(opt_data, opt_ignored) {
  return '<h2>' + soy.$$escapeHtml("Hey! Did you know...") + '</h2><p>' + soy.$$escapeHtml("You can view the tasks you created, or assigned to you, in the tasks tabs of your profile.") + '</p>';
};
if (goog.DEBUG) {
  Confluence.InlineTasks.Report.Templates.tasksFeatureDiscoveryNotification.soyTemplateName = 'Confluence.InlineTasks.Report.Templates.tasksFeatureDiscoveryNotification';
}


Confluence.InlineTasks.Report.Templates.tasksReportLine = function(opt_data, opt_ignored) {
  var output = '<tr data-task-id="' + soy.$$escapeHtml(opt_data.task.taskId) + '" aria-disabled="false">';
  var columnList51 = opt_data.columns;
  var columnListLen51 = columnList51.length;
  for (var columnIndex51 = 0; columnIndex51 < columnListLen51; columnIndex51++) {
    var columnData51 = columnList51[columnIndex51];
    if (columnData51 == 'duedate') {
      output += '<td class=\'tasks-report-date\'>' + ((opt_data.task.dueDate) ? soy.$$escapeHtml(opt_data.task.dueDate) : '') + '</td>';
    } else if (columnData51 == 'description') {
      output += '<td>' + soy.$$filterNoAutoescape(opt_data.task.taskHtml) + '</td>';
    } else if (columnData51 == 'assignee') {
      output += '<td class=\'tasks-report-assignee\'>' + ((opt_data.task.assigneeUserName) ? Confluence.Templates.User.usernameLink({username: opt_data.task.assigneeUserName, fullName: opt_data.task.assigneeFullName, canView: false}) : '') + '</td>';
    } else if (columnData51 == 'location') {
      output += '<td><a class=\'task-location\' href="' + soy.$$escapeHtml("/confluence") + soy.$$escapeHtml(opt_data.task.pageUrl) + '">' + soy.$$escapeHtml(opt_data.task.pageTitle) + '</a></td>';
    } else if (columnData51 == 'completedate') {
      output += '<td class=\'tasks-report-date\'>' + ((opt_data.task.completeDate) ? soy.$$escapeHtml(opt_data.task.completeDate) : (opt_data.task.taskCompleted) ? '<span class="emptycompletedate">--</span>' : '') + '</td>';
    } else if (columnData51 == 'labels') {
      output += '<td>';
      var labelList90 = opt_data.task.labels;
      var labelListLen90 = labelList90.length;
      for (var labelIndex90 = 0; labelIndex90 < labelListLen90; labelIndex90++) {
        var labelData90 = labelList90[labelIndex90];
        output += aui.labels.label({text: labelData90});
      }
      output += '</td>';
    }
  }
  output += '</tr>';
  return output;
};
if (goog.DEBUG) {
  Confluence.InlineTasks.Report.Templates.tasksReportLine.soyTemplateName = 'Confluence.InlineTasks.Report.Templates.tasksReportLine';
}


Confluence.InlineTasks.Report.Templates.taskReportBrowserWarning = function(opt_data, opt_ignored) {
  var param98 = '<p>' + soy.$$escapeHtml("Unable to show this task report.") + '</p>';
  var messageList102 = opt_data.messages;
  var messageListLen102 = messageList102.length;
  for (var messageIndex102 = 0; messageIndex102 < messageListLen102; messageIndex102++) {
    var messageData102 = messageList102[messageIndex102];
    param98 += '<p>' + soy.$$escapeHtml(messageData102) + '</p>';
  }
  var output = '' + aui.message.warning({content: param98});
  return output;
};
if (goog.DEBUG) {
  Confluence.InlineTasks.Report.Templates.taskReportBrowserWarning.soyTemplateName = 'Confluence.InlineTasks.Report.Templates.taskReportBrowserWarning';
}


Confluence.InlineTasks.Report.Templates.taskReportWarning = function(opt_data, opt_ignored) {
  return '' + aui.message.warning({content: '<p>' + soy.$$escapeHtml("Unable to show the task report. Edit this page to resolve the issues.") + '</p>'});
};
if (goog.DEBUG) {
  Confluence.InlineTasks.Report.Templates.taskReportWarning.soyTemplateName = 'Confluence.InlineTasks.Report.Templates.taskReportWarning';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-report-resources', location = 'js/tasks-report-blank-exp.js' */
(function(b){Confluence.InlineTasks=Confluence.InlineTasks||{};Confluence.InlineTasks.TasksReport=Confluence.InlineTasks.TasksReport||{};var a={"blank.complete.title":"Task report","blank.complete.desc":"Get going, no tasks completed yet.","blank.incomplete.title":"Task report","blank.incomplete.desc":"Looking good, no incomplete tasks."};Confluence.InlineTasks.TasksReport.renderBlankExperiences=function(g,c){if(!c){c="incomplete"}var f=a["blank."+c+".title"],e=a["blank."+c+".desc"];var d=Confluence.UI.Components.BlankPlaceholderBox.Templates.blankBox({blankTitle:f,blankDescription:e,customClass:c+" tasks-report-blank"});g.html(d)}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-report-resources', location = 'js/tasks-report.js' */
AJS.$(function(c){var b="/rest/inlinetasks/1/task-report/",a=Confluence.InlineTasks.Report.Templates,e=Confluence.InlineTasks.TasksTableSortable;var d=c(".tasks-report").parent();_.each(d,function(i){var l=c(i),n=l.find("table.tasks-report"),m=n.data("page-size"),k=n.data("total-pages"),f=n.data("page-limit"),q=n.data("adaptive"),p=l.find("input[name=reportParameters]").val(),g=JSON.parse(p);var o=function(r,s){c(r).attr("aria-disabled",s)};AJS.bind("inline-tasks.status-update.start",function(t,s){if(s.taskListQueue.length>0){var r=c("li[data-inline-task-id="+s.taskId+"]").closest(".tasks-report").siblings(".macro-auto-pagination");o(r,true);r=r.find("li a");r.on("click.taskreport.pagination",function(u){u.preventDefault();u.stopPropagation()})}});AJS.bind("inline-tasks.status-update.complete",function(s,r){if(r.taskListQueue.length===0){o(".macro-auto-pagination",false);c(".macro-auto-pagination li a").off("click.taskreport.pagination")}});var j=n.closest(".table-wrapper");var h=new e({$wrapper:j,table:n[0],sortReverseSortDefault:g.reverseSort,sortColumnDefault:e.getColumnNameFromSortBy(g.sortColumn),reportParametersDefault:g,pageIndex:0,pageSize:m,pageTotal:k,adaptive:q,pageLimit:f,templates:a,columns:g.columns,onRenderEmptyTable:function(){Confluence.InlineTasks.TasksReport.renderBlankExperiences(j,g.status)},analyticEventKey:"confluence-spaces.tasks.report.sorted",restUrlPagination:b,ajaxUrl:Confluence.getContextPath()+b});h.init();if(q||k>1){h.renderPagination()}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-help-tips:common', location = 'js/help-tip.js' */
(function(f){function b(){return false}function d(){return true}var l=0,g=new Date().getTime();var k=AJS.contextPath()+"/rest/helptips/1.0/tips";function h(n){n=""+(n||"");return n.replace(/\./g,"-")}function j(o,n){if(AJS.EventQueue&&n&&n.attributes.id){var q={};var p=h(n.attributes.id);q.name="helptips."+p+"."+o;q.properties={};AJS.EventQueue.push(q)}}function c(){return"c"+g+(l++)}var a={dismissedTipIds:[],loaded:f.Deferred(),url:function(){return k},sync:function(o,n){o||(o="get");n||(n=null);return f.ajax(this.url(),{type:o,context:this,dataType:"json",contentType:"application/json",data:n&&JSON.stringify(n),processData:false}).promise()},fetch:function(){var n=this.sync();n.done(function(o){f.merge(this.dismissedTipIds,o);this.loaded.resolve()});return n.promise()},show:function(n){this.loaded.done(n)},dismiss:function(n){var o=n.attributes.id;if(!o){n._dismissed=true}else{this.dismissedTipIds.push(o);this.sync("post",{id:o})}},undismiss:function(n){var o=n.attributes.id;if(!o){n._dismissed=false}else{this.dismissedTipIds.splice(f.inArray(o,this.dismissedTipIds),1);this.sync("delete",{id:o})}},isDismissed:function(n){var o=n.attributes.id;return(o)?f.inArray(o,this.dismissedTipIds)>=0:n._dismissed}};var e=AJS.HelpTip=function(n){var o;this.attributes=f.extend({},n);this.attributes.id||(this.attributes.id=false);if(this.attributes.body){this.attributes.bodyHtml=this.attributes.body;delete this.attributes.body}this.cid=c();o=this.attributes.anchor;delete this.attributes.anchor;this.view=o?new i(this,o):new m(this);this.view.$el.addClass("aui-help-tip")};AJS.HelpTip.Manager=a;f.extend(e.prototype,{show:function(){var n=this;AJS.HelpTip.Manager.show(function(){if(!n.isDismissed()){if(AJS.Popups&&AJS.Popups.DisplayController){AJS.Popups.DisplayController.request({name:n.id,weight:1000,show:function(){n.view.show()}})}else{n.view.show()}j("shown",n)}})},dismiss:function(){var n=h(arguments[0]||"programmatically");this.view.dismiss();if(!this.isDismissed()){AJS.HelpTip.Manager.dismiss(this);j("dismissed."+n,this)}},isVisible:function(){return this.view.$el.is(":visible")},isDismissed:function(){return AJS.HelpTip.Manager.isDismissed(this)}});var i=function(o,n){this.initialize(o,n)};f.extend(i.prototype,{initialize:function(r,q){var o=this;var s=q.prop("ownerDocument");var p=s!=window.document;if(p){var n=f("iframe").filter(function(){return this.contentDocument==s});n.contents().scroll(function(){var v=f(this).contents().find("body").scrollTop();var w=n.offset().top;var u=o.popup.data("offset-top");var t=o.popup.find(".arrow").height();o.popup.css("top",u-v);o.popup.toggle(v<=u-w-t&&v+n.height()-t+w-o.popup.height()>=u)})}this.model=r;this.beforeHide=b;this.dismissButton=f(AJS.Templates.HelpTip.tipDismiss());this.dismissButton.click(function(t){r.dismiss("close-button");t.preventDefault()});this.popup=AJS.InlineDialog(q,r.cid,function(v,u,t){v.html(AJS.Templates.HelpTip.tipContent(r.attributes));v.find(".helptip-body").after(o.dismissButton);v.unbind("mouseover mouseout");v.find(".helptip-link").click(function(){j("learn-more.clicked",r)});t()},{container:"body",noBind:true,preHideCallback:function(){return o.beforeHide()},calculatePositions:function(t,y,z,x){var w=AJS.InlineDialog.opts.calculatePositions(t,y,z,x);if(p){var v=t.find(".arrow").height();var u=n.contents().find("body").scrollTop();w.popupCss.top=n.offset().top+(q.offset().top-u)+q.height()+v;w.popupCss.left=q.offset().left;n.contents().scroll()}t.data("offset-top",w.popupCss.top);return w}});this.popup.refresh();this._popupHide=this.popup.hide;this.popup.hide=b;this.$el=f(this.popup[0]);AJS.$(document).bind("showLayer",function(v,u,t){if(u==="inlineDialog"&&t.id===r.cid){AJS.InlineDialog.current=null;AJS.$(document.body).unbind("click."+r.cid+".inline-dialog-check");t._validateClickToClose=b;t.hide=b}})},show:function(){var n=this.popup,o=function(p){if(!n.has(p.target).length){n.shadow.remove();n.remove()}};n.show()},dismiss:function(){this.beforeHide=d;this._popupHide()}});var m=function(n){this.initialize(n)};f.extend(m.prototype,{initialize:function(){this.$el=f("<div />")},show:f.noop,dismiss:f.noop});if(AJS.Meta.get("remote-user")){a.fetch()}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-help-tips:common', location = 'templates/help-tip.soy' */
// This file was automatically generated from help-tip.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace AJS.Templates.HelpTip.
 */

if (typeof AJS == 'undefined') { var AJS = {}; }
if (typeof AJS.Templates == 'undefined') { AJS.Templates = {}; }
if (typeof AJS.Templates.HelpTip == 'undefined') { AJS.Templates.HelpTip = {}; }


AJS.Templates.HelpTip.tipContent = function(opt_data, opt_ignored) {
  return ((opt_data.title) ? '<h4 class="helptip-title">' + soy.$$escapeHtml(opt_data.title) + '</h4>' : '') + '<div class="helptip-body">' + soy.$$filterNoAutoescape(opt_data.bodyHtml) + '</div>' + ((opt_data.url) ? '<a class="helptip-link" href="' + soy.$$escapeHtml(opt_data.url) + '" target="_blank">' + soy.$$escapeHtml("Learn more") + '</a>' : '');
};
if (goog.DEBUG) {
  AJS.Templates.HelpTip.tipContent.soyTemplateName = 'AJS.Templates.HelpTip.tipContent';
}


AJS.Templates.HelpTip.tipDismiss = function(opt_data, opt_ignored) {
  return '<button class="helptip-dismiss aui-button" type="button">' + soy.$$escapeHtml("Dismiss") + '</button>';
};
if (goog.DEBUG) {
  AJS.Templates.HelpTip.tipDismiss.soyTemplateName = 'AJS.Templates.HelpTip.tipDismiss';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-tasks:tasks-feature-discovery-resources', location = 'js/tasks-discovery.js' */
(function(d){var c="com.atlassian.confluence.plugins.confluence-jira-metadata";var b="inline-tasks-flag";function a(){if(!!AJS.HelpTip){var e={id:null,body:Confluence.InlineTasks.Report.Templates.tasksFeatureDiscoveryNotification(),anchor:d("#user-menu-link")};var f=new AJS.HelpTip(e);AJS.trigger("analyticsEvent",{name:"confluence-spaces.tasks.feature.discovery.shown"});f.show();Confluence.FeatureDiscovery.forPlugin(c).markDiscovered(b)}}d(function(){if(d("meta[name=show-task-feature-discovery-flag]").length>0&&Confluence.FeatureDiscovery.forPlugin(c).shouldShow(b)){a()}})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:plupload', location = 'js/plupload.js' */
(function(){function x(){this.returnValue=!1}function y(){this.cancelBubble=!0}var z=0,p=[],u={},v={},t={},w={"<":"lt",">":"gt","&":"amp",'"':"quot","'":"#39"},A=/[<>&\"\']/g,q=window.setTimeout,m={},h,j="application/msword,doc dot,application/pdf,pdf,application/pgp-signature,pgp,application/postscript,ps ai eps,application/rtf,rtf,application/vnd.ms-excel,xls xlb,application/vnd.ms-powerpoint,ppt pps pot,application/zip,zip,application/java-archive,jar,application/java-archive,war,application/java-archive,ear,application/x-shockwave-flash,swf swfl,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.template,xltx,application/vnd.openxmlformats-officedocument.presentationml.presentation,pptx,application/vnd.openxmlformats-officedocument.presentationml.slideshow,ppsx,application/vnd.openxmlformats-officedocument.presentationml.template,potx,application/vnd.openxmlformats-officedocument.wordprocessingml.document,docx,application/vnd.openxmlformats-officedocument.wordprocessingml.template,dotx,audio/mpeg,mpga mpega mp2 mp3,audio/mp3,mp3,audio/x-wav,wav,audio/mp4,m4a,image/bmp,bmp,image/gif,gif,image/jpeg,jpeg jpg jpe,image/photoshop,psd,image/png,png,image/svg+xml,svg svgz,image/tiff,tiff tif,text/html,htm html xhtml,text/xml,xml,text/javascript,js,text/css,css,text/rtf,rtf,text/x-java-source,java,video/mpeg,mpeg mpg mpe,video/quicktime,qt mov,video/mp4,mp4,video/x-m4v,m4v,video/x-flv,flv,video/x-ms-wmv,wmv,video/avi,avi,video/webm,webm,video/vnd.rn-realvideo,rv,text/csv,csv,text/plain,asc txt text diff log,application/octet-stream,exe".split(/,/),
k,n,o;for(k=0;k<j.length;k+=2){o=j[k+1].split(/ /);for(n=0;n<o.length;n++){v[o[n]]=j[k];var r=t[j[k]]||[];r.push(o[n]);t[j[k]]=r}}j=navigator;k=j.userAgent;o=j.vendor;r=(n=/WebKit/.test(k))&&-1!==o.indexOf("Apple");o=window.opera&&window.opera.buildNumber;var j={windows:-1!==navigator.platform.indexOf("Win"),ie:!n&&!o&&/MSIE/gi.test(k)&&/Explorer/gi.test(j.appName),webkit:n,gecko:!n&&/Gecko/.test(k),safari:r,opera:!!o},c={VERSION:"@@version@@",STOPPED:1,STARTED:2,QUEUED:1,UPLOADING:2,FAILED:4,DONE:5,
GENERIC_ERROR:-100,HTTP_ERROR:-200,IO_ERROR:-300,SECURITY_ERROR:-400,INIT_ERROR:-500,FILE_SIZE_ERROR:-600,FILE_EXTENSION_ERROR:-601,IMAGE_FORMAT_ERROR:-700,IMAGE_MEMORY_ERROR:-701,IMAGE_DIMENSIONS_ERROR:-702,mimeTypes:v,mineTypeToExtensionsMap:t,ua:j,extend:function(a){c.each(arguments,function(b,g){0<g&&c.each(b,function(b,c){a[c]=b})});return a},getElement:function(a){return a&&1===a.nodeType?a:document.getElementById(a)},cleanName:function(a){var b,c;c=[/[\300-\306]/g,"A",/[\340-\346]/g,"a",/\307/g,
"C",/\347/g,"c",/[\310-\313]/g,"E",/[\350-\353]/g,"e",/[\314-\317]/g,"I",/[\354-\357]/g,"i",/\321/g,"N",/\361/g,"n",/[\322-\330]/g,"O",/[\362-\370]/g,"o",/[\331-\334]/g,"U",/[\371-\374]/g,"u"];for(b=0;b<c.length;b+=2)a=a.replace(c[b],c[b+1]);a=a.replace(/\s+/g,"_");return a=a.replace(/[^a-z0-9_\-\.]+/gi,"")},addRuntime:function(a,b){b.name=a;p[a]=b;p.push(b);return b},guid:function(){var a=(new Date).getTime().toString(32),b;for(b=0;5>b;b++)a+=Math.floor(65535*Math.random()).toString(32);return(c.guidPrefix||
"p")+a+(z++).toString(32)},buildUrl:function(a,b){var g="";c.each(b,function(a,b){g+=(g?"&":"")+encodeURIComponent(b)+"="+encodeURIComponent(a)});g&&(a+=(0<a.indexOf("?")?"&":"?")+g);return a},each:function(a,b){var c,f;if(a)if(c=a.length,void 0===c)for(f in a){if(a.hasOwnProperty(f)&&!1===b(a[f],f))break}else for(f=0;f<c&&!1!==b(a[f],f);f++);},formatSize:function(a){return void 0===a||/\D/.test(a)?c.translate("N/A"):1073741824<a?Math.round(a/1073741824,1)+" GB":1048576<a?Math.round(a/1048576,1)+
" MB":1024<a?Math.round(a/1024,1)+" KB":a+" b"},getPos:function(a,b){function c(a){var b,e=0;b=0;a&&(b=a.getBoundingClientRect(),a="CSS1Compat"===h.compatMode?h.documentElement:h.body,e=b.left+a.scrollLeft,b=b.top+a.scrollTop);return{x:e,y:b}}var f=0,d=0,e,h=document,b=b||h.body;if(a&&a.getBoundingClientRect&&0<navigator.userAgent.indexOf("MSIE")&&8!==h.documentMode)return f=c(a),d=c(b),{x:f.x-d.x,y:f.y-d.y};for(e=a;e&&e!=b&&e.nodeType;)f+=e.offsetLeft||0,d+=e.offsetTop||0,e=e.offsetParent;for(e=
a.parentNode;e&&e!=b&&e.nodeType;)f-=e.scrollLeft||0,d-=e.scrollTop||0,e=e.parentNode;return{x:f,y:d}},getSize:function(a){return{w:a.offsetWidth||a.clientWidth,h:a.offsetHeight||a.clientHeight}},parseSize:function(a){var b;"string"==typeof a&&(a=/^([0-9]+)([mgk]?)$/.exec(a.toLowerCase().replace(/[^0-9mkg]/g,"")),b=a[2],a=+a[1],"g"==b&&(a*=1073741824),"m"==b&&(a*=1048576),"k"==b&&(a*=1024));return a},xmlEncode:function(a){return a?(""+a).replace(A,function(a){return w[a]?"&"+w[a]+";":a}):a},toArray:function(a){var b,
c=[];for(b=0;b<a.length;b++)c[b]=a[b];return c},addI18n:function(a){return c.extend(u,a)},translate:function(a){return u[a]||a},isEmptyObj:function(a){if(void 0===a)return!0;for(var b in a)return!1;return!0},hasClass:function(a,b){return""==a.className?!1:RegExp("(^|\\s+)"+b+"(\\s+|$)").test(a.className)},addClass:function(a,b){c.hasClass(a,b)||(a.className=""==a.className?b:a.className.replace(/\s+$/,"")+" "+b)},removeClass:function(a,b){a.className=a.className.replace(RegExp("(^|\\s+)"+b+"(\\s+|$)"),
function(a,b,c){return" "===b&&" "===c?" ":""})},getStyle:function(a,b){if(a.currentStyle)return a.currentStyle[b];if(window.getComputedStyle)return window.getComputedStyle(a,null)[b]},addEvent:function(a,b,g,f){var d,b=b.toLowerCase();void 0===h&&(h="Plupload_"+c.guid());a.addEventListener?(d=g,a.addEventListener(b,d,!1)):a.attachEvent&&(d=function(){var a=window.event;a.target||(a.target=a.srcElement);a.preventDefault=x;a.stopPropagation=y;g(a)},a.attachEvent("on"+b,d));void 0===a[h]&&(a[h]=c.guid());
m.hasOwnProperty(a[h])||(m[a[h]]={});a=m[a[h]];a.hasOwnProperty(b)||(a[b]=[]);a[b].push({func:d,orig:g,key:f})},removeEvent:function(a,b,g){var f,d;"function"==typeof g?f=g:d=g;b=b.toLowerCase();if(a[h]&&m[a[h]]&&m[a[h]][b]){for(var g=m[a[h]][b],e=g.length-1;0<=e;e--)if(g[e].key===d||g[e].orig===f)if(a.detachEvent?a.detachEvent("on"+b,g[e].func):a.removeEventListener&&a.removeEventListener(b,g[e].func,!1),g[e].orig=null,g[e].func=null,g.splice(e,1),void 0!==f)break;g.length||delete m[a[h]][b];if(c.isEmptyObj(m[a[h]])){delete m[a[h]];
try{delete a[h]}catch(k){a[h]=void 0}}}},removeAllEvents:function(a,b){void 0!==a[h]&&a[h]&&c.each(m[a[h]],function(g,f){c.removeEvent(a,f,b)})},Uploader:function(a){function b(){var a,b=0,d;if(this.state==c.STARTED){for(d=0;d<e.length;d++)!a&&e[d].status==c.QUEUED?(a=e[d],a.status=c.UPLOADING,this.trigger("BeforeUpload",a)&&this.trigger("UploadFile",a)):b++;b==e.length&&(this.stop(),this.trigger("UploadComplete",e))}}function g(){var a,b;d.reset();for(a=0;a<e.length;a++)b=e[a],void 0!==b.size?(d.size+=
b.size,d.loaded+=b.loaded):d.size=void 0,b.status==c.DONE?d.uploaded++:b.status==c.FAILED?d.failed++:d.queued++;void 0===d.size?d.percent=0<e.length?Math.ceil(100*(d.uploaded/e.length)):0:(d.bytesPerSec=Math.ceil(d.loaded/((+new Date-h||1)/1E3)),d.percent=0<d.size?Math.ceil(100*(d.loaded/d.size)):0)}var f={},d,e=[],h;d=new c.QueueProgress;a=c.extend({chunk_size:0,multipart:!0,multi_selection:!0,file_data_name:"file",filters:[]},a);c.extend(this,{state:c.STOPPED,runtime:"",features:{},files:e,settings:a,
total:d,id:c.guid(),init:function(){function f(){var a=s[k++],b,e,d;if(a){b=a.getFeatures();if(e=i.settings.required_features){e=e.split(",");for(d=0;d<e.length;d++)if(!b[e[d]]){f();return}}a.init(i,function(c){c&&c.success?(i.features=b,i.runtime=a.name,i.trigger("Init",{runtime:a.name}),i.trigger("PostInit"),i.refresh()):f()})}else i.trigger("Error",{code:c.INIT_ERROR,message:c.translate("Init error.")})}var i=this,l,s,k=0,j;"function"==typeof a.preinit?a.preinit(i):c.each(a.preinit,function(a,
b){i.bind(b,a)});a.page_url=a.page_url||document.location.pathname.replace(/\/[^\/]+$/g,"/");/^(\w+:\/\/|\/)/.test(a.url)||(a.url=a.page_url+a.url);a.chunk_size=c.parseSize(a.chunk_size);a.max_file_size=c.parseSize(a.max_file_size);i.bind("FilesAdded",function(b,d){b.trigger("Started",d);var f,g,l=0,h;if((f=a.filters)&&f.length){h=[];c.each(f,function(a){c.each(a.extensions.split(/,/),function(a){/^\s*\*\s*$/.test(a)?h.push("\\.*"):h.push("\\."+a.replace(RegExp("["+"/^$.*+?|()[]{}\\".replace(/./g,
"\\$&")+"]","g"),"\\$&"))})});h=RegExp(h.join("|")+"$","i")}for(f=0;f<d.length;f++){g=d[f];g.loaded=0;g.percent=0;g.status=c.QUEUED;if(h&&!h.test(g.name))b.trigger("Error",{code:c.FILE_EXTENSION_ERROR,message:c.translate("File extension error."),file:g});else if(g.size!==void 0&&g.size>a.max_file_size)b.trigger("Error",{code:c.FILE_SIZE_ERROR,message:c.translate("File size error."),file:g});else{e.push(g);l++}}if(l)q(function(){i.trigger("QueueChanged");i.refresh()},1);else return false});a.unique_names&&
i.bind("UploadFile",function(a,b){var c=b.name.match(/\.([^.]+)$/),d="tmp";c&&(d=c[1]);b.target_name=b.id+"."+d});i.bind("UploadProgress",function(a,b){b.percent=b.size>0?Math.ceil(b.loaded/b.size*100):100;g()});i.bind("StateChanged",function(a){if(a.state==c.STARTED)h=+new Date;else if(a.state==c.STOPPED)for(l=a.files.length-1;l>=0;l--)if(a.files[l].status==c.UPLOADING){a.files[l].status=c.QUEUED;g()}});i.bind("QueueChanged",g);i.bind("Error",function(a,e){if(e.file){e.file.status=c.FAILED;g();a.state==
c.STARTED&&(d.queued||q(function(){b.call(i)},1))}});i.bind("FileUploaded",function(a,d){d.status=c.DONE;d.loaded=d.size;a.trigger("UploadProgress",d);q(function(){b.call(i)},1)});if(a.runtimes){s=[];j=a.runtimes.split(/\s?,\s?/);for(l=0;l<j.length;l++)p[j[l]]&&s.push(p[j[l]])}else s=p;f();"function"==typeof a.init?a.init(i):c.each(a.init,function(a,b){i.bind(b,a)})},refresh:function(){this.trigger("Refresh")},start:function(){this.state!=c.STARTED&&(this.state=c.STARTED,this.trigger("StateChanged"),
b.call(this))},stop:function(){this.state!=c.STOPPED&&(this.state=c.STOPPED,this.trigger("CancelUpload"),this.trigger("StateChanged"))},getFile:function(a){var b;for(b=e.length-1;0<=b;b--)if(e[b].id===a)return e[b]},removeFile:function(a){var b;for(b=e.length-1;0<=b;b--)if(e[b].id===a.id)return this.splice(b,1)[0]},splice:function(a,b){var f;f=e.splice(void 0===a?0:a,void 0===b?e.length:b);this.trigger("FilesRemoved",f);this.trigger("QueueChanged");f[0].status==c.UPLOADING&&this.state==c.STARTED&&
this.trigger("CancelUpload");if(!d.queued){var g=this;q(function(){g.trigger("UploadComplete")})}return f},trigger:function(a){var b=f[a.toLowerCase()],c,d;if(b){d=Array.prototype.slice.call(arguments);d[0]=this;for(c=0;c<b.length;c++)if(!1===b[c].func.apply(b[c].scope,d))return!1}return!0},hasEventListener:function(a){return!!f[a.toLowerCase()]},bind:function(a,b,c){var d,a=a.toLowerCase();d=f[a]||[];d.push({func:b,scope:c||this});f[a]=d},unbind:function(a,b){var a=a.toLowerCase(),c=f[a],d;if(c){if(void 0!==
b)for(d=c.length-1;0<=d;d--){if(c[d].func===b){c.splice(d,1);break}}else c=[];c.length||delete f[a]}},unbindAll:function(){var a=this;c.each(f,function(b,c){a.unbind(c)})},destroy:function(){this.trigger("Destroy");this.unbindAll()}})},File:function(a,b,c){this.id=a;this.name=b;this.size=c;this.status=this.percent=this.loaded=0},Runtime:function(){this.getFeatures=function(){};this.init=function(){}},QueueProgress:function(){var a=this;a.size=0;a.loaded=0;a.uploaded=0;a.failed=0;a.queued=0;a.percent=
0;a.bytesPerSec=0;a.reset=function(){a.size=a.loaded=a.uploaded=a.failed=a.queued=a.percent=a.bytesPerSec=0}},runtimes:{}};window.plupload=c})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:plupload', location = 'js/plupload.html5.js' */
(function(s,j,e,p){function G(e,f,k,g){var b,a,c,q,m=this;var d=y[e.id],r=function(d){b=j.createElement("canvas");b.style.display="none";j.body.appendChild(b);a=b.getContext("2d");c=new Image;c.onerror=c.onabort=function(){g({success:!1})};c.onload=function(){var r,t,j,o;f.width||(f.width=c.width);f.height||(f.height=c.height);q=Math.min(f.width/c.width,f.height/c.height);if(1>q||1===q&&"image/jpeg"===k){r=Math.round(c.width*q);t=Math.round(c.height*q);b.width=r;b.height=t;a.drawImage(c,0,0,r,t);
if("image/jpeg"===k){if(j=new w(atob(d.substring(d.indexOf("base64,")+7))),j.headers&&j.headers.length&&(o=new H,o.init(j.get("exif")[0])&&(o.setExif("PixelXDimension",r),o.setExif("PixelYDimension",t),j.set("exif",o.getBinary()),m.hasEventListener("ExifData")&&m.trigger("ExifData",e,o.EXIF()),m.hasEventListener("GpsData")&&m.trigger("GpsData",e,o.GPS()))),f.quality)try{d=b.toDataURL(k,f.quality/100)}catch(s){d=b.toDataURL(k)}}else d=b.toDataURL(k);d=d.substring(d.indexOf("base64,")+7);d=atob(d);
j&&(j.headers&&j.headers.length)&&(d=j.restore(d),j.purge());b.parentNode.removeChild(b);g({success:!0,data:d})}else g({success:!1})};c.src=d},t;"FileReader"in s?(t=new FileReader,t.readAsDataURL(d),t.onload=function(){r(t.result)}):r(d.getAsDataURL())}function C(){function e(b,a){var c=k?0:-8*(a-1),q=0,m;for(m=0;m<a;m++)q|=g.charCodeAt(b+m)<<Math.abs(c+8*m);return q}function f(b,a,c){c=3===arguments.length?c:g.length-a-1;g=g.substr(0,a)+b+g.substr(c+a)}var k=!1,g;return{II:function(b){if(b===p)return k;
k=b},init:function(b){k=!1;g=b},SEGMENT:function(b,a,c){switch(arguments.length){case 1:return g.substr(b,g.length-b-1);case 2:return g.substr(b,a);case 3:f(c,b,a);break;default:return g}},BYTE:function(b){return e(b,1)},SHORT:function(b){return e(b,2)},LONG:function(b,a){if(a===p)return e(b,4);var c="",q=k?0:-24,m;for(m=0;4>m;m++)c+=String.fromCharCode(a>>Math.abs(q+8*m)&255);f(c,b,4)},SLONG:function(b){b=e(b,4);return 2147483647<b?b-4294967296:b},STRING:function(b,a){for(var c="",a=a+b;b<a;b++)c+=
String.fromCharCode(e(b,1));return c}}}function w(e){var f={65505:{app:"EXIF",name:"APP1",signature:"Exif\x00"},65506:{app:"ICC",name:"APP2",signature:"ICC_PROFILE\x00"},65517:{app:"IPTC",name:"APP13",signature:"Photoshop 3.0\x00"}},k=[],g,b,a=p,c=0;g=new C;g.init(e);if(65496===g.SHORT(0)){b=2;for(e=Math.min(1048576,e.length);b<=e;)if(a=g.SHORT(b),65488<=a&&65495>=a)b+=2;else{if(65498===a||65497===a)break;c=g.SHORT(b+2)+2;f[a]&&g.STRING(b+4,f[a].signature.length)===f[a].signature&&k.push({hex:a,app:f[a].app.toUpperCase(),
name:f[a].name.toUpperCase(),start:b,length:c,segment:g.SEGMENT(b,c)});b+=c}g.init(null);return{headers:k,restore:function(a){g.init(a);var c=new w(a);if(!c.headers)return!1;for(a=c.headers.length;0<a;a--){var d=c.headers[a-1];g.SEGMENT(d.start,d.length,"")}c.purge();b=65504==g.SHORT(2)?4+g.SHORT(4):2;a=0;for(c=k.length;a<c;a++)g.SEGMENT(b,0,k[a].segment),b+=k[a].length;return g.SEGMENT()},get:function(a){for(var c=[],d=0,b=k.length;d<b;d++)k[d].app===a.toUpperCase()&&c.push(k[d].segment);return c},
set:function(a,c){var d=[];"string"===typeof c?d.push(c):d=c;for(var b=ii=0,e=k.length;b<e&&!(k[b].app===a.toUpperCase()&&(k[b].segment=d[ii],k[b].length=d[ii].length,ii++),ii>=d.length);b++);},purge:function(){k=[];g.init(null)}}}}function H(){function e(a,c){var q=f.SHORT(a),m,d,k,h,l,j=[],n={};for(m=0;m<q;m++)if(l=a+12*m+2,k=c[f.SHORT(l)],k!==p){d=f.SHORT(l+=2);h=f.LONG(l+=2);l+=4;j=[];switch(d){case 1:case 7:4<h&&(l=f.LONG(l)+g.tiffHeader);for(d=0;d<h;d++)j[d]=f.BYTE(l+d);break;case 2:4<h&&(l=
f.LONG(l)+g.tiffHeader);n[k]=f.STRING(l,h-1);continue;case 3:2<h&&(l=f.LONG(l)+g.tiffHeader);for(d=0;d<h;d++)j[d]=f.SHORT(l+2*d);break;case 4:1<h&&(l=f.LONG(l)+g.tiffHeader);for(d=0;d<h;d++)j[d]=f.LONG(l+4*d);break;case 5:l=f.LONG(l)+g.tiffHeader;for(d=0;d<h;d++)j[d]=f.LONG(l+4*d)/f.LONG(l+4*d+4);break;case 9:l=f.LONG(l)+g.tiffHeader;for(d=0;d<h;d++)j[d]=f.SLONG(l+4*d);break;case 10:l=f.LONG(l)+g.tiffHeader;for(d=0;d<h;d++)j[d]=f.SLONG(l+4*d)/f.SLONG(l+4*d+4);break;default:continue}h=1==h?j[0]:j;
n[k]=b.hasOwnProperty(k)&&"object"!=typeof h?b[k][h]:h}return n}var f,k,g={},b;f=new C;k={tiff:{274:"Orientation",34665:"ExifIFDPointer",34853:"GPSInfoIFDPointer"},exif:{36864:"ExifVersion",40961:"ColorSpace",40962:"PixelXDimension",40963:"PixelYDimension",36867:"DateTimeOriginal",33434:"ExposureTime",33437:"FNumber",34855:"ISOSpeedRatings",37377:"ShutterSpeedValue",37378:"ApertureValue",37383:"MeteringMode",37384:"LightSource",37385:"Flash",41986:"ExposureMode",41987:"WhiteBalance",41990:"SceneCaptureType",
41988:"DigitalZoomRatio",41992:"Contrast",41993:"Saturation",41994:"Sharpness"},gps:{"0":"GPSVersionID",1:"GPSLatitudeRef",2:"GPSLatitude",3:"GPSLongitudeRef",4:"GPSLongitude"}};b={ColorSpace:{1:"sRGB","0":"Uncalibrated"},MeteringMode:{"0":"Unknown",1:"Average",2:"CenterWeightedAverage",3:"Spot",4:"MultiSpot",5:"Pattern",6:"Partial",255:"Other"},LightSource:{1:"Daylight",2:"Fliorescent",3:"Tungsten",4:"Flash",9:"Fine weather",10:"Cloudy weather",11:"Shade",12:"Daylight fluorescent (D 5700 - 7100K)",
13:"Day white fluorescent (N 4600 -5400K)",14:"Cool white fluorescent (W 3900 - 4500K)",15:"White fluorescent (WW 3200 - 3700K)",17:"Standard light A",18:"Standard light B",19:"Standard light C",20:"D55",21:"D65",22:"D75",23:"D50",24:"ISO studio tungsten",255:"Other"},Flash:{"0":"Flash did not fire.",1:"Flash fired.",5:"Strobe return light not detected.",7:"Strobe return light detected.",9:"Flash fired, compulsory flash mode",13:"Flash fired, compulsory flash mode, return light not detected",15:"Flash fired, compulsory flash mode, return light detected",
16:"Flash did not fire, compulsory flash mode",24:"Flash did not fire, auto mode",25:"Flash fired, auto mode",29:"Flash fired, auto mode, return light not detected",31:"Flash fired, auto mode, return light detected",32:"No flash function",65:"Flash fired, red-eye reduction mode",69:"Flash fired, red-eye reduction mode, return light not detected",71:"Flash fired, red-eye reduction mode, return light detected",73:"Flash fired, compulsory flash mode, red-eye reduction mode",77:"Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected",
79:"Flash fired, compulsory flash mode, red-eye reduction mode, return light detected",89:"Flash fired, auto mode, red-eye reduction mode",93:"Flash fired, auto mode, return light not detected, red-eye reduction mode",95:"Flash fired, auto mode, return light detected, red-eye reduction mode"},ExposureMode:{"0":"Auto exposure",1:"Manual exposure",2:"Auto bracket"},WhiteBalance:{"0":"Auto white balance",1:"Manual white balance"},SceneCaptureType:{"0":"Standard",1:"Landscape",2:"Portrait",3:"Night scene"},
Contrast:{"0":"Normal",1:"Soft",2:"Hard"},Saturation:{"0":"Normal",1:"Low saturation",2:"High saturation"},Sharpness:{"0":"Normal",1:"Soft",2:"Hard"},GPSLatitudeRef:{N:"North latitude",S:"South latitude"},GPSLongitudeRef:{E:"East longitude",W:"West longitude"}};return{init:function(a){g={tiffHeader:10};if(a===p||!a.length)return!1;f.init(a);return 65505===f.SHORT(0)&&"EXIF\x00"===f.STRING(4,5).toUpperCase()?(a=p,a=g.tiffHeader,f.II(18761==f.SHORT(a)),42!==f.SHORT(a+=2)?a=!1:(g.IFD0=g.tiffHeader+f.LONG(a+
2),a=e(g.IFD0,k.tiff),g.exifIFD="ExifIFDPointer"in a?g.tiffHeader+a.ExifIFDPointer:p,g.gpsIFD="GPSInfoIFDPointer"in a?g.tiffHeader+a.GPSInfoIFDPointer:p,a=!0),a):!1},EXIF:function(){var a;a=e(g.exifIFD,k.exif);a.ExifVersion&&(a.ExifVersion=String.fromCharCode(a.ExifVersion[0],a.ExifVersion[1],a.ExifVersion[2],a.ExifVersion[3]));return a},GPS:function(){var a;a=e(g.gpsIFD,k.gps);a.GPSVersionID&&(a.GPSVersionID=a.GPSVersionID.join("."));return a},setExif:function(a,c){if("PixelXDimension"!==a&&"PixelYDimension"!==
a)return!1;var b;b=a;var e,d,h,j=0;if("string"===typeof b)for(hex in e=k.exif,e)if(e[hex]===b){b=hex;break}e=g.exifIFD;d=f.SHORT(e);for(i=0;i<d;i++)if(h=e+12*i+2,f.SHORT(h)==b){j=h+8;break}j?(f.LONG(j,c),b=!0):b=!1;return b},getBinary:function(){return f.SEGMENT()}}}var y={},F;e.runtimes.Html5=e.addRuntime("html5",{getFeatures:function(){var h,f,k,g,b,a;f=k=b=a=!1;s.XMLHttpRequest&&(h=new XMLHttpRequest,k=!!h.upload,f=!(!h.sendAsBinary&&!h.upload));f&&(g=!!(h.sendAsBinary||s.Uint8Array&&s.ArrayBuffer),
b=!(!File||!File.prototype.getAsDataURL&&!s.FileReader||!g),a=!(!File||!File.prototype.mozSlice&&!File.prototype.webkitSlice&&!File.prototype.slice));F=e.ua.safari&&e.ua.windows&&navigator.userAgent&&0<navigator.userAgent.indexOf("Version/4");h=f;f=j.createElement("div");return{html5:h,dragdrop:"draggable"in f||"ondragstart"in f&&"ondrop"in f,jpgresize:b,pngresize:b,multipart:b||!!s.FileReader||!!s.FormData,canSendBinary:g,cantSendBlobInFormData:!(!e.ua.gecko||!s.FormData||!s.FileReader||FileReader.prototype.readAsArrayBuffer),
progress:k,chunks:a,multi_selection:!(e.ua.safari&&e.ua.windows),triggerDialog:e.ua.gecko&&s.FormData||e.ua.webkit||e.ua.windows}},init:function(h,f){function k(a){var c,b,g=[],d,f={};for(b=0;b<a.length;b++)c=a[b],f[c.name]||(f[c.name]=!0,d=e.guid(),y[d]=c,d=new e.File(d,c.fileName||c.name,c.fileSize||c.size),d.nativeFile=c,g.push(d));g.length&&h.trigger("FilesAdded",g)}var g,b;g=this.getFeatures();g.html5?(h.upload=function(a){k(a)},h.bind("Init",function(a){var c,b,g=[],d,f,t=a.settings.filters,
l,s;d=j.body;var n;c=j.createElement("div");c.id=a.id+"_html5_container";e.extend(c.style,{position:"absolute",background:h.settings.shim_bgcolor||"transparent",width:"100px",height:"100px",overflow:"hidden",zIndex:99999,opacity:h.settings.shim_bgcolor?"":0});c.className="plupload html5";h.settings.container&&(d=j.getElementById(h.settings.container),"static"===e.getStyle(d,"position")&&(d.style.position="relative"));d.appendChild(c);d=0;a:for(;d<t.length;d++){l=t[d].extensions.split(/,/);for(f=0;f<
l.length;f++){if("*"===l[f]){g=[];break a}(s=e.mimeTypes[l[f]])&&g.push(s)}}c.innerHTML='<input id="'+h.id+'_html5"  style="font-size:999px" type="file" accept="'+g.join(",")+'" '+(h.settings.multi_selection&&h.features.multi_selection?'multiple="multiple"':"")+" />";c.scrollTop=100;n=j.getElementById(h.id+"_html5");h.settings.inputFileClazz&&(n.className+=" "+h.settings.inputFileClazz);a.features.triggerDialog?e.extend(n.style,{position:"absolute",width:"100%",height:"100%"}):e.extend(n.style,{cssFloat:"right",
styleFloat:"right"});var p=function(){k(this.files);if(navigator.appVersion.indexOf("MSIE10")===-1){n=this.cloneNode(true);n.onchange=p;this.parentNode.replaceChild(n,this)}else this.value=""};n.onchange=p;if(b="string"===typeof a.settings.browse_button?j.getElementById(a.settings.browse_button):a.settings.browse_button){var o=a.settings.browse_button_hover,B=a.settings.browse_button_active;c=a.features.triggerDialog?b:c;o&&(e.addEvent(c,"mouseover",function(){e.addClass(b,o)},a.id),e.addEvent(c,
"mouseout",function(){e.removeClass(b,o)},a.id));B&&(e.addEvent(c,"mousedown",function(){e.addClass(b,B)},a.id),e.addEvent(j.body,"mouseup",function(){e.removeClass(b,B)},a.id));a.features.triggerDialog&&e.addEvent(b,"click",function(c){j.getElementById(a.id+"_html5").click();c.preventDefault()},a.id)}}),h.bind("PostInit",function(){var a=e.getElement(h.settings.drop_element),c,b=!1;a&&(F?(e.addEvent(a,"dragenter",function(){var c,d;c=j.getElementById(h.id+"_drop");c||(c=j.createElement("input"),
c.setAttribute("type","file"),c.setAttribute("id",h.id+"_drop"),c.setAttribute("multiple","multiple"),e.addEvent(c,"change",function(){k(this.files);e.removeEvent(c,"change",h.id);c.parentNode.removeChild(c)},h.id),a.appendChild(c),b=!0);e.getPos(a,j.getElementById(h.settings.container));d=e.getSize(a);"static"===e.getStyle(a,"position")&&e.extend(a.style,{position:"relative"});e.extend(c.style,{position:"absolute",display:"block",top:0,left:0,width:d.w+"px",height:d.h+"px",opacity:0})},h.id),e.addEvent(a,
"dragleave",function(){b||(c&&c.parentElement.removeChild(c),c=null);b=!1})):(e.addEvent(a,"dragover",function(a){a.preventDefault()},h.id),e.addEvent(a,"drop",function(a){if(!$(".disable-attachment-uploader").length){var b=a.dataTransfer;b&&b.files&&k(b.files)}c&&c.parentElement.removeChild(c);c=null;a.preventDefault();h.settings.stop_propagation&&(a.cancelBubble?a.cancelBubble=!0:a.stopPropagation())},h.id)))}),h.bind("Refresh",function(a){var c,b,f;if(c=j.getElementById(h.settings.browse_button))b=
e.getPos(c,j.getElementById(a.settings.container)),f=e.getSize(c),a=j.getElementById(h.id+"_html5_container"),e.extend(a.style,{top:b.y+"px",left:b.x+"px",width:f.w+"px",height:f.h+"px"}),h.features.triggerDialog&&("static"===e.getStyle(c,"position")&&e.extend(c.style,{position:"relative"}),b=parseInt(e.getStyle(c,"z-index"),10),isNaN(b)&&(b=0),e.extend(c.style,{zIndex:b}),e.extend(a.style,{zIndex:b-1}))}),h.bind("CancelUpload",function(){b&&b.abort&&b.abort()}),h.bind("UploadFile",function(a,c){function f(d){function k(){function f(d){var h=
0,m="----pluploadboundary"+e.guid(),n,r="";b=new XMLHttpRequest;b.upload&&(b.upload.onprogress=function(b){c.loaded=Math.min(c.size,q+b.loaded-h);a.trigger("UploadProgress",c)});b.onreadystatechange=function(){var f,g;if(b.readyState==4){try{f=b.status}catch(h){f=0}if(f>=400)a.trigger("Error",{code:e.HTTP_ERROR,message:e.translate("HTTP Error."),file:c,status:f,response:b.responseText||""});else{if(p){g={chunk:j,chunks:p,response:b.responseText,status:f};a.trigger("ChunkUploaded",c,g);q=q+z;if(g.cancelled){c.status=
e.FAILED;return}c.loaded=Math.min(c.size,(j+1)*u)}else c.loaded=c.size;a.trigger("UploadProgress",c);d=o=n=r=null;if(!p||++j>=p){c.status=e.DONE;a.trigger("FileUploaded",c,{response:b.responseText,status:f})}else k()}}};if(a.settings.multipart&&g.multipart){x.name=c.target_name||c.name;b.open("post",D,!0);e.each(a.settings.headers,function(a,c){b.setRequestHeader(c,a)});if("string"!==typeof d&&s.FormData){n=new FormData;e.each(e.extend(x,a.settings.multipart_params),function(a,b){n.append(b,a)});
n.append(a.settings.file_data_name,d);b.send(n);return}if("string"===typeof d){b.setRequestHeader("Content-Type","multipart/form-data; boundary="+m);e.each(e.extend(x,a.settings.multipart_params),function(a,b){r=r+("--"+m+'\r\nContent-Disposition: form-data; name="'+b+'"\r\n\r\n');r=r+(unescape(encodeURIComponent(a))+"\r\n")});y=e.mimeTypes[c.name.replace(/^.+\.([^.]+)/,"$1").toLowerCase()]||"application/octet-stream";r+="--"+m+'\r\nContent-Disposition: form-data; name="'+a.settings.file_data_name+
'"; filename="'+unescape(encodeURIComponent(c.name))+'"\r\nContent-Type: '+y+"\r\n\r\n"+d+"\r\n--"+m+"--\r\n";h=r.length-d.length;d=r;if(b.sendAsBinary)b.sendAsBinary(d);else if(g.canSendBinary){for(var w=new Uint8Array(d.length),v=0;v<d.length;v++)w[v]=d.charCodeAt(v)&255;b.send(w.buffer)}return}}D=e.buildUrl(a.settings.url,e.extend(x,a.settings.multipart_params));b.open("post",D,!0);b.setRequestHeader("Content-Type","application/octet-stream");d.encoding&&b.setRequestHeader("Content-Encoding",d.encoding);
e.each(a.settings.headers,function(a,c){b.setRequestHeader(c,a)});b.send(d.getData?d.getData():d)}var o,p,x,u,z,y,D=a.settings.url;if(!(c.status==e.DONE||c.status==e.FAILED||a.state==e.STOPPED)){x={name:c.target_name||c.name};if(h.chunk_size&&c.size>h.chunk_size&&(g.chunks||"string"==typeof d)){u=h.chunk_size;p=Math.ceil(c.size/u);z=Math.min(u,c.size-j*u);if("string"==typeof d)o=d.substring(j*u,j*u+z);else{var v=d,A=j*u,E=j*u+z,w;if(File.prototype.slice)try{v.slice(),o=v.slice(A,E)}catch(C){o=v.slice(A,
E-A)}else o=(w=File.prototype.webkitSlice||File.prototype.mozSlice)?w.call(v,A,E):null}x.chunk=j;x.chunks=p}else z=c.size,o=d;"string"!==typeof o&&n&&g.cantSendBlobInFormData&&g.chunks&&a.settings.chunk_size?(n.onload=function(){f(n.result)},n.readAsBinaryString(o)):f(o)}}var j=0,q=0,n="FileReader"in s?new FileReader:null;k()}var h=a.settings,d;d=y[c.id];g.jpgresize&&a.settings.resize&&/\.(png|jpg|jpeg)$/i.test(c.name)?G.call(a,c,a.settings.resize,/\.png$/i.test(c.name)?"image/png":"image/jpeg",function(a){a.success?
(c.size=a.data.length,f(a.data)):f(d)}):f(d)}),h.bind("Destroy",function(a){var b,f,g=j.body,d={inputContainer:a.id+"_html5_container",inputFile:a.id+"_html5",browseButton:a.settings.browse_button,dropElm:a.settings.drop_element};for(b in d)(f=j.getElementById(d[b]))&&e.removeAllEvents(f,a.id);e.removeAllEvents(j.body,a.id);a.settings.container&&(g=j.getElementById(a.settings.container));g.removeChild(j.getElementById(d.inputContainer))}),f({success:!0})):f({success:!1})}})})(window,document,plupload);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:jquery-ui-position', location = 'js-vendor/jquery/jquery-ui/jquery.ui.position.js' */
/*
 * jQuery UI Position 1.8.24
 *
 * Copyright 2012, AUTHORS.txt (http://jqueryui.com/about)
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * http://docs.jquery.com/UI/Position
 *
 * MODIFIED BY ATLASSIAN (fraction support detection removed)
 */
(function(G,H){G.ui=G.ui||{};var D=/left|center|right/,E=/top|center|bottom/,A="center",F={},B=G.fn.position,C=G.fn.offset;G.fn.position=function(J){if(!J||!J.of){return B.apply(this,arguments)}J=G.extend({},J);var N=G(J.of),M=N[0],P=(J.collision||"flip").split(" "),O=J.offset?J.offset.split(" "):[0,0],L,I,K;if(M.nodeType===9){L=N.width();I=N.height();K={top:0,left:0}}else{if(M.setTimeout){L=N.width();I=N.height();K={top:N.scrollTop(),left:N.scrollLeft()}}else{if(M.preventDefault){J.at="left top";L=I=0;K={top:J.of.pageY,left:J.of.pageX}}else{L=N.outerWidth();I=N.outerHeight();K=N.offset()}}}G.each(["my","at"],function(){var Q=(J[this]||"").split(" ");if(Q.length===1){Q=D.test(Q[0])?Q.concat([A]):E.test(Q[0])?[A].concat(Q):[A,A]}Q[0]=D.test(Q[0])?Q[0]:A;Q[1]=E.test(Q[1])?Q[1]:A;J[this]=Q});if(P.length===1){P[1]=P[0]}O[0]=parseInt(O[0],10)||0;if(O.length===1){O[1]=O[0]}O[1]=parseInt(O[1],10)||0;if(J.at[0]==="right"){K.left+=L}else{if(J.at[0]===A){K.left+=L/2}}if(J.at[1]==="bottom"){K.top+=I}else{if(J.at[1]===A){K.top+=I/2}}K.left+=O[0];K.top+=O[1];return this.each(function(){var T=G(this),V=T.outerWidth(),S=T.outerHeight(),U=parseInt(G.curCSS(this,"marginLeft",true))||0,R=parseInt(G.curCSS(this,"marginTop",true))||0,X=V+U+(parseInt(G.curCSS(this,"marginRight",true))||0),Y=S+R+(parseInt(G.curCSS(this,"marginBottom",true))||0),W=G.extend({},K),Q;if(J.my[0]==="right"){W.left-=V}else{if(J.my[0]===A){W.left-=V/2}}if(J.my[1]==="bottom"){W.top-=S}else{if(J.my[1]===A){W.top-=S/2}}Q={left:W.left-U,top:W.top-R};G.each(["left","top"],function(a,Z){if(G.ui.position[P[a]]){G.ui.position[P[a]][Z](W,{targetWidth:L,targetHeight:I,elemWidth:V,elemHeight:S,collisionPosition:Q,collisionWidth:X,collisionHeight:Y,offset:O,my:J.my,at:J.at})}});if(G.fn.bgiframe){T.bgiframe()}T.offset(G.extend(W,{using:J.using}))})};G.ui.position={fit:{left:function(I,J){var L=G(window),K=J.collisionPosition.left+J.collisionWidth-L.width()-L.scrollLeft();I.left=K>0?I.left-K:Math.max(I.left-J.collisionPosition.left,I.left)},top:function(I,J){var L=G(window),K=J.collisionPosition.top+J.collisionHeight-L.height()-L.scrollTop();I.top=K>0?I.top-K:Math.max(I.top-J.collisionPosition.top,I.top)}},flip:{left:function(J,L){if(L.at[0]===A){return }var N=G(window),M=L.collisionPosition.left+L.collisionWidth-N.width()-N.scrollLeft(),I=L.my[0]==="left"?-L.elemWidth:L.my[0]==="right"?L.elemWidth:0,K=L.at[0]==="left"?L.targetWidth:-L.targetWidth,O=-2*L.offset[0];J.left+=L.collisionPosition.left<0?I+K+O:M>0?I+K+O:0},top:function(J,L){if(L.at[1]===A){return }var N=G(window),M=L.collisionPosition.top+L.collisionHeight-N.height()-N.scrollTop(),I=L.my[1]==="top"?-L.elemHeight:L.my[1]==="bottom"?L.elemHeight:0,K=L.at[1]==="top"?L.targetHeight:-L.targetHeight,O=-2*L.offset[1];J.top+=L.collisionPosition.top<0?I+K+O:M>0?I+K+O:0}}};if(!G.offset.setOffset){G.offset.setOffset=function(M,J){if(/static/.test(G.curCSS(M,"position"))){M.style.position="relative"}var L=G(M),O=L.offset(),I=parseInt(G.curCSS(M,"top",true),10)||0,N=parseInt(G.curCSS(M,"left",true),10)||0,K={top:(J.top-O.top)+I,left:(J.left-O.left)+N};if("using" in J){J.using.call(M,K)}else{L.css(K)}};G.fn.offset=function(I){var J=this[0];if(!J||!J.ownerDocument){return null}if(I){if(G.isFunction(I)){return this.each(function(K){G(this).offset(I.call(this,K,G(this).offset()))})}return this.each(function(){G.offset.setOffset(this,I)})}return C.call(this)}}if(!G.curCSS){G.curCSS=G.css}}(jQuery));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-experimental-progress-indicator', location = 'js/aui-experimental-progress-indicator.js' */
(function(){function A(B,D,C){AJS._internal.animation.recomputeStyle(B);B.css("width",C*100+"%");D.attr("data-value",C)}AJS.progressBars={update:function(G,M){var C=AJS.$(G).first();var F=C.children(".aui-progress-indicator-value");var L=F.attr("data-value")||0;var K="aui-progress-indicator-after-update";var I="aui-progress-indicator-before-update";var D="transitionend webkitTransitionEnd";var E=!C.attr("data-value");if(E){F.css("width",0)}if(typeof M==="number"&&M<=1&&M>=0){C.trigger(I,[L,M]);var H=document.body||document.documentElement;var B=H.style;var J="transition";if(typeof B.transition==="string"||typeof B.WebkitTransition==="string"){F.one(D,function(){C.trigger(K,[L,M])});A(F,C,M)}else{A(F,C,M);C.trigger(K,[L,M])}}return C},setIndeterminate:function(D){var C=AJS.$(D).first();var B=C.children(".aui-progress-indicator-value");C.removeAttr("data-value");AJS._internal.animation.recomputeStyle(C);B.css("width","100%")}}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:support', location = 'js/drag-and-drop-utils.js' */
define("confluence-drag-and-drop/drag-and-drop-utils",["jquery","window","ajs"],function(c,d,f){return{defaultMimeType:"application/octet-stream",base:/^\w+:\/\/[^\/?#]+/.exec(location.href),bindDragEnter:function(a,b){if(a.addEventListener)(b=this.isFireFox35OrLater()?this.firefox35DragEnterAndOverCallbackWrapper(b):b)&&a.addEventListener("dragenter",b,!1);else if(a.attachEvent){var e=this.ieDragEnterAndDragOverCallbackWrapper(b);a.attachEvent("ondragenter",e);c(d).unload(function(){a.detachEvent("ondragenter",
e)})}},bindDragOver:function(a,b){if(a.addEventListener)this.isFireFox35OrLater()?b=this.firefox35DragEnterAndOverCallbackWrapper(b):c.browser.safari&&(b=this.safariDragOverCallbackWrapper(b)),b&&a.addEventListener("dragover",b,!1);else if(a.attachEvent){var e=this.ieDragEnterAndDragOverCallbackWrapper(b);a.attachEvent("ondragover",e);c(d).unload(function(){a.detachEvent("ondragover",e)})}},bindDragLeave:function(a,b){b&&(c.browser.safari||this.isFireFox35OrLater()||tinymce.isIE11?a.addEventListener("dragleave",
b,!1):c.browser.msie?(a.attachEvent("ondragleave",b),c(d).unload(function(){a.detachEvent("ondragleave",b)})):c.browser.mozilla&&a.addEventListener("dragexit",b,!1))},bindDrop:function(a,b){if(c.browser.mozilla){var e=this.isFireFox35OrLater()?"drop":"dragdrop";a.addEventListener(e,this.mozillaDropCallbackWrapper(b),!1)}else if(c.browser.msie){if(b){var g=function(a){b(a);f.DragAndDropUtils.stopPropagation(a)};a.attachEvent("ondrop",g);c(d).unload(function(){a.detachEvent("ondrop",g)})}}else c.browser.safari&&
b&&a.addEventListener("drop",function(a){b(a);f.DragAndDropUtils.stopPropagation(a)},!1)},niceSize:function(a){for(var b=" B; kB; MB; GB; TB; PB; EB; ZB; YB".split(";"),c=0,d=b.length;c<d;c++)if(a<Math.pow(2,10*(c+1)))return(!c?a:(a/Math.pow(2,10*c)).toFixed(2))+b[c];return(a/Math.pow(2,10*(c+1))).toFixed(2)+b[b.length-1]},ieDragEnterAndDragOverCallbackWrapper:function(a){return function(b){if(b=b||d.event)a&&a(b),c.browser.msie&&(b.returnValue=!1)}},safariDragOverCallbackWrapper:function(a){return function(b){if((b=
b||d.event)&&"file"!==b.target.type)a&&a(b),-1!=c.inArray("public.file-url",b.dataTransfer.types)&&b.preventDefault()}},mozillaDropCallbackWrapper:function(a){return function(b){b&&(a&&a(b),b.preventDefault(),f.DragAndDropUtils.isFireFox35OrLater()?f.DragAndDropUtils.firefox35FileDataInEvent(b)&&b.stopPropagation():b.stopPropagation())}},firefox35DragEnterAndOverCallbackWrapper:function(a){return function(b){b&&(a&&a(b),f.DragAndDropUtils.firefox35FileDataInEvent(b)&&b.preventDefault())}},firefox35FileDataInEvent:function(a){return-1!=
c.inArray("application/x-moz-file",a.dataTransfer.types)},stopPropagation:function(a){if(a=a||d.event)a.stopPropagation?a.stopPropagation():a.cancelBubble=!0},preventDefault:function(a){if(a=a||d.event)a.preventDefault?a.preventDefault():a.returnValue=!1},isFireFox35OrLater:function(){return!this.isFireFox30()&&-1!=c.browser.version.indexOf("1.9.")},isFireFox30:function(){return-1!=c.browser.version.indexOf("1.9.0")},enableDropZoneOn:function(a,b){if(!a)throw Error("Cannot enable drop zone on invalid container. Received: "+
a);b=b||f.DragAndDrop.defaultDropHandler;this.bindDragEnter(a);this.bindDragOver(a);this.bindDragLeave(a);this.bindDrop(a,b)}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-drag-and-drop/drag-and-drop-utils","AJS.DragAndDropUtils");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:support', location = 'js/default-drop-handler.js' */
define("confluence-drag-and-drop/default-drop-handler","ajs document confluence/meta jquery confluence/legacy underscore plupload window".split(" "),function(a,h,j,f,k,p,l,q){var m={initialise:function(){function n(){var a=f(".aui-blanket:visible");return a.length&&a.css("visibility")!=="hidden"&&!f("#drag-and-drop-progress-dialog:visible").length}function m(){for(;e.files.length;)e.removeFile(e.files[0])}var d,i=h.getElementById("fileuploadShim");if(!i){i=h.createElement("div");i.setAttribute("id",
"fileuploadShim");h.body.appendChild(i)}var e=new l.Uploader({runtimes:"html5",dragdrop:true,drop_element:f("body")[0],browse_button:i.getAttribute("id"),multipart:false,stop_propagation:true,max_file_size:+j.get("global-settings-attachment-max-size")}),o=function(){d=a.Editor&&a.Editor.isVisible()&&k.EditorUploadProgressDialog?k.EditorUploadProgressDialog:new a.DragAndDropProgressDialog};d=null;e.init();a.DragAndDrop.defaultDropHandler=null;e.bind("FilesAdded",function(g,b){function r(a,b){!d&&o();
for(var c=0;c<b.length;c++){var g=b[c];g.status!==l.FAILED&&d.render({workId:g.id,status:g.status,file:g})}e.start()}if(n())m();else if(a.Editor&&a.Editor.isVisible()){var c=p.reject(b,function(a){return a.status===l.FAILED});k.Uploader&&k.Uploader.trigger("FilesAdded",c)}else a.UploadUtils.filterFiles(g,b,r)});e.bind("BeforeUpload",function(g,b){if(!a.Editor||!a.Editor.isVisible()){var e=a.DragAndDropUtils.base+a.contextPath()+"/plugins/drag-and-drop/upload.action",c=j.get("page-id"),c=c!=0?{pageId:c}:
{draftId:j.get("draft-id")},f=b.name.substr(b.name.lastIndexOf(".")+1);c.filename=b.name;c.size=b.size;c.mimeType=l.mimeTypes[f.toLowerCase()]||a.DragAndDropUtils.defaultMimeType;c.spaceKey=j.get("space-key");c.atl_token=j.get("atl-token");g.settings.url=l.buildUrl(e,c);d.cancelListeners.push(function(b,c){var e=g.getFile(c.workId);e&&g.removeFile(e);d.renderInfo(c.workId,"File was manually removed from the queue.")});d.show()}});e.bind("UploadProgress",function(a,b){d.renderUpdateToBytesUploaded(b.id,
b.loaded,b.size);d.hideCloseButton()});e.bind("FileUploaded",function(e,b,f){f.status===0?d.renderError(b.id,"The server is not responding. Please check that it is running."):d.renderComplete(b.id)});e.bind("Error",function(e,b){if(n())m();else if(a.Editor&&a.Editor.isVisible())k.Uploader&&k.Uploader.trigger("Error",b);else{var h,c;if(b.response){try{h=f.parseJSON(b.response);c=h.actionErrors[0]}catch(i){c=i.name==="SyntaxError"?"Invalid response received from the server.":b.message}d.renderError(b.file.id,
c);a.trigger("analyticsEvent",{name:"confluence.default-drop.upload.error.server-unknown"})}else{c=b.message;if(b.code===l.FILE_SIZE_ERROR){c=a.format("is too big to upload. Files must be less than {0}.",a.DragAndDropUtils.niceSize(j.get("global-settings-attachment-max-size")));a.trigger("analyticsEvent",{name:"confluence.default-drop.upload.error.file-size"})}else if(b.code===a.UploadUtils.ErrorCode.FILE_IS_A_FOLDER_ERROR){c="might be a folder or an unsupported file type.";a.trigger("analyticsEvent",{name:"confluence.default-drop.upload.error.file-type"})}!d&&
o();d.render({workId:b.file.id,status:b.file.status,file:b.file,errorMessage:c});if(!d.isVisible()){d.show();d.showCloseButton()}}}});e.bind("UploadComplete",function(){if(!e.total.queued&&d){d.showCloseButton();d.hasErrors()||setTimeout(function(){d.hide();d.clearRenderOutput();q.location.reload()},1E3)}})},bind:function(){function a(){f(h).unbind("dragenter",a);m.initialise()}f(h).bind("dragenter",a)}};return m});
require("confluence/module-exporter").safeRequire("confluence-drag-and-drop/default-drop-handler",function(a){require("ajs").toInit(a.bind)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:support', location = 'js/observable-array-list.js' */
define("confluence-drag-and-drop/observable-array-list",["ajs","jquery"],function(g,f){var e=function(){this._data=[];this._pushObservers=[]};e.prototype={push:function(a){this._data.push(a);this._notifyPushObservers(a)},length:function(){return this._data.length},remove:function(a,b){return this._remove.call(this._data,a,b)},_remove:function(a,b){var c=this.slice((b||a)+1||this.length);this.length=0>a?this.length+a:a;return this.push.apply(this,c)},shift:function(){return this._data.shift()},removeByPredicate:function(a){for(var b=
[],c=this._data.length,d=0;d<c;d++)a(this._data[d])||b.push(this._data[d]);this._data=b;return c-this._data.length},addPushObserver:function(a){if(f.isFunction(a))this._pushObservers.push(a);else throw Error("Attempting to add an observer that is not a function: "+a);},_notifyPushObservers:function(a){for(var b=0,c=this._pushObservers.length;b<c;b++)this._pushObservers[b](a)}};return e});require("confluence/module-exporter").exportModuleAsGlobal("confluence-drag-and-drop/observable-array-list","AJS.ObservableArrayList");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:support', location = 'js/upload-progress-dialog.js' */
define("confluence-drag-and-drop/upload-progress-dialog",["ajs","plupload","jquery","document"],function(b,g,c,i){var h=function(a){var d=this,e={header:"Attach files",width:600,height:400};this._options=c.extend({},e,a);this.id="drag-and-drop-progress-dialog";this._dialog=new b.Dialog(this._options.width,this._options.height,this.id);this._dialog.addHeader(this._options.header).addPanel("Panel 1",b.DragAndDrop.Templates.uploadFileStatusContainer()).addButton("Done",
function(){d.hide();d.clearRenderOutput()},"all-file-uploads-complete");this._dialog.getCurrentPanel().setPadding(0);this._$closeButton=this.find(".all-file-uploads-complete");c(i).keydown(function(a){if(27===a.which)return d._$closeButton.prop("disabled")||(d.hide(),d.clearRenderOutput()),b.stopEvent(a)});this._$container=this.find("#upload-statuses");this._workIdsOfFilesInProgress=[];this.cancelListeners=[];this.onShowListeners=[];this._hidden=!0;this.hasErrorMessage=!1};h.prototype={show:function(){this._hidden&&
(this._dialog.show(),this._hidden=!1,c.each(this.onShowListeners,function(a,c){c()}));this.hideCloseButton()},hide:function(){this._hidden||(this._dialog.hide(),this._hidden=!0)},isVisible:function(){return!this._hidden},_getProgressElementId:function(a){return"file-"+a+"-progress"},render:function(a){this._workIdsOfFilesInProgress.push(a.workId);var d=this._getProgressElementId(a.workId);this._$container.append(b.DragAndDrop.Templates.fileStatus({filename:a.file.name,progressElementId:d,workId:a.workId,
showCancel:a.status==g.QUEUED}));b.progressBars.update("#"+d,0);a.status==g.QUEUED?c("#file-upload-cancel-"+a.workId).click(function(b){return function(d){c.each(b,function(c,b){b(d,a)})}}(this.cancelListeners)):this.renderError(a.workId,a.errorMessage)},renderError:function(a,d){if(-1==c.inArray(a,this._workIdsOfFilesInProgress))throw Error("No file status found with id: "+a);var e=c("#file-status-block-"+a),f=b.escapeEntities(e.attr("data-filename"));e.html(aui.message.warning({content:d,titleContent:f}));
this.hasErrorMessage=!0},renderInfo:function(a,d){if(-1==c.inArray(a,this._workIdsOfFilesInProgress))throw Error("No file status found with id: "+a);var e=c("#file-status-block-"+a),f=b.escapeEntities(e.attr("data-filename"));e.html(aui.message.info({content:d,titleContent:f}));this.hasErrorMessage=!0},hasErrors:function(){return this.hasErrorMessage},renderUpdateToBytesUploaded:function(a,d,e){if(-1==c.inArray(a,this._workIdsOfFilesInProgress))throw Error("No file status found with id: "+a);var f=
b.DragAndDropUtils.niceSize(d),g=c("#file-"+a+"-uploaded");g.length?g.text(f):c("#file-upload-progress-text-"+a).html(b.DragAndDrop.Templates.uploadFileStatusProgressMessage({fileId:a,uploadedSizeNice:f,totalSizeNice:b.DragAndDropUtils.niceSize(e)}));b.progressBars.update("#"+this._getProgressElementId(a),d/e)},renderComplete:function(a){if(-1==c.inArray(a,this._workIdsOfFilesInProgress))throw Error("No file status found with id: "+a);c("#cancel-or-success-placeholder-"+a).html(b.DragAndDrop.Templates.uploadFileStatusSuccessIcon())},
renderCancelled:function(a){if(-1==c.inArray(a,this._workIdsOfFilesInProgress))throw Error("No file status found with id: "+a);b.progressBars.setIndeterminate("#"+this._getProgressElementId(a));c("#file-upload-progress-text-"+a).html("Cancelled.");c("#cancel-or-success-placeholder-"+a).hide()},clearRenderOutput:function(){this.showCloseButton();this._$container.empty();this._workIdsOfFilesInProgress=[];this.hasErrorMessage=!1},hideCloseButton:function(){this._$closeButton.hide()},
showCloseButton:function(){this._$closeButton.show()},find:function(a){return this._dialog.getCurPanel().page.body.parent().find(a)}};return h});require("confluence/module-exporter").exportModuleAsGlobal("confluence-drag-and-drop/upload-progress-dialog","AJS.DragAndDropProgressDialog");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:support', location = 'templates/drag-and-drop.soy' */
// This file was automatically generated from drag-and-drop.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace AJS.DragAndDrop.Templates.
 */

if (typeof AJS == 'undefined') { var AJS = {}; }
if (typeof AJS.DragAndDrop == 'undefined') { AJS.DragAndDrop = {}; }
if (typeof AJS.DragAndDrop.Templates == 'undefined') { AJS.DragAndDrop.Templates = {}; }


AJS.DragAndDrop.Templates.fileStatus = function(opt_data, opt_ignored) {
  return '<li id="file-status-block-' + soy.$$escapeHtml(opt_data.workId) + '" data-filename="' + soy.$$escapeHtml(opt_data.filename) + '"><div class="aui-group aui-group-split file-status-item"><div class="aui-item"><label>' + soy.$$escapeHtml(opt_data.filename) + '</label></div><div class="aui-item"><div id="file-upload-progress-text-' + soy.$$escapeHtml(opt_data.workId) + '" class="file-upload-progress-text">' + soy.$$escapeHtml("Waiting...") + '</div></div></div><div class="file-upload-progress-block"><div class="aui-progress-indicator" id="' + soy.$$escapeHtml(opt_data.progressElementId) + '"><span class="aui-progress-indicator-value"></span></div>' + ((opt_data.showCancel) ? '<div id="cancel-or-success-placeholder-' + soy.$$escapeHtml(opt_data.workId) + '" class="cancel-or-success-placeholder ui-state-default"><span id="file-upload-cancel-' + soy.$$escapeHtml(opt_data.workId) + '" class="aui-icon aui-icon-small aui-iconfont-remove" title="' + soy.$$escapeHtml("Cancel Upload") + '">' + soy.$$escapeHtml("Cancel") + '</span></div>' : '') + '</div></li>';
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.fileStatus.soyTemplateName = 'AJS.DragAndDrop.Templates.fileStatus';
}


AJS.DragAndDrop.Templates.uploadFileStatusContainer = function(opt_data, opt_ignored) {
  return '<ul id="upload-statuses"></ul>';
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.uploadFileStatusContainer.soyTemplateName = 'AJS.DragAndDrop.Templates.uploadFileStatusContainer';
}


AJS.DragAndDrop.Templates.uploadFileStatusSuccessIcon = function(opt_data, opt_ignored) {
  return '<span class=\'aui-icon aui-icon-small aui-iconfont-success\'></span>';
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.uploadFileStatusSuccessIcon.soyTemplateName = 'AJS.DragAndDrop.Templates.uploadFileStatusSuccessIcon';
}


AJS.DragAndDrop.Templates.uploadFileStatusProgressMessage = function(opt_data, opt_ignored) {
  return '<span id="file-' + soy.$$escapeHtml(opt_data.fileId) + '-uploaded">' + soy.$$escapeHtml(opt_data.uploadedSizeNice) + '</span> ' + soy.$$escapeHtml("of") + ' ' + soy.$$escapeHtml(opt_data.totalSizeNice);
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.uploadFileStatusProgressMessage.soyTemplateName = 'AJS.DragAndDrop.Templates.uploadFileStatusProgressMessage';
}


AJS.DragAndDrop.Templates.dropZone = function(opt_data, opt_ignored) {
  return '<div class="attachments-drop-zone"><div class="drop-zone-image"></div><div class="drop-zone-text">' + soy.$$escapeHtml("Drop files here to attach them") + '</div></div>';
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.dropZone.soyTemplateName = 'AJS.DragAndDrop.Templates.dropZone';
}


AJS.DragAndDrop.Templates.dragOverlay = function(opt_data, opt_ignored) {
  return '<div id="dragOverlay"><div class="overlay-blanket"></div><div class="overlay-center"><p>' + soy.$$escapeHtml("Drop files to insert them into the page") + '</p></div><span class="overlay-baseline"></span><div class="overlay-drop-zone"></div></div>';
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.dragOverlay.soyTemplateName = 'AJS.DragAndDrop.Templates.dragOverlay';
}


AJS.DragAndDrop.Templates.dragAndDropTip = function(opt_data, opt_ignored) {
  return '<div class="attach-tip-discovery"><span class="img"></span><div class="text"><strong>' + soy.$$escapeHtml("Tip:") + ' </strong><p>' + soy.$$escapeHtml("Drop files straight into your page to insert them directly.") + '</p><div><a class="close-tip" href="#">' + soy.$$escapeHtml("Ok, got it!") + '</a></div></div></div>';
};
if (goog.DEBUG) {
  AJS.DragAndDrop.Templates.dragAndDropTip.soyTemplateName = 'AJS.DragAndDrop.Templates.dragAndDropTip';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.drag-and-drop:support', location = 'js/upload-utils.js' */
define("confluence-drag-and-drop/upload-utils",["ajs"],function(h){return{ErrorCode:{FILE_IS_A_FOLDER_ERROR:-602},filterFiles:function(d,a,g){for(var e=[],b=0,c=0;c<a.length;c++)if(4096>=a[c].nativeFile.size){var f=new FileReader;f.onload=function(){b++;e.push(this.currentFile);b===a.length&&g(d,e)};f.onerror=function(){d.removeFile(this.currentFile);d.trigger("Error",{code:h.UploadUtils.ErrorCode.FILE_IS_A_FOLDER_ERROR,message:"File is a folder",file:this.currentFile});b++;b===a.length&&g(d,e)};
f.currentFile=a[c];f.readAsText(a[c].nativeFile)}else b++,e.push(a[c]),b===a.length&&g(d,e)}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-drag-and-drop/upload-utils","AJS.UploadUtils");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:util-resource', location = 'util/utils.js' */
define("confluence/ic/util/utils",["jquery","underscore","ajs","backbone","exports"],function(w,R,u,x,F){var m={INLINE_COMMENTS:u.DarkFeatures.isEnabled("confluence-inline-comments"),RESOLVED_INLINE_COMMENTS:u.DarkFeatures.isEnabled("confluence-inline-comments-resolved"),RICH_TEXT_EDITOR:u.DarkFeatures.isEnabled("confluence-inline-comments-rich-editor"),DANGLING_COMMENT:u.DarkFeatures.isEnabled("confluence-inline-comments-dangling-comment")},t=["dateautocomplete","confluencemacrobrowser","propertypanel","jiraconnector","dfe"],n=["autoresize","confluenceleavecomment"],r=["code"];var a,C,q;function O(){return R.clone(m)}function N(){return R.clone(t)}function j(){return R.clone(n)}function d(U,T){var W;if(!U||!T){return}var S=w(U.containingElement);if(!S.is(".inline-comment-marker.valid")){S=w("<div/>").append(U.html).find(".inline-comment-marker.valid")}if(S.length>0&&f(S)){var V=S.first().data("ref");W=T.findWhere({markerRef:V});return W}}function f(S){return S.filter(function(){return w(this).text().length>0}).length>0}function h(S){return u.contextPath()+"/pages/viewpage.action?pageId="+u.Meta.get("latest-page-id")+"&focusedCommentId="+S+"#comment-"+S}function s(Y,X,S){var V=X.match(/(focusedCommentId|replyToComment)=(\d+)/);if(V==null){return}var U=V[1]==="replyToComment";var W=parseInt(V[2],10);var T=Y.findWhere({id:W});if(T!=null){o(Y,T,S,U)}else{w.ajax({url:u.contextPath()+"/rest/inlinecomments/1.0/comments/replies/"+W+"/commentId"}).done(function(Z){T=Y.findWhere({id:Z});o(Y,T,S,U)})}}function o(V,U,S,T){if(U!=null){if(U.isResolved()){new S({collection:V,focusCommentId:U.get("id")}).render()}else{if(!U.isDangling()){x.trigger("ic:view",U,"permalink",{isReplyComment:T})}}}}function K(){if(u.Meta.get("current-user-avatar-url")){return u.contextPath()+u.Meta.get("current-user-avatar-url")}return u.Meta.get("static-resource-url-prefix")+"/images/icons/profilepics/anonymous.png"}function P(){return u.Meta.get("user-display-name")||u.Meta.get("current-user-fullname")}function b(U){if(typeof U.selectionStart==="number"){var S=U.value.length;U.selectionStart=S;U.selectionEnd=S}else{if(typeof U.createTextRange!=null){U.focus();var T=U.createTextRange();T.collapse(false);T.select()}}}function L(S){b(S);window.setTimeout(function(){b(S)},1)}function E(X,W){var U="webkitAnimationEnd oanimationend msAnimationEnd animationend";var T=X.$wikiContent;var S=w.Deferred();if(W){var Y=w(".inline-comment-marker.active");T.addClass("ic-fade-in-animation");T.one(U,function(){w(this).removeClass("ic-fade-in-animation")});X.$el.addClass("ic-slide-in");X.$el.one(U,function(){w(this).removeClass("ic-slide-in");Y.addClass("ic-highlight-pulse");Y.one(U,function(){Y.removeClass("ic-highlight-pulse")})});S.resolve()}else{T.bind(U,function(Z){if(Z.originalEvent.animationName=="ic-fade-out-animation"){X.$wikiContent.removeClass("ic-fade-out-animation");X.$wikiContent.css("opacity","0.5")}else{if(Z.originalEvent.animationName=="ic-fade-in-animation"){X.$wikiContent.css("opacity","1");X.$wikiContent.removeClass("ic-fade-in-animation");X.$wikiContent.unbind(U)}}});T.addClass("ic-fade-out-animation");X.$el.addClass("ic-slide-out");var V=function(){X.$el.removeClass("ic-slide-out");X._emptySidebar();y().css("padding-right","0");T.addClass("ic-fade-in-animation");T.css("position","static");S.resolve();X.$el.off(U,V)};X.$el.on(U,V)}return S.promise()}function k(S){var T=w(S).closest("a");if(!T.length){T=w(S).find("a")}return T}function A(S){S.each(function(){var T=k(this);T.length&&T.off("mousemove")})}function Q(){return document.body.style.animation!==undefined||document.body.style.webkitAnimation!==undefined}function c(T){var S=T.parents(".expand-content.expand-hidden");S.each(function(U){w(this).siblings(".expand-control").click()})}function v(T){var S=u.Rte&&u.Rte.getEditor();if(T===true){if(M()&&S&&S.isDirty()){return confirm("Your comment will be lost.")}}else{if(S&&S.isDirty()&&Confluence.Editor&&!Confluence.Editor.getContentType){return confirm("Your comment will be lost.")}}return true}function M(){return !!w(".ic-sidebar #wysiwygTextarea_ifr").length}function G(){return u.Meta.get("use-keyboard-shortcuts")&&Confluence.KeyboardShortcuts&&Confluence.KeyboardShortcuts.enabled}function p(S){S.$("button.ic-action-hide").tooltip({gravity:"se"});S.$("#ic-nav-next").tooltip({gravity:"s"});S.$("#ic-nav-previous").tooltip({gravity:"s"})}function B(W){if(J()){W.css("padding-bottom","20px");return}var U=W.height();var V=W.offset().top;var T=V+U;var X=this.getPageContainer().offset().top;var S=T-X;this.getPageContainer().css({"min-height":S+"px"})}function z(W){W=W.closest(".ic-display-comment-view");var V=this;var T=w(".confluence-embedded-image, .confluence-embedded-file img",W);var U=T.length;var S=0;if(U>0){T.off("load").one("load",function(){if(++S===U){V.recalculateContentHeight(W)}}).each(function(){if(this.complete){w(this).load()}})}}function J(){if(q===undefined){q=!!D().length}return q}function y(){if(a===undefined){a=w("#content")}return a}function D(){if(C===undefined){C=w("#splitter-content")}return C}function g(S,T){if(T&&!T.is(":visible")){return}if(S){if(this.isDocTheme()){this.getSplitterContent().scrollTop(T.offset().top-S)}else{window.scrollTo(0,T.offset().top-S)}}}function e(T){var S=w.Deferred();w.ajax({url:u.contextPath()+"/rest/api/content/"+T+"?expand=body.editor",type:"GET",dataType:"json",contentType:"application/json; charset=utf-8"}).then(function(U){var V=U.body.editor.value;S.resolve(V)}).fail(function(U,W,V){S.reject(U,W,V)});return S.promise()}function I(S){var T=S.closest(".conf-macro");return(T.data("hasbody")===false||S.find('.conf-macro[data-hasbody="false"]').length>0)||r.indexOf(T.data("macro-name"))!=-1}function i(S){return S.closest(".user-mention").length>0||S.find(".user-mention").length>0}function l(S){return S.closest("a[href^='/']:not('.user-mention')").length>0||S.find("a[href^='/']:not('.user-mention')").length>0}function H(){var S={isDefault:true,path:u.Meta.get("static-resource-url-prefix")+"/images/icons/profilepics/default.png"};if(u.Meta.get("current-user-avatar-url")!=="/images/icons/profilepics/default.png"){S={isDefault:false,path:u.contextPath()+u.Meta.get("current-user-avatar-url")}}var T=u.Meta.get("remote-user");return{userName:T==""?null:T,displayName:u.Meta.get("current-user-fullname"),profilePicture:S}}F.overlappedSelection=d;F.focusedCommentUrl=h;F.showFocusedComment=s;F.getAuthorAvatarUrl=K;F.moveCaretToEnd=L;F.animateSidebar=E;F.getDarkFeatures=O;F.getInlineLinks=k;F.removeInlineLinksDialog=A;F.isAnimationSupported=Q;F.showHighlightContent=c;F.getUnsupportedRtePlugins=N;F.getSupportedRtePlugins=j;F.confirmProcess=v;F.getAuthorDisplayName=P;F.isKeyboardShortcutsEnable=G;F.addSidebarHeadingTooltip=p;F.hasEditorInSidebar=M;F.recalculateContentHeight=B;F.resizeContentAfterLoadingImages=z;F.isDocTheme=J;F.getPageContainer=y;F.getSplitterContent=D;F.scrollToCommentAfterToggleSideBar=g;F.getEditorFormat=e;F.containUnsupportedMacro=I;F.containInternalLink=i;F.containUserMetion=l;F.getCurrentUserInfo=H});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:util-resource', location = 'util/text-highlighter.js' */
define("confluence/ic/util/text-highlighter",["jquery"],function(c){var a="ic-current-selection";function b(){c.textHighlighter.createWrapper=function(d){return c("<span></span>").addClass(d.highlightedClass)};this.$el=c("#content .wiki-content").first();if(this.$el.length>0){this.$el.textHighlighter({highlightedClass:a})}}b.prototype.highlight=function(e){if(this.$el.length===0){return}var d=c(this.$el.getHighlighter().doHighlight(e));return this.$el.getHighlighter().serializeHighlights(d)};b.prototype.removeHighlight=function(){if(this.$el.length===0){return}this.$el.getHighlighter().removeHighlights();return this};b.prototype.deserializeHighlights=function(d,e){if(this.$el.length===0){return}var f='<span class="inline-comment-marker" data-ref="'+e+'"></span>';return this.$el.getHighlighter().deserializeHighlights(d,f)};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/comment.js' */
define("confluence/ic/model/comment",["jquery","underscore","backbone","ajs","confluence/ic/util/utils","confluence/ic/model/reply-collection"],function(d,b,g,a,c,f){var e=g.Model.extend({defaults:{authorDisplayName:c.getAuthorDisplayName(),authorUserName:a.Meta.get("remote-user"),authorAvatarUrl:a.contextPath()+a.Meta.get("current-user-avatar-url"),body:"",originalSelection:"",containerId:a.Meta.get("latest-page-id"),parentCommentId:"0",lastFetchTime:d("meta[name=confluence-request-time]").attr("content"),hasDeletePermission:true,hasEditPermission:true,hasResolvePermission:true,resolveProperties:{resolved:false,resolvedTime:0},serializedHighlights:"",deleted:false},urlRoot:a.contextPath()+"/rest/inlinecomments/1.0/comments",initialize:function(h){h=h||{};this._setHighlights(h.markerRef);var i=this;this.replies=new f();this.replies.url=function(){return i.url()+"/replies"};if(c.getDarkFeatures().DANGLING_COMMENT&&a.Meta.get("page-id")===a.Meta.get("latest-page-id")){if(this.isDangling()&&!this.isResolved()){this.resolve(true,{wait:true,dangling:true,success:b.bind(function(){g.trigger("ic:open:dangled",this)},this),error:b.bind(function(){g.trigger("ic:resolve:dangled:failed",this)},this)})}}},validate:function(){if(!this.get("body")){return true}},resolve:function(h,i){i=i||{};this.save({},b.extend(i,{url:this.urlRoot+"/"+this.get("id")+"/resolve/"+h+"/dangling/"+(i.dangling===true)}))},isResolved:function(){return this.get("resolveProperties").resolved},isDangling:function(){return this.highlight===undefined},isDeleted:function(){return this.get("deleted")},_setHighlights:function(i){var h;if(i!==undefined){h=d("#content .wiki-content:first").find('.inline-comment-marker[data-ref="'+i+'"]')}else{h=d(".ic-current-selection")}if(h.length!==0){this.highlights=h;this.highlight=h.first()}else{this.highlights=undefined;this.highlight=undefined}},destroy:function(i){i=i?b.clone(i):{};var h=this;var k=i.success;var j=function(n,m){var l=m.error;m.error=function(o){if(l){l(n,o,m)}n.trigger("error",n,o,m)}};i.success=function(l){if(k){k(h,l,i)}};j(this,i);return this.sync("delete",this,i)}});return e});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/comment-collection.js' */
define("confluence/ic/model/comment-collection",["jquery","backbone","ajs","underscore","confluence/ic/model/comment"],function(d,f,a,b,e){var c=f.Collection.extend({model:e,initialize:function(){this.listenTo(this,"sort",this._removeCachedMarkers)},url:function(){var h=a.contextPath();var g=a.Meta.get("page-id");return h+"/rest/inlinecomments/1.0/comments?containerId="+g},getResolvedCount:function(){return this.getResolvedComments().length},getUnresolveCount:function(){return this.reject(function(g){return g.isResolved()===true&&g.isDeleted()===false}).length},getResolvedComments:function(){return this.filter(function(g){return g.isResolved()===true&&g.isDeleted()===false})},getResolvedCommentsDesc:function(){return b.sortBy(this.getResolvedComments(),function(g){return 0-g.get("resolveProperties").resolvedTime})},getNextCommentOnPage:function(){return this._getCommentAtRelativeOffset(1)},getPrevCommentOnPage:function(){return this._getCommentAtRelativeOffset(-1)},_getCommentAtRelativeOffset:function(j){var k=this.getCommentsOnPage();var g=this.findWhere({active:true});if(g===undefined||k.length<=1){return null}var i=b.pluck(k,"id");var h=b.indexOf(i,g.get("id"));return k[(h+j+k.length)%k.length]},getCommentsOnPage:function(){return this.filter(function(g){return((g.isResolved()===false)&&!g.isDangling()&&(g.isDeleted()===false))||g.get("active")===true})},getCommentsOnPageCount:function(){return this.getCommentsOnPage().length},getActiveIndexWithinPageComments:function(){var h=b.pluck(this.getCommentsOnPage(),"id");var g=this.findWhere({active:true});if(g===undefined){return null}var i=g.get("id");return b.indexOf(h,i)},comparator:function(h,g){if(this.markers===undefined){this.markers=d("#content .wiki-content:first").find(".inline-comment-marker")}if(h.highlight===undefined){return 1}if(g.highlight===undefined){return -1}return this.markers.index(h.highlight)-this.markers.index(g.highlight)},_removeCachedMarkers:function(){this.markers=undefined}});return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/reply.js' */
define("confluence/ic/model/reply",["jquery","backbone","ajs","confluence/ic/util/utils",],function(d,e,b,c){var a=e.Model.extend({defaults:{authorDisplayName:c.getAuthorDisplayName(),authorUserName:b.Meta.get("remote-user"),authorAvatarUrl:b.contextPath()+b.Meta.get("current-user-avatar-url"),body:"",commentId:"0",hasDeletePermission:true,hasEditPermission:!!b.Meta.get("remote-user")},urlRoot:function(){return b.contextPath()+"/rest/inlinecomments/1.0/comments/"+this.get("commentId")+"/replies"},sync:function(h,g,f){f=f||{};if(h==="create"){f.url=this.urlRoot()+"?containerId="+b.Meta.get("latest-page-id")}return e.sync.call(this,h,g,f)},validate:function(){if(!this.get("body")){return true}}});return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:models', location = '/model/reply-collection.js' */
define("confluence/ic/model/reply-collection",["backbone","confluence/ic/model/reply"],function(c,a){var b=c.Collection.extend({model:a});return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:app', location = 'analytics/ic-analytics.js' */
define("confluence/ic/analytics",["ajs","underscore","backbone"],function(b,c,d){var a={};c.extend(a,d.Events);a.start=function(){if(this.running===true){return}this.running=true;this.send=function(e,f){b.trigger("analytics",{name:e,data:f})};this.listenTo(d,"ic:highlight-panel-click",function(){this.send("confluence.highlight.actions.comment.inline")});this.listenTo(d,"ic:view",function(f,e){this.send("confluence.comment.inline.view");if(e==="nav"){this.send("confluence.comment.inline.view.nav")}if(e==="permalink"){this.send("confluence.comment.inline.view.permalink")}});this.listenTo(d,"ic:overlap",function(){this.send("confluence.comment.inline.overlap")});this.listenTo(d,"ic:edit",function(){this.send("confluence.comment.inline.edit")});this.listenTo(d,"ic:persist",function(){this.send("confluence.comment.inline.create")});this.listenTo(d,"ic:sidebar:close",function(){this.send("confluence.comment.inline.sidebar.close")});this.listenTo(d,"ic:reply:persist",function(){this.send("confluence.comment.inline.reply")});this.listenTo(d,"ic:delete ic:reply:delete",function(){this.send("confluence.comment.inline.delete")});this.listenTo(d,"ic:resolved",function(){this.send("confluence.comment.inline.resolved")});this.listenTo(d,"ic:unresolved",function(){this.send("confluence.comment.inline.unresolved")});this.listenTo(d,"ic:resolved:view",function(f){var e={total:f};this.send("confluence.comment.inline.resolved.view",e)});this.listenTo(d,"ic:resolved:dismiss:recovery",function(){this.send("confluence.comment.inline.resolved.dismiss")});this.listenTo(d,"ic:resolved:show:recovery",function(){this.send("confluence.comment.inline.resolved.discovery")});this.listenTo(d,"ic:open:dangled",function(f){var e={commentId:f.get("id"),pageId:b.Meta.get("page-id")};this.send("confluence.comment.inline.open.dangled",e)});this.listenTo(d,"ic:editor:load:fail",function(){var e={pageId:b.Meta.get("page-id")};this.send("confluence.comment.inline.editor.load.fail",e)});this.listenTo(d,"ic:resolve:dangled:failed",function(f){var e={commentId:f.get("id"),pageId:b.Meta.get("page-id")};this.send("confluence.comment.inline.resolved.dangled.failed",e)})};a.stop=function(){this.running=false;this.stopListening()};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:app', location = '/app/app.js' */
define("confluence/ic/app/app",["jquery","backbone","ajs","confluence/ic/model/comment","confluence/ic/model/comment-collection","confluence/ic/analytics","exports"],function(e,h,c,f,d,b,a){function g(){b.start();var n=true;var i=new d();function l(){q().done(function(s){s.afterSyncCommentCollection();s.displayPermalinkedComment(i)})}e("body").on("click","#view-resolved-comments",function(s){s.preventDefault();q().done(function(t){t.createResolvedCommentListView()})});i.fetch({cache:false}).done(function(){if(i.getCommentsOnPageCount()>0){l()}if(i.getResolvedCount()>0){q().done(function(s){s.updateResolvedCommentCountInToolsMenu()})}else{e("#view-resolved-comments").hide()}});var k=window.location.search;if(k.indexOf("focusedCommentId")!==-1){l()}h.listenTo(h,"ic:resolved",function(){l()});var o=e("#view-resolved-comments>span");o.text("Resolved comments"+c.format(" ({0})",i.getResolvedCount()));var p=function(u,t){var v=i.get(t);var s=false;if(v===undefined){v=new f({id:t});s=true}v.fetch({success:function(w){w._setHighlights(w.get("markerRef"));if(s){i.add(w)}else{v.replies.isFetched=false}h.trigger("ic:view",v,"quickreload")}})};c.bind("qr:show-new-thread",function(t,s){q().done(function(){p(t,s)})});c.bind("qr:add-new-highlight",function(u,t,s){q().done(function(){c.trigger("qr:add-new-highlight-text",[t,s])})});var j;var r;function q(){if(n){n=false;if(j){return j.promise()}j=e.Deferred();WRM.require("wrc!inline-comments-load-sidebar").then(function(){var s=require("confluence/ic/app/loader");s.init(i);j.resolve(s)})}r=false;return j.promise()}var m="com.atlassian.confluence.plugins.confluence-inline-comments:create-inline-comment";if(Confluence&&Confluence.HighlightAction){Confluence.HighlightAction.registerButtonHandler(m,{onClick:function(s){q().done(function(t){if(r==false){r=true;t.loadSidebarOnClick(s)}})},shouldDisplay:Confluence.HighlightAction.WORKING_AREA.MAINCONTENT_ONLY})}}a.init=g});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-inline-comments:bootstrap', location = '/app/bootstrap.js' */
require(["jquery","ajs","confluence/ic/app/app"],function(c,a,b){if(a.Meta.get("page-id")&&(a.Meta.get("page-id")===a.Meta.get("latest-page-id"))){c(b.init)}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.editor-loader:background-loading-editor', location = 'jscripts/editor-loader.js' */
define("confluence-editor-loader/editor-loader","jquery confluence/legacy confluence/meta ajs wrm window".split(" "),function(e,j,h,d,l,m){var b,c={_listening:false,_queuedHandlers:[],_watchHandler:function(){j.Editor.UI.toggleWatchPage(false)},_unwatchHandler:function(){j.Editor.UI.toggleWatchPage(true)},_createQueueAdder:function(a){return function(){c._listening&&c._queuedHandlers.push(a)}},bind:function(){d.bind("watchpage.pageoperation",this._createQueueAdder(this._watchHandler));d.bind("unwatchpage.pageoperation",
this._createQueueAdder(this._unwatchHandler))},setListening:function(a){this._listening=a},applyHandlers:function(){for(var a=this._queuedHandlers.pop();a;){a();a=this._queuedHandlers.pop()}}};c.setListening(true);c.bind();var k=function(){var a=e("#editor-preload-container");a.length||(a=e('<div id="editor-preload-container" style="display: none;"></div>'));return a},f;return{getPreloadContainer:k,getEditorPreloadMarkup:function(){if(f)return f;var a=d.contextPath()+"/plugins/editor-loader/editor.action";
return f=e.get(a,{parentPageId:h.get("parent-page-id"),pageId:h.get("page-id"),spaceKey:h.get("space-key"),atl_after_login_redirect:m.location.pathname,timeout:d.Confluence.EditorLoader.loadingTimeout})},resourcesLoaded:function(){return b&&b.isResolved()},loadingTimeout:12E3,isEditorActive:function(){var a=e("#editor-preload-container");return a.length&&a.is(":visible")},load:function(a,c){var g;if(b){b.fail(function(){c?c.call(this,arguments):d.log("EditorLoader: loadGuard - previous load failed.")});
b.done(function(){a?b.done(function(){setTimeout(a,0)}):d.log("EditorLoader: loadGuard - editor is already loaded.")});g=true}else g=void 0;if(!g){b=new e.Deferred;a&&b.done(a);c&&b.fail(c);var f=k();e("body").append(f);var i=new e.Deferred;h.get("page-id")?this.getEditorPreloadMarkup().done(function(a,b,c){if(b==="success"||b==="notmodified"){f.append(a);a=d.renderTemplate("dynamic-editor-metadata");e("head").append(a);d.populateParameters();d.debug("EditorLoader: Finished loading the editor template.");
i.resolve()}else i.reject("Error loading the Editor template: "+c.status+" - "+c.statusText)}):i.resolve();g=l.require(["wrc!editor","wrc!macro-browser","wrc!fullpage-editor"]).fail(function(a){d.logError("Failed to load editor resources",a)});e.when(i,g).done(function(){d.debug("EditorLoader: Finished loading the editor.");b.resolve()}).fail(function(){b.reject(arguments)})}},getEditorForm:function(){if(this.isEditorActive()){var a=require("tinymce");return e(a.activeEditor.getContainer()).closest("form")}return null}}});
require("confluence/module-exporter").exportModuleAsGlobal("confluence-editor-loader/editor-loader","AJS.Confluence.EditorLoader");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.editor-loader:background-loading-editor', location = 'jscripts/block-and-buffer-keys.js' */
define("confluence-editor-loader/block-and-buffer-keys",[],function(){return{block:function(e){var d=[],f=function(a){a.preventDefault();a.stopPropagation();var c=a.which;c||(c=a.charCode?a.charCode:a.keyCode);13!==c&&48>c||d.push(c);a.preventDefault()};e.keypress(f);return function(){e.unbind("keypress",f);for(var a="",c=0;c<d.length;c++){var b;b=d[c];65535<b?(b-=65536,b=String.fromCharCode(55296+(b>>10),56320+(b&1023))):b=String.fromCharCode(b);a+=b}return a}}}});
require("confluence/module-exporter").exportModuleAsGlobal("confluence-editor-loader/block-and-buffer-keys","AJS.Confluence.BlockAndBuffer");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.editor:editor-core-resources', location = 'loader/profiles.js' */
define("confluence-editor/profiles",["jquery","ajs"],function(d,c){return{createProfileForCommentEditor:function(){return{plugins:"searchreplace confluenceimagedialog autocompletemacro confluencemacrobrowser confluenceleavecomment confluencewatch autoresize".split(" ")}},createProfileForPageEditor:function(a){var b="searchreplace confluencedrafts confluenceimagedialog autocompletemacro confluencemacrobrowser flextofullsize referrer".split(" ");c.Meta.getBoolean("shared-drafts")&&c.DarkFeatures.isEnabled("unpublished-changes-lozenge")&&
b.push("unpublishedchanges");a&&a.versionComment&&b.push("confluenceversioncomment");a&&a.notifyWatchers&&b.push("confluencenotifywatchers");return{plugins:b}},createProfileForTemplateEditor:function(){return{plugins:"searchreplace confluenceimagedialog autocompletemacro confluencemacrobrowser confluenceleavetemplate flextofullsize confluencetemplateeditor".split(" ")}}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-editor/profiles","AJS.Confluence.Editor._Profiles");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-util', location = 'jscripts/util.js' */
define("confluence-quick-edit/util",["window","ajs"],function(c,d){return{generateUUID:function(){var a=function(){return Math.floor(65536*(1+Math.random())).toString(16).substring(1)};return a()+a()+"-"+a()+"-"+a()+"-"+a()+"-"+a()+a()+a()},getBaseUrl:function(){var a=c.location.protocol.replace(/:$/,"")+"://"+c.location.host+"/"+c.location.pathname.replace(/^\//,""),b=c.location.search.replace(/^\?/,""),b=b.replace(/\&?focusedCommentId=\d+/,""),b=b.replace(/^\&/,"");return{url:a,search:b,addQueryParam:function(a,
b){this.search=this.search?this.search+"&"+a+"="+b:a+"="+b},toString:function(){return this.url+"?"+this.search}}},timeoutDeferred:function(a,b,c){"function"!==typeof b.reject&&d.log("WARNING: invalid, not rejectable object passed to AJS.Confluence.QuickEdit.Util.timeoutDeferred. You should use a Deferred object");setTimeout(function(){"pending"===b.state()&&(d.logError("Timeout: "+a),b.reject("timeout"))},c);return b}}});
require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/util","AJS.Confluence.QuickEdit.Util");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/quick-edit.js' */
define("confluence-quick-edit/quick-edit","ajs confluence/legacy jquery window document confluence-quick-edit/util wrm".split(" "),function(b,e,c,n,o,p,q){function r(){var a=new c.Deferred;b.Confluence.EditorLoader.load(function(){setTimeout(function(){a.resolve()},0)},function(){a.reject()});return a}var i={enableShortcut:function(){c("#editPageLink").addClass("full-load")},disableShortcut:function(){c("#editPageLink").removeClass("full-load")}},h=[],l={loadingContentTimeout:4E3,register:function(a){h.push(a)},
disableHandlers:function(){c.each(h,function(a,b){return b.disable()})},enableHandlers:function(){c.each(h,function(a,b){return b.enable()})},SaveBarBinder:{bind:function(a,b){a&&e.Editor.addSaveHandler(a);b&&e.Editor.addCancelHandler(b)}},activateEditor:function(a){function e(){function f(a){var b=new c.Deferred;q.require(a).done(function(a){b.resolve(a)}).fail(function(a){b.reject(a)});return b}var h,j=new c.Deferred;if(b.Rte&&b.Rte.getEditor()){b.debug("there is already an editor open");return j.reject("there is already an editor open")}if(!a.$container||
!a.$form){b.logError("activateEditor could not be initialsed: bad arguments",a);return j.reject("bad parameters")}h=b.Confluence.BlockAndBuffer.block(c(o));a.preActivate&&a.preActivate();i.disableShortcut();var m=a.timeoutResources||b.Confluence.EditorLoader.loadingTimeout,g=l.loadingContentTimeout,k=p.timeoutDeferred;c.when(k("resources",r(),m),k("fetch content",a.fetchContent||c.Deferred().resolve(),g),k("additional resources",a.additionalResources?f(a.additionalResources):c.Deferred().resolve(),
m)).done(function(e,f){var d={$container:a.$container,content:f,$form:a.$form,replayBufferedKeys:h};a.preInitialise&&a.preInitialise(d);c(".quick-comment-prompt",d.$container).hide();c(".quick-comment-body",d.$container).addClass("comment-body");var g=b.Confluence.EditorLoader.getPreloadContainer();if(d.content&&d.content.title){var k=d.content.title;g.find("#content-title").val(k)}d.$form.append(g.children());g.show();c("#editor-precursor").hide();c("#rte-savebar").find(".toolbar-split-left").hide();
var i=function(){d.editor=b.Rte.getEditor();d.$container.find(".quick-comment-loading-container").hide();d.$form.show();d.$form.addClass("fadeIn");var e=d.editor,f=d.content?d.content.editorContent:"",g=d.replayBufferedKeys;if(f){e.setContent(f);e.startContent=e.getContent({format:"raw",no_events:1});e.undoManager.clear()}g();e.undoManager.add();b.trigger("quickedit.success");b.trigger("quickedit.visible");b.trigger("add-bindings.keyboardshortcuts");b.trigger("active.dynamic.rte");c("div.aui-message.closeable").each(function(){var a=
c(this),d;if(!a.find(".icon-close").length){d=c('<span class="aui-icon icon-close" role="button" tabindex="0"></span>').click(function(){a.closeMessage()}).keypress(function(c){if(c.which===b.keyCode.ENTER||c.which===b.keyCode.SPACE){a.closeMessage();c.preventDefault()}});a.append(d)}});a.postInitialise&&a.postInitialise(d);l.SaveBarBinder.bind(a.saveHandler,a.cancelHandler);b.trigger("rte-quick-edit-ready");b.unbind("rte-ready",i);j.resolve()};b.bind("rte-ready",i);b.bind("rte-destroyed",a.postDeactivate||
function(){});b.Rte.BootstrapManager.initialise({plugins:a.plugins,toolbar:a.toolbar,excludePlugins:a.excludePlugins,isQuickEdit:true,onInitialise:a.onInitialise})}).fail(function(c){j.reject(c);b.logError("Error loading page quick edit. Falling back to normal edit URL...");b.trigger("analytics",{name:"rte.quick-edit.activate-editor.failed"});if(a.fallbackUrl){b.log("This parameter is deprecated. To be removed in the next major version (5.8 or 6.0). Please use the promise returned to bind custom action if the editor fails to load instead.");
n.location=a.fallbackUrl}});return j.promise()}if(a.closeAnyExistingEditor&&b.Rte&&b.Rte.getEditor()){var f=new c.Deferred;this.deactivateEditor().done(function(){e().done(function(){f.resolve()}).fail(function(a){f.reject(a)})}).fail(function(){b.debug("Could not deactivate current editor.");f.reject("Could not deactivate current editor.")});return f}return e()},deactivateEditor:function(){require("tinymce").execCommand("mceRemoveControl",true,"wysiwygTextarea");e.Editor.UI.toggleSavebarBusy(false);
var a=b.Confluence.EditorLoader.getPreloadContainer().empty();c(".editor-container").remove();c("#editor-precursor").remove();c("#anonymous-warning").remove();c(".quick-comment-prompt").show();c(".bottom-comment-panels").show();c("#editor-notification-container").empty();c(".action-reply-comment").removeAttr("reply-disabled");i.enableShortcut();e.Editor.removeAllSaveHandlers();e.Editor.removeAllCancelHandlers();return b.Confluence.EditorLoader.getEditorPreloadMarkup().done(function(c){a.append(c);
a.hide();(new b.Confluence.QuickEditCaptchaManager(a)).refreshCaptcha();b.trigger("rte-destroyed");b.unbind("rte-destroyed")})}};return l});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/quick-edit","AJS.Confluence.QuickEdit");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/handlers/view.js' */
define("confluence-quick-edit/handlers/view",["jquery","ajs","window"],function(c,d,e){return function(){var a;sessionStorage.viewPort&&(a=JSON.parse(sessionStorage.viewPort));if(a&&a.pageId==d.params.pageId){var b;b=c("#main-content");var f=c("#header");b=-1!==a.blockIndex?b.children().first().children().eq(a.blockIndex).find(".innerCell").eq(a.columnIndex).children().eq(a.index):b.children().eq(a.index);e.scrollTo(0,b.offset().top+a.offset-f.outerHeight())}delete sessionStorage.viewPort}});
require("confluence/module-exporter").safeRequire("confluence-quick-edit/handlers/view",function(c){require("ajs").toInit(c)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/captcha-manager.js' */
define("confluence-quick-edit/captcha-manager",["jquery","ajs"],function(d,e){return function(f){function a(a){return d(f||"body").find(a)}return{refreshCaptcha:function(){var b=a("img.captcha-image");if(0<b.length){var c=Math.random();b.attr("src",e.contextPath()+"/jcaptcha?id="+c);a('input[name="captchaId"]').val(c);a('input[name="captchaResponse"]').val("")}},getCaptchaData:function(){return{id:a('input[name="captchaId"]').val(),response:a('input[name="captchaResponse"]').val()}}}}});
require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/captcha-manager","AJS.Confluence.QuickEditCaptchaManager");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/handlers/shortcut.js' */
define("confluence-quick-edit/handlers/shortcut",["ajs"],function(a){var d=!1;a.bind("initialize.keyboardshortcuts add-bindings.keyboardshortcuts",function(){d=!0});a.bind("remove-bindings.keyboardshortcuts",function(){d=!1});return{createShortcut:function(f,g){function b(){c=c||a.whenIType(f).moveToAndClick(g)}function e(){c&&c.unbind();c=null}var c;return{bind:function(){d&&b();a.bind("initialize.keyboardshortcuts",b);a.bind("add-bindings.keyboardshortcuts",b);a.bind("remove-bindings.keyboardshortcuts",
e)},unbind:function(){e();a.unbind("initialize.keyboardshortcuts",b);a.unbind("add-bindings.keyboardshortcuts",b);a.unbind("remove-bindings.keyboardshortcuts",e)}}}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/handlers/shortcut","AJS.Confluence.QuickEdit.KeyboardShortcuts");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/handlers/page.js' */
define("confluence-quick-edit/handlers/page",["jquery","ajs","confluence/legacy","confluence-quick-edit/handlers/shortcut","window"],function(c,b,i,n,j){function m(a,b,f){var d={pageId:f,blockIndex:-1,columnIndex:-1,index:-1,offset:0,hasBlock:function(){return-1!==this.blockIndex}},k=!1,e=function(a,c){var f=a.offset();g(a)&&(d.index=c,d.offset=b-f.top,k=!0)},g=function(a){var c=a.offset();return c.top-8<=b&&c.top+a.height()>=b};1===a.children().length&&a.children().first().hasClass("contentLayout2")?
(a.children().first().children().each(function(a){!d.hasBlock()&&g(c(this))&&(d.blockIndex=a)}),d.hasBlock()&&(a=a.children().first().children().eq(d.blockIndex).find(".innerCell"),a.each(function(a){if(-1===d.columnIndex){var b=c(this).children().length;0<b&&(2>b?25<c(this).children().first().height()&&(d.columnIndex=a):d.columnIndex=a)}}),a.eq(d.columnIndex).children().each(function(a){k||e(c(this),a)}))):a.children().each(function(a){k||e(c(this),a)});return k?d:null}function o(a){var h=require("tinymce");
e.disable();b.populateParameters();if(b.DarkFeatures.isEnabled("confluence.view.edit.transition")){var f=c("#main-content"),d=c("#header"),k=c("#main-header"),d=j.pageYOffset+d.outerHeight()+k.outerHeight();g=m(f,d,b.params.pageId);b.trigger("quick-edit.viewport.saved");var l=function(){c(h.activeEditor.getWin().document).find("body#tinymce").addClass("page-edit");c("#content").css({paddingRight:0});b.unbind("quickedit.visible",l)};b.bind("quickedit.visible",l)}f=a.$form;d="page"===b.Meta.get("content-type")?
"doeditpage":"doeditblogpost";d=b.contextPath()+"/pages/"+d+".action?pageId="+i.getContentId();c(".ia-splitter-left").remove();try{c("#main").unwrap()}catch(s){}c("#rte").removeClass("editor-default").addClass("editor-fullheight");a.$container.children().remove();c(".editor-container").children().eq(0).unwrap();f.attr({"class":"editor aui",action:d,name:"editpageform",id:"editpageform",style:""});a.$container.append(f);a.$container.removeClass("view").addClass("edit");c("body").addClass("contenteditor edit")}
function p(a){require("tinymce");c("#editor-precursor").show();c("#rte-savebar").find(".toolbar-split-left").show();if(j.history.pushState){var h=c("#editPageLink").attr("href");h!=j.location.pathname+j.location.search&&(history.pushState({quickEdit:!0},"",h),b.trigger("rte-quick-edit-push-state",h))}else j.location.hash="editor",b.trigger("rte-quick-edit-push-hash");h=a.content;if(h.permissions)for(var f in h.permissions)c("#"+f).attr("value",h.permissions[f]);c("#originalVersion").val(a.content.pageVersion);
f=a.content.atlToken;b.Meta.set("atl-token",f);c('input[name="atl_token"]').val(f);b.trigger("analyticsEvent",{name:"quick-edit-success"});c("#navigation").remove();var d=new Date,e=function(c,b){if(d&&!("keydown"===b.type&&-1<[91,92,93,224,33,34,37,38,39,40,16,17,18,20,112,113,114,115,116,117,118,119,120,121,122,123].indexOf(b.keyCode))){var f=new Date-d;d=null;i.Analytics.publish("confluence.editor.transition.firstkeydown",{delay:f});a.editor.onKeyDown.remove(e);a.editor.onChange.remove(e)}};a.editor.onKeyDown.add(e);
a.editor.onChange.add(e)}function q(a){setTimeout(function(){if(g){var b;b=c(a.getBody());b=g.hasBlock()?b.children().first().children().eq(g.blockIndex).find(".innerCell").eq(g.columnIndex).children().eq(g.index):b.children().eq(g.index);a.getWin().scrollTo(0,b.offset().top+g.offset);c("#main").css("visibility","visible")}})}function r(){var a=new c.Deferred,e=c.ajax({url:b.contextPath()+"/rest/tinymce/1/content/"+i.getContentId()+".json",cache:!1});e.success(function(b){a.resolve(b)});e.error(function(){a.reject("error fetching content")});
return a}var l,g,e={editShortcut:n.createShortcut("e","#editPageLink"),activateEventHandler:function(a){if(!a.metaKey&&!a.shiftKey&&!a.ctrlKey&&!a.altKey&&!(2===a.which||3===a.which))a.preventDefault(),l&&"pending"===l.state()?b.debug("Editor is being activated. Ignoring handler..."):(l=e.activateEditor(),a=c("#editPageLink"),a.find(".aui-icon").css("visibility","hidden"),a.parent().spin({left:"10px"}))},enable:function(){if(c("body").is(".theme-default")){var a=c("#editPageLink");a.bind("click",
e.activateEventHandler);a.removeClass("full-load");e.editShortcut.bind();b.debug("QuickPageEdit enabled")}else b.debug("QuickPageEdit not enabled")},activateEditor:function(){var a=c("#content").find(".quick-comment-form"),e=function(){var a=require("tinymce").activeEditor.getWin(),d=c(a.document).find("#tinymce");if(a=m(d,a.pageYOffset,b.params.pageId))sessionStorage.viewPort=JSON.stringify(a)};return b.Confluence.QuickEdit.activateEditor({fetchContent:r(),$container:c("#content"),$form:a.length?
a:c('<form method="post"></form>'),preInitialise:o,postInitialise:p,saveHandler:function(){b.DarkFeatures.isEnabled("confluence.view.edit.transition")&&e();1<i.Editor.getNumConcurrentEditors()&&b.Confluence.Analytics.publish("rte.notification.concurrent-editing.save",{numEditors:i.Editor.getNumConcurrentEditors(),pageId:b.params.pageId,draftType:b.params.draftType})},cancelHandler:function(){b.DarkFeatures.isEnabled("confluence.view.edit.transition")&&e();1<i.Editor.getNumConcurrentEditors()&&b.Confluence.Analytics.publish("rte.notification.concurrent-editing.cancel",
{numEditors:i.Editor.getNumConcurrentEditors(),pageId:b.params.pageId,draftType:b.params.draftType})},plugins:b.Confluence.Editor._Profiles.createProfileForPageEditor({versionComment:!0,notifyWatchers:!0}).plugins,onInitialise:function(a){b.DarkFeatures.isEnabled("confluence.view.edit.transition")&&a.onLoad.add(q)}}).fail(function(){j.location=c("#editPageLink").attr("href")})},disable:function(){b.debug("QuickPageEdit disabled.");e.editShortcut.unbind();c("#editPageLink").unbind("click",e.activateEventHandler)}};
b.Confluence.QuickEdit.register(e);return{disable:e.disable}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/handlers/page","AJS.Confluence.QuickEdit.QuickEditPage");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-edit-general', location = 'jscripts/init.js' */
define("confluence-quick-edit/init",["ajs","jquery","window"],function(a,b,c){return function(){b("body").hasClass("page-gadget")?a.debug("QuickComment: editor preload is disabled"):b(c).load(function(){a.debug("QuickComment: instigated background loading of the comment editor.");a.Confluence.EditorLoader.load()});a.Confluence.QuickEdit.enableHandlers();a.trigger("rte-quick-edit-enable-handlers")}});
require("confluence/module-exporter").safeRequire("confluence-quick-edit/init",function(a){var b=require("ajs");b.DarkFeatures.isEnabled("disable-quick-edit")?b.log("disable-quick-edit is turned on; run AJS.Confluence.EditorLoader.load() manually."):b.toInit(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment.js' */
define("confluence-quick-edit/handlers/comment",["ajs","confluence/legacy","jquery","aui/flag","confluence-quick-edit/util"],function(a,f,d,m,j){function l(a,c){var g=a.match(RegExp("[?&]"+c+"=(\\d+)"));return g&&1<g.length?parseInt(g[1]):0}d(function(){a.AppLinksInitialisationBinder=function(b){a.bind("init.rte",b)}});var e={timeout:8E3,showLoadingEditorErrorMessage:function(){a.trigger("rte-quick-comment-loading-failed");m({type:"error",title:"Error",
persistent:!1,body:"Error loading the comment editor. Please refresh the page to try again."})},preInitialise:function(){a.Confluence.QuickEdit.QuickEditPage.disable();a.Meta.set("content-type","comment");a.Meta.set("draft-type","");a.params.contentType="comment";a.params.draftType="";a.Meta.set("use-inline-tasks","false");d("#editor-precursor").children().eq(0).hide();d("#pagelayout-menu").parent().hide();d("#page-layout-2-group").hide();d("#rte-button-tasklist").remove();d("#rte-insert-tasklist").parent().remove()},
postInitialise:function(b){a.Rte.editorFocus(b.editor)},delegatingSaveCommentHandler:function(a){return a.asyncRenderSafe?e.ajaxSaveCommentHandler(a):e.reloadPageSaveCommentHandler(a)},reloadPageSaveCommentHandler:function(a){var c=j.getBaseUrl();c.addQueryParam("focusedCommentId",a.id);c.addQueryParam("refresh",+new Date);window.location.href=c.toString()+"#comment-"+a.id},ajaxSaveCommentHandler:function(b){var c={isDefault:!0,path:a.Meta.get("static-resource-url-prefix")+"/images/icons/profilepics/default.png"};
"/images/icons/profilepics/default.png"!==a.Meta.get("current-user-avatar-url")&&(c={isDefault:!1,path:a.contextPath()+a.Meta.get("current-user-avatar-url")});var g=a.Meta.get("remote-user"),d={userName:""==g?null:g,displayName:a.Meta.get("current-user-fullname"),profilePicture:c};e.cancelComment().done(function(){f.CommentDisplayManager.addOrUpdateComment(d,b,!0,!1);a.trigger("page.commentAddedOrUpdated",{commentId:b.id})})},cancelHandler:function(){a.Confluence.QuickEdit&&(a.Rte.Content.editorResetContentChanged(),
a.Confluence.QuickEdit.deactivateEditor())},createCommenterParam:function(b,c,d){return{userName:c||a.Meta.get("remote-user")||null,displayName:d||a.Meta.get("user-display-name"),profilePicture:{isDefault:b.hasClass("defaultLogo"),path:b.attr("src")}}},createSaveHandler:function(b,c){var g=j.generateUUID();return function(e){e.preventDefault();if(a.Rte.Content.isEmpty())a.Confluence.EditorNotification.notify("warning","Comment text is empty. Cannot create empty comments."),f.Editor.UI.toggleSavebarBusy(!1);else{var h=e=
0,i=a.Confluence.EditorLoader.getEditorForm();i.is("form")&&(h=i.attr("action"),e=l(h,"parentId"),h=l(h,"commentId"));var k=new a.Confluence.QuickEditCaptchaManager(i),i=function(a){c(a);k.refreshCaptcha()},j=d("#watchPage").is(":checked");0<h?f.Editor.CommentManager.updateComment(f.getContentId(),h,a.Rte.Content.getHtml(),j,k.getCaptchaData(),b,i):f.Editor.CommentManager.saveComment(f.getContentId(),e,a.Rte.Content.getHtml(),j,g,k.getCaptchaData(),b,i)}}},saveCommentErrorHandler:function(b){f.Editor.UI.toggleSavebarBusy(!1);
var c;c=b&&-1!=b.search(/captcha/i)?"The typed word did not match the text in the picture.":"Failed to save the comment. Please try again later.";a.logError("Error saving comment",b);a.Confluence.EditorNotification.notify("error",c)},cancelComment:function(){a.Rte.Content.editorResetContentChanged();return a.Confluence.QuickEdit.deactivateEditor()},proceedWithActivation:function(){var b=new d.Deferred,c=a.Rte&&a.Rte.getEditor();if(c)if(c.isDirty()&&!f.Editor.isEmpty())if(confirm("Your comment will be lost."))b=
e.cancelComment();else return b.reject();else b=e.cancelComment();else b.resolve();return b}};return e});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/handlers/comment","AJS.Confluence.QuickEdit.QuickComment");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment/top-level.js' */
define("confluence-quick-edit/handlers/comment/top-level",["ajs","jquery","confluence-quick-edit/handlers/shortcut","confluence-quick-edit/handlers/comment","window"],function(b,a,e,c,f){function g(a){c.preInitialise(a)}function h(b){a("#comments-section").one("click",".quick-comment-prompt",d.activateEventHandler);a("#rte-savebar").scrollWindowToElement();c.postInitialise(b)}function i(){b.Confluence.EditorLoader.resourcesLoaded()||(b.trigger("analytics",{name:"rte.quick-edit.top-comment.spinner"}),
a(".quick-comment-prompt").hide(),a(".quick-comment-loading-container").fadeIn().spin("medium"))}function j(b){b.preventDefault();f.location=a("#add-comment-rte").attr("href")}var k=b.DarkFeatures.isEnabled("editor.slow.comment.disable"),d={commentShortcut:e.createShortcut("m",".quick-comment-prompt"),activateEventHandler:function(e){e.preventDefault();c.proceedWithActivation().done(function(){var d=c.createSaveHandler(c.delegatingSaveCommentHandler,c.saveCommentErrorHandler);return b.Confluence.QuickEdit.activateEditor({preActivate:i,
$container:a("form[name=inlinecommentform]").closest(".quick-comment-container"),$form:a("form[name=inlinecommentform]"),preInitialise:g,saveHandler:d,cancelHandler:c.cancelHandler,postInitialise:h,plugins:b.Confluence.Editor._Profiles.createProfileForCommentEditor().plugins,additionalResources:["wrc!comment-editor"],timeoutResources:c.timeout}).fail(function(){k?c.showLoadingEditorErrorMessage():f.location=a("#add-comment-rte").attr("href")})}).fail(function(){a("#comments-section").one("click",
".quick-comment-prompt",d.activateEventHandler)})},enable:function(){a("#comments-section").one("click",".quick-comment-prompt",d.activateEventHandler);a("#add-comment-rte").removeClass("full-load");this.commentShortcut.bind()},disable:function(){a("#comments-section").off("click",".quick-comment-prompt");this.commentShortcut.unbind()}};b.Confluence.QuickEdit.register(d);return{bindCommentAreaFallbackHandler:function(){a("#comments-section").delegate(".quick-comment-prompt","click",j)},cancelComment:function(){b.log("'AJS.Confluence.QuickEdit.QuickComment.TopLevel.cancelComment' is deprecated in 5.7, consider using 'AJS.Confluence.QuickEdit.QuickComment.cancelComment' instead.");
return b.Confluence.QuickEdit.QuickComment.cancelComment()}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/handlers/comment/top-level","AJS.Confluence.QuickEdit.QuickComment.TopLevel");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment/reply.js' */
define("confluence-quick-edit/handlers/comment/reply",["ajs","confluence/legacy","jquery"],function(a,g,b){function i(b){a.Confluence.QuickEdit.QuickComment.preInitialise(b);b.$container.scrollWindowToElement()}function j(b){a.Confluence.QuickEdit.QuickComment.postInitialise(b)}function h(b){var e=b.attr("id").match(/comment-(\d+)/),f=0;e?f=parseInt(e[1]):(a.trigger("analytics",{name:"rte.quick-edit.get-reply-parent.failed"}),a.logError("replyHandler: activateEventHandler - could not extract a parent comment Id from the comment id "+
b.attr("id")));return f}function k(){b(".comment.reply").closest(".comment-threads").remove()}var l=a.DarkFeatures.isEnabled("editor.slow.comment.disable"),d={activateEventHandler:function(d){d.preventDefault();d.stopPropagation();var e=this;if(b(e).attr("reply-disabled"))return!1;a.Confluence.QuickEdit.QuickComment.proceedWithActivation().done(function(){var f=b(e).closest("div.comment"),c=b(".quick-comment-container img.userLogo"),c=a.Confluence.QuickEdit.QuickComment.createCommenterParam(c),c=
{contentId:g.getContentId(),parentCommentId:h(f),commenter:c,context:{contextPath:a.Meta.get("context-path"),staticResourceUrlPrefix:a.Meta.get("static-resource-url-prefix")}},c=b(g.Templates.Comments.displayReplyEditorLoadingContainer(c)),d=b(".quick-comment-loading-container",c);d.hide();f.after(c);a.Confluence.EditorLoader.resourcesLoaded()?a.trigger("analytics",{name:"rte.quick-edit.reply-comment.no-spinner"}):(a.trigger("analytics",{name:"rte.quick-edit.reply-comment.spinner"}),f.after(c),d.fadeIn(),
d.spin("medium"),d[0].scrollIntoView());c=b(e).closest(".comment-thread").find(".quick-comment-container");a.Meta.set("form-name",b("form",c).attr("name"));a.Confluence.QuickEdit.activateEditor({$container:c,$form:b("form.quick-comment-form[name=threadedcommentform]"),preInitialise:i,postInitialise:j,saveHandler:a.Confluence.QuickEdit.QuickComment.createSaveHandler(a.Confluence.QuickEdit.QuickComment.delegatingSaveCommentHandler,a.Confluence.QuickEdit.QuickComment.saveCommentErrorHandler),cancelHandler:a.Confluence.QuickEdit.QuickComment.cancelHandler,
plugins:a.Confluence.Editor._Profiles.createProfileForCommentEditor().plugins,postDeactivate:k,additionalResources:["wrc!comment-editor"],timeoutResources:a.Confluence.QuickEdit.QuickComment.timeout}).fail(function(){l?a.Confluence.QuickEdit.QuickComment.showLoadingEditorErrorMessage():window.location=b("#reply-comment-"+h(f)).attr("href")});b(e).attr("reply-disabled",!0)})},enable:function(){b("#comments-section").delegate(".action-reply-comment","click",d.activateEventHandler)},disable:function(){b("#comments-section").undelegate(".action-reply-comment",
"click")}};a.Confluence.QuickEdit.register(d);return{cancelComment:function(){a.log("'AJS.Confluence.QuickEdit.QuickComment.Reply.cancelComment' is deprecated in 5.7, consider using 'AJS.Confluence.QuickEdit.QuickComment.cancelComment' instead.");return a.Confluence.QuickEdit.QuickComment.cancelComment()}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/handlers/comment/reply","AJS.Confluence.QuickEdit.QuickComment.Reply");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/handlers/comment/edit.js' */
define("confluence-quick-edit/handlers/comment/edit",["ajs","confluence-quick-edit/handlers/comment","jquery","confluence/legacy"],function(e,b,d,i){function j(a){b.preInitialise(a);a.$container.scrollWindowToElement()}function k(a){b.postInitialise(a)}function h(a){return(a=a.attr("id").match(/comment-(\d+)/))?parseInt(a[1]):0}function l(a){var b=new d.Deferred;d.ajax({url:e.contextPath()+"/rest/api/content/"+a+"?expand=body.editor",cache:!1}).done(function(a){!a||!a.body||!a.body.editor?b.reject("invalid response from loading comment rest endpoint"):
b.resolve({editorContent:a.body.editor.value})}).fail(function(){b.reject("error fetching content")});return b}function m(){var a=d(".comment.edit");a.prev(".comment").show();a.remove()}var n=e.DarkFeatures.isEnabled("editor.slow.comment.disable"),g={activateEventHandler:function(a){var g=this;a.preventDefault();a.stopPropagation();b.proceedWithActivation().done(function(){var a=d(g).closest("div.comment"),c;c=a.find(".author .confluence-userlink");var f=a.find(".comment-user-logo img.userLogo");
c=b.createCommenterParam(f,c.attr("data-username"),c.text());c={contentId:i.getContentId(),commentId:h(a),commenter:c,context:{contextPath:e.Meta.get("context-path"),staticResourceUrlPrefix:e.Meta.get("static-resource-url-prefix")},mode:"edit"};c=d(i.Templates.Comments.displayEditEditorContainer(c));f=d(".quick-comment-loading-container",c);a.hide();a.after(c);f.fadeIn().spin("medium");f[0].scrollIntoView();c=a.next(".quick-comment-container");e.Meta.set("form-name",d("form",c).attr("name"));e.Confluence.QuickEdit.activateEditor({$container:c,
$form:d("form.quick-comment-form[name=editcommentform]"),fetchContent:l(h(a)),preInitialise:j,postInitialise:k,saveHandler:b.createSaveHandler(b.delegatingSaveCommentHandler,b.saveCommentErrorHandler),cancelHandler:b.cancelHandler,plugins:e.Confluence.Editor._Profiles.createProfileForCommentEditor().plugins,postDeactivate:m,additionalResources:["wrc!comment-editor"],timeoutResources:b.timeout}).fail(function(){n?b.showLoadingEditorErrorMessage():window.location=d("#edit-comment-"+h(a)).attr("href")})})},
enable:function(){d("#comments-section").delegate(".comment-action-edit","click",g.activateEventHandler)},disable:function(){d("#comments-section").undelegate(".comment-action-edit","click")}};e.Confluence.QuickEdit.register(g);return{cancelComment:function(){e.log("'AJS.Confluence.QuickEdit.QuickComment.Edit.cancelComment' is deprecated in 5.7, consider using 'AJS.Confluence.QuickEdit.QuickComment.cancelComment' instead.");return b.cancelComment()}}});
require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/handlers/comment/edit","AJS.Confluence.QuickEdit.QuickComment.Edit");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-initial', location = 'jscripts/editor-comment-manager.js' */
define("confluence-quick-edit/editor-comment-manager",["ajs","jquery","confluence/legacy"],function(d,e,j){return function(){function k(a,f,l,i,b,g,h){d.trigger("analytics",{name:"confluence.page.comment.create",data:{pageID:d.Meta.get("page-id")}});a={type:"POST",url:a,contentType:"application/x-www-form-urlencoded; charset=UTF-8",data:{html:f,watch:l,uuid:i},dataType:"json",cache:!1,headers:{"X-Atlassian-Token":"no-check"},success:function(a){g(a)},error:function(a,c,b){c=c+": "+b;a.responseText&&
(c=c+" - "+a.responseText);h(c)},timeout:12E4};b&&b.id&&(a.headers["X-Atlassian-Captcha-Id"]=b.id,a.headers["X-Atlassian-Captcha-Response"]=b.response);e.ajax(a)}return{addComment:function(a,f,d,i,b,g,h,e,c){j.Editor.CommentManager.saveComment(a,f,d,function(a){j.CommentDisplayManager.addComment(h,a,g);e(a)},c)},saveComment:function(a,f,e,i,b,g,h,j){var c=null,c=f?d.contextPath()+"/rest/tinymce/1/content/"+a+"/comments/"+f+"/comment?actions=true":d.contextPath()+"/rest/tinymce/1/content/"+a+"/comment?actions=true";
k(c,e,i,b,g,h,j)},updateComment:function(a,f,e,i,b,g,h){a=d.contextPath()+"/rest/tinymce/1/content/"+a+"/comments/"+f+"?actions=true";k(a,e,i,null,b,g,h)}}}});require("confluence/module-exporter").safeRequire("confluence-quick-edit/editor-comment-manager",function(d){var e=require("confluence/legacy");require("ajs").bind("init.rte",function(){e.Editor.CommentManager=d()})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:editor-view-resources', location = 'jscripts/view-content/pushed-navigation-util.js' */
define("confluence-quick-edit/view-content/pushed-navigation-util",["ajs","jquery","window"],function(d,f,a){function c(){return d.Rte&&d.Rte.getEditor()&&!!f("#editpageform").length}var b=a.location.hash,e=a.location.search;return{isInEditPage:c,filterPreviewHashChange:function(){var g=c()||a.history.pushState||!(a.location.hash&&0===a.location.hash.indexOf("#!"))&&!(b&&0===b.indexOf("#!"));b=a.location.hash;return g},filterPreviewNavigationEvent:function(){var b=c()||!/[?&]preview=([^&]*)/.test(a.location.search)&&
!/[?&]preview=([^&]*)/.test(e);e=a.location.search;return b}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-quick-edit/view-content/pushed-navigation-util","Confluence.Editor.PushedNavUtil");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:editor-view-resources', location = 'jscripts/view-content/pushed-navigation.js' */
define("confluence-quick-edit/view-content/pushed-navigation","jquery underscore window confluence/legacy ajs confluence-quick-edit/view-content/pushed-navigation-util".split(" "),function(b,n,a,g,c,d){function e(){if(h){if(f.split("#")[0]!=a.location.href.split("#")[0]){b(a).unbind("popstate",k);a.location.reload()}}else f.split("#")[0]==a.location.href.split("#")[0]&&f.split("#")[1]!=="editor"||a.location.reload()}function i(){f=a.location.href}function l(){var b=g.Editor.Drafts.unloadMessage();
if(b){g.Editor.Drafts.unBindUnloadMessage();if(confirm(b+"\n\n"+"Press OK to continue, or Cancel to stay on the current page.")){c.trigger("analytics",{name:"rte.quick-edit.confirmation.leaving"});e()}else{c.trigger("analytics",{name:"rte.quick-edit.confirmation.staying"});if(h){j=true;a.history.forward()}else a.location.hash="editor";g.Editor.Drafts.bindUnloadMessage()}}else e()}function o(){d.isInEditPage()?a.location.hash!=="#editor"&&l():e()}function k(){j?j=false:d.isInEditPage()?l():e()}function m(a,b){return function(){n.every(b,
function(a){return a()})&&a()}}var h=!!a.history.pushState,j=false,f=a.location.href,p=[d.filterPreviewHashChange],q=[d.filterPreviewNavigationEvent];c.bind("rte-quick-edit-enable-handlers",function(){a.location.hash==="#editor"&&b("#editPageLink").click()});return function(){i();if(h){b(a).bind("popstate",m(k,q));b(a).bind("rte-quick-edit-push-state",i)}else{b(a).bind("hashchange",m(o,p));b(a).bind("rte-quick-edit-push-hash",i)}}});
require("confluence/module-exporter").safeRequire("confluence-quick-edit/view-content/pushed-navigation",function(b){require("ajs").toInit(function(){setTimeout(b,0)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-amd-resources', location = '/js/amd/confluence-amd.js' */
define("confluence",function(){return Confluence});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-amd-resources', location = '/js/amd/tinymce-amd.js' */
define("tinymce",function(){return tinymce});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:common', location = '/js/view-file-macro-utils.js' */
define("vfm/view-file-macro-utils",[],function(){var a={DEFAULT_HEIGHT:"250",DEFAULT_HEIGHT_IN_COMMENT:"150",THUMBNAIL_STATUS_IN_PROGRESS:202,THUMBNAIL_STATUS_CONVERTED:200,THUMBNAIL_STATUS_ERROR:415,THUMBNAIL_STATUS_BUSY:429,THUMBNAIL_POLLING_PERIOD:1000,THUMBNAIL_POLLING_BACKOFF_RATIO:1.25,MAP_NICE_TYPE_TO_TEXT:{"pdf document":"PDF","word document":"Document","excel spreadsheet":"Spreadsheet","powerpoint presentation":"Presentation","generic file":"File"},getFileNameFromUrl:function(b){if(!b){return""}var c=b.indexOf("#");c=(c>=0)?c:b.length;b=b.substring(0,c);c=b.indexOf("?");c=(c>=0)?c:b.length;b=b.substring(0,c);c=b.lastIndexOf("/");b=b.substring(c+1,b.length);return decodeURIComponent(b)},isSupportPointerEvents:function(){var b=document.createElement("x");b.style.cssText="pointer-events:auto";return b.style.pointerEvents==="auto"},getParameterByName:function(d,c){var e=d.indexOf("#");if(e>=0){d=d.substring(0,e)}var b=new RegExp(c+"=([^&]*)","i").exec(d);return b?decodeURIComponent(b[1]):null},addParamsToUrl:function(b,h){var f="";if(b.indexOf("?")===-1){f="?"}else{f="&"}var e=Object.keys(h);for(var d=0;d<e.length;d++){var c=e[d];var g=h[c];if(d>0){f+="&"}f+=c+"="+g}return b+f},getFileTypeTextFromNiceType:function(b){b=b?b.toLowerCase():"";return this.MAP_NICE_TYPE_TO_TEXT[b]?this.MAP_NICE_TYPE_TO_TEXT[b]:b}};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:common', location = '/js/services/conversion-service.js' */
define("vfm/services/conversion-service",["ajs","jquery"],function(a,b){return{postThumbnailConversionResults:function(c){var d=a.contextPath()+"/rest/documentConversion/latest/conversion/thumbnail/results";var e=Object.keys(c);var f=_.map(e,function(g){return{id:g,v:c[g].version}});return b.ajax({type:"POST",url:d,contentType:"application/json",data:JSON.stringify(f)})},getThumbnailUrl:function(d,c){return a.contextPath()+"/rest/documentConversion/latest/conversion/thumbnail/"+d+"/"+c}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.editor:file-types-utils-resources', location = 'utils/file-types-utils.js' */
define("confluence-editor/utils/file-types-utils",[],function(){var e={"aui-iconfont-file-image":"image/gif image/jpeg image/pjpeg image/png image/tiff image/bmp".split(" "),"aui-iconfont-file-pdf":["application/pdf"],"aui-iconfont-file-video":"audio/mpeg audio/x-wav audio/mp3 audio/mp4 video/mpeg video/quicktime video/mp4 video/x-m4v video/x-flv video/x-ms-wmv video/avi video/webm video/vnd.rn-realvideo".split(" "),"aui-iconfont-file-code":"text/html text/xml text/javascript application/javascript application/x-javascript text/css text/x-java-source".split(" "),
"aui-iconfont-file-doc":["application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"],"aui-iconfont-file-xls":["application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],"aui-iconfont-file-ppt":["application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation"],"aui-iconfont-file-txt":["text/plain"],"aui-iconfont-file-zip":["application/zip","application/java-archive"]},b={},c;for(c in e)for(var f=
e[c],d=0,g=f.length;d<g;d++)b[f[d]]=c;return{getAUIIconFromMime:function(a){return b[a]||"aui-iconfont-file-generic"},isImage:function(a){return b[a]&&0===a.indexOf("image/")}}});require("confluence/module-exporter").exportModuleAsGlobal("confluence-editor/utils/file-types-utils","AJS.Confluence.FileTypesUtils");
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-embedded-file-view-soy-resources', location = '/templates/embedded-file-view.soy' */
// This file was automatically generated from embedded-file-view.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.ViewFileMacro.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.ViewFileMacro == 'undefined') { Confluence.ViewFileMacro = {}; }
if (typeof Confluence.ViewFileMacro.Templates == 'undefined') { Confluence.ViewFileMacro.Templates = {}; }


Confluence.ViewFileMacro.Templates.embeddedFile = function(opt_data, opt_ignored) {
  return '<span class="confluence-embedded-file-wrapper"><a class="confluence-embedded-file" href="' + soy.$$escapeHtml(opt_data.fileSrc) + '" data-nice-type="' + soy.$$escapeHtml(opt_data.niceType) + '" data-file-src="' + soy.$$escapeHtml(opt_data.fileSrc) + '" data-linked-resource-id="' + soy.$$escapeHtml(opt_data.attachmentId) + '" data-linked-resource-type="attachment" data-linked-resource-container-id="' + soy.$$escapeHtml(opt_data.containerId) + '" data-linked-resource-default-alias="' + soy.$$escapeHtml(opt_data.fileName) + '" data-mime-type="' + soy.$$escapeHtml(opt_data.mimeType) + '" data-has-thumbnail="' + ((opt_data.hasThumbnail) ? 'true' : 'false') + '" data-linked-resource-version="' + soy.$$escapeHtml(opt_data.attachmentVersion) + '"' + ((opt_data.unresolvedCommentCount && opt_data.unresolvedCommentCount >= 0) ? 'data-unresolved-comment-count=' + soy.$$escapeHtml(opt_data.unresolvedCommentCount) : '') + '><img src="' + soy.$$escapeHtml(opt_data.placeholderSrc) + '" height="' + soy.$$escapeHtml(opt_data.height) + '" />' + ((! opt_data.hasThumbnail) ? '<span class="title">' + soy.$$escapeHtml(opt_data.fileName) + '</span>' : '') + '</a></span>';
};
if (goog.DEBUG) {
  Confluence.ViewFileMacro.Templates.embeddedFile.soyTemplateName = 'Confluence.ViewFileMacro.Templates.embeddedFile';
}


Confluence.ViewFileMacro.Templates.embeddedUnknownFile = function(opt_data, opt_ignored) {
  return '<span class="confluence-embedded-file-wrapper"><img class="confluence-embedded-file unknown-attachment" src="' + soy.$$escapeHtml(opt_data.placeholderSrc) + '" /></span>';
};
if (goog.DEBUG) {
  Confluence.ViewFileMacro.Templates.embeddedUnknownFile.soyTemplateName = 'Confluence.ViewFileMacro.Templates.embeddedUnknownFile';
}


Confluence.ViewFileMacro.Templates.overlayEmbeddedFile = function(opt_data, opt_ignored) {
  return '<span class="overlay"></span>';
};
if (goog.DEBUG) {
  Confluence.ViewFileMacro.Templates.overlayEmbeddedFile.soyTemplateName = 'Confluence.ViewFileMacro.Templates.overlayEmbeddedFile';
}


Confluence.ViewFileMacro.Templates.overlayEmbeddedFileCommentCount = function(opt_data, opt_ignored) {
  return '<span class="comment-count-overlay"><span class="content">' + soy.$$escapeHtml(opt_data.commentCountRep) + '</span></span>';
};
if (goog.DEBUG) {
  Confluence.ViewFileMacro.Templates.overlayEmbeddedFileCommentCount.soyTemplateName = 'Confluence.ViewFileMacro.Templates.overlayEmbeddedFileCommentCount';
}


Confluence.ViewFileMacro.Templates.overlayEmbeddedFileFileTypeDesc = function(opt_data, opt_ignored) {
  return '<span class="file-type-desc-overlay"><i class="aui-icon aui-icon-small ' + soy.$$escapeHtml(opt_data.iconClass) + '"></i><span class="content"> ' + soy.$$escapeHtml(opt_data.fileType) + '</span></span>';
};
if (goog.DEBUG) {
  Confluence.ViewFileMacro.Templates.overlayEmbeddedFileFileTypeDesc.soyTemplateName = 'Confluence.ViewFileMacro.Templates.overlayEmbeddedFileFileTypeDesc';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-embedded-file-view-resources', location = '/js/services/file-service.js' */
define("vfm/services/file-service",["ajs","jquery"],function(a,b){return{getCommentCount:function(c,e){var d="/rest/files/1.0/files/content/{0}/commentCount?attachmentId={1}";d=a.contextPath()+a.format(d,c,e);return b.get(d)}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-embedded-file-view-resources', location = '/js/components/embedded-file-view.js' */
define("vfm/components/embedded-file-view",["jquery","backbone","ajs","confluence","vfm/view-file-macro-utils"],function(c,g,f,h,i){function b(s){var r=c(s.el);var q=r.find(".confluence-embedded-image, .confluence-embedded-file");if(q.hasClass("unknown-attachment")||(q.attr("src")&&q.attr("src").indexOf("/confluence/plugins/servlet/confluence/placeholder/unknown-attachment")>=0)){return this}var j={mimeType:"",niceType:""};var k=q.hasClass("confluence-embedded-image");var o=r.parent().is("a");var m=q.attr("data-has-thumbnail")==="true";if(k){j.mimeType="image/png"}else{j.mimeType=q.attr("data-mime-type");j.niceType=q.attr("data-nice-type")!=="null"?q.attr("data-nice-type"):"generic file"}var p=!o?e(q):"";var l=(!k&&m)?a(j):"";if(p||l){var n=h.ViewFileMacro.Templates.overlayEmbeddedFile();r.append(c(n).append(p).append(l));if(l){r.addClass("has-comment-overlay")}}}var d=function(j){j=parseInt(j,10);j=c.isNumeric(j)?j:0;return j>9?"9+":j+""};var e=function(o){var j="",k=o.attr("data-linked-resource-container-id"),m=o.attr("data-linked-resource-id");if(k&&m){var n=o.attr("data-unresolved-comment-count");var l=d(n);if(l!=="0"){j=h.ViewFileMacro.Templates.overlayEmbeddedFileCommentCount({commentCountRep:l})}}return j};var a=function(j){return h.ViewFileMacro.Templates.overlayEmbeddedFileFileTypeDesc({fileType:i.getFileTypeTextFromNiceType(j.niceType),iconClass:f.Confluence.FileTypesUtils.getAUIIconFromMime(j.mimeType)})};return{render:b}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-view-file-macro:view-file-macro-resources', location = '/js/vfm.js' */
require(["jquery","ajs","vfm/components/embedded-file-view"],function(c,a,b){c(document).on("click",".confluence-embedded-file.unknown-attachment",function(d){d.preventDefault()});a.toInit(function(){c(".confluence-embedded-file-wrapper").each(function(){b.render({el:this})})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-alignment', location = 'js/aui/internal/alignment.js' */
(function(A){AJS.Alignment=A(window.Tether);if(typeof window.define==="function"){define("aui/internal/alignment",["aui/internal/tether"],function(){return AJS.Alignment})}})(function(E){var C="data-aui-alignment";var J="data-aui-alignment-static";var H="aui-alignment";var A="aui-alignment-side-";var K="aui-alignment-snap-";var D="right middle";var I={"top left":{el:"bottom left",target:"top left"},"top center":{el:"bottom center",target:"top center"},"top right":{el:"bottom right",target:"top right"},"right top":{el:"top left",target:"top right"},"right middle":{el:"middle left",target:"middle right"},"right bottom":{el:"bottom left",target:"bottom right"},"bottom left":{el:"top left",target:"bottom left"},"bottom center":{el:"top center",target:"bottom center"},"bottom right":{el:"top right",target:"bottom right"},"left top":{el:"top right",target:"top left"},"left middle":{el:"middle right",target:"middle left"},"left bottom":{el:"bottom right",target:"bottom left"}};function G(Q,P,M){var N=A+P;var O=K+M;Q.className+=" "+N+" "+O}function B(M){var N=(M.getAttribute(C)||D).split(" ");return{side:N[0],snap:N[1]}}function F(N,M){return I[N+" "+M]||I[D]}function L(O,P){var R=B(O);var Q=F(R.side,R.snap);var N=O.hasAttribute(J);var M=new E({enabled:false,element:O,target:P,attachment:Q.el,targetAttachment:Q.target,classPrefix:H,constraints:[{to:"window",attachment:N===true?"none":"together"}]});G(O,R.side,R.snap);this._auiTether=M}L.prototype={destroy:function(){this._auiTether.destroy();return this},disable:function(){this._auiTether.disable();return this},enable:function(){this._auiTether.enable();return this}};return L});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-trigger', location = 'js/aui/trigger.js' */
(function(A){define("aui/trigger",[],function(){return A(AJS.$,window.skate)})})(function(E,B){function D(G,H){var F=E(H).closest("a[href]",G);return !!F.length&&F[0]!==G}function C(F){return document.getElementById(F.getAttribute("aria-controls"))}function A(G,H){if(G.isEnabled()){var F=C(G);if(F&&F.message){F.message(H)}}}B("data-aui-trigger",{type:B.types.ATTR,insert:function(F){E(F).on({click:function(G){if(!D(F,G.target)){A(F,G);G.preventDefault()}},"mouseenter mouseleave focus blur":function(G){A(F,G)}})},prototype:{disable:function(){this.setAttribute("aria-disabled","true")},enable:function(){this.setAttribute("aria-disabled","false")},isEnabled:function(){return this.getAttribute("aria-disabled")!=="true"}}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-trigger', location = 'soy/trigger.soy' */
// This file was automatically generated from trigger.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace aui.trigger.
 */

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.trigger == 'undefined') { aui.trigger = {}; }


aui.trigger.trigger = function(opt_data, opt_ignored) {
  return '<' + soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'a') + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + ' class="' + aui.renderExtraClasses(opt_data) + '" aria-owns="' + soy.$$escapeHtml(opt_data.menu.id) + '" aria-controls="' + soy.$$escapeHtml(opt_data.menu.id) + '" aria-haspopup="true"' + ((opt_data.title) ? ' title="' + soy.$$escapeHtml(opt_data.title) + '"' : '') + ((opt_data.container) ? ' data-container="' + soy.$$escapeHtml(opt_data.container) + '"' : '') + (((! opt_data.tagName || opt_data.tagName == 'a') && (! opt_data.extraAttributes || Object.prototype.toString.call(opt_data.extraAttributes) === '[object Object]' && ! opt_data.extraAttributes.href && ! opt_data.extraAttributes.tabindex)) ? ' tabindex="0"' : '') + ' data-aui-trigger' + aui.renderExtraAttributes(opt_data) + '>' + ((opt_data.content) ? soy.$$filterNoAutoescape(opt_data.content) : '') + ((opt_data.text) ? soy.$$escapeHtml(opt_data.text) : '') + ((! (opt_data.showIcon == false)) ? '<span class="icon ' + soy.$$escapeHtml(opt_data.iconClasses ? opt_data.iconClasses : 'aui-icon-dropdown') + '">' + ((opt_data.iconText) ? soy.$$escapeHtml(opt_data.iconText) : '') + '</span>' : '') + '</' + soy.$$escapeHtml(opt_data.tagName ? opt_data.tagName : 'a') + '>';
};
if (goog.DEBUG) {
  aui.trigger.trigger.soyTemplateName = 'aui.trigger.trigger';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-inline-dialog2', location = 'js/aui/inline-dialog2.js' */
(function(A){define("aui/inline-dialog2",["./internal/alignment","./trigger"],function(B){return A(B,AJS.layer,window.skate)})})(function(J,C,E){var I=1000;function K(M){return document.querySelector('[aria-controls="'+M.id+'"]')}function F(N,O){var M=K(N);if(M){O(M)}}function G(M,O){var N=M.getAttribute("data-aui-responds-to")==="hover";if(N){O(M)}}function L(N,M){if(!N._auiAlignment){N._auiAlignment=new J(N,M)}}function B(N,M){L(N,M);N._auiAlignment.enable()}function A(N,M){L(N,M);N._auiAlignment.disable()}E("aui-inline-dialog2",{type:E.types.TAG,ready:function(M){F(M,function(N){N.setAttribute("aria-expanded",M.isVisible());N.setAttribute("aria-haspopup","true")});G(M,function(){M.mouseInside=false;M.addEventListener("mouseenter",function(){M.mouseInside=true;M.message({type:"mouseenter"})});M.addEventListener("mouseleave",function(){M.mouseInside=false;M.message({type:"mouseleave"})})})},remove:function(M){if(M._auiAlignment){M._auiAlignment.destroy()}},prototype:{remove:function(){C(this).remove()},show:function(){var M=this;C(this).show();F(this,function(N){B(M,N);N.setAttribute("aria-expanded","true")});return this},hide:function(){var M=this;C(this).hide();F(this,function(N){A(M,N);N.setAttribute("aria-expanded","false")});return this},isVisible:function(){return C(this).isVisible()},message:function(M){D(this,M);return this}}});function D(O,Q){var N={toggle:["click"],hover:["mouseenter","mouseleave","focus","blur"]};var M=O.getAttribute("data-aui-responds-to");var P=N[M];if(P&&P.indexOf(Q.type)>-1){H[Q.type](O,Q)}}var H={click:function(M){if(M.isVisible()){if(!C(M).isPersistent()){M.hide()}}else{M.show()}},mouseenter:function(M){if(!M.isVisible()){M.show()}if(M._clearMouseleaveTimeout){M._clearMouseleaveTimeout()}},mouseleave:function(M){if(C(M).isPersistent()||!M.isVisible()){return }if(M._clearMouseleaveTimeout){M._clearMouseleaveTimeout()}var N=setTimeout(function(){if(!M.mouseInside){M.hide()}},I);M._clearMouseleaveTimeout=function(){clearTimeout(N);M._clearMouseleaveTimeout=null}},focus:function(M){if(!M.isVisible()){M.show()}},blur:function(M){if(!C(M).isPersistent()&&M.isVisible()){M.hide()}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.auiplugin:aui-inline-dialog2', location = 'soy/inline-dialog2.soy' */
// This file was automatically generated from inline-dialog2.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace aui.inlineDialog2.
 */

if (typeof aui == 'undefined') { var aui = {}; }
if (typeof aui.inlineDialog2 == 'undefined') { aui.inlineDialog2 = {}; }


aui.inlineDialog2.inlineDialog2 = function(opt_data, opt_ignored) {
  return '<aui-inline-dialog2 ' + ((opt_data.id) ? ' id="' + soy.$$escapeHtml(opt_data.id) + '"' : '') + '  class="aui-layer aui-inline-dialog' + aui.renderExtraClasses(opt_data) + '" data-aui-alignment="' + soy.$$escapeHtml(opt_data.alignment ? opt_data.alignment : '') + '" data-aui-responds-to="' + soy.$$escapeHtml(opt_data.respondsTo ? opt_data.respondsTo : '') + '" aria-hidden="true"' + aui.renderExtraAttributes(opt_data) + '>' + aui.inlineDialog2.inlineDialog2Content(opt_data) + '</aui-inline-dialog2>';
};
if (goog.DEBUG) {
  aui.inlineDialog2.inlineDialog2.soyTemplateName = 'aui.inlineDialog2.inlineDialog2';
}


aui.inlineDialog2.inlineDialog2Content = function(opt_data, opt_ignored) {
  return '<div class="aui-inline-dialog-contents">' + ((opt_data.content) ? soy.$$filterNoAutoescape(opt_data.content) : '') + '</div>';
};
if (goog.DEBUG) {
  aui.inlineDialog2.inlineDialog2Content.soyTemplateName = 'aui.inlineDialog2.inlineDialog2Content';
}


aui.inlineDialog2.trigger = function(opt_data, opt_ignored) {
  return '' + aui.trigger.trigger(soy.$$augmentMap(opt_data, {showIcon: opt_data.showIcon ? opt_data.showIcon : false}));
};
if (goog.DEBUG) {
  aui.inlineDialog2.trigger.soyTemplateName = 'aui.inlineDialog2.trigger';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-jquery', location = '/js/confluence/preview-support.js' */
define("cp/confluence/preview-support",["ajs"],function(a){var d=function(){var e=b.SELECTOR_STRINGS.IMAGE+", "+b.SELECTOR_STRINGS.LINK_IMAGE+", "+b.SELECTOR_STRINGS.EXTERNAL_IMAGE;if(b.isPDFSupported()){e+=", "+b.SELECTOR_STRINGS.PDF+", "+b.SELECTOR_STRINGS.LINK_PDF}return e};var c=function(){return b.SELECTOR_STRINGS.IMAGE+", "+b.SELECTOR_STRINGS.EXTERNAL_IMAGE+", "+b.SELECTOR_STRINGS.FILE+", "+b.SELECTOR_STRINGS.LINK_FILE+", "+b.SELECTOR_STRINGS.ATTACHMENT_MACRO};var b={SELECTOR_STRINGS:{IMAGE:"img.confluence-embedded-image[data-linked-resource-id]",EXTERNAL_IMAGE:"img.confluence-embedded-image.confluence-external-resource",PDF:"a.confluence-embedded-file[data-nice-type='PDF Document']",LINK_IMAGE:"a[data-linked-resource-type='attachment'][data-nice-type='Image']",LINK_PDF:"a[data-linked-resource-type='attachment'][data-nice-type='PDF Document']",FILE:"a.confluence-embedded-file",LINK_FILE:"a[data-linked-resource-type='attachment']",FILE_OVERLAY:"span.confluence-embedded-file-wrapper .overlay",ATTACHMENT_MACRO:".plugin_attachments_container a.previewAttachmentLink"},VIEW_MODE:{FULL:"full",COMMENT:"comment",SIMPLE:"simple"},isPDFSupported:function(){return a.DarkFeatures.isEnabled("pdf-preview")},getFileSelectorString:function(){if(a.DarkFeatures.isEnabled("previews.trigger-all-file-types")){return c()}else{return d()}}};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-jquery', location = '/js/confluence/preview.js' */
define("cp/confluence/preview",["underscore","jquery","cp/confluence/preview-support","ajs","confluence/jsUri"],function(k,e,f,i,b){var j,l;e(document).ready(g);function g(){var o=e(f.getFileSelectorString());o.off("click.fb");e(document.body).off("click.filePreviews");e(document.body).on("click.filePreviews",f.getFileSelectorString(),n);e(document.body).on("click.filePreviews",f.SELECTOR_STRINGS.FILE_OVERLAY,h);e(window).on("popstate",function(){if(!l&&i.DarkFeatures.isEnabled("previews.sharing.pushstate")){a()}});a()}function n(o){if(!o.altKey&&!o.ctrlKey&&!o.metaKey&&!e(this).parent().closest("a, #draft-changes-dialog, #cp-annotations").length){o.preventDefault();m(this)}}function h(p){p.preventDefault();var o=e(p.target);var q=o.closest("span.confluence-embedded-file-wrapper");m(q.find(f.SELECTOR_STRINGS.IMAGE+","+f.SELECTOR_STRINGS.FILE),{autoShowAnnotationPanel:o.closest(".comment-count-overlay").length>0})}function m(r,q){if(!l){var t="confluence-previews-css";WRM.require("wr!com.atlassian.confluence.plugins.confluence-previews:"+t);var u=e.Deferred(),o=u.promise();var p=setInterval(function(){for(var w=0;w<document.styleSheets.length;w++){if(document.styleSheets[w].href&&document.styleSheets[w].href.indexOf(t)!==-1){s();return}if(document.styleSheets[w].imports&&document.all&&!window.atob){for(var v=0;v<document.styleSheets[w].imports.length;v++){if(document.styleSheets[w].imports[v].href.indexOf(t)!==-1){s();return}}}}},100);var s=function(){u.resolve();clearInterval(p)};l=e.when(WRM.require(["wr!com.atlassian.confluence.plugins.confluence-previews:confluence-previews-js","wrc!file-viewer"]),o);l.done(function(){j=require("cp/confluence/file-preview-loader");d(r,q)});Confluence.PageLoadingIndicator(e("body")).showUntilResolved(l,"We were unable to load the file previewer")}else{l.done(k.partial(d,r,q))}return l}var d=function(q,p){p=p||{};var o=e("#content");var r=e(q).closest(".comment,.cq-content,.ic-content");if(!p.viewMode){if(!(o.hasClass("page")||o.hasClass("blogpost"))){p.viewMode=f.VIEW_MODE.SIMPLE}else{if(r.length){p.viewMode=f.VIEW_MODE.COMMENT}}}if(p.viewMode===f.VIEW_MODE.COMMENT){j.showPreviewerForComment(q,r,p)}else{if(p.viewMode===f.VIEW_MODE.SIMPLE){j.showPreviewerForSingleFile(q,p)}else{p.viewMode=f.VIEW_MODE.FULL;j.showPreviewer(q,p)}}};function a(){if(c()){var q=new b(window.location.href);var p=window.history.pushState&&i.DarkFeatures.isEnabled("previews.sharing.pushstate");if(q.getQueryParamValue("preview")&&!p){var r="#!/preview"+q.getQueryParamValue("preview");var o=decodeURIComponent(q.deleteQueryParam("preview").setAnchor(r).toString());if(window.history.replaceState){window.history.replaceState({},"",o)}else{window.location=o}}else{if(q.anchor().indexOf("!/preview")===0&&p){var o;if(q.getQueryParamValue("preview")){o=q.setAnchor("")}else{o=q.addQueryParam("preview",q.anchor().substr("!/preview".length,q.anchor().length)).setAnchor("")}window.history.replaceState({},"",o)}}m()}}function c(){var o=new b(window.location.href);return i.DarkFeatures.isEnabled("previews.sharing")&&(o.getQueryParamValue("preview")||(o.anchor()&&o.anchor().indexOf("!/preview")===0))}return{loadConfluencePreviews:m}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-previews:confluence-previews-jquery', location = '/js/confluence/jquery-previewer.js' */
require(["cp/confluence/preview","jquery"],function(b,a){a.fn.previewer=function(c){if(!a(this).length){return this}var d=a.extend({},c);return this.each(function(){var f=a(this);var e=f.closest("li");var g=d.src||f.attr("data-image-src")||f.attr("src");if(g){f.click(function(j){var i={src:g,type:d.type,thumbnail:g,title:d.title||e.attr("data-file-name")||g,rank:0,id:e.attr("data-attachment-id"),ownerId:e.attr("data-owner-id")};var h=b.loadConfluencePreviews([i],{source:d.from||"custom",viewMode:d.viewMode||"simple"});d.zindex&&h.done(function(){a("#cp-container").css({"z-index":d.zindex})})})}})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'org.randombits.confluence.toc:toc-plugin-analytics', location = 'net/customware/confluence/plugin/toc/analytics/analytics.js' */
AJS.toInit(function(){AJS.$(".toc-macro a").click(function(){AJS.trigger("analyticsEvent",{name:"confluence.toc-macro.heading-click"})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'org.randombits.confluence.toc:client-side-toc-resources', location = 'net/customware/confluence/plugin/toc/js/client-side-toc.js' */
require(["ajs"],function(a){a.toInit(function(f){function b(n){var m=f({});m.data("precedenceLevel",n);return m}function g(m){return f(m).data("precedenceLevel")}function i(n,m){f(n).data("precedenceLevel",m);return n}function h(n,m){return m===g(n)}function d(s,m,o){if(s.length===0){return f()}var n=s.map(g).reduce(function(u,t){return Math.min(u,t)});if(!h(s[0],n)){s.unshift(b(n))}var q=m.createTocLevelContainer();var r={subElements:[],currentItem:undefined,outline:undefined,flush:function(){if(this.subElements.length>0&&this.currentItem){d(this.subElements,m,this.outline).appendTo(this.currentItem);this.subElements=[]}},add:function(t){this.subElements.push(t)},resetItem:function(t){this.outline=(o||[]).slice(0);this.outline.push(t);this.currentItem=m.createTocItemContainer();this.currentItem.appendTo(q);return this.currentItem}};var p=0;s.forEach(function(t){if(h(t,n)){p++;r.flush();r.resetItem(p);if(t.textContent){c(t,r.outline.join(".")).appendTo(r.currentItem)}else{r.currentItem.addClass("toc-empty-item")}}else{r.add(t)}});r.flush();if(o.length===0&&m.decorateToc){m.decorateToc(q)}return q}function c(m,n){return f(Confluence.Plugins.TableOfContents.Client.tocItemBody({outline:n,linkHref:"#"+m.id,linkText:m.textContent}))}function l(m){return{createTocLevelContainer:function(){return this.createTocItemContainer()},createTocItemContainer:function(){return f(Confluence.Plugins.TableOfContents.Client.flatStyleTocItemContainer({cssClass:"toc-item-container"}))},decorateToc:function(o){function n(r,p){var s=r in m?m[r]:p;if(s){var q=f(Confluence.Plugins.TableOfContents.Client.flatStyleTocSeparator({separator:s}));q.appendTo(o)}}n("preseparator","[ ");f(o).find("span.toc-item-body").each(function(p,q){if(p>0){n("midseparator"," ] [ ")}f(q).appendTo(o)});n("postseparator"," ]");f(o).find(".toc-item-container").remove()}}}function e(m){return{createTocLevelContainer:function(){return f(Confluence.Plugins.TableOfContents.Client.listStyleTocLevelContainer({cssliststyle:m.cssliststyle,csslistindent:m.csslistindent}))},createTocItemContainer:function(){return f(Confluence.Plugins.TableOfContents.Client.listStyleTocItemContainer())}}}function j(m){var o;if(m.includeheaderregex){o=new RegExp(m.includeheaderregex)}var n;if(m.excludeheaderregex){n=new RegExp(m.excludeheaderregex)}return function(){var p=f(this).text();if(o&&!o.test(p)){return false}if(n&&n.test(p)){return false}return true}}function k(o,q){var m=q.headerelements;var r=m.split(",");var p=j(q);var n=f("#main-content").find(m).filter(p).each(function(){i(this,r.indexOf(this.nodeName))}).toArray();return d(n,o,[])}f(".client-side-toc-macro").each(function(){var o=f(this);var n=o.data()||{};var m;if(n.structure==="flat"){m=l(n)}else{m=e(n)}if(n.numberedoutline!==true){o.addClass("hidden-outline")}o.html(k(m,n))})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'org.randombits.confluence.toc:client-side-toc-resources', location = 'net/customware/confluence/plugin/toc/templates/client.soy' */
// This file was automatically generated from client.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Plugins.TableOfContents.Client.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Plugins == 'undefined') { Confluence.Plugins = {}; }
if (typeof Confluence.Plugins.TableOfContents == 'undefined') { Confluence.Plugins.TableOfContents = {}; }
if (typeof Confluence.Plugins.TableOfContents.Client == 'undefined') { Confluence.Plugins.TableOfContents.Client = {}; }


Confluence.Plugins.TableOfContents.Client.tocItemBody = function(opt_data, opt_ignored) {
  return '<span class="toc-item-body" data-outline="' + soy.$$escapeHtml(opt_data.outline) + '"><span class="toc-outline">' + soy.$$escapeHtml(opt_data.outline) + '</span><a href="' + soy.$$escapeHtml(opt_data.linkHref) + '" class="toc-link">' + soy.$$escapeHtml(opt_data.linkText) + '</a></span>';
};
if (goog.DEBUG) {
  Confluence.Plugins.TableOfContents.Client.tocItemBody.soyTemplateName = 'Confluence.Plugins.TableOfContents.Client.tocItemBody';
}


Confluence.Plugins.TableOfContents.Client.listStyleTocLevelContainer = function(opt_data, opt_ignored) {
  return '<ul style="' + ((opt_data.cssliststyle) ? ' list-style: ' + soy.$$escapeHtml(opt_data.cssliststyle) + ';' : '') + ((opt_data.csslistindent) ? ' padding-left: ' + soy.$$escapeHtml(opt_data.csslistindent) + ';' : '') + '"></ul>';
};
if (goog.DEBUG) {
  Confluence.Plugins.TableOfContents.Client.listStyleTocLevelContainer.soyTemplateName = 'Confluence.Plugins.TableOfContents.Client.listStyleTocLevelContainer';
}


Confluence.Plugins.TableOfContents.Client.listStyleTocItemContainer = function(opt_data, opt_ignored) {
  return '<li></li>';
};
if (goog.DEBUG) {
  Confluence.Plugins.TableOfContents.Client.listStyleTocItemContainer.soyTemplateName = 'Confluence.Plugins.TableOfContents.Client.listStyleTocItemContainer';
}


Confluence.Plugins.TableOfContents.Client.flatStyleTocItemContainer = function(opt_data, opt_ignored) {
  return '<span class="' + soy.$$escapeHtml(opt_data.cssClass) + '"></span>';
};
if (goog.DEBUG) {
  Confluence.Plugins.TableOfContents.Client.flatStyleTocItemContainer.soyTemplateName = 'Confluence.Plugins.TableOfContents.Client.flatStyleTocItemContainer';
}


Confluence.Plugins.TableOfContents.Client.flatStyleTocSeparator = function(opt_data, opt_ignored) {
  return '<span class="toc-separator">' + soy.$$escapeHtml(opt_data.separator) + '</span>';
};
if (goog.DEBUG) {
  Confluence.Plugins.TableOfContents.Client.flatStyleTocSeparator.soyTemplateName = 'Confluence.Plugins.TableOfContents.Client.flatStyleTocSeparator';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-mobile:mobile-switch-resources', location = 'js/mobile-switch.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-mobile:mobile-switch-resources', location = 'com/atlassian/confluence/plugins/mobile/soy/mobile-switch.soy' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:application-header-administration-cog-resource', location = 'header/cog.js' */
var NavLinks=(function(a){a.ApplicationHeader=function(b){b.Cog=(function(){var c=function(){var d=AJS.$("#system-admin-menu-content");if(d.length>0){return d}var e=AJS.$("#admin-menu-link-content");if(e.length>0){return e}return AJS.$("#bamboo\\.global\\.header-admin\\.menu")};return{getDropdown:c}}());return b}(a.ApplicationHeader||{});return a}(NavLinks||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:administration-shortcuts-resources', location = 'adminshortcuts/adminshortcuts.soy' */
// This file was automatically generated from adminshortcuts.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace navlinks.templates.adminshortcuts.
 */

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.adminshortcuts == 'undefined') { navlinks.templates.adminshortcuts = {}; }


navlinks.templates.adminshortcuts.section = function(opt_data, opt_ignored) {
  var param5 = '<ul class="aui-list-truncate">';
  var linkList7 = opt_data.links;
  var linkListLen7 = linkList7.length;
  for (var linkIndex7 = 0; linkIndex7 < linkListLen7; linkIndex7++) {
    var linkData7 = linkList7[linkIndex7];
    param5 += '<li><a href="' + soy.$$escapeHtml(linkData7.link) + '">' + soy.$$escapeHtml(linkData7.label) + '</a></li>';
  }
  param5 += '</ul>';
  var output = '' + aui.dropdown2.section({id: 'nl-remote-admin-section', label: "Other applications", content: param5});
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.adminshortcuts.section.soyTemplateName = 'navlinks.templates.adminshortcuts.section';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:administration-shortcuts-resources', location = 'adminshortcuts/adminnavlinks.js' */
var NavLinks=(function(a){a.AdminShortcuts=(function(){var c=function(){return AJS.$.ajax({url:AJS.contextPath()+"/rest/menu/latest/admin",cache:false,dataType:"json"})};var b=function(){AJS.$("#nl-remote-admin-section").on("click","a",function(){NL.trackEvent("remoteAdminItemSelected",NL.getCurrentApplication(),$(this).attr("href"))})};return{render:function(){c().done(function(e){e=_.reject(e,function(f){return f.local===true});if(e.length){var d=navlinks.templates.adminshortcuts.section({links:e});a.ApplicationHeader.Cog.getDropdown().append(d);b()}})}}}());return a}(NavLinks||{}));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:administration-shortcuts', location = 'adminshortcuts/adminshortcuts-cdn.js' */
AJS.toInit(function(){if(AJS.DarkFeatures&&AJS.DarkFeatures.isEnabled("rotp.admin.shortcuts")){NavLinks.AdminShortcuts.render()}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-projectshortcuts', location = 'projectshortcuts/projectshortcuts.soy' */
// This file was automatically generated from projectshortcuts.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace navlinks.templates.projectshortcuts.
 */

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.projectshortcuts == 'undefined') { navlinks.templates.projectshortcuts = {}; }


navlinks.templates.projectshortcuts.dialogContent = function(opt_data, opt_ignored) {
  return '' + ((opt_data.localShortcuts && opt_data.localShortcuts.length > 0) ? navlinks.templates.projectshortcuts.dialogContentShortcuts({shortcuts: opt_data.localShortcuts, listClass: 'projectshortcut-links'}) : '') + ((opt_data.remoteShortcuts != null) ? (opt_data.remoteShortcuts.length > 0) ? '<h2 class="projectshortcuts-heading">Related Links</h2>' + navlinks.templates.projectshortcuts.dialogContentShortcuts(soy.$$augmentMap(opt_data.remoteShortcuts, {shortcuts: opt_data.remoteShortcuts, listClass: 'projectshortcut-links'})) : '' : navlinks.templates.projectshortcuts.dialogLoading(null));
};
if (goog.DEBUG) {
  navlinks.templates.projectshortcuts.dialogContent.soyTemplateName = 'navlinks.templates.projectshortcuts.dialogContent';
}


navlinks.templates.projectshortcuts.headingWrapper = function(opt_data, opt_ignored) {
  return '<div class="project-dialog-header-wrapper"><div class="project-header"><img class="project-img" src="' + soy.$$escapeHtml(opt_data.logoUrl) + '"><h2 class="dialog-title">' + soy.$$escapeHtml(opt_data.title) + '</h2></div><div class="project-content-wrapper">' + soy.$$filterNoAutoescape(opt_data.contentHtml) + '</div></div>';
};
if (goog.DEBUG) {
  navlinks.templates.projectshortcuts.headingWrapper.soyTemplateName = 'navlinks.templates.projectshortcuts.headingWrapper';
}


navlinks.templates.projectshortcuts.dialogContentShortcuts = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  var output = '<ul' + ((opt_data.listClass) ? ' class="' + soy.$$escapeHtml(opt_data.listClass) + '"' : '') + '>';
  var shortcutList35 = opt_data.shortcuts;
  var shortcutListLen35 = shortcutList35.length;
  for (var shortcutIndex35 = 0; shortcutIndex35 < shortcutListLen35; shortcutIndex35++) {
    var shortcutData35 = shortcutList35[shortcutIndex35];
    output += '<li' + ((shortcutIndex35 == shortcutListLen35 - 1) ? ' class="last"' : '') + '>' + navlinks.templates.projectshortcuts.dialogContentShortcut(shortcutData35) + '</li>';
  }
  output += '</ul>';
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.projectshortcuts.dialogContentShortcuts.soyTemplateName = 'navlinks.templates.projectshortcuts.dialogContentShortcuts';
}


navlinks.templates.projectshortcuts.dialogContentShortcut = function(opt_data, opt_ignored) {
  return '<a href="' + soy.$$escapeHtml(opt_data.link) + '"' + ((opt_data.tooltip) ? ' title="' + soy.$$escapeHtml(opt_data.tooltip) + '"' : '') + '>' + soy.$$escapeHtml(opt_data.label) + '</a>';
};
if (goog.DEBUG) {
  navlinks.templates.projectshortcuts.dialogContentShortcut.soyTemplateName = 'navlinks.templates.projectshortcuts.dialogContentShortcut';
}


navlinks.templates.projectshortcuts.dialogLoading = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '<div class="projectshortcuts-loading">' + ((opt_data.text) ? soy.$$escapeHtml(opt_data.text) : '') + '</div>';
};
if (goog.DEBUG) {
  navlinks.templates.projectshortcuts.dialogLoading.soyTemplateName = 'navlinks.templates.projectshortcuts.dialogLoading';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-projectshortcuts', location = 'projectshortcuts/projectshortcuts.js' */
(function(e,g){var i,k={},m="key",b="name",j="entity-type";function f(s){var n=e(this),o=n.data(m),q=n.data(b),p=n.data(j);if(typeof o==="undefined"){return}s.preventDefault();i=new AJS.Dialog({width:600,keypressListener:function(u){if(u.which==jQuery.ui.keyCode.ESCAPE){i.remove()}},id:"project-shortcuts-dialog"}).addCancel("Close",function(){i.remove()}).addPanel("",navlinks.templates.projectshortcuts.headingWrapper({title:q,logoUrl:h(),contentHtml:navlinks.templates.projectshortcuts.dialogLoading({text:"Retrieving links…"})})).show();c(i);if(!k[o]){k[o]={entity:{title:q},localShortcuts:null,remoteShortcuts:null};d(AJS.contextPath()+"/rest/project-shortcuts/1.0/local/"+o,{entityType:p}).done(t);d(AJS.contextPath()+"/rest/project-shortcuts/1.0/remote/"+o,{entityType:p}).done(r).fail(function(){var u=i.getCurrentPanel().body.find(".project-content-wrapper");u.find(".projectshortcuts-loading").remove();AJS.messages.error(u,{body:"Could not retrieve remote project shortcuts",closeable:false});c(i)})}else{l(k[o])}function t(u){k[o].localShortcuts=u.shortcuts;l(k[o])}function r(u){k[o].remoteShortcuts=u.shortcuts;l(k[o])}}function h(){return e(".project-shortcut-dialog-trigger img").attr("src")}function l(n){if(n.localShortcuts){i.getCurrentPanel().html(navlinks.templates.projectshortcuts.headingWrapper({title:n.entity.title,logoUrl:h(),contentHtml:navlinks.templates.projectshortcuts.dialogContent(n)}));c(i)}}function a(p){var o=210;if(!p||p.length<=o){return p}var n=o;while(n>0&&p.charAt(n)!=" "){n--}if(n==0){n=o}p=p.substring(0,n);if(p.length>=n){p=p+"..."}return p}function c(n){var q=n.popup.element,p=q.find(".dialog-panel-body"),o=q.find(".dialog-components");p.height("auto");q.height(o.outerHeight()-1);e(".aui-shadow").remove()}function d(n,o){return e.ajax({url:n,cache:false,data:o,dataType:"json"})}e(document).on("click",".project-shortcut-dialog-trigger",f)}(jQuery,window.NL=(window.NL||{})));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:atlassian-ui-popup-display-controller', location = 'popups/DisplayController.js' */
AJS.Popups=AJS.Popups||{};AJS.Popups.DisplayController=function(){var c=[];var a=false;var b=false;AJS.toInit(function(){setTimeout(function(){AJS.Popups.DisplayController.render()},0)});return{request:function(d){c.push(d);if(a&&b===false){this.render()}},render:function(){c.sort(function(e,d){return e.weight-d.weight});a=true;if(c.length!==0){b=true;c[0].show()}}}}();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jira-issues-view-mode-resources', location = 'amd/confluence-shim.js' */
define("confluence/jim/confluence-shim",function(){return window.Confluence});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jira-issues-view-mode-resources', location = 'util/retry-caller.js' */
define("confluence/jim/util/retry-caller",["ajs","jquery","underscore"],function(b,d,c){var a=function(g,p){p=p||{};var h=p.args;var j=(typeof p.tester==="function")?p.tester:function(){return true};var i=p.delays||[0.1,0.3,0.5,0.7,1];var l=i.length;var e=p.name||"";var k=d.Deferred(),o=k.promise();var f=p.context||k;var n=0;var m=function(){if(n===l){return k.rejectWith(f,[f,"exceed-maximum-called-times",""])}var r=i[n++];var q=function(){d.when(g.apply(f,h)).then(function(){if(j.apply(f,arguments)){m()}else{k.resolveWith(f,arguments)}},function(){k.rejectWith(f,arguments)})};c.delay(q,r)};m();return o};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jira-issues-view-mode-resources', location = 'jira/jira-issues-view-mode/fetching-job.js' */
define("confluence/jim/jira/jira-issues-view-mode/fetching-job",["jquery","ajs","confluence/jim/confluence-shim","confluence/jim/util/retry-caller"],function(d,b,e,a){var c=function(f){this.clientId=f.clientId;var g=1000;this.TICK_RETRIES=[0,1*g,1*g,2*g,3*g,5*g,8*g,13*g,13*g,13*g];this.RETRY_HTTP_CODE=202};c.prototype.startJob=function(){return this.fetchSingeJiraServer()};c.prototype.fetchSingeJiraServer=function(){var f=b.contextPath()+"/rest/jiraanywhere/1.0/jira/clientId/{0}";var g=d.ajax({type:"GET",url:b.format(f,this.clientId),cache:true});g.clientId=this.clientId;return g};c.prototype.startJobWithRetry=function(){return a(this.startJob,{name:this.clientId,delays:this.TICK_RETRIES,context:this,tester:function(g,f,h){return h&&h.status===this.RETRY_HTTP_CODE}})};return c});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jira-issues-view-mode-resources', location = 'jira/jira-issues-view-mode/lazy-loading.js' */
define("confluence/jim/jira/jira-issues-view-mode/lazy-loading",["jquery","ajs","underscore","confluence/jim/jira/jira-issues-view-mode/fetching-job"],function(c,f,j,a){var h=null;var e={renderUISingleJIMFromMacroHTML:function(l,k){j.each(l,function(o,n){var m=k.filter("[data-issue-key="+n+"]");m.each(function(p,q){c(q).replaceWith(o[p])})})},renderUISingleJIMInErrorCase:function(l,n){var m="Data cannot be retrieved due to an unexpected error.";l.find(".summary").text(m+" "+n);l.find(".jira-status").remove();l.find(".issue-placeholder").remove();l.find(".aui-icon-wait").remove();var k="aui-message aui-message-warning jim-error-message jim-error-message-single ";l.removeClass("jira-issue").addClass(k)}};var i={handleSuccessAjax:function(m,l,n){var k=h.filter("[data-client-id="+n.clientId+"]");e.renderUISingleJIMFromMacroHTML(m.htmlMacro,k)},handleErrorAjaxCB:function(m,l){var k=h.filter("[data-client-id="+m.clientId+"]");e.renderUISingleJIMInErrorCase(k,l)}};var d={findAllClientIdInPageContent:function(){var k=j.map(h,function(m){var l=c(m).attr("data-client-id");if(l){return l}});return j.uniq(k)},collectFetchingJobs:function(){var l=d.findAllClientIdInPageContent();var k=[];j.each(l,function(m){var n=new a({clientId:m});k.push(n)});return k}};var b={loadOneByOneJiraServerStrategy:function(){var k=d.collectFetchingJobs();var n=k.length;var m=c.Deferred();var l=0;k.forEach(function(o){o.startJobWithRetry().done(i.handleSuccessAjax).fail(function(r,p,q){i.handleErrorAjaxCB(r,q)}).always(function(){if(++l===n){m.resolve()}})});return m.promise()}};var g={init:function(){h=c(".wiki-content .jira-issue[data-client-id]");return b.loadOneByOneJiraServerStrategy()}};return g});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jira-issues-view-mode-resources', location = 'jira/jira-issues-view-mode/fix-ui.js' */
define("confluence/jim/jira/jira-issues-view-mode/fix-ui",["jquery","ajs"],function(c,a){var b={fixBreakIconInOldConf:function(){var d=b.compareVersion(a.version,"5.4.4")<=0;if(!d){return}c(".jim-error-message").each(function(){var f=c(this);var e=f;if(f.hasClass("jim-error-message-table")){e=f.find(".aui-message")}e.addClass("warning").prepend('<span class="aui-icon icon-warning"></span>')})},compareVersion:function(j,h){if(typeof j!=="string"||typeof h!=="string"){return false}var f=j.split(".");var e=h.split(".");var g=0;var d=Math.max(f.length,e.length);for(;g<d;g++){if((f[g]&&!e[g]&&parseInt(f[g])>0)||(parseInt(f[g])>parseInt(e[g]))){return 1}else{if((e[g]&&!f[g]&&parseInt(e[g])>0)||(parseInt(f[g])<parseInt(e[g]))){return -1}}}return 0}};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jira-issues-view-mode-resources', location = 'jira/jira-issues-view-mode/main.js' */
require(["ajs","jquery","confluence/jim/jira/jira-issues-view-mode/lazy-loading","confluence/jim/jira/jira-issues-view-mode/fix-ui"],function(b,d,c,a){d(document).ready(function(){c.init().done(function(){a.fixBreakIconInOldConf()})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:lodash-amd', location = 'applinks/internal/lib/lodash-amd-global.js' */
define("applinks/lib/lodash",function(){if(!window._){throw"lodash not found"}return window._});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-lib', location = 'applinks/internal/lib/console-amd.js' */
define("applinks/lib/console",function(){return window.console});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-lib', location = 'applinks/internal/lib/jquery-amd.js' */
define("applinks/lib/jquery",function(){return window.jQuery});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-lib', location = 'applinks/internal/lib/aui-amd.js' */
define("applinks/lib/aui",function(){var b=window.AJS;if(!b){throw"window.AJS not defined, cannot load AUI"}var a=b.version.split(".");b.versionDetails={major:parseInt(a[0]),minor:parseInt(a[1]),bugfix:parseInt(a[2])};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-lib', location = 'applinks/internal/lib/wrm-amd.js' */
define("applinks/lib/wrm",function(){return window.WRM});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-lib', location = 'applinks/internal/lib/skate-amd.js' */
define("applinks/lib/skate",function(){return window.skate});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-lib', location = 'applinks/internal/lib/window-amd.js' */
define("applinks/lib/window",function(){return window});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/preconditions.js' */
define("applinks/common/preconditions",["applinks/lib/lodash"],function(b){function e(h,i,g){c(b.isString(h)&&!b.isEmpty(h),g,a(i,": expected a non-empty string"))}function f(h,i,g){c(b.isFunction(h),g,a(i,": expected a function, was: "+h))}function d(h,i,g){c(h,g,a(i,": expected a value"))}function c(i,h,g){var j=h?h:g;if(!i){throw new Error(j)}}function a(h,g){return(h||"[unspecified]")+g}return{checkArgument:b.partial(c,b,b,""),nonEmptyString:e,isFunction:f,hasValue:d}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/context.js' */
define("applinks/common/context",["applinks/lib/console","applinks/lib/window","applinks/lib/wrm","applinks/common/modules"],function(b,e,a,d){var c=a.data.claim(d.dataFqn("applinks-common","applinks-context"));return{currentUser:function(){return c.currentUser},hostApplication:function(){return c.hostApplication},validateCurrentUser:function(){if(!this.currentUser()){b.log("No user context, reloading the page to trigger redirect to the login screen");e.location.reload()}}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/help-paths.js' */
define("applinks/common/help-paths",["applinks/lib/console","applinks/lib/wrm","applinks/lib/lodash","applinks/common/modules","applinks/common/preconditions"],function(b,a,g,e,d){var f=g.memoize(function(){var j=a.data.claim(e.dataFqn("applinks-common","applinks-help-paths"));if(!j.entries){b.warn("Help paths not found, all help links are likely to be broken.")}return j.entries||{}});var i=function(j,m){d.nonEmptyString(j,"key");var l=f()[j]||j;if(m){d.nonEmptyString(m,"sectionKey");var k=l.replace(/\+/g,"");l+="#"+k+"-"+m}return l};function c(j,k){return j.indexOf(k,j.length-k.length)!==-1}function h(j,k){return c(j,k)?j:j+k}return{getPath:i,getFullPath:function(j,l){var k=this.baseUrl();return h(k,"/")+this.getPath(j,l)},baseUrl:g.partial(i,"applinks.docs.root")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/events.js' */
define("applinks/common/events",function(){var a="applinks.event.";return{PREREADY:a+"preready",READY:a+"ready",APPLINKS_LOADED:a+"loaded",APPLINKS_UPDATED:a+"updated",NEW_APPLINK_CREATED:a+"created",Legacy:{MESSAGE_BOX_DISPLAYED:a+"message-box-displayed"}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/initializer.js' */
define("applinks/common/initializer",["applinks/lib/jquery","applinks/lib/lodash"],function(b,a){function c(d){if(d&&a.isFunction(d.init)){d.init()}if(d&&a.isFunction(d.initialize)){d.initialize()}}return{init:function(d){c(d)},initOnDomReady:function(d){b(document).ready(function(){c(d)})}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/modules.js' */
define("applinks/common/modules",function(){return{PLUGIN_KEY:"com.atlassian.applinks.applinks-plugin",fqn:function(a){return this.PLUGIN_KEY+":"+a},dataFqn:function(a,b){return this.fqn(a)+"."+b}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/features.js' */
define("applinks/common/features",["applinks/lib/wrm","applinks/lib/lodash","applinks/common/modules","applinks/common/context","applinks/common/rest"],function(a,l,h,f,d){var g,e;function i(){if(l.isUndefined(g)){g=a.data.claim(h.dataFqn("applinks-common","applinks-features"))}return g}function c(){if(l.isUndefined(e)){e=a.data.claim(h.dataFqn("applinks-common","applinks-discovered-features"))}return e}function b(m){return l.contains(c(),m.toLowerCase())}function j(m){l.extend(i(),m)}function k(m){m.forEach(function(n){if(!b(n)){c().push(n.toLowerCase())}})}return{BITBUCKET_REBRAND:"BITBUCKET_REBRAND",V3_UI_OPT_IN:"V3_UI_OPT_IN",V3_UI:"V3_UI",getEnabledFeatures:function(){return i()},isEnabled:function(m){return this.getEnabledFeatures()[m]},disable:function(m){f.validateCurrentUser();return d.V3.features(m).del().done(function(){i()[m]=false})},enable:function(m){f.validateCurrentUser();return d.V3.features(m).put().done(function(n){j(n)})},getDiscoveredFeatures:function(){return c()},isDiscovered:b,discover:function(m){f.validateCurrentUser();d.V3.featureDiscovery(m).put().fail(function(n){throw"Feature discovery request failed: "+n.status+": "+n.responseText}).done(function(n){k(n)})}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/products.js' */
define("applinks/common/products",["applinks/lib/window"],function(a){function b(c){return a.appLinksI18n.entries["applinks.application.type."+c]}return{BAMBOO:"bamboo",BITBUCKET:"stash",CONFLUENCE:"confluence",FECRU:"fecru",JIRA:"jira",REFAPP:"refapp",STASH:"stash",getTypeName:b}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/response-status.js' */
define("applinks/common/response-status",["applinks/lib/lodash"],function(a){function e(f){this.familyCode=f}e.prototype.matches=function(f){return Math.floor(d(f)/100)==this.familyCode};var c={INFORMATIONAL:new e(1),SUCCESSFUL:new e(2),REDIRECTION:new e(3),CLIENT_ERROR:new e(4),SERVER_ERROR:new e(5),forCode:function(f){return a.find(c.all(),function(g){return g.matches(f)})},all:function(){return[c.INFORMATIONAL,c.SUCCESSFUL,c.REDIRECTION,c.CLIENT_ERROR,c.SERVER_ERROR]}};function b(f){this.code=f;this.family=c.forCode(f)}b.prototype.matches=function(f){return d(f)==this.code};function d(f){if(f&&f.status&&a.isNumber(f.status)){return f.status}else{if(a.isNumber(f)){return f}else{return 0}}}return{OK:new b(200),CREATED:new b(201),BAD_REQUEST:new b(400),UNAUTHORIZED:new b(401),FORBIDDEN:new b(403),NOT_FOUND:new b(404),CONFLICT:new b(409),Family:c}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/rest-request.js' */
define("applinks/common/rest-request",["applinks/lib/console","applinks/lib/window","applinks/lib/jquery","applinks/lib/lodash","applinks/common/preconditions","applinks/common/response-status"],function(e,h,f,j,g,b){var i={dataType:"json",contentType:"application/json"};function c(l,m){if(j.isEmpty(m)){return l}var n=l.indexOf("?")>-1?"&":"?";return l+n+f.param(m)}function d(l){return function(n,o,m){if(!j.some(l,function(p){return p.matches(m)})){e.error("Unexpected response status: "+m.status+": "+m.responseText)}}}function a(l){return function(n,o,m){if(!j.some(l,function(p){return p.matches(n)})){e.error("Unexpected response status: "+n.status+": "+n.responseText);if(b.UNAUTHORIZED.matches(n)){h.location.reload()}}}}function k(l,m){g.nonEmptyString(l,"url");g.checkArgument(l.indexOf("#")==-1,'url: "#" fragments not supported');this._url=l;this._queryParams=j.extend({},m);this._expectedStatus=[b.Family.SUCCESSFUL]}k.GET="GET";k.PUT="PUT";k.POST="POST";k.DELETE="DELETE";k.prototype.get=function(){return this._execute(this._requestSettings(k.GET))};k.prototype.del=function(){return this._execute(this._requestSettings(k.DELETE))};k.prototype.put=function(m){var l=this._requestSettings(k.PUT);if(m){l.data=m}return this._execute(l)};k.prototype.post=function(m){var l=this._requestSettings(k.POST);if(m){l.data=m}return this._execute(l)};k.prototype.queryParam=function(l,m){this._queryParams[l]=m;return this};k.prototype.queryParams=function(l){this._queryParams=j.extend(this._queryParams,l);return this};k.prototype.authorisationCallback=function(l){this.queryParam("authorisationCallback",l);return this};k.prototype.expectStatus=function(){this._expectedStatus=j.isArray(arguments[0])?arguments[0]:j.toArray(arguments);return this};k.prototype._requestSettings=function(l){var m=this;return j.defaults({url:c(m._url,m._queryParams),type:l},i)};k.prototype._execute=function(l){return f.ajax(l).done(d(this._expectedStatus)).fail(a(this._expectedStatus))};return k});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/rest.js' */
define("applinks/common/rest",["applinks/lib/aui","applinks/common/preconditions","applinks/common/rest-request","applinks/common/rest-oauth"],function(d,h,a,c){function g(i){h.hasValue(i,"version");this._version=i}g.prototype.baseUrl=function(){return d.contextPath()+"/rest/applinks/"+this._version};g.prototype.withPath=function(i){return this.baseUrl()+"/"+i};function f(){this.module=new g("1.0")}function b(){this.module=new g("2.0")}function e(){this.module=new g("3.0")}e.prototype.featureDiscovery=function(i){if(!i){throw"feature key not defined"}return new a(this.module.withPath("feature-discovery/"+i))};e.prototype.features=function(i){if(!i){throw"feature name not defined"}return new a(this.module.withPath("features/"+i))};e.prototype.status=function(i){if(!i){throw"applinkId not defined"}return new a(this.module.withPath("status/"+i))};return{V1:new f(),V2:new b(),V3:new e(),OAuth:c}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/rest-oauth.js' */
define("applinks/common/rest-oauth",["applinks/lib/aui","applinks/common/rest-request","applinks/common/preconditions"],function(c,a,e){function b(f){e.hasValue(f,"version");this.baseUrl=c.contextPath()+"/rest/applinks-oauth/"+f+"/"}b.prototype._withPath=function(f){return this.baseUrl+f};function d(){this.module=new b("1.0")}d.prototype.consumerToken=function(f){e.hasValue(f,"applinkId");return new a(this.module._withPath("consumer-token/"+f))};return{V1:new d()}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-common', location = 'applinks/internal/common/i18n.js' */
define("applinks/common/i18n",["applinks/lib/jquery","applinks/lib/aui"],function(b,a){function c(){a.I18n.keys=a.I18n.keys||{};b.extend(a.I18n.keys,appLinksI18n.entries)}return{init:c}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'js/fecru-compatibility.js' */
if(jQuery!=undefined&&AJS!=undefined){jQuery=AJS.$};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'applinks/internal/common/rest-service.js' */
AppLinks=AJS.$.extend(window.AppLinks||{},{Event:{NAMESPACE:"applinks"}});var ApplinksEvents=require("applinks/common/events");AppLinks.Event=AJS.$.extend(window.AppLinks.Event,ApplinksEvents);if(AJS.AppLinksInitialisationBinder){AppLinks.initialisationBinder=AJS.AppLinksInitialisationBinder}else{AppLinks.initialisationBinder=function(a){AJS.toInit(a)}}AppLinks.initialisationBinder(function(){var c=AJS.$;AppLinks=c.extend(window.AppLinks||{},{failure:function(f){if(f.status==401){window.location.reload()}else{var d=AppLinks.parseError(f);var e=c(".page-error");if(e.length>0){e.html(d).fadeIn("slow")}else{alert("REST request failed: "+d)}}},jsonRequest:function(e,f,g,h,d){if(g){g=JSON.stringify(g)}c(".page-error").fadeOut("fast");if(!d){d=AppLinks.failure}return jQuery.ajax({url:e,type:f,data:g,dataType:"json",contentType:"application/json; charset=utf-8",cache:false,success:h,error:d})},xmlRequest:function(e,f,g,h,d){if(g){g=JSON.stringify(g)}c(".page-error").fadeOut("fast");if(!d){d=AppLinks.failure}return jQuery.ajax({url:e,type:f,data:g,dataType:"xml",contentType:"application/xml; charset=utf-8",cache:false,success:h,error:d})},parseError:function(g){var d;try{d=JSON.parse(g.responseText)}catch(f){if(g.statusText){return d=g.statusText}else{return g}}if(d.message){if(c.isArray(d.message)){return d.message.join(" ")}return d.message}else{return g.statusText}},put:function(e,f,g,d){return AppLinks.jsonRequest(e,"PUT",f,g,d)},post:function(e,f,g,d){return AppLinks.jsonRequest(e,"POST",f,g,d)},update:function(e,f,d){AppLinks.put(AppLinks.self_link(e),e,f,d)},get:function(e,f,d){return AppLinks.jsonRequest(e,"GET",null,f,d)},getXml:function(e,f,d){return AppLinks.xmlRequest(e,"GET",null,f,d)},self_link:function(f){for(var d=0,g=f.link.length;d<g;d++){var e=f.link[d];if(e.rel=="self"){return e.href}}throw"No self-link found"},del:function(g,f,e){var d;if(typeof(g)=="string"){d=g}else{d=AppLinks.self_link(g)}return AppLinks.jsonRequest(d,"DELETE",null,f,e)},SPI:c.extend({},{API_VERSION:"1.0",REST_RESOURCE_URL:AJS.contextPath()+"/rest/applinks/",BASE_URL:AJS.contextPath()+"/rest/applinks/1.0",OAUTH_REST_RESOURCE_URL:AJS.contextPath()+"/rest/applinks-oauth/",OAUTH_BASE_URL:AJS.contextPath()+"/rest/applinks-oauth/1.0",setApiVersion:function(d){AppLinks.SPI.API_VERSION=d;AppLinks.SPI.setBaseUrl(AppLinks.SPI.REST_RESOURCE_URL+AppLinks.SPI.API_VERSION)},setBaseUrl:function(d){AppLinks.SPI.BASE_URL=d},setOAuthBaseUrl:function(d){AppLinks.SPI.OAUTH_BASE_URL=d},getRemoteRestBaseUrl:function(d){return d+"/rest/applinks/"+AppLinks.SPI.API_VERSION},getRemotePluginServletBaseUrl:function(d){return d+"/plugins/servlet"},getAllLinks:function(f,e){var d=AppLinks.SPI.BASE_URL+"/applicationlink";return AppLinks.get(d,f,e)},getAllLinksWithAuthInfo:function(f,e){var d=AppLinks.SPI.BASE_URL+"/listApplicationlinks";return AppLinks.get(d,f,e)},getApplicationLinkState:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/listApplicationlinkstates/id/"+g;return AppLinks.get(d,f,e)},getLinksOfType:function(f,g,e){var d=AppLinks.SPI.BASE_URL+"/applicationlink/type/"+f;return AppLinks.get(d,g,e)},tryToFetchManifest:function(f,g,e){var d=AppLinks.SPI.BASE_URL+"/applicationlinkForm/manifest.json?url="+encodeURIComponent(f);return AppLinks.get(d,g,e)},getManifestFor:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/manifest/"+g+".json";return AppLinks.get(d,f,e)},getLocalManifest:function(f,e){var d=AppLinks.SPI.BASE_URL+"/manifest.json";return AppLinks.get(d,f,e)},getRemoteManifest:function(f,g,e){var d=AppLinks.SPI.getRemoteRestBaseUrl(f)+"/manifest.json";return AppLinks.get(d,g,e)},getRemoteOAuthConsumerInfo:function(f,g,e){var d=AppLinks.SPI.getRemotePluginServletBaseUrl(f)+"/oauth/consumer-info";return AppLinks.getXml(d,g,e)},getApplinkStatus:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/status/"+g;return AppLinks.get(d,f,e)},createStaticUrlAppLink:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/applicationlinkForm/createStaticUrlAppLink?typeId="+g;return AppLinks.post(d,null,f,e)},createLink:function(k,i,m,e,j,l,g,n,f){var d=AppLinks.SPI.BASE_URL+"/applicationlinkForm/createAppLink";var h={applicationLink:k,username:i,password:m,createTwoWayLink:e,customRpcURL:j,rpcUrl:l,configFormValues:g};return AppLinks.post(d,h,n,f)},createLinkWithOrphanedTrust:function(k,i,n,e,j,l,g,m,o,f){var d=AppLinks.SPI.BASE_URL+"/applicationlinkForm/createAppLink";var h={applicationLink:k,username:i,password:n,createTwoWayLink:e,customRpcURL:j,rpcUrl:l,configFormValues:g,orphanedTrust:m};return AppLinks.post(d,h,o,f)},verifyTwoWayLinkDetails:function(d,j,k,g,i,f){var e=AppLinks.SPI.BASE_URL+"/applicationlinkForm/details";var h={username:k,password:g,remoteUrl:d,rpcUrl:j};return AppLinks.post(e,h,i,f)},getApplicationLinkInfo:function(f,g,e){var d=AppLinks.SPI.BASE_URL+"/applicationlinkInfo/id/"+f;return AppLinks.get(d,g,e)},deleteLink:function(h,d,g,f){var e=AppLinks.SPI.BASE_URL+"/applicationlink/"+h.id;if(d){e+="?reciprocate=true"}return AppLinks.del(e,g,f)},makePrimary:function(f,e){var d=AppLinks.SPI.BASE_URL+"/applicationlink/primary/"+f.id;return AppLinks.post(d,null,e)},relocate:function(i,g,d,h,f){var e=AppLinks.SPI.BASE_URL+"/relocateApplicationlink/"+i.id+"?newUrl="+encodeURIComponent(g)+"&nowarning="+(d?"true":"false");return AppLinks.post(e,null,h,f)},legacyUpgrade:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/upgrade/legacy/"+g.id;return AppLinks.post(d,null,f,e)},ualUpgrade:function(h,d,g,f){var e=AppLinks.SPI.BASE_URL+"/upgrade/ual/"+h.id;return AppLinks.post(e,d,g,f)},getEntityTypesForApplicationType:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/type/entity/"+g;return AppLinks.get(d,f,e)},getLocalEntitiesWithLinksToApplication:function(d,g,f){var e=AppLinks.SPI.BASE_URL+"/entitylink/localEntitiesWithLinksTo/"+d+".json";return AppLinks.get(e,g,f)},getEntityLinksForApplication:function(d,g,f){var e=AppLinks.SPI.BASE_URL+"/entities/"+d+".json";AppLinks.get(e,g,f)},getEntityLinksForApplicationUsingAnonymousAccess:function(d,g,f){var e=AppLinks.SPI.BASE_URL+"/entities/anonymous/"+d+".json";return AppLinks.get(e,g,f)},createNonUalEntityLink:function(m,h,e,g,k,f,l,j){var d=AppLinks.SPI.BASE_URL+"/entitylink/"+m+"/"+h+"?reciprocate=false";var i={applicationId:e,typeId:g,key:k,name:f,isPrimary:false};return AppLinks.put(d,i,l,j)},createEntityLink:function(i,h,e,d,j,g){var f=AppLinks.SPI.BASE_URL+"/entitylink/"+i+"/"+h+"?reciprocate=";f+=(d?"true":"false");return AppLinks.put(f,e,j,g)},getConfiguredEntityLinks:function(g,f,h,e){var d=AppLinks.SPI.BASE_URL+"/entitylink/primaryLinks/"+g+"/"+f+".json";return AppLinks.get(d,h,e)},deleteEntityLink:function(i,h,e,d,j,g){var f=AppLinks.SPI.BASE_URL+"/entitylink/"+i+"/"+h+"?typeId="+e.typeId+"&key="+e.key+"&applicationId="+e.applicationId+"&reciprocate="+d;return AppLinks.del(f,j,g)},makePrimaryEntityLink:function(h,g,d,i,f){var e=AppLinks.SPI.BASE_URL+"/entitylink/primary/"+h+"/"+g+"?typeId="+d.typeId+"&key="+d.key+"&applicationId="+d.applicationId;return AppLinks.post(e,null,i,f)},canDeleteAppLink:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/permission/reciprocate-application-delete/"+g;return AppLinks.get(d,f,e)},canDeleteEntityLink:function(h,g,d,i,f){var e=AppLinks.SPI.BASE_URL+"/permission/reciprocate-entity-delete/"+d.applicationId+"/"+h+"/"+g+"/"+d.typeId+"/"+d.key;return AppLinks.get(e,i,f)},canCreateReciprocateEntityLink:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/permission/reciprocate-entity-create/"+g;return AppLinks.get(d,f,e)},processPermissionCode:function(e){var d={noPermission:function(){},missing:function(){},credentialsRequired:function(f){},authenticationFailed:function(f){},noAuthentication:function(f){},noAuthenticationConfigured:function(){},noConnection:function(){},allowed:function(){},unrecognisedCode:function(f){},updateView:function(h,g,f){}};if(!e){e={}}e=c.extend(d,e);return function(g){var f=g.code;if(f=="NO_PERMISSION"){e.noPermission()}else{if(f=="MISSING"){e.missing()}else{if(f=="CREDENTIALS_REQUIRED"){e.credentialsRequired(g.url)}else{if(f=="AUTHENTICATION_FAILED"){e.authenticationFailed(g.url)}else{if(f=="NO_AUTHENTICATION"){e.noAuthentication(g.url)}else{if(f=="NO_AUTHENTICATION_CONFIGURED"){e.noAuthenticationConfigured()}else{if(f=="NO_CONNECTION"){e.noConnection()}else{if(f=="ALLOWED"){e.allowed()}else{e.unrecognisedCode(g.code)}}}}}}}}}},addAuthenticationTrigger:function(f,d,e){if(!e){e={}}if(typeof e.onSuccess=="undefined"){e.onSuccess=function(){location.reload()}}if(typeof e.onFailure=="undefined"){e.onFailure=function(){return true}}c(f).unbind("click");c(f).click(function(){if(e.before){e.before()}AppLinks.authenticateRemoteCredentials(d,e.onSuccess,e.onFailure)})},deleteOrphanedTrust:function(h,f,g,e){var d=AppLinks.SPI.BASE_URL+"/orphaned-trust/"+f+"/"+h;return AppLinks.del(d,g,e)},getOrphanedTrust:function(f,e){var d=AppLinks.SPI.BASE_URL+"/orphaned-trust/";return AppLinks.get(d,f,e)},showCreateEntityLinkSuggestion:function(){return true},getApplicationLink:function(g,f,e){var d=AppLinks.SPI.BASE_URL+"/applicationlink/"+g;return AppLinks.get(d,f,e)},createApplicationLink:function(g,e,j,k,d,l,h){var f=AppLinks.SPI.BASE_URL+"/applicationlink";var i={id:g,name:e,rpcUrl:j,displayUrl:k,typeId:d};return AppLinks.put(f,i,l,h)},createConsumer:function(f,o,e,n,j,m,h,q,i,l,p,g){var d=AppLinks.SPI.OAUTH_BASE_URL+"/applicationlink/"+f+"/authentication/consumer";var k={key:o,name:e,description:n,sharedSecret:j,publicKey:m,outgoing:l,twoLOAllowed:h,executingTwoLOUser:q,twoLOImpersonationAllowed:i};return AppLinks.put(d,k,p,g)},createConsumerAutoConfigure:function(k,j,g,d,i,f){var e=AppLinks.SPI.OAUTH_BASE_URL+"/applicationlink/"+k+"/authentication/consumer?autoConfigure=true";var h={twoLOAllowed:j,executingTwoLOUser:g,twoLOImpersonationAllowed:d};return AppLinks.put(e,h,i,f)},registerProvider:function(j,i,f,h,e){var d=AppLinks.SPI.BASE_URL+"/applicationlink/"+j+"/authentication/provider";var g={config:f,provider:i};return AppLinks.put(d,g,h,e)},enableFeature:function(f,g,e){var d=AppLinks.SPI.BASE_URL+"/features/"+f;return AppLinks.put(d,{},g,e)},disableFeature:function(f,g,e){var d=AppLinks.SPI.BASE_URL+"/features/"+f;return AppLinks.del(d,g,e)}},(window.AppLinks&&window.AppLinks.SPI)||{})});var b="applinks";AppLinks.UI={showInfoBox:function(d){c(".aui-message.success").remove();AppLinks.UI.createMessage("success",d,"page-info")},hideInfoBox:function(){c(".aui-message.success").remove()},showErrorBox:function(d){AppLinks.UI.createMessage("error",d,"page-error")},hideErrorBox:function(){c(".aui-message.error").remove()},showWarningBox:function(e){if(c.isArray(e)&&e.length>0){var d=c("<ul></ul>");c(e).each(function(g){d.append(c("<li/>",{text:e[g]}))});var f=c('<div class="page-warning"></div>').append(d);AppLinks.UI.createMessage("warning",f.html(),"page-warning")}else{AppLinks.UI.createMessage("warning",e,"page-warning")}},hideWarningBox:function(){c(".aui-message.warning").remove()},shortenString:function(e,d){if(e.length>d){e=e.substring(0,d)+"..."}return e},createMessage:function(e,f,d){var g=c('<div class="'+d+'">');g.html(f);AJS.messages[e](".applinks-message-bar",{title:"",body:g.wrap("<div></div>").parent().html(),closeable:true});c(document).trigger(AppLinks.Event.Legacy.MESSAGE_BOX_DISPLAYED)},displayValidationErrorMessages:function(e,g,f){if(c.isArray(f)){c(f).each(function(k,j){var l=c('<div class="error applinks-error">');l.text(j);c(g).find("."+e).append(l)})}else{if(typeof f!="undefined"){var h=c('<div class="error applinks-error">');h.text(f.toString());c(g).find("."+e).append(h)}}},displayValidationError:function(d,e,f){return function(k){if(k.status==401){window.location.reload();return}c(".applinks-error").remove();c(".loading").remove();var i=k.responseText;var j=c.parseJSON(i);var h=j.message;if(typeof j.fields=="undefined"){AppLinks.UI.displayValidationErrorMessages(d,e,h)}else{var g=j.fields;c(g).each(function(l){var m=c('<div class="error applinks-error" id="'+g[l]+'-error">');m.text(h[l]);if(c(e).find("."+g[l]).length>0){m.insertAfter(c(e).find("."+g[l]))}else{m.insertAfter(c(e).find("."+d).append(m))}})}c(e).find("."+d).addClass("fully-populated-errors");if(f){f()}}},addProtocolToURL:function(d){var g=c.trim(d);var f=g.toLowerCase();var e=false;if(f.length>=7){if(f.substring(0,7).indexOf("http")!=-1){e=true}}if(!e){g="http://"+g}return g},prettyJoin:function(e,h,g){if(!g){g=AppLinks.I18n.getText("applinks.and")}var d=e.length;var f="";c.each(e,function(i,j){if(i==(d-1)&&d>1){f+=" "+g+"  "+h(j)}else{f+=h(j);if(i+2<d){f+=", "}}});return f},showLoadingIcon:function(d){c('<span class="loading">&nbsp;</span>').insertAfter(d)},hideLoadingIcon:function(d){c(d).next(".loading").remove()},findUrl:function(g){var f=undefined;var h=g.toLowerCase();var e=h.indexOf("http:");if(e==-1){e=h.indexOf("https:")}if(e>-1){var d=h.indexOf(" ",e);if(d==-1){d=h.length}f=g.substring(e,d)}return f},findApplicationType:function(d){d=d.toLowerCase();if(d.indexOf("jira")!=-1){return"jira"}else{if(d.indexOf("fisheye")!=-1){return"fecru"}else{if(d.indexOf("confluence")!=-1){return"confluence"}else{if(d.indexOf("refapp")!=-1){return"refapp"}else{return undefined}}}}},escapeSelector:function(d){return d.replace(/([#;&,\.\+\*\~':"\!\^$\[\]\(\)=>\|])/g,"\\$1")},sanitiseHTML:function(d){var e={"<":"&lt;",'"':"&quot;","&":"&amp;"};return d.replace(/[<"&]/g,function(f){return e[f]})},refreshOrphanedTrust:function(){var d=function(e){c("tr.orphaned-trust-row").each(function(){var k=c(this);var l=k.attr("data-id");var h=k.attr("data-type");var g=false;for(var f=0;f<e.orphanedTrust.length;f++){var j=e.orphanedTrust[f];if(l==j.id&&h==j.type){g=true;break}}if(!g){k.remove();if(e.orphanedTrust.length==0){c(".orphaned-trust-warning").hide()}}})};AppLinks.SPI.getOrphanedTrust(d)},removeCssClass:function(d,e){c(d).removeClass(function(g,i){var h=i.split(" ");var f="";c.each(h,function(j,k){if(k.indexOf(e)!=-1){f=k}});return f})}};(function(){var d=c({});c.each(["bind","unbind","trigger"],function(e,f){AppLinks.UI[f]=function(){return d[f].apply(d,arguments)}})})();AppLinks.I18n={interpolate:function(e,d){if(d){if(!c.isArray(d)){d=[new String(d)]}d.unshift(e);e=AJS.format.apply(AJS,d)}return e},getTextWithPrefix:function(d,e){return AppLinks.I18n.interpolate(appLinksI18n.entries[b+"."+d],e)},getText:function(d,e){return AppLinks.I18n.interpolate(AppLinks.I18n.resolveValue(d),e)},getApplicationTypeName:function(d){return appLinksI18n.entries["applinks.application.type."+d]},getEntityTypeName:function(d){return appLinksI18n.entries["applinks.entity.type."+d]},getPluralizedEntityTypeName:function(d){return appLinksI18n.entries["applinks.entity.type.plural."+d]},getAuthenticationTypeName:function(d){return appLinksI18n.entries["applinks.auth.provider."+d]},resolveValue:function(d){var e=appLinksI18n.entries[d];return typeof e=="undefined"?d:e}};var a=require("applinks/common/help-paths");AppLinks.Docs={createDocLink:function(e,f,d){if(!d){d=""}else{d=" "+d}return c("<a/>",{"class":"ual-help-link help-link"+d,href:AppLinks.Docs.getDocHref(e,f),target:"_blank","data-help-link-key":e,text:AppLinks.I18n.getText("applinks.help"),title:AppLinks.I18n.getText("applinks.help")})},getDocHref:function(e,f){var d=a.getFullPath(e);if(f){d+="#"+a.getPath(e)}return d}};c(document).trigger(AppLinks.Event.PREREADY);c(document).trigger(AppLinks.Event.READY)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'applinks/internal/component/autocomplete.js' */
AJS.$(document).bind(AppLinks.Event.READY,function(){AppLinks.autoComplete={cacheManager:function(c){var a={},b=[],c=c||30;return{get:function(d){return a[d]},put:function(d,e){a[d]=e;b.push(d);if(b.length>c){delete a[b.shift()]}},clear:function(){a={};b=[]}}}};(function(d){var c=function(f){AJS.log("InputDrivenDropDown: truncating text");var h=f.$.closest(".aui-dropdown").width(),g=20;d("a span:not(.icon)",f.$).each(function(){var j=d(this),i=AJS("var","&#8230;"),l=i.width(),k=false;j.wrapInner(d("<em>"));d("em",j).each(function(){var m=d(this);m.show();if(this.offsetLeft+this.offsetWidth>h){var t=this.childNodes,s=false;for(var o=t.length-1;o>=0;o--){var p=t[o],n=1,r=(p.nodeType==3)?"nodeValue":"innerHTML",q=p[r];do{if(n<=q.length){p[r]=q.substr(0,q.length-n++)}else{break}}while(this.offsetLeft+this.offsetWidth+l>h-g);if(n<=q.length){s=true;break}}if(s){k=true}else{m.hide()}}});if(k){j.append(i);this.elpss=i}})};var b=function(f,l){if(!l.length||!l[0]){return}AJS.log("InputDrivenDropDown: highlighting tokens");for(var h=0,j=l.length;h<j;h++){var g=l[h];l[h]=g?g.replace(/[\.\*\+\?\|\(\)\[\]{}\\]/g,"\\$"):""}var k=new RegExp("("+l.join("|")+")","gi");d("li a:not(.dropdown-prevent-highlight) span",f.$).each(function(){var m=d(this),i=m.html().replace(k,"<strong>$1</strong>");m.html(i)})};var e=function(j,g){var i=j.options,h=j.dd;if(h){h.hide();h.$.remove()}i.ajsDropDownOptions=i.ajsDropDownOptions||{};if(i.ajsDropDownOptions&&!i.ajsDropDownOptions.alignment){i.ajsDropDownOptions.alignment="left"}i.ajsDropDownOptions.selectionHandler=i.ajsDropDownOptions.selectionHandler||function(l,k){if(l.type!="click"){l.preventDefault();d("a",k).click();document.location=d("a",k).attr("href")}};i.ajsDropDownOptions.displayHandler=function(k){return AJS.escapeHtml(k.name)};var f=j.dd=new AJS.dropDown(g.matrix,i.ajsDropDownOptions)[0];if(i.ajsDropDownOptions&&i.ajsDropDownOptions.className){f.$.addClass(i.ajsDropDownOptions.className)}if(i.dropdownPlacement){i.dropdownPlacement(f.$)}else{AJS.log("No dropdownPlacement function specified. Appending dropdown to the body.");d("body").append(f.$)}b(f,g.queryTokens||[g.query]);c(f);if(i.dropdownPostprocess){i.dropdownPostprocess(f.$)}f.show(j._effect);if(typeof i.onShow=="function"){i.onShow.call(f,f.$)}return f};function a(g,f){this._effect="appear";this._timer=null;this.id=g;this.options=f;this.inactive=false;this.busy=false;this.cacheManager=AppLinks.autoComplete.cacheManager()}a.prototype.clearCache=function(){this.cacheManager.clear()};a.prototype.change=function(h,g){var f=this;if(h!=f._value||g){f._value=h;f.busy=false;clearTimeout(f._timer);if(g||(/\S{0,}/).test(h)){var i=f.cacheManager.get(h);if(i){e(f,i)}else{f.busy=true;f._timer=setTimeout(function(){f.options.getDataAndRunCallback.call(f,h,f.show)},200)}}else{f.dd&&f.dd.hide()}}};a.prototype.dropDownLength=function(){return this.dd.links?this.dd.links.length:0};a.prototype.dropDownItem=function(f){return this.dropDownLength()>f?this.dd.links[f]:null};a.prototype.hide=function(){this.dd&&this.dd.hide()};a.prototype.remove=function(){var f=this.dd;if(f){this.hide();f.$.remove()}this.inactive=true;this.options.onDeath&&this.options.onDeath()};a.prototype.show=function(g,i,h){if(this.inactive){AJS.log("Quick search abandoned before server response received, ignoring. "+this);return}var f={matrix:g,query:i,queryTokens:h};this.cacheManager.put(i,f);e(this,f);this.busy=false};AppLinks.inputDrivenDropdown=function(f){return new a("inputdriven-dropdown",f)}})(jQuery)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'applinks/internal/component/wizard.js' */
AJS.$(document).bind(AppLinks.Event.PREREADY,function(){(function(d){d.fn.wizard=function(v){var u={width:500,height:350,onshow:function(w,x){return true},aftershow:function(){return true},oncancel:function(){return true},onsubmit:function(){return true},aftersubmit:function(){return true},onnext:function(){return true},onprevious:function(){return true},cancelLabel:AppLinks.I18n.getText("applinks.cancel"),submitLabel:AppLinks.I18n.getText("applinks.create"),nextLabel:AppLinks.I18n.getText("applinks.next"),previousLabel:AppLinks.I18n.getText("applinks.previous"),id:""};if(!v){v={}}v=d.extend(u,v);var t=this;this.each(function(){var D=d(this);var w=new AJS.Dialog(v.width,v.height,v.id);var L=q(w,v.onshow,v.aftershow);var K=c(w,v.oncancel);var z=h(w,v.onsubmit,v.aftersubmit);var M=a(w,v.onprevious);var I=m(w,v.onnext);var G=k(w);var B=o(w);var C=g(w);var H=l(w);var J=s(w);var E=n(w);if(v.showButtonId){d("#"+v.showButtonId).click(L)}var y=f(D);for(var A=0;A<y.length;A++){var F=y[A];j(w,F);if(F.className){w.addHeader(F.title,F.className+"-header")}else{w.addHeader(F.title)}if(A!=0&&d(F.div).attr("previous")!="false"){w.addButton(v.previousLabel,M,"applinks-previous-button")}if(A<y.length-1&&d(F.div).attr("submit")!="true"&&d(F.div).attr("next")!="false"){w.addButton(v.nextLabel,I,"applinks-next-button")}if(d(F.div).attr("submit")=="true"){w.addButton(v.submitLabel,z,"wizard-submit")}if(!w.getPage(A).buttonpanel){w.addButton("",null);d(w.getPage(A).buttonpanel).empty();var x=d('<button class="aui-button aui-button-link button-panel-button applinks-cancel-link">'+v.cancelLabel+"</button>");w.getPage(A).buttonpanel.append(x);x.click(K)}else{var x=d('<button class="aui-button aui-button-link button-panel-link button-panel-cancel-link applinks-cancel-link">'+v.cancelLabel+"</button>");d(w.getPage(A).buttonpanel).append(x);x.click(K)}if(A<y.length-1){w.addPage()}}t={dialog:w,nextPage:I,prevPage:M,submit:z,cancel:K,show:L,disableNextBtn:G,enableNextBtn:B,disableSubmitBtn:C,enableSubmitBtn:H,disablePreviousBtn:J,enablePreviousBtn:E};w.gotoPage(0);w.gotoPanel(0)});return t};function s(t){return function(){b(r(t,"applinks-previous-button"))}}function n(t){return function(){i(r(t,"applinks-previous-button"))}}function k(t){return function(){b(r(t,"applinks-next-button"))}}function o(t){return function(){i(r(t,"applinks-next-button"))}}function g(t){return function(v){var u=r(t,"wizard-submit");b(u);if(typeof(v)=="undefined"||v){d('<span class="loading">&nbsp;</span>').insertBefore(u)}else{u.parent().find(".loading").remove()}}}function l(t){return function(){var u=r(t,"wizard-submit");i(u);u.parent().find(".loading").remove()}}function r(u,t){return d(u.getPage(u.curpage).buttonpanel).find("."+t)}function p(t){d(t.popup.element).find("form").each(function(){this.reset()})}function i(t){t.attr("disabled",false)}function b(t){t.attr("disabled",true)}function q(t,u,v){return function(w){if(u(t,w)!==false){t.gotoPage(0);t.gotoPanel(0);d(document).unbind("keydown.ual.dialog");d(document).bind("keydown.ual.dialog",e(t));t.show();v()}}}function c(t,u){return function(){if(u(t)!==false){t.hide();p(t)}}}function a(t,u){return function(){if(u(t)!==false){t.prevPage()}}}function m(t,u){return function(){if(u(t)!==false){t.nextPage()}}}function e(t){return function(u){if(u.keyCode===27){p(t);d(document).unbind("keydown.ual.dialog")}}}function h(u,v,t){return function(){if(v(u)!==false){t(u);p(u)}}}function j(v,w){var u=d("> div[panel]",w.div);if(u.length>0){u.each(function(y,z){var x=v.addPanel(z.title,null,z.className,"menu-"+z.id);x.getCurrentPanel().body.append(u[y])})}else{var t=v.addPanel(w.title);t.getCurrentPanel().body.append(w.div)}}function f(v){var u=d(" > div",v);var t=[];u.each(function(x){var w=d(this);t[x]={title:w.attr("title")||null,className:w.attr("class"),div:w}});return t}})(jQuery)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'applinks/internal/feature/applinks-wizard/applinkwizard.js' */
(function(a){AppLinks.Wizard={getWizard:function(){return a("#create-application-link-container").data("wizard")},initAuthenticationUI:function(d){var h=a(d);var f=h.find(".create-reciprocal-link");var c=h.find(".ual-arrow");var l=h.find(".two-way-link-details");var j=h.find(".reciprocal-link-description");var b=h.find(".no-reciprocal-link-description");f.click(function(){if(f.is(":checked")){c.removeClass("no-background");l.show();j.show();b.hide()}else{c.addClass("no-background");l.hide();j.hide();b.show()}});var i=h.find(".same-user-radio-btn");var k=h.find(".different-user-radio-btn");var e=h.find(".different-userbase-image");var g=h.find(".same-userbase-image");i.click(function(){e.addClass("different-userbase-image-grey");g.removeClass("same-userbase-image-grey")});k.click(function(){g.addClass("same-userbase-image-grey");e.removeClass("different-userbase-image-grey")})},initNonUALUI:function(e){var c=a(e);var b=c.find(".application-types");for(var d=0;d<nonAppLinksApplicationTypes.length;d++){a('<option value="'+nonAppLinksApplicationTypes[d].typeId+'">'+nonAppLinksApplicationTypes[d].label+"</option>").appendTo(b)}},fetchManifest:function(e,h,d,b){var i=h.find("#application-url");if(i.val()==""){var c=h.find("#application-types");if(c.val()==""){a('<div class="error applinks-error">'+AppLinks.I18n.getText("applinks.error.url.field.empty")+"</div>").insertAfter(i);return false}var g=function(j){e.enableSubmitBtn();e.enablePreviousBtn();e.cancel();AppLinks.UI.listApplicationLinks(j.applicationLink.id,"new",j)};AppLinks.SPI.createStaticUrlAppLink(c.val(),g,null);return true}var f=AppLinks.UI.addProtocolToURL(i.val());AppLinks.UI.showLoadingIcon(i);var g=function(l){var k=l;e.enableNextBtn();h.find(".loading").remove();h.find(".reciprocal-rpc-url").val(a("#baseUrl").val());if(typeof l.typeId!="undefined"){AppLinks.Wizard.handleUALManifest(k,h);e.dialog.gotoPage(2);h.find(".reciprocal-link-username").focus();if(d){d(k)}}else{if(l.code=="applinks.warning.redirected.host"&&!i.data("hasWarnedAboutRedirection")){AppLinks.UI.displayValidationErrorMessages("manifest-validation-errors",h,l.warning);i.data("hasWarnedAboutRedirection","true");var m=function(){a(i).removeData("hasWarnedAboutRedirection");a(i).unbind("change",m)};i.bind("change",m)}else{if(l.code=="applinks.warning.unknown.host"&&!i.data("forceWhenHostIsOffline")){AppLinks.UI.displayValidationErrorMessages("manifest-validation-errors",h,l.warning);i.data("forceWhenHostIsOffline","true");var j=function(){a(i).removeData("forceWhenHostIsOffline");a(i).unbind("change",j)};i.bind("change",j)}else{if(k.code=="applinks.warning.unknown.host"||k.code=="applinks.warning.redirected.host"){delete k.warning;delete k.code}AppLinks.Wizard.handleNonUALManifest(k,f,h);e.dialog.gotoPage(1);h.find(".application-name").focus();if(b){b(k)}}}}};e.disableNextBtn();AppLinks.SPI.tryToFetchManifest(f,g,AppLinks.UI.displayValidationError("manifest-validation-errors",h,function(){e.enableNextBtn()}));return f},handleUALManifest:function(f,e){var c=a(e);c.find(".remote-app-image").removeClass(function(j,l){var k=l.split(" ");var i="";a.each(k,function(m,n){if(n.indexOf("application-type-image-")!=-1){i=n}});return i});c.find(".remote-app-image").addClass("application-type-image-"+f.typeId);c.find(".link-to-app-type").html(AppLinks.I18n.getText("applinks.create.title.link.to",AppLinks.I18n.getApplicationTypeName(f.typeId)));c.find(".remote-app-name").text(AppLinks.UI.shortenString(f.name,20));c.find(".create-reciprocal-link").attr("checked",true);c.find("#reciprocal-link-back-to-server").html(AppLinks.I18n.getText("applinks.create.link.back.to.server",AJS.escapeHtml(f.name)));var d=["administrator",AJS.escapeHtml(f.name),'<a target="_blank" href="'+AppLinks.Docs.getDocHref("applinks.docs.adding.application.link")+'">',"</a>"];if(f.applinksVersion!=undefined){var h=f.applinksVersion.split(".");var b=parseInt(h[0]);var g=parseInt(h[1]);if((f.typeId=="jira"||f.typeId=="confluence")&&(b==3&&g<10)){d[0]="system administrator"}}c.find(".reciprocal-link-description").html(AppLinks.I18n.getText("applinks.create.two.way.link",d));c.find(".no-reciprocal-link-description").hide();c.find(".no-reciprocal-link-description").html(AppLinks.I18n.getText("applinks.create.two.way.no.link",AJS.escapeHtml(f.name)));c.find(".reciprocal-link-username").val("");c.find(".reciprocal-link-password").val("");c.find(".ual-arrow").removeClass("no-background");c.find(".two-way-link-details").show();c.find(".reciprocal-link-description").show();c.find(".no-reciprocal-link-description").hide()},handleNonUALManifest:function(d,e,c){var b=a(c);b.find(".application-name").val("");b.find(".application-types option:first-child").attr("selected","selected");b.find(".non-ual-application-url").text(e);if(d.warning){b.find(".create-non-ual-warning").show();b.find(".create-non-ual-warning").html(d.warning)}else{b.find(".create-non-ual-warning").hide()}},checkReciprocalLinkFormThreeStepMode:function(c,d,g,j,f){var h=a(c);if(h.find(".create-reciprocal-link").is(":checked")){var k=a.trim(h.find(".reciprocal-rpc-url").val());if(k==""){a("<div class='error applinks-error'>"+AppLinks.I18n.getText("applinks.error.url.field.empty")+"</div>").insertAfter(h.find(".reciprocal-rpc-url"));if(f){f()}return}var e=h.find(".reciprocal-link-username");var b=h.find(".reciprocal-link-password");if(e.val()==""){a('<div class="error applinks-error">'+AppLinks.I18n.getText("applinks.error.username.empty")+"</div>").insertAfter(e);if(f){f()}return false}var i=function(l){h.find(".same-user-description").find("input").attr("checked",true);h.find(".trust-radio-btn").attr("checked",true);h.find(".same-user-radio-btn").click();g(l)};k=AppLinks.UI.addProtocolToURL(k);AppLinks.SPI.verifyTwoWayLinkDetails(j,k,e.val(),b.val(),i,AppLinks.UI.displayValidationError("two-way-link-errors",c,f));return false}else{d();return false}},checkReciprocalLinkFormTwoStepMode:function(f,h,b,i){var c=a(f);var g=a.trim(c.find(".reciprocal-rpc-url").val());if(g==""){a("<div class='error applinks-error'>"+AppLinks.I18n.getText("applinks.error.url.field.empty")+"</div>").insertAfter(c.find(".reciprocal-rpc-url"));if(i){i()}return}var d=c.find(".reciprocal-link-username");var e=c.find(".reciprocal-link-password");if(d.val()==""){a('<div class="error applinks-error">'+AppLinks.I18n.getText("applinks.error.username.empty")+"</div>").insertAfter(d);if(i){i()}return false}g=AppLinks.UI.addProtocolToURL(g);AppLinks.SPI.verifyTwoWayLinkDetails(h,g,d.val(),e.val(),b,AppLinks.UI.displayValidationError("two-way-link-errors",f,i));return false}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'applinks/internal/common/urls.js' */
define("applinks/common/urls",["applinks/lib/aui","applinks/lib/lodash","applinks/common/products"],function(b,c,d){var a={generateUrl:function(f,e){var g=f;if(c.isUndefined(e)){return g}else{c.each(e,function(i,h){if(g.indexOf("?")<0){g=g+"?"}else{g=g+"&"}g=g+h+"="+encodeURIComponent(JSON.stringify(i))});return g}}};a.Local={admin:function(f){var e=b.contextPath()+"/plugins/servlet/applinks/listApplicationLinks";return a.generateUrl(e,f)}};a.Remote={admin:function(f,i,h){var g=i===d.CONFLUENCE?"/admin/listapplicationlinks.action":"/plugins/servlet/applinks/listApplicationLinks";var e=f+g;return a.generateUrl(e,h)}};return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-util-js', location = 'js/help-link-analytics.js' */
(function(a){a(function(){AJS.$("body").on("click",".help-link",function(){AJS.trigger("analyticsEvent",{name:"applinks.view.documentation",data:{linkKey:a(this).attr("data-help-link-key")}})})})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:feature-oauth-dance', location = 'applinks/internal/feature/oauth/oauth-callback.js' */
define("applinks/feature/oauth-callback",["applinks/lib/window","applinks/lib/lodash","applinks/common/preconditions"],function(c,a,d){function b(e){d.nonEmptyString(e,"url");this._url=e}b.prototype.onSuccess=function(e){d.isFunction(e,"onSuccess");this._onSuccess=e;return this};b.prototype.onFailure=function(e){d.isFunction(e,"onFailure");this._onFailure=e;return this};b.prototype.success=function(){this.oauthWindow.close();if(this._onSuccess){this._onSuccess()}delete c.oauthCallback};b.prototype.failure=function(){this.oauthWindow.close();if(this._onFailure){this._onFailure()}delete c.oauthCallback};b.prototype.open=function(){c.oauthCallback=this;this.oauthWindow=c.open(this._url,"com_atlassian_applinks_authentication")};return b});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:feature-oauth-dance', location = 'applinks/internal/feature/oauth/oauth-dance.js' */
define("applinks/feature/oauth-dance",["applinks/lib/console","applinks/lib/jquery","applinks/lib/lodash","applinks/lib/window","applinks/common/events","applinks/common/preconditions","applinks/feature/oauth-callback"],function(a,f,c,e,b,h,d){function g(j,i){this._scope=j||e.document;this._selector=i}g.prototype.onSuccess=function(i){h.isFunction(i,"onSuccess");this._onSuccess=i;return this};g.prototype.onFailure=function(i){h.isFunction(i,"onFailure");this._onFailure=i;return this};g.prototype.defaultSuccess=function(){return this.onSuccess(function(){e.location.reload()})};g.prototype.defaultFailure=function(){return this.onFailure(function(){return true})};g.prototype.initialize=function(){var i=this;if(this._selector){f(this._scope).on("click",this._selector,function(){i._open(f(this))})}else{f(this._scope).on("click",function(){i._open(f(this))})}};g.prototype.start=function(){var j=f(this._scope);var i=this._selector?j.find(this._selector):j;this._open(i)};g.prototype._open=function(i){var j=i.attr("data-authorisation-uri");if(j){this._onSuccess||this.defaultSuccess();this._onFailure||this.defaultFailure();new d(j).onSuccess(this._onSuccess).onFailure(this._onFailure).open()}else{a.warn("Could not trigger OAuth dance, data-authorisation-uri missing for: "+i)}};return g});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.applinks.applinks-plugin:applinks-oauth-ui', location = 'js/oauth-dialog.js' */
(function(c,a,b){AppLinks.authenticateRemoteCredentials=function(d,f,e){c(".applinks-error").remove();new b(d).onSuccess(f).onFailure(e).open()}})(require("applinks/lib/jquery"),require("applinks/common/events"),require("applinks/feature/oauth-callback"));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:common-resources', location = 'templates/extra/jira/common.js' */
AJS.JiraIssues={Remote:{}};var appLinksI18n={entries:{}};jQuery(document).ready(function(){AJS.JiraIssues=jQuery.extend(AJS.JiraIssues||{},{bindOAuthLink:function(c,f){var e={onSuccess:function(){f()},onFailure:function(){}};var d=c.attr("href");c.click(function(g){AppLinks.authenticateRemoteCredentials(d,e.onSuccess,e.onFailure);g.preventDefault()})},getOAuthRealm:function(f){var d=f.getResponseHeader("WWW-Authenticate")||"";var c=/OAuth realm\=\"([^\"]+)\"/;var e=c.exec(d);if(e){return e[1]}else{return null}}});jQuery("a.static-oauth-init").each(function(){AJS.JiraIssues.bindOAuthLink(jQuery(this),function(){window.location.reload()})});jQuery("a.anonymous-init").each(function(f,e){var c=encodeURIComponent(window.location.pathname.replace(Confluence.getContextPath(),""));var d=Confluence.getContextPath()+"/login.action?os_destination="+c;AJS.$(e).attr("href",d)});var a=function(j){var e=AJS.JiraIssues.Remote[j];var h="";for(var g=0;g<e.length;g++){h=h+(e[g].key+(g<e.length-1?",":""))}var d=function(l){var i="issuekey in ("+l+")";var m="/sr/jira.issueviews:searchrequest-xml/temp/SearchRequest.xml?jqlQuery="+encodeURIComponent(i)+"&returnMax=true";var k=contextPath+"/plugins/servlet/issue-retriever?appId="+j+"&url="+encodeURIComponent(m)+"&columns=summary&columns=type&columns=resolution&columns=status";return k};var f=function(k){var i=AJS.$("item",k);i.each(function(){var u=AJS.$("link",this).text();var v=AJS.$("key",this).text();var r=AJS.$("summary",this).text();var s=AJS.$("type",this);var m=AJS.$("resolution",this);var w=m.attr("id")!="-1";var o=AJS.$("status",this);var n=AJS.$(".unknown-jira-issue."+v);for(var p=0;p<n.length;p++){var t=AJS.$("<a style=\"background-image: url('"+s.attr("iconUrl")+'\')" href="'+u+'"></a>');t.text(v);var l=AJS.$('<span class="jira-status"></span>');l.text(o.text().toUpperCase());var q=AJS.$('<span class="jira-issue'+(w?" resolved":"")+'" ></span>');q.append(t);q.append(document.createTextNode(" - "+r+" - "));q.append(l);AJS.$(n[p]).replaceWith(q)}})};var c=d(h);AJS.$.ajax({url:c,success:f,error:function(l){if(l.status==401){var k=AJS.JiraIssues.getOAuthRealm(l);if(k){var i={};AJS.$(e).each(function(){if(!i[this.key]){i[this.key]=true;var m=AJS.$('<span class="oauth-msg"> - <a class="oauth-init" href="'+k+'">'+"Authenticate"+"</a> "+"to see issue details"+"</span>");AJS.$(".unknown-jira-issue."+this.key).addClass("single-issue-oauth").append(m)}});AJS.JiraIssues.bindOAuthLink(AJS.$(".single-issue-oauth a.oauth-init"),function(){window.location.reload()})}}else{if(l.status==400&&e.length>1){AJS.$(e).each(function(){var m=this.key;var n=d(m);AJS.$.ajax({url:n,success:f,error:function(p){var o=AJS.$(".unknown-jira-issue."+m);o.removeClass("single-issue-oauth");AJS.$(".oauth-msg",o).remove();o.addClass("jira-error")}})})}}}})};AJS.$(".unknown-jira-issue").each(function(e,f){var d=AJS.$(f);var g=d.attr("data-app-link");var c=d.attr("data-key");AJS.JiraIssues.Remote[g]=AJS.JiraIssues.Remote[g]||[];AJS.JiraIssues.Remote[g].push({key:c})});for(var b in AJS.JiraIssues.Remote){a(b)}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:refresh-resources', location = '/jira/refresh.js' */
(function(b){var c={REFRESH_STATE_STARTED:1,REFRESH_STATE_DONE:2,REFRESH_STATE_FAILED:3,refreshs:[],sortables:[],init:function(){a.getAll().each(function(){c.registerRefresh(this.getRefresh())});b.each(this.refreshs,function(e,f){var g=a.get(f.id);g.getRefreshButton().bind("click",f,c.handleRefreshClick);g.getRefreshLink().bind("click",f,c.handleRefreshClick)});d.getAll().each(function(){c.registerSort(this.getSortable())});b.each(this.sortables,function(f,e){var g=d.get(e.id);g.getHeadersTable().bind("click",e,c.onHeaderClick)})},onHeaderClick:function(j){refeshId=j.data.id;var h="ASC";if(b(this).hasClass("tablesorter-headerAsc")){h="DESC"}var f=b(this).find(".jim-table-header-content").text();var m=b("#refresh-wiki-"+refeshId);var i=m.data("wikimarkup");var g=m.data("pageid");var l=b("#refresh-"+refeshId);var k=new c.Refresh(refeshId,i,g,l.html());var n=a.get(refeshId);n.updateRefreshVisibility(c.REFRESH_STATE_STARTED);c.processRefresh(k,f,h)},replaceRefresh:function(g,e){var f=a.get(g);f.updateRefreshVisibility(c.REFRESH_STATE_DONE);b.each(this.refreshs,function(l,m){if(m.id===g){c.refreshs.splice(l,1);var n=a.get(e);var j=n.getRefresh();c.registerRefresh(j);c.sortables.splice(l,1);var h=d.get(e);var k=h.getSortable();c.registerSort(k);n.getRefreshButton().bind("click",j,c.handleRefreshClick);n.getRefreshLink().bind("click",j,c.handleRefreshClick);h.getHeadersTable().bind("click",k,c.onHeaderClick)}})},registerRefresh:function(e){if(!(e instanceof c.Refresh)){throw "Refresh object must be an instance of RefreshMacro.Refresh"}c.refreshs.push(e)},registerSort:function(e){if(!(e instanceof c.Sortable)){throw "Refresh object must be an instance of RefreshMacro.Refresh"}c.sortables.push(e)},handleRefreshClick:function(h){var f=h.data;var g=a.get(f.id);g.getMacroPanel().html(f.loadingMsg);g.updateRefreshVisibility(c.REFRESH_STATE_STARTED);c.processRefresh(f)},processRefresh:function(g,f,e){var h={};if(arguments.length==1){h={pageId:g.pageId,wikiMarkup:g.wiki}}else{if(arguments.length==3){h={pageId:g.pageId,wikiMarkup:g.wiki,columnName:f,order:e}}}AJS.$.ajax({type:"POST",dataType:"html",url:Confluence.getContextPath()+"/plugins/servlet/jiraRefreshRenderer",data:h,success:function(j){var i=b(j).attr("id");if(i){i=i.replace("refresh-module-","");a.get(g.id).getContentModule().replaceWith(j);new c.CallbackSupport(g).callback(i)}else{new c.CallbackSupport(g).errorHandler(j)}},error:function(j,k,i){new c.CallbackSupport(g).errorHandler(i)}})}};c.Refresh=function(f,e){this.id=f;this.wiki=e;this.pageId=arguments.length>2?arguments[2]:null;this.loadingMsg=arguments.length>3?arguments[3]:null};c.CallbackSupport=function(e){this.refresh=e;this.module=b("#refresh-module-"+e.id)};c.CallbackSupport.prototype={errorHandler:function(f){var g=a.get(this.refresh.id);var e="Refresh didn\'t work. Try again or click an issue to see it in JIRA.";g.getErrorMessagePanel().html(e);g.updateRefreshVisibility(c.REFRESH_STATE_FAILED)},callback:function(e){c.replaceRefresh(this.refresh.id,e)}};var a=function(){if(arguments.length==1){this.id=arguments[0]}};var d=function(){if(arguments.length==1){this.id=arguments[0]}};a.prototype.getRefresh=function(){return new c.Refresh(this.id,this.getWikiMarkup(),this.getPageId(),this.getMacroPanel().html())};d.prototype.getSortable=function(){return new c.Sortable(this.id,b("#refresh-page-id-"+this.id).val(),b("#refresh-"+this.id).html())};a.get=function(f){var e=b("#refresh-"+f);if(!e){return null}return new a(f)};d.get=function(f){var e=b("#refresh-"+f);if(!e){return null}return new d(f)};c.Sortable=function(g,e,f){this.id=g;this.pageId=e;this.loadingMsg=f};d.getAll=function(){return b("div.refresh-macro").map(function(){var e=this.id.replace("refresh-","");return d.get(e)})};a.getAll=function(){return b("div.refresh-macro").map(function(){var e=this.id.replace("refresh-","");return a.get(e)})};a.prototype.getErrorMessagePanel=function(){return b("#error-message-"+this.id)};a.prototype.removeDarkLayer=function(){b("#jim-dark-layout-"+this.id).remove()};a.prototype.displayDarkLayer=function(){var f=b("#refresh-module-"+this.id);var e=f.position();b("<div />",{id:"jim-dark-layout-"+this.id,"class":"jim-sortable-dark-layout",css:{top:e.top+"px",left:e.left+"px",width:f.width()+"px",height:f.height()+"px"}}).appendTo(f.parent())};a.prototype.getMacroPanel=function(){return b("#refresh-"+this.id)};d.prototype.getMacroPanel=function(){return b("#refresh-"+this.id).val()};a.prototype.getContentModule=function(){return b("#refresh-module-"+this.id)};a.prototype.getPageId=function(){return b("#refresh-wiki-"+this.id).data("pageid")};d.prototype.getPageId=function(){return b("#refresh-wiki-"+this.id).data("pageid")};a.prototype.getWikiMarkup=function(){return b("#refresh-wiki-"+this.id).data("wikimarkup")};a.prototype.getRefreshButton=function(){return b("#refresh-issues-button-"+this.id)};d.prototype.getHeadersTable=function(){return b("#jira-issues-"+this.id+" .jira-tablesorter-header")};a.prototype.getRefreshLink=function(){return b("#refresh-issues-link-"+this.id)};a.prototype.getJiraIssuesArea=function(){return b("#jira-issues-"+this.id)};a.prototype.getIssuesCountArea=function(){return b("#total-issues-count-"+this.id)};a.prototype.updateRefreshVisibility=function(e){if(e===c.REFRESH_STATE_STARTED){this.displayDarkLayer();this.getErrorMessagePanel().addClass("hidden")}else{if(e===c.REFRESH_STATE_FAILED){this.getRefreshButton().show();this.getRefreshLink().show();this.removeDarkLayer();this.getErrorMessagePanel().removeClass("hidden")}else{if(e===c.REFRESH_STATE_DONE){this.removeDarkLayer()}}}};b(function(){c.init()})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:web-resources', location = 'templates/extra/jira/jiraIssues.js' */
jQuery(document).ready(function(){var a=jQuery.extend(window.JiraIssues||{},{ADG_ENABLED:AJS.Meta.getNumber("build-number")>=4000,ADG_FONT_SIZE_OVER_FLEXIGRID_FONT_SIZE_RATIO:14/11,fixMenusShowingUnderWidgetInIE:function(){if(jQuery.browser.msie){jQuery("ul.ajs-menu-bar li.ajs-menu-item").each(function(){jQuery(this).hover(function(){jQuery("div.ajs-drop-down",jQuery(this)).parents().each(function(){var c=jQuery(this);var b=c.css("position");if(b&&b!="auto"){c.addClass("ajs-menu-bar-z-index-fix-for-ie")}})},function(){jQuery("div.ajs-drop-down",jQuery(this)).parents().removeClass("ajs-menu-bar-z-index-fix-for-ie")})})}},onSuccessFunction:function(d){if(!jQuery("fieldset input[name='height']",d).length){var b=jQuery(".bDiv table[id^='jiraissues_table']",d)[0];var e=b.grid;var c=b.clientHeight+jQuery(".hDiv",d)[0].clientHeight;jQuery(".bDiv",d).css("height",c+"px");e.options.height=c;e.fixHeight(c)}},onErrorFunction:function(h,c,b,n,f){var o=jQuery("#"+c);var g=b+": ";if(n.status=="200"){g+=f}else{g+=n.responseText}var i=n.getResponseHeader("WWW-Authenticate")||"";if(n.status=="401"&&i.indexOf("OAuth")!=-1){var m=/OAuth realm\=\"([^\"]+)\"/;var e=m.exec(i);if(e){o.empty();a.bigMessageFunction(c,'<a class="oauth-init" href="'+e[1]+'">'+"Authenticate"+"</a> "+"to retrieve your issues"+"</span>");jQuery(".bmDiv",h).css({"z-index":2});var j={onSuccess:function(){window.location.reload()},onFailure:function(){}};var l=jQuery(".oauth-init",o.parent());var d=l.attr("href");l.click(function(p){AppLinks.authenticateRemoteCredentials(d,j.onSuccess,j.onFailure);p.preventDefault()});AJS.$(".gBlock").remove()}}else{if(n.status=="400"){a.bigMessageFunction(c,"The JIRA server was not able to process the search. This may indicate a problem with the syntax of this macro. Alternatively, if this table is requesting specific issue keys, you may not have permission to view one of these issues. ")}else{var k=jQuery("iframe.jiraissues_errorMsgSandbox",h);k.load(function(){var r=this.contentWindow||this.contentDocument;var q=jQuery((r.document?r.document:r).body);jQuery("a",q).each(function(){this.target="_top"});jQuery(".pPageStat",h).empty().text(q.text());var p=jQuery("div.bmDiv",h)[0];k.removeClass("hidden");k.css({height:p.clientHeight+"px",width:p.clientWidth+"px"})});k[0].src=jQuery("fieldset input[name='retrieverUrlHtml']",h).val();a.bigMessageFunction(c,k)}}jQuery(h).find(".pReload").removeClass("loading");o[0].grid.loading=false;jQuery(h).find(".pButton").each(function(){jQuery(this).removeClass("pBtnOver");jQuery(this).css({cursor:"default",opacity:"0.3"})});jQuery(h).find("span.pcontrol input").attr("readonly","true")},onReloadFunction:function(b,d,c){jQuery(".bmDiv",d).remove();jQuery(".bmDistance",d).remove();c.onSubmit=function(){a.reloadOnSubmitFunction(b,c);return true}},reloadOnSubmitFunction:function(b,c){c.params=[{name:"useCache",value:false}];c.onSubmit=function(){a.onSubmitFunction(b,c);return true}},onSubmitFunction:function(b,c){c.params=[{name:"useCache",value:b}]},showTrustWarningsFunction:function(d,c){var b=jQuery(d).children(".trusted_warnings");if(c.trustedMessage){b.find("td:last").html(c.trustedMessage);b.css("display","block")}else{b.css("display","none")}},preProcessFunction:function(e,b,d,c,f){if(d){a.showTrustWarningsFunction(e,c)}if(c.total==0){jQuery(".pPageStat",e).html(f);a.bigMessageFunction(b,f);jQuery(".pReload",e).removeClass("loading");return}},bigMessageFunction:function(e,f){var d=jQuery("<div></div>");var b=jQuery("<div></div>");d.addClass("bmDistance");b.addClass("bmDiv");if(typeof f=="string"){b.html("<p><strong>"+f+"</strong></p>")}else{f.appendTo(b)}var c=jQuery("#"+e);c.after(b).after(d)},getParamsFrom:function(c){var b={};c.children("input").each(function(){b[jQuery(this).attr("name")]=jQuery(this).attr("value")});return b},initializeColumnWidth:function(f,p){var d={},m=function(i){return a.ADG_ENABLED?Math.round(i*a.ADG_FONT_SIZE_OVER_FLEXIGRID_FONT_SIZE_RATIO):i};if(!(p&&p.length)){return d}var h=37,n=11,k=f.width()-(h+(p.length*n)),j=false,q=false,o=0,c=m(140);for(var l=0,e=p.length;l<e;l++){var g=p[l].name;switch(g){case"summary":j=true;o++;break;case"description":q=true;o++;break;case"type":o++;d[g]=30;k-=30;break;case"priority":o++;d[g]=50;k-=50;break;case"status":o++;d[g]=m(100);k-=m(100);break;case"key":o++;d[g]=m(90);k-=m(90);break;case"comments":case"attachments":case"version":case"component":case"resolution":o++;d[g]=m(80);k-=m(80);break;default:d[g]=c}}if(j||q){k-=(c*(p.length-o));var b=250;if(j&&q){d.summary=Math.max(k/2,b);d.description=Math.max(k/2,b)}else{if(j){d.summary=Math.max(k,b)}else{d.description=Math.max(k,b)}}}else{if(!j&&!q&&(p.length>o)){c=k/(p.length-o);for(l=0;l<e;l++){if(!{resolution:true,key:true,type:true,priority:true,status:true}[p[l]]){d[p[l]]=c}}}}return d}});a.fixMenusShowingUnderWidgetInIE();jQuery(".jiraissues_table").each(function(f,j){var k=jQuery(j),h=k.children("fieldset"),e=a.getParamsFrom(h),c="jiraissues_table_"+f;k.append('<table id="'+c+'" style="display:none"></table>');k.css("width",e.width);var d=[];h.children(".columns").each(function(l){var m=jQuery(this).hasClass("nowrap");d[l]={display:this.name,name:this.value,nowrap:m,sortable:true,align:"left"}});var b=a.initializeColumnWidth(k,d);jQuery.each(d,function(l,m){m.width=b[m.name]});var g=jQuery("<div></div>");jQuery("<a></a>").attr({rel:"nofollow",href:e.clickableUrl}).text(e.title).appendTo(g);jQuery("#"+c).flexigrid({url:e.retrieverUrlHtml,method:"GET",dataType:"json",colModel:d,sortname:e.sortField,sortorder:e.sortOrder,usepager:true,title:g.html(),page:parseInt(e.requestedPage,10),useRp:false,rp:parseInt(e.resultsPerPage,10),showTableToggleBtn:true,height:(function(){return e.height?parseInt(e.height,10):480})(),onSuccess:function(){a.onSuccessFunction(j)},onSubmit:function(){a.onSubmitFunction(e.useCache,this);return true},preProcess:function(i){a.preProcessFunction(j,c,e.showTrustWarnings,i,e.nomsg);return i},onError:function(m,l,i){a.onErrorFunction(j,c,e.jiraissuesError,m,l,i)},onReload:function(){a.onReloadFunction(e.useCache,j,this);return true},errormsg:e.errormsg,pagestat:e.pagestat,procmsg:e.procmsg,nomsg:e.nomsg})});jQuery(".jiraissues_count").each(function(b,d){var c=jQuery(d);jQuery.ajax({cache:false,type:"GET",url:c.find(".url").text(),data:{useCache:c.find(".use-cache").text(),rp:c.find(".rp").text(),showCount:"true"},success:function(f){var e=c.find(".result");if(f>1){e.text(AJS.format("{0} issues",f))}else{e.text(AJS.format("{0} issue",f))}e.removeClass("hidden");jQuery(".calculating, .error, .data",c).remove()},error:function(h){var f=jQuery(".error",c).removeClass("hidden"),g=h.getResponseHeader("WWW-Authenticate")||"",j=false;if(h.status===401&&g.indexOf("OAuth")!=-1){var e=/OAuth realm\=\"([^\"]+)\"/,i=e.exec(g);if(i){f.empty().append(AJS.$("<a/>",{href:i[1],"class":"oauth-init"}).text("Authenticate").click(function(){AppLinks.authenticateRemoteCredentials(i[1],function(){window.location.reload()},function(){});return false})).append(AJS.$("<span/>",{text:" "+"to retrieve your issues"}));j=true}}if(!j){f.text(AJS.format(f.text(),h.status))}jQuery(".calculating, .result, .data",c).remove()}})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'templates/recently.soy' */
// This file was automatically generated from recently.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace RY.Templates.
 */

if (typeof RY == 'undefined') { var RY = {}; }
if (typeof RY.Templates == 'undefined') { RY.Templates = {}; }


RY.Templates.body = function(opt_data, opt_ignored) {
  return '<div id="recently-viewed" class="aui-group"><div class="aui-item"><div class="top"><div class="filter"><form class="aui"><input class="filter-input text" type="text" placeholder="' + soy.$$escapeHtmlAttribute("Filter") + '"></form></div></div><div class="pages"></div></div></div>';
};
if (goog.DEBUG) {
  RY.Templates.body.soyTemplateName = 'RY.Templates.body';
}


RY.Templates.pageCollection = function(opt_data, opt_ignored) {
  return '<div class="groups"></div><div class="empty"></div>';
};
if (goog.DEBUG) {
  RY.Templates.pageCollection.soyTemplateName = 'RY.Templates.pageCollection';
}


RY.Templates.pageGroup = function(opt_data, opt_ignored) {
  return '<h3>' + soy.$$escapeHtml(opt_data.title) + '</h3><ul/>';
};
if (goog.DEBUG) {
  RY.Templates.pageGroup.soyTemplateName = 'RY.Templates.pageGroup';
}


RY.Templates.pageItem = function(opt_data, opt_ignored) {
  return '<div class="page-icon"><a href=' + soy.$$escapeHtmlAttributeNospace(soy.$$filterNormalizeUri(opt_data.href)) + ' class="icon icon-' + soy.$$escapeHtmlAttribute(opt_data.type) + '"></a></div><div class="page-title"><a class="ellipsis" href=' + soy.$$escapeHtmlAttributeNospace(soy.$$filterNormalizeUri(opt_data.href)) + '>' + soy.$$escapeHtml(opt_data.title) + ' - ' + soy.$$escapeHtml(opt_data.space) + '</a></div>';
};
if (goog.DEBUG) {
  RY.Templates.pageItem.soyTemplateName = 'RY.Templates.pageItem';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/util.js' */
var RY=RY||{};(function(){var b=new Date();var c=new Date(b).getTime();var a=new Date(b.getFullYear(),b.getMonth(),b.getDate()).getTime();var d=new Date(b.getFullYear(),b.getMonth(),b.getDate()-1).getTime();RY.util=RY.Util={analytics:{trackDialogOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-dialog-open"})},trackPageOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-page-open"})}},quote:function(e){return(e).replace(/([.?*+^$[\]\\(){}|-])/g,"\\$1")},diffInDays:function(g,f){var e=1000*60*60*24;return Math.floor((g-f)/e)},daysSince:function(e){if(e>=a){return 0}else{if(e>=d){return 1}else{return RY.util.diffInDays(c,e)}}},wait:function(h,j,f){var i,k,e;var g=function(){k=setTimeout(function(){h.apply(f,e)},j)};return function(){e=arguments;var l=new Date();if(i&&l-i<j){clearTimeout(k)}g();i=l}}}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/page-storage.js' */
var RY=RY||{};RY.RecentPageStorage=function(h){var f="com.atlassian.confluence.plugins.recently.viewed.pages.v1";var d=100;var c={};var b=function(){var i=function(k,l){if(k==="lastSeen"&&_.isString(l)){if(AJS.$.browser.msie){l=l.replace(/\-/g,"/");l=l.replace(/T.*$/,"")}return new Date(l).getTime()}else{return l}};try{c=JSON.parse(h.getItem(f),i)||{}}catch(j){c={}}return c};var g=function(){var i=_.values(c);var k=i.length-d;if(k>0){var j=_.sortBy(i,function(l){return l.lastSeen});_.times(k,function(){var l=j.shift();delete c[l.id]})}};var e=function(){g();try{h.setItem(f,JSON.stringify(c))}catch(i){}};this.addCurrentPage=function(i){if(!(i.id&&i.title)){return}b();a(i);e()};var a=function(i){var j=c[i.id];if(!j){c[i.id]=j={}}j=_.extend(j,i);j.lastSeen=new Date().getTime();j.count=j.count+1||1};this.getPages=function(){return _.values(b())}};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/filter.js' */
var RY=RY||{};RY.FilterView=Backbone.View.extend({className:"filter",events:{"input .filter-input":"onInput","keyup .filter-input":"onInput","keydown .filter-input":"onKeydown"},initialize:function(){_.bindAll(this,"render","onInput","onKeydown","search");this.navigationEvents=this.options.navigationEvents;this.onInput=RY.util.wait(this.onInput,100,this)},render:function(){this.$input=this.$(".filter-input");return this},onInput:function(a){if(a&&_.contains([37,38,39,40],a.which)){return}this.search()},onKeydown:function(a){switch(a.which){case 13:this.navigationEvents.trigger("select");a.preventDefault();a.stopPropagation();break;case 38:this.navigationEvents.trigger("previous");a.preventDefault();break;case 40:this.navigationEvents.trigger("next");a.preventDefault();break}},search:function(){var a=this.$input.val();this.collection.search(a)}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/page-model.js' */
var RY=RY||{};(function(){var a;if(typeof ConfluenceMobile!="undefined"){a=ConfluenceMobile.AppData.get("confluence-context-path")}else{a=AJS.contextPath()}RY.Page=Backbone.Model.extend({href:function(){return a+this.get("url")},daysSinceLastSeen:function(){return RY.util.daysSince(this.get("lastSeen"))}});RY.PageCollection=Backbone.Collection.extend({model:RY.Page,url:a+"/rest/recentlyviewed/1.0/recent",search:function(c){var b;if(this._queryLength(c)===0){b=this.models}else{var d=c.match(/[^\s-]+/g);b=this.filter(function(g){var h=g.get("title");var f=g.get("space");var e=(h+f).toLowerCase();return _.all(d,function(i){return e.indexOf(i.toLowerCase())!==-1})})}this.trigger("filter",b,c);return b},_queryLength:function(b){if(!String.prototype.trim){return AJS.$.trim(b).length}return b.trim().length},comparator:function(b){return -(b.get("lastSeen"))}})})();
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/page.js' */
var RY=RY||{};RY.PageView=Backbone.View.extend({tagName:"li",className:"ry-page",template:RY.Templates.pageItem,initialize:function(){_.bindAll(this,"hide","show","render")},hide:function(){this.$el.hide().removeClass("shown")},show:function(){this.$el.show().addClass("shown")},render:function(){var a=this.model.toJSON();a.href=this.model.href();this.$el.html(this.template(a));return this}});RY.PageGroupView=Backbone.View.extend({className:"group",template:RY.Templates.pageGroup,initialize:function(){_.bindAll(this,"hide","hideAll","show","showBorder","showPages","add","render");this.title=this.options.title;this.modelViews={}},hide:function(){this.$el.hide()},hideAll:function(){this.$el.removeClass("border").hide();_.invoke(_.values(this.modelViews),"hide")},show:function(){this.$el.show()},showBorder:function(){this.$el.addClass("border")},showPages:function(a){var c=this;var b=false;_.each(a,function(e){var d=c.modelViews[e.cid];if(d){b=true;d.show()}});if(b){this.show()}return b},add:function(b){var a=new RY.PageView({model:b});this.modelViews[b.cid]=a;this.$list.append(a.render().el)},render:function(){this.$el.html(this.template({title:this.title}));this.$list=this.$("ul");return this}});RY.PageNavigator=function(a,e,c){var g=null;function f(){return a.find("li.shown")}function b(i){pageItems=f();var h=pageItems.index(pageItems.filter(".highlight"));if(g){g.removeClass("highlight")}i+=h;if(i<0){i=pageItems.length-1}if(i>=pageItems.length){i=0}g=pageItems.eq(i);g.addClass("highlight")}function d(){if(!g.length){return}var k=e;var l=k.children();var j=k.height();var i=g.outerHeight(true);var h=g.position().top;if(h<0){if(f().index(g)===0){k.scrollTop(0);return}k.scrollTop(g.offset().top-l.offset().top)}else{if(h>j){k.scrollTop(g.offset().top-l.offset().top-j+i)}}}c.on("select",function(){if(g&&g.is(":visible")){RY.util.analytics.trackPageOpen();var h=g.find(".page-title a").attr("href");window.location=h}},this);c.on("previous",function(){b(-1);d()},this);c.on("next",function(){b(1);d()},this)};RY.PageCollectionView=Backbone.View.extend({template:RY.Templates.pageCollection,events:{"click .page-title a":RY.util.analytics.trackPageOpen},initialize:function(){_.bindAll(this,"checkEmpty","filter","_groupForPage","addOne","showEmptyMessage","clearEmptyMessage","addAll","render");this.modelViews={};this.collection.on("reset",this.addAll,this);this.collection.on("add",this.addOne,this);this.collection.on("filter",this.filter,this)},checkEmpty:function(a,e){var f=this.collection.isEmpty();var b=a.length===0;if(f||b){var c;if(f){c="Sorry mate, looks like you haven\'t visited any pages yet."}else{var d=AJS.contextPath()+"/dosearchsite.action?queryString="+encodeURIComponent(e);c="We didn\'t find any matching pages in your history."+" "+AJS.format("\u003ca href=\"{0}\"\u003eClick here\u003c/a\u003e to search for this term instead.",d)}this.showEmptyMessage(c)}else{this.clearEmptyMessage()}},filter:function(b,d){d=d||"";this.checkEmpty(b,d);var a=[this.$today,this.$yesterday,this.$older];_.invoke(a,"hideAll");var c=[];_.each(a,function(f){var e=f.showPages(b);if(e){c.push(f)}});if(c.length>1){c.pop();_.invoke(c,"showBorder")}},_groupForPage:function(a){var b=a.daysSinceLastSeen();if(b===0){return this.$today}else{if(b===1){return this.$yesterday}else{return this.$older}}},addOne:function(a){var b=this._groupForPage(a);b.add(a)},showEmptyMessage:function(a){this.$(".empty").html(AJS.$("<p>").html(a))},clearEmptyMessage:function(){this.$(".empty").html("")},addAll:function(){this.collection.each(this.addOne)},render:function(){this.$el.html(this.template());this.$today=new RY.PageGroupView({title:"Today"});this.$yesterday=new RY.PageGroupView({title:"Yesterday"});this.$older=new RY.PageGroupView({title:"Older"});var a=this.$(".groups");a.append(this.$today.render().el);a.append(this.$yesterday.render().el);a.append(this.$older.render().el);_.invoke([this.$today,this.$yesterday,this.$older],"hideAll");return this}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/quicknav/util.js' */
var RYQ=RYQ||{};(function(){RYQ.util={analytics:{trackQuickNavOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-quicknav-open"})},trackQuickNavPageOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-quicknav-click-page"})},trackQuickNavRecentlyDialogOpen:function(){AJS.trigger("analytics",{name:"recently-viewed-quicknav-click-more-recent"})}}}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:app-resources', location = 'js/quicknav/quicknav.js' */
var RYQ=RYQ||{};RYQ.QuickNavEntry=Backbone.Model.extend({classNameByType:{blogpost:"content-type-blogpost",page:"content-type-page"},parse:function(a){return{className:this.classNameByType[a.type],name:a.title,href:AJS.contextPath()+a.url,id:a.id,spaceName:a.space,lastSeen:a.lastSeen}}},{escape:function(b){var a=_.map(b,_.clone);_.each(a,function(c){c.name=_.escape(c.name);c.spaceName=_.escape(c.spaceName)});return a}});RYQ.QuickNavEntryCollection=Backbone.Collection.extend({model:RYQ.QuickNavEntry,url:AJS.contextPath()+"/rest/recentlyviewed/1.0/recent?limit=8",search:function(b){var a;if(AJS.$.trim(b).length===0){a=this.models}else{var c=b.match(/[^\s-]+/g);a=this.filter(function(e){var f=e.get("name");var d=f.toLowerCase();return _.all(c,function(g){return d.indexOf(g.toLowerCase())!==-1})})}this.trigger("filter",a);return a},comparator:function(a){return -(a.get("lastSeen"))}});(function(a){RYQ.QuickNav=Backbone.View.extend({initialize:function(){this.moreLink={className:"recently-viewed",href:"#",name:"More recently viewed pages..."};this.$input=a("#quick-search-query");this.makeDropdown();this.addShowHideHandlers();this.getHistory=_.once(this._getHistory);_.bindAll(this,"makeDropdown","addSearchResultBoostingHandler","_getHistory","render","addShowHideHandlers","_getItemsToShow","showQuickResults","onQuickSearch")},makeDropdown:function(){var c=function(d){a("a",d).each(function(){var h=a(this);var e=h.find("span");var g=e.data("properties");var f=g?g.spaceName:null;if(f&&!h.is(".content-type-spacedesc")){h.after(h.clone().attr("class","space-name").html(f));h.parent().addClass("with-space-name")}})};var b=this;this.$dropdown=AJS.inputDrivenDropdown({dropdownPlacement:function(d){b.$input.closest("form").find(".quick-nav-drop-down").append(d)},dropdownPostprocess:function(d){c(d)},ajsDropDownOptions:{className:"recently-viewed-dropdown"}})},addSearchResultBoostingHandler:function(){var b=this;a(window).on("quicksearch.ajax-success",function(g,f){var d=f.url.match("/json/contentnamesearch.action");var c=f.url.match(/rest\/quicknav\/\d\/search/);if(d||c){b.onQuickSearch(g,f)}})},_getHistory:function(){return this.collection.fetch().done(this.addSearchResultBoostingHandler)},render:function(){if(!AJS.Meta.get("remote-user")){return}var b=this.getHistory();b.done(_.bind(function(){if(AJS.dropDown.current==null&&this.collection.length!==0&&this.$input.val().length===0){this.showQuickResults()}},this));var c=this.$input;c.trigger("quick-search-loading-start");b.always(function(){c.trigger("quick-search-loading-stop")})},addShowHideHandlers:function(){var b=this;this.$input.on("focus",function(){b.render()}).on("click",function(c){c.stopPropagation();b.render()}).on("keyup",function(f){var c=f.which===27;var g=f.which===13;var d=a(this).val().length!==0;if(d||c){if(b.$dropdown.dd&&b.$dropdown.dd.$.is(":visible")){b.$dropdown.hide()}}else{if(!g){b.render()}}})},_getItemsToShow:function(){var c=this.collection.toJSON();var b=c.length>0&&c[0].id==AJS.Meta.get("page-id");if(b){c.shift()}return c},showQuickResults:function(){var b=RYQ.QuickNavEntry.escape(this._getItemsToShow());this.$dropdown.show([b,[this.moreLink]],"","");a(".recently-viewed-dropdown").on("click",".recently-viewed",function(c){c.preventDefault();a("#view-user-history-link").click();RYQ.util.analytics.trackQuickNavRecentlyDialogOpen()});a(".recently-viewed-dropdown").on("click",".with-space-name",function(c){RYQ.util.analytics.trackQuickNavPageOpen()});RYQ.util.analytics.trackQuickNavOpen()},onQuickSearch:function(l,f){var o=f.json.query;var c=_.map(this.collection.search(o),function(e){return e.attributes});c=RYQ.QuickNavEntry.escape(c);if(c.length==0){return}var m=f.json.contentNameMatches;var p=-1;for(var g=0;g<m.length;g++){var n=m[g][0].className;if(n=="content-type-blogpost"||n=="content-type-page"){p=g;break}}if(p!=-1){var h=m[p];var b=Math.min(h.length>4?2:6-h.length,c.length);h.unshift.apply(h,_(c).first(b));m[p]=_.uniq(h,function(e){return +e.id});if(h.length>6){var k=6-b;for(var d=k;d>0;d--){h.pop()}}}else{m.unshift(_(c).first(6))}}})}(AJS.$));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:main-resources', location = 'js/main.js' */
var RY=RY||{};AJS.toInit(function(a){a("#view-user-history-link").unbind("click");a("#view-user-history-link").click(function(g){g.preventDefault();var c=new AJS.Dialog({width:600,height:500,id:"recently-viewed-dialog",closeOnOutsideClick:true});var f=a(RY.Templates.body());c.addHeader("Recently viewed pages");c.addPanel("SinglePanel",f);c.addLink("Close",function(e){e.hide()});var d=a("<div>",{"class":"dialog-tip"}).text("Hint: type \"g\" and then \"r\" anywhere to quickly open this menu");c.popup.element.find(".dialog-button-panel").append(d);var i=new RY.PageCollection();var b=new RY.PageCollectionView({collection:i});f.find(".pages").html(b.render().el);c.gotoPanel(0);c.show();var h=a("#recently-viewed-dialog").spin("large");i.fetch({success:function(){h.spinStop();var j=_.extend({},Backbone.Events);var k=new RY.PageNavigator(b.$el,f.parent(),j);var e=new RY.FilterView({collection:i,el:f.find(".filter"),navigationEvents:j}).render();e.search()}});RY.util.analytics.trackDialogOpen()})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.recently-viewed-plugin:main-resources', location = 'js/quicknav/main.js' */
var RYQ=RYQ||{};AJS.toInit(function(){var b=new RYQ.QuickNavEntryCollection();var a=new RYQ.QuickNav({collection:b})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacemenu-resources', location = 'js/space-menu.js' */
AJS.toInit(function(a){var d=a(Confluence.Templates.BrowseSpaces.spacesLink());a("#space-directory-link").replaceWith(a(d));var b=a("#space-menu-link"),c=function(e){var f=a("#space-menu-link-content");f.html(e.template);if(AJS&&AJS.Confluence&&AJS.Confluence.Analytics&&AJS.Confluence.Analytics.setAnalyticsSource){AJS.Confluence.Analytics.setAnalyticsSource(f.find("a"),"spacemenu")}a("#create-space-header").click(function(){AJS.trigger("analytics",{name:"create-space-from-header"});Confluence.SpaceBlueprint.Dialog.launch();return false})};b.click(function(){if(!a("#space-menu-link-content .aui-dropdown2-section").length){a.ajax({url:Confluence.getContextPath()+"/rest/ia/1.0/spacesmenu",type:"GET",dataType:"json",cache:false,success:c})}return false});a("#space-menu-link-content").on("aui-dropdown2-show",function(){AJS.trigger("analytics",{name:"open-space-menu"})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacemenu-resources', location = 'soy/space-menu.soy' */
// This file was automatically generated from space-menu.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.BrowseSpaces.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.BrowseSpaces == 'undefined') { Confluence.Templates.BrowseSpaces = {}; }


Confluence.Templates.BrowseSpaces.spacesLink = function(opt_data, opt_ignored) {
  return '' + aui.dropdown2.trigger({menu: {id: 'space-menu-link-content'}, id: 'space-menu-link', tagName: 'a', extraClasses: 'aui-nav-link', title: "Spaces", showIcon: true, text: "Spaces"}) + aui.dropdown2.contents({id: 'space-menu-link-content', extraClasses: 'aui-style-default aui-dropdown2-in-header'});
};
if (goog.DEBUG) {
  Confluence.Templates.BrowseSpaces.spacesLink.soyTemplateName = 'Confluence.Templates.BrowseSpaces.spacesLink';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:querystring', location = '/includes/js/api/querystring.js' */
define("confluence/api/querystring",[],function(){return{stringify:function(a){var b="",c;for(c in a)for(var d=0;d<a[c].length;d++)b+="&"+c,a[c][d]&&(b+="="+a[c][d]);return b.substring(1)},parse:function(a){var b={};if(a){"?"===a.substr(0,1)&&(a=a.substr(1));for(var a=a.split("&"),c=0;c<a.length;c++){var d=a[c].split("=");b[d[0]]||(b[d[0]]=[]);b[d[0]].push(a[c].substring(d[0].length+1))}}return b}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:url', location = '/includes/js/api/url.js' */
define("confluence/api/url",["confluence/api/querystring","jquery"],function(d,e){var g=/([^\?|#]+)[\?]?([^#]*)[#]?(.*)/,f=["source","urlPath","queryParams","anchor"];return{parse:function(a){var b={};if(a=g.exec(a)){for(var c=0;c<f.length;c++)b[f[c]]=a[c];b.queryParams=d.parse(b.queryParams)}return b},format:function(a){return e.isEmptyObject(a)?"":(!a.urlPath?"":a.urlPath)+(e.isEmptyObject(a.queryParams)?"":"?"+d.stringify(a.queryParams))+(!a.anchor?"":"#"+a.anchor)}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:analytics-support', location = '/includes/js/analytics-support.js' */
define("confluence/analytics-support","jquery ajs confluence/meta window document confluence/api/url".split(" "),function(j,o,n,k,l,h){var b={},m;b.setAnalyticsSource=function(a,d){if(typeof m==="undefined"){var c=j._data(k,"events");m=c&&c.analytics&&c.analytics.length>0}m&&a.attr("href",function(a,c){var b=encodeURIComponent(d),g=h.parse(c);if(!j.isEmptyObject(g))g.queryParams.src=[b];return h.format(g)})};b.srcRemovedUrl=function(a){a=h.parse(a);delete a.queryParams.src;for(var d=Object.keys(a.queryParams),
c=0;c<d.length;c++){var b=d[c],f=b.split(".");f.length===3&&f[0]==="src"&&delete a.queryParams[b];b==="jwt"&&delete a.queryParams[b]}return h.format(a)};b.srcParamValues=function(a){return(a=h.parse(a).queryParams)&&a.src?a.src:[]};b.srcAttrParamValues=function(a){for(var a=h.parse(a).queryParams,b={},c=Object.keys(a),e=0;e<c.length;e++){var f=c[e],i=f.split(".");if(i.length===3&&i[0]==="src"){var g=i[1],i=i[2];b[g]=b[g]||{};b[g][i]=decodeURIComponent(a[f][0])}}return b};b.extractAnalyticsData=function(a){for(var d=
[],c=b.srcParamValues(a),a=b.srcAttrParamValues(a),e=0;e<c.length;e++){var f=c[e];d.push({src:f,attr:a[f]||{}})}return d};b.publish=function(a,b){o.trigger("analytics",{name:a,data:b||{}})};b.init=function(){var a=b.extractAnalyticsData(l.URL),d={userKey:n.get("remote-user-key"),pageID:n.get("page-id")};if(a.length>0){for(var c=0;c<a.length;c++){var e=a[c],f=j.extend({},d,e.attr);b.publish("confluence.viewpage.src."+e.src,f)}if(k.history&&k.history.replaceState){a=b.srcRemovedUrl(l.URL);l.URL!==a&&
k.history.replaceState(null,"",a)}}else b.publish("confluence.viewpage.src.empty",d)};return b});require("confluence/module-exporter").exportModuleAsGlobal("confluence/analytics-support","AJS.Confluence.Analytics",function(j){require("ajs").toInit(j.init)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:space-ia-analytics', location = 'js/space-ia-analytics.js' */
(function(b){var c=AJS.Confluence.Analytics.setAnalyticsSource;function d(){var g=b(".acs-side-bar");var f=g.find("a:not(.external_link a, #acs-configure-link)");c(f,"sidebar");var e=g.find(".quick-links-section li:not(.external_link) a");c(e,"spaceshortcut");var h=g.find(".ia-secondary-container a:not(.more-children-link)");if(g.find(".ia-secondary-container").data("tree-type")=="pages"){c(h,"contextnavchildmode")}else{if(g.find(".ia-secondary-container").data("tree-type")=="page-tree"){c(h,"contextnavpagetreemode")}else{c(h,"contextnav")}}}function a(e){return function(){AJS.trigger("analytics",{name:"space-ia-nav",data:{linkType:e}})}}AJS.toInit(function(e){e(".acs-side-bar").find(".ia-secondary-container .more-children-link").click(a("context-nav.more-children"));AJS.bind("sidebar.exit-configure-mode",d);AJS.bind("sidebar.flyout-triggered",function(g,f){a("flyout-triggered."+f.flyout)()});AJS.bind("pagetree-children-loaded",d);d()})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.aui.staging:persistable', location = 'js/persistable.js' */
define("confluence/persistable",["skate","confluence/storage-manager"],function(f,g){var d=g("confluence","userSettings");return f("data-persist",{type:f.types.ATTRIBUTE,ready:function(b){if(!b.name)throw'Missing attribute "name"';var c=b.getAttribute("data-persist"),a=b.getAttribute("data-persist-scope"),a=a?b.name+"."+a.replace(/\./g,"-"):b.name,a=d.getItem(a),e=b.getAttribute("data-default-value");if(/value|checked/.test(c))a=a||e||null,null!==a&&("checked"===c&&(a="true"===a),b[c]=a);else throw"Persistable only works with 'value' or 'checked' attributes!";
},events:{change:function(b){var c=b.getAttribute("data-persist"),a=b.getAttribute("data-persist-scope"),a=a?b.name+"."+a.replace(/\./g,"-"):b.name,e=b.getAttribute("data-default-value");String(b[c])===e?d.removeItem(a):d.setItem(a,b[c],2592E3)}}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-feature-discovery-plugin:confluence-feature-discovery-plugin-resources', location = '/js/confluence-feature-discovery-plugin.js' */
(function(f){Confluence.FeatureDiscovery={};var c,e=false,i=3;var d="com.atlassian.confluence.plugins.confluence-feature-discovery-plugin";var g=d+":confluence-feature-discovery-plugin-resources.test-mode";var a=WRM.data.claim(g);function j(k){if(c===undefined){c=JSON.parse(AJS.Meta.get("discovered-plugin-features")||"{}")}if(k){return c[k]||[]}return c}function b(m,o){var n=j(m);for(var l=0,k=n.length;l<k;l++){if(n[l]==o){return true}}return false}function h(n,p){var l="com.atlassian.webdriver.discovery="+n+":"+p;var k=document.cookie.split(";");for(var m=0;m<k.length;m++){var o=k[m];while(o.charAt(0)==" "){o=o.substring(1)}if(o.indexOf(l)!=-1){return true}}return false}Confluence.FeatureDiscovery.forPlugin=function(m,l){var p=Confluence.storageManager("feature-discovery."+m);l=l||i;function o(r){var q=parseInt(p.getItem(r),10);return isNaN(q)?0:q}function n(r,q){return p.setItem(r,q)}function k(q){return p.removeItem(q)}return{addDiscoveryView:function(q){n(q,o(q)+1)},shouldShow:function(r,q){if(q===true&&a&&!h(m,r)){return false}if(e||b(m,r)){return false}if(o(r)>=l){this.markDiscovered(r);return false}e=true;return true},markDiscovered:function(r,q){if(b(m,r)){return}AJS.safeAjax({url:AJS.contextPath()+"/rest/feature-discovery/1.0/discovered/"+m+"/"+r,type:"POST",data:{},success:function(){j(m).unshift(r);k(r);AJS.trigger("feature-discovered",{pluginKey:m,featureKey:r});if(q&&f.isFunction(q)){q()}}})},listDiscovered:function(){return j(m).slice(0)}}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.support.stp:stp-license-status-resources', location = 'js/stp-licenseStatus.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-license-banner:confluence-license-banner-resources', location = '/js/confluence-license-banner.js' */
require(["ajs","jquery"],function(a,b){a.toInit(function(){var d=WRM.data.claim("com.atlassian.confluence.plugins.confluence-license-banner:confluence-license-banner-resources.license-details");if(!d){a.warn("Unable to claim my required data");return}var c={destroyBanner:function(){b("#license-banner").slideUp(function(){b("#license-banner").remove()})},remindMeLater:function(){b.ajax({type:"POST",dataType:"json",contentType:"application/json; charset=utf-8",data:JSON.stringify({atl_token:a.Meta.get("atl-token")}),url:a.contextPath()+"/rest/licensebanner/1.0/reminder/later"});c.destroyBanner()},remindMeNever:function(){b.ajax({type:"POST",dataType:"json",contentType:"application/json; charset=utf-8",data:JSON.stringify({atl_token:a.Meta.get("atl-token")}),url:a.contextPath()+"/rest/licensebanner/1.0/reminder/never"});c.destroyBanner()},createBanner:function(g){var e;if(g.showLicenseExpiryBanner){e=Confluence.Templates.LicenseBanner.expiryBanner({days:g.daysBeforeLicenseExpiry,mac:g.renewUrl,sales:g.salesEmail})}else{if(g.showMaintenanceExpiryBanner){e=Confluence.Templates.LicenseBanner.maintenanceBanner({days:g.daysBeforeMaintenanceExpiry,mac:g.renewUrl,sales:g.salesEmail})}}if(e){var f=b(e);b("#full-height-container").prepend(f);b("#license-banner-later").click(function(h){h.preventDefault();c.remindMeLater()});b("#license-banner-never").click(function(h){h.preventDefault();c.remindMeNever()});f.find(".icon-close").click(function(h){h.preventDefault();c.remindMeLater()})}}};c.createBanner(d)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-license-banner:confluence-license-banner-resources', location = 'soy/confluence-license-banner.soy' */
// This file was automatically generated from confluence-license-banner.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.LicenseBanner.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.LicenseBanner == 'undefined') { Confluence.Templates.LicenseBanner = {}; }


Confluence.Templates.LicenseBanner.wrapper = function(opt_data, opt_ignored) {
  return '<div>' + soy.$$filterNoAutoescape(opt_data.contentHTML) + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.LicenseBanner.wrapper.soyTemplateName = 'Confluence.Templates.LicenseBanner.wrapper';
}


Confluence.Templates.LicenseBanner.expiryBanner = function(opt_data, opt_ignored) {
  var output = '';
  var renewTag__soy8 = '<a id="license-banner-my-link" target="_blank" href="' + soy.$$escapeHtml(opt_data.mac) + '">';
  var end__soy12 = '</a>';
  var mailTag__soy14 = '<a id="license-banner-sales-link" href="mailto:' + soy.$$escapeHtml(opt_data.sales) + '">';
  output += Confluence.Templates.LicenseBanner.wrapper({contentHTML: '' + aui.message.warning({content: '<div id="license-banner-content" data-days="' + soy.$$escapeHtml(opt_data.days) + '" data-subscription="true">' + ((opt_data.days < 0) ? soy.$$filterNoAutoescape(AJS.format("Your license subscription has expired. This instance is now read-only. Please renew {0}online{1} or contact {2}sales{3}.",renewTag__soy8,end__soy12,mailTag__soy14,end__soy12)) : (opt_data.days == 0) ? soy.$$filterNoAutoescape(AJS.format("Your license subscription will expire today and Confluence will become read-only. Please renew {0}online{1} or contact {2}sales{3}.",renewTag__soy8,end__soy12,mailTag__soy14,end__soy12)) : soy.$$filterNoAutoescape(AJS.format("Your license subscription will expire in {0,choice,1#{0} day|1\x3c{0} days}. Confluence will become read-only after the expiry. Please renew {1}online{2} or contact {3}sales{4}.",opt_data.days,renewTag__soy8,end__soy12,mailTag__soy14,end__soy12))) + '</div>', isCloseable: opt_data.days > 7, id: 'license-banner'})});
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.LicenseBanner.expiryBanner.soyTemplateName = 'Confluence.Templates.LicenseBanner.expiryBanner';
}


Confluence.Templates.LicenseBanner.maintenanceBanner = function(opt_data, opt_ignored) {
  var output = '';
  var renewTag__soy39 = '<a id="license-banner-my-link" target="_blank" href="' + soy.$$escapeHtml(opt_data.mac) + '">';
  var end__soy43 = '</a>';
  var later__soy45 = '<a href="#" id="license-banner-later">';
  var never__soy47 = '<a href="#" id="license-banner-never">';
  output += Confluence.Templates.LicenseBanner.wrapper({contentHTML: '' + aui.message.warning({content: '<div id="license-banner-content" data-days="' + soy.$$escapeHtml(opt_data.days) + '" data-subscription="false">' + ((opt_data.days < 0) ? soy.$$filterNoAutoescape(AJS.format("You no longer have access Support and Updates. {0}Renew online{1}, {2}remind me later{3} or {4}never remind me again{5}.",renewTag__soy39,end__soy43,later__soy45,end__soy43,never__soy47,end__soy43)) : (opt_data.days == 0) ? soy.$$filterNoAutoescape(AJS.format("You will lose access to Support and Updates today. {0}Renew online{1}, {2}remind me later{3} or {4}never remind me again{5}.",renewTag__soy39,end__soy43,later__soy45,end__soy43,never__soy47,end__soy43)) : soy.$$filterNoAutoescape(AJS.format("You will lose access to Support and Updates in {0,choice,1#{0} day|1\x3c{0} days}. {1}Renew online{2}, {3}remind me later{4} or {5}never remind me again{6}.",opt_data.days,renewTag__soy39,end__soy43,later__soy45,end__soy43,never__soy47,end__soy43))) + '</div>', id: 'license-banner'})});
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.LicenseBanner.maintenanceBanner.soyTemplateName = 'Confluence.Templates.LicenseBanner.maintenanceBanner';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-user-rest:crowd-aggregation-warning', location = '/aggregation/js/directory-aggregation-warning.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-user-rest:crowd-aggregation-warning', location = 'aggregation/soy/directory-aggregation-warning.soy' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.adaptavist.confluence.contentFormattingMacros:clickable-resources', location = 'js/clickable.js' */
jQuery(function(a){a(".clickable").live("click",function(c){if(a(c.target).closest("a[href]").length===0&&a(c.target).closest(".clickable").length===1){var b=a(this).attr("href")||a("a[href]:first",this).attr("href");if(b){location.href=b}}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher.soy' */
// This file was automatically generated from appswitcher.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace navlinks.templates.appswitcher.
 */

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.appswitcher == 'undefined') { navlinks.templates.appswitcher = {}; }


navlinks.templates.appswitcher.linkSection = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.list.length > 0) {
    output += '<div class="aui-nav-heading sidebar-section-header">' + soy.$$escapeHtml(opt_data.title) + '</div><ul class="aui-nav nav-links">';
    var linkList8 = opt_data.list;
    var linkListLen8 = linkList8.length;
    for (var linkIndex8 = 0; linkIndex8 < linkListLen8; linkIndex8++) {
      var linkData8 = linkList8[linkIndex8];
      output += navlinks.templates.appswitcher.applicationsItem(linkData8);
    }
    output += '</ul>';
  }
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.linkSection.soyTemplateName = 'navlinks.templates.appswitcher.linkSection';
}


navlinks.templates.appswitcher.applicationsItem = function(opt_data, opt_ignored) {
  return '<li class="nav-link"><a href="' + soy.$$escapeHtml(opt_data.link) + '" ' + ((opt_data.self) ? 'class="checked"' : '') + ' title="' + soy.$$escapeHtml(opt_data.link) + '"><span class="nav-link-label">' + soy.$$escapeHtml(opt_data.label) + '</span></a></li>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.applicationsItem.soyTemplateName = 'navlinks.templates.appswitcher.applicationsItem';
}


navlinks.templates.appswitcher.shortcutsItem = function(opt_data, opt_ignored) {
  return '<li class="nav-link"><a href="' + soy.$$escapeHtml(opt_data.link) + '" ' + ((opt_data.self) ? 'class="checked"' : '') + ' title="' + soy.$$escapeHtml(opt_data.link) + '"><span class="nav-link-label">' + soy.$$escapeHtml(opt_data.label) + '</span>' + ((opt_data.showDescription && opt_data.description) ? '<span class="nav-link-description">' + soy.$$escapeHtml(opt_data.description) + '</span>' : '') + '</a></li>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.shortcutsItem.soyTemplateName = 'navlinks.templates.appswitcher.shortcutsItem';
}


navlinks.templates.appswitcher.error = function(opt_data, opt_ignored) {
  return '<div class="app-switcher-error">' + soy.$$filterNoAutoescape("Something went wrong, please \x3cspan class\x3d\x22app-switcher-retry\x22\x3etry again\x3c/span\x3e.") + '</div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.error.soyTemplateName = 'navlinks.templates.appswitcher.error';
}


navlinks.templates.appswitcher.sidebarContents = function(opt_data, opt_ignored) {
  return '<div class="aui-page-panel-nav"><nav class="aui-navgroup aui-navgroup-vertical"><div class="app-switcher-section app-switcher-applications"><div class="aui-nav-heading">' + soy.$$escapeHtml("Application Links") + '</div><div class="app-switcher-loading">' + soy.$$filterNoAutoescape("Loading\x26hellip;") + '</div></div><div class="app-switcher-section app-switcher-shortcuts"><div class="aui-nav-heading">' + soy.$$escapeHtml("Shortcuts") + '</div><div class="app-switcher-loading">' + soy.$$filterNoAutoescape("Loading\x26hellip;") + '</div></div></nav></div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.sidebarContents.soyTemplateName = 'navlinks.templates.appswitcher.sidebarContents';
}


navlinks.templates.appswitcher.trigger = function(opt_data, opt_ignored) {
  return '<span class="aui-icon aui-icon-small aui-iconfont-appswitcher">' + soy.$$escapeHtml("Linked Applications") + '</span>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.trigger.soyTemplateName = 'navlinks.templates.appswitcher.trigger';
}


navlinks.templates.appswitcher.projectHeaderSection = function(opt_data, opt_ignored) {
  return '<div class="app-switcher-title">' + aui.avatar.avatar({size: 'large', avatarImageUrl: opt_data.avatarUrl, isProject: true, title: opt_data.name}) + '<div class="sidebar-project-name">' + soy.$$escapeHtml(opt_data.name) + '</div></div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.projectHeaderSection.soyTemplateName = 'navlinks.templates.appswitcher.projectHeaderSection';
}


navlinks.templates.appswitcher.cogDropdown = function(opt_data, opt_ignored) {
  var output = '';
  var dropdownList__soy74 = '' + navlinks.templates.appswitcher.dropdownList({list: opt_data.links});
  output += aui.dropdown2.dropdown2({menu: {id: opt_data.id, content: dropdownList__soy74, extraClasses: 'aui-style-default sidebar-customize-section'}, trigger: {showIcon: false, content: '<span class="aui-icon aui-icon-small aui-iconfont-configure"></span>', container: '#app-switcher'}});
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.cogDropdown.soyTemplateName = 'navlinks.templates.appswitcher.cogDropdown';
}


navlinks.templates.appswitcher.dropdownList = function(opt_data, opt_ignored) {
  var output = '<ul class="sidebar-admin-links">';
  var linkList82 = opt_data.list;
  var linkListLen82 = linkList82.length;
  for (var linkIndex82 = 0; linkIndex82 < linkListLen82; linkIndex82++) {
    var linkData82 = linkList82[linkIndex82];
    output += '<li class="nav-link"><a href="' + soy.$$escapeHtml(linkData82.href) + '" title="' + soy.$$escapeHtml(linkData82.title) + '"><span class="nav-link-label">' + soy.$$escapeHtml(linkData82.label) + '</span></a></li>';
  }
  output += '</ul>';
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.dropdownList.soyTemplateName = 'navlinks.templates.appswitcher.dropdownList';
}


navlinks.templates.appswitcher.switcher = function(opt_data, opt_ignored) {
  var output = '';
  if (true) {
    if (AJS.DarkFeatures.isEnabled('rotp.sidebar')) {
      var sidebarContents__soy97 = '' + navlinks.templates.appswitcher.sidebarContents(null);
      var triggerContent__soy99 = '' + navlinks.templates.appswitcher.trigger(null);
      output += navlinks.templates.appswitcher.sidebar({sidebar: {id: 'app-switcher', content: sidebarContents__soy97}, trigger: {showIcon: false, content: triggerContent__soy99}}) + '<script>\n                (function (NL) {\n                    var initialise = function () {\n                        new NL.SideBar({\n                            sidebarContents: \'#app-switcher\'\n                        });\n                    };\n                    if (NL.SideBar) {\n                        initialise();\n                    } else {\n                        NL.onInit = initialise;\n                    }\n                }(window.NL = (window.NL || {})));\n                window.NL.isUserAdmin = ' + soy.$$escapeHtml(false) + '<\/script>';
    } else {
      output += navlinks.templates.appswitcher_old.switcher(null);
    }
  }
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.switcher.soyTemplateName = 'navlinks.templates.appswitcher.switcher';
}


navlinks.templates.appswitcher.sidebar = function(opt_data, opt_ignored) {
  return '<a href="' + soy.$$escapeHtml(opt_data.sidebar.id) + '" class="sidebar-trigger app-switcher-trigger" aria-owns="' + soy.$$escapeHtml(opt_data.sidebar.id) + '" aria-haspopup="true">' + soy.$$filterNoAutoescape(opt_data.trigger.content) + '</a><div id=' + soy.$$escapeHtml(opt_data.sidebar.id) + ' class="app-switcher-sidebar aui-style-default sidebar-offscreen">' + soy.$$filterNoAutoescape(opt_data.sidebar.content) + '</div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher.sidebar.soyTemplateName = 'navlinks.templates.appswitcher.sidebar';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher.js' */
(function(c,a){a.SideBar=function(d){var e=this;this.$sidebar=null;d=c.extend({sidebarContents:null},d);this.getLinks=function(){return c.ajax({url:AJS.contextPath()+"/rest/menu/latest/appswitcher",cache:false,dataType:"json"}).done(this.updateAppLinks).fail(this.showAppSwitcherError)};this.populateProjectHeader=function(g,f){e.getSidebar().find(".app-switcher-shortcuts .aui-nav-heading").after(navlinks.templates.appswitcher.projectHeaderSection({avatarUrl:f,name:g}))};this.getProjectData=function(){var f=c(".project-shortcut-dialog-trigger"),g=f.data("key"),h=f.data("entity-type");if(f.size()==0||!g||!h){c(".app-switcher-shortcuts").remove();return}var j,i;i=c.ajax({url:AJS.contextPath()+"/rest/project-shortcuts/1.0/local/"+g,cache:false,data:{entityType:h},dataType:"json"});j=c.ajax({url:AJS.contextPath()+"/rest/project-shortcuts/1.0/remote/"+g,cache:false,data:{entityType:h},dataType:"json"});c.when(i,j).then(function(l,k){e.updateProjectShortcuts(l,k,{key:g,entityType:h,name:f.data("name"),avatarUrl:f.find("img").prop("src")})},e.showProjectShortcutsError)};this.getSidebar=function(){if(!this.$sidebar){this.$sidebar=c(d.sidebarContents)}return this.$sidebar};this.addApplicationsCog=function(){c(".app-switcher-applications .aui-nav-heading").before(navlinks.templates.appswitcher.cogDropdown({id:"sidebar-applications-admin-dropdown",links:[{href:AJS.contextPath()+"/plugins/servlet/customize-application-navigator",label:"Customize navigator",title:"Add new entries, hide existing or restrict who sees what"},{href:AJS.contextPath()+"/plugins/servlet/applinks/listApplicationLinks",label:"Manage application links",title:"Link to more Atlassian applications"}]}))};this.addProjectShortcutsCog=function(f,h){var g=[{href:AJS.contextPath()+"/plugins/servlet/custom-content-links-admin?entityKey="+f,label:"Customize shortcuts",title:""}];if(e.entityMappings[h]){g.push({href:e.generateEntityLinksUrl(f,e.entityMappings[h]),label:"Manage product links",title:""})}e.getSidebar().find(".app-switcher-shortcuts .aui-nav-heading").before(navlinks.templates.appswitcher.cogDropdown({id:"sidebar-project-shortcuts-admin-dropdown",links:g}))};this.updateAppLinks=function(f){c(function(){e.getSidebar().find(".app-switcher-applications").html(navlinks.templates.appswitcher.linkSection({title:"Application Links",list:f}));if(a.isUserAdmin){e.addApplicationsCog()}e.bindAnalyticsHandlers(e.getSidebar(),f)})};this.updateProjectShortcuts=function(i,g,h){var j=i[0].shortcuts,f=g[0].shortcuts;e.getSidebar().find(".app-switcher-shortcuts").html(navlinks.templates.appswitcher.linkSection({title:"Shortcuts",list:j.concat(f)}));if(a.isUserAdmin){e.addProjectShortcutsCog(h.key,h.entityType)}e.populateProjectHeader(h.name,h.avatarUrl);e.bindAnalyticsHandlers(e.getSidebar(),data)};this.entityMappings={"confluence.space":"com.atlassian.applinks.api.application.confluence.ConfluenceSpaceEntityType","jira.project":"com.atlassian.applinks.api.application.jira.JiraProjectEntityType","bamboo.project":"com.atlassian.applinks.api.application.bamboo.BambooProjectEntityType","stash.project":"com.atlassian.applinks.api.application.stash.StashProjectEntityType"};this.generateEntityLinksUrl=function(f,g){if(g===e.entityMappings["confluence.space"]){return AJS.contextPath()+"/spaces/listentitylinks.action?typeId="+g+"&key="+f}else{return AJS.contextPath()+"/plugins/servlet/applinks/listEntityLinks/"+g+"/"+f}};this.showAppSwitcherError=function(){c(function(){var f=e.getSidebar();f.find(".app-switcher-applications .app-switcher-loading").replaceWith(navlinks.templates.appswitcher.error());f.off(".appswitcher").on("click.appswitcher",".app-switcher-retry",c.proxy(e.retryLoading,e))})};this.showProjectShortcutsError=function(){c(function(){var f=e.getSidebar();f.find(".app-switcher-shortcuts .app-switcher-loading").replaceWith(navlinks.templates.appswitcher.error());f.off(".appswitcher").on("click.appswitcher",".app-switcher-retry",c.proxy(e.retryLoading,e))})};this.retryLoading=function(f){this.getSidebar().html(navlinks.templates.appswitcher.sidebarContents());this.getLinks();this.getProjectData();f&&f.stopPropagation()};this.bindAnalyticsHandlers=function(f,g){};this.getLinks();c(this.getProjectData);this.toggleSidebar=function(h){var i=e.getSidebar(),g=c("body"),f=c(window.document);if(!g.hasClass("app-switcher-open")){var k=c("#header");i.css("left",-i.width());i.parent("body").length||i.appendTo("body");b({data:i});i.animate({left:0},300);function j(l){var n=l.target&&c(l.target),m=l.keyCode;if(l.originalEvent===h.originalEvent){return}if(n&&!m&&!(n.closest(i).length||n.closest(k).length)&&h.which==1&&!(l.shiftKey||l.ctrlKey||l.metaKey)){e.toggleSidebar()}else{if(m===27){e.toggleSidebar()}}}f.on("click.appSwitcher",j);f.on("keydown.appSwitcher",j);f.on("scroll.appSwitcher",i,b)}else{f.off(".appSwitcher")}g.toggleClass("app-switcher-open")};c("#header").on("click",".app-switcher-trigger",this.toggleSidebar)};function b(f){var d=c(document).scrollTop(),g=c("#header"),e=(g.height()+g.offset().top)-d;if(e>=0){f.data.css({top:e,position:"fixed"})}else{f.data.css({top:0,left:0,position:"fixed"})}}if(a.onInit){a.onInit()}}(jQuery,window.NL=(window.NL||{})));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher_old.js' */
var APPSWITCHER_TRIGGER_CLICK="appswitcher.trigger.click";var APPSWITCHER_DROPDOWN_SHOW="appswitcher.dropdown.show";var APPSWITCHER_DROPDOWN_DISPLAY_ERROR="appswitcher.dropdown.display.error";var APPSWITCHER_APP_LINK_CLICK="appswitcher.app.link.click";var APPSWITCHER_CONFIGURE_LINK_CLICK="appswitcher.configure.link.click";(function(e,c){c.AppSwitcher=function(f){var h=AJS.contextPath()+"/plugins/servlet/customize-application-navigator";var g="unified.usermanagement";var i=this;this.$dropdown=null;f=e.extend({dropdownContents:null},f);this.getLinks=function(){return e.ajax({url:AJS.contextPath()+"/rest/menu/latest/appswitcher",cache:false,dataType:"json"}).done(this.updateDropdown).fail(this.showError)};this.getDropdown=function(){if(!this.$dropdown){this.$dropdown=e(f.dropdownContents)}return this.$dropdown};this.updateDropdown=function(j){e(function(){i.getDropdown().html(navlinks.templates.appswitcher_old.applications({apps:j,showAdminLink:c.environment.isUserAdmin,adminLink:h}));i.bindAnalyticsHandlers();if(c.environment.isAppSuggestionAvailable===true){i.handleSuggestionApps(j)}})};this.bindAnalyticsHandlers=function(){e(".app-switcher-trigger").on("click",function(){AJS.trigger("analyticsEvent",{name:APPSWITCHER_TRIGGER_CLICK})});e("#app-switcher").on("aui-dropdown2-show",function(){AJS.trigger("analyticsEvent",{name:APPSWITCHER_DROPDOWN_SHOW})});e("#app-switcher .nav-link").on("click",function(){var l="custom";var m=e(this).find("a");var k=m.attr("href");var j=window.location.hostname;if(k.indexOf(j+"/wiki")>-1){l="confluence"}else{if(k.indexOf(j+"/build")>-1){l="bamboo"}else{if(k.indexOf(j)>-1){l="jira"}}}AJS.trigger("analyticsEvent",{name:APPSWITCHER_APP_LINK_CLICK,data:{product:l}})});e(".nav-link-edit-wrapper").on("click",function(){AJS.trigger("analyticsEvent",{name:APPSWITCHER_CONFIGURE_LINK_CLICK})})};this.isBillingSystemEnabled=function(){return(c.environment.isSiteAdminUser===true)&&AJS.DarkFeatures.isEnabled(g)};this.handleSuggestionApps=function(m){var n=_.map(m,function(o){return o.applicationType.toLowerCase()});var k=e("<div id='app-switcher-suggestion-apps' class='aui-dropdown2-section'/>");k.html(navlinks.templates.appswitcher_old.suggestionApps);var l=k.find(".suggestion-apps");var j=false;_.each(a,function(o){if(!_.contains(n,o.appName)){j=true;l.append(navlinks.templates.appswitcher_old.suggestionApp({suggestionApp:o,isBillingSystemEnabled:i.isBillingSystemEnabled()}))}});if(!j){return}e("#app-switcher").append(k);e(".app-discovery-suggestion-app").click(function(){var p=e(this).find("a");var o;if(c.environment.isSiteAdminUser){o="appswitcher.discovery.siteadmin.select.inproduct."}else{o="appswitcher.discovery.user.select."}o=o+p.attr("id").toLowerCase();AJS.trigger("analytics",{name:o})});e(".app-discovery-suggestion-app").hover(function(){e(this).find("a").removeClass("active").removeClass("aui-dropdown2-active")});e(".app-discovery-cancel-button").click(function(){AJS.trigger("analytics",{name:"appswitcher.discovery.nothanks.button.click"});d(b,"true");k.remove()})};this.showError=function(){e(function(){AJS.trigger("analyticsEvent",{name:APPSWITCHER_DROPDOWN_DISPLAY_ERROR});i.getDropdown().html(navlinks.templates.appswitcher_old.error()).off(".appswitcher").on("click.appswitcher",".app-switcher-retry",e.proxy(i.retryLoading,i))})};this.retryLoading=function(j){this.getDropdown().html(navlinks.templates.appswitcher_old.loading());this.getLinks();j&&j.stopPropagation()};this.getLinks()};var b="key-no-thanks";var a=[{appName:"jira",appDesc:"Issue & Project Tracking Software",discoveryUrl:"https://www.atlassian.com/software/jira",billingSystemDiscoveryUrl:"/admin/billing/addapplication"},{appName:"confluence",appDesc:"Collaboration and content sharing",discoveryUrl:"https://www.atlassian.com/software/confluence",billingSystemDiscoveryUrl:"/admin/billing/addapplication?product=confluence.ondemand"},{appName:"bamboo",appDesc:"Continuous integration",discoveryUrl:"https://www.atlassian.com/software/bamboo",billingSystemDiscoveryUrl:"/admin/billing/addapplication?product=bamboo.ondemand"}];var d=function(f,g){e.ajax({url:AJS.contextPath()+"/rest/menu/latest/userdata/",type:"PUT",contentType:"application/json",data:JSON.stringify({key:f,value:g})})};if(c.onInit){c.onInit()}}(jQuery,window.NL=(window.NL||{})));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nav-links-plugin:rotp-menu', location = 'appswitcher/appswitcher_old.soy' */
// This file was automatically generated from appswitcher_old.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace navlinks.templates.appswitcher_old.
 */

if (typeof navlinks == 'undefined') { var navlinks = {}; }
if (typeof navlinks.templates == 'undefined') { navlinks.templates = {}; }
if (typeof navlinks.templates.appswitcher_old == 'undefined') { navlinks.templates.appswitcher_old = {}; }


navlinks.templates.appswitcher_old.applications = function(opt_data, opt_ignored) {
  return '' + navlinks.templates.appswitcher_old.applicationsSection({list: opt_data.apps, listClass: 'nav-links', showDescription: opt_data.showDescription}) + ((opt_data.custom) ? navlinks.templates.appswitcher_old.applicationsSection({list: opt_data.custom, showDescription: opt_data.showDescription}) : '') + ((opt_data.showAdminLink) ? navlinks.templates.appswitcher_old.adminSection(opt_data) : '');
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.applications.soyTemplateName = 'navlinks.templates.appswitcher_old.applications';
}


navlinks.templates.appswitcher_old.applicationsSection = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.list.length > 0) {
    var param19 = '<ul' + ((opt_data.listClass) ? ' class="' + soy.$$escapeHtml(opt_data.listClass) + '"' : '') + '>';
    var linkList27 = opt_data.list;
    var linkListLen27 = linkList27.length;
    for (var linkIndex27 = 0; linkIndex27 < linkListLen27; linkIndex27++) {
      var linkData27 = linkList27[linkIndex27];
      param19 += navlinks.templates.appswitcher_old.applicationsItem(soy.$$augmentMap(linkData27, {showDescription: opt_data.showDescription}));
    }
    param19 += '</ul>';
    output += aui.dropdown2.section({content: param19});
  }
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.applicationsSection.soyTemplateName = 'navlinks.templates.appswitcher_old.applicationsSection';
}


navlinks.templates.appswitcher_old.applicationsItem = function(opt_data, opt_ignored) {
  return '<li class="nav-link' + ((opt_data.self) ? ' nav-link-local' : '') + '"><a href="' + soy.$$escapeHtml(opt_data.link) + '" class="aui-dropdown2-radio ' + ((opt_data.self) ? 'aui-dropdown2-checked' : '') + '" title="' + soy.$$escapeHtml(opt_data.link) + '"><span class="nav-link-label">' + soy.$$escapeHtml(opt_data.label) + '</span>' + ((opt_data.showDescription && opt_data.description) ? '<span class="nav-link-description">' + soy.$$escapeHtml(opt_data.description) + '</span>' : '') + '</a></li>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.applicationsItem.soyTemplateName = 'navlinks.templates.appswitcher_old.applicationsItem';
}


navlinks.templates.appswitcher_old.adminSection = function(opt_data, opt_ignored) {
  return '' + aui.dropdown2.section({content: '<ul class="nav-links"><li><a class="nav-link-edit-wrapper" href="' + soy.$$escapeHtml(opt_data.adminLink) + '"><span class="nav-link-edit">' + soy.$$filterNoAutoescape("Configure\x26hellip;") + '</span></a></li></ul>'});
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.adminSection.soyTemplateName = 'navlinks.templates.appswitcher_old.adminSection';
}


navlinks.templates.appswitcher_old.error = function(opt_data, opt_ignored) {
  return '<div class="app-switcher-error">' + soy.$$filterNoAutoescape("Something went wrong, please \x3cspan class\x3d\x22app-switcher-retry\x22\x3etry again\x3c/span\x3e.") + '</div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.error.soyTemplateName = 'navlinks.templates.appswitcher_old.error';
}


navlinks.templates.appswitcher_old.loading = function(opt_data, opt_ignored) {
  return '<div class="app-switcher-loading">' + soy.$$filterNoAutoescape("Loading\x26hellip;") + '</div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.loading.soyTemplateName = 'navlinks.templates.appswitcher_old.loading';
}


navlinks.templates.appswitcher_old.trigger = function(opt_data, opt_ignored) {
  return '<span class="aui-icon aui-icon-small aui-iconfont-appswitcher">' + soy.$$escapeHtml("Linked Applications") + '</span>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.trigger.soyTemplateName = 'navlinks.templates.appswitcher_old.trigger';
}


navlinks.templates.appswitcher_old.switcher = function(opt_data, opt_ignored) {
  var output = '';
  if (true) {
    var loadingContent__soy81 = '' + navlinks.templates.appswitcher_old.loading(null);
    var triggerContent__soy83 = '' + navlinks.templates.appswitcher_old.trigger(null);
    output += aui.dropdown2.dropdown2({menu: {id: 'app-switcher', content: loadingContent__soy81, extraClasses: 'aui-style-default'}, trigger: {showIcon: false, content: triggerContent__soy83, extraClasses: 'app-switcher-trigger', extraAttributes: {href: '#app-switcher'}}}) + '<script>\n            (function (NL) {\n                var initialise = function () {\n                    // For some milestones of AUI, the atlassian soy namespace was renamed to aui. Handle that here by ensuring that window.atlassian is defined.\n                    window.atlassian = window.atlassian || window.aui;\n                    new NL.AppSwitcher({\n                        dropdownContents: \'#app-switcher\'\n                    });\n                };\n                if (NL.AppSwitcher) {\n                    initialise();\n                } else {\n                    NL.onInit = initialise;\n                }\n            }(window.NL = (window.NL || {})));\n            window.NL.environment = ' + soy.$$escapeHtml({}) + ';<\/script>';
  }
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.switcher.soyTemplateName = 'navlinks.templates.appswitcher_old.switcher';
}


navlinks.templates.appswitcher_old.suggestionApp = function(opt_data, opt_ignored) {
  var output = '';
  var href__soy92 = opt_data.isBillingSystemEnabled == true ? opt_data.suggestionApp.billingSystemDiscoveryUrl : opt_data.suggestionApp.discoveryUrl;
  output += '<li class="app-discovery-suggestion-app"><a id="' + soy.$$escapeHtml(opt_data.suggestionApp.appName) + '" href="' + soy.$$escapeHtml(href__soy92) + '" class="app-discovery-link aui-icon-container app-discovery-' + soy.$$escapeHtml(opt_data.suggestionApp.appName) + '-product-icon" title="' + soy.$$escapeHtml(href__soy92) + '" target="_blank"/><div class="app-discovery-small">' + soy.$$escapeHtml(opt_data.suggestionApp.appDesc) + '</div></li>';
  return output;
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.suggestionApp.soyTemplateName = 'navlinks.templates.appswitcher_old.suggestionApp';
}


navlinks.templates.appswitcher_old.suggestionApps = function(opt_data, opt_ignored) {
  return '<ul class=\'nav-links suggestion-apps\'><li><span class=\'app-discovery-suggest-title nav-link-label\'><h6>' + soy.$$escapeHtml("Try other Atlassian apps") + '</h6></span></li></ul><div class=\'buttons-container app-discovery-suggest-apps-buttons\'><div class=\'buttons\'><button class=\'aui-button aui-button-link app-discovery-cancel-button\' name=\'cancel\' accesskey=\'c\' href=\'#\'>' + soy.$$escapeHtml("Don\x27t show this again") + '</button></div></div>';
};
if (goog.DEBUG) {
  navlinks.templates.appswitcher_old.suggestionApps.soyTemplateName = 'navlinks.templates.appswitcher_old.suggestionApps';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:general-analytics-bindings', location = '/includes/js/analytics-bindings.js' */
define("confluence/analytics-bindings",["jquery","confluence/analytics-support"],function(b,d){return function(){function e(a,c){b(a).on("click",".view-historical-version-trigger",function(){d.publish("confluence.page.view-historical.from-"+(c||"unknown"))})}function f(a,c){b(a).on("click",".restore-historical-version-trigger",function(){d.publish("confluence.page.restore-historical.from-"+(c||"unknown"))})}function g(a,c){b("#header .aui-header-secondary "+a).on("click",function(){var a=b(this).hasClass("aui-dropdown2-active")?
"expanded":"collapsed";d.publish("confluence.header.dropdown."+c,{state:a})})}e("#page-history-warning","navigation");e("#page-history-container","history");e(".diff-menu","diff");f("#page-history-warning","navigation");f("#page-history-container","history");g("#admin-menu-link","administration");g("#user-menu-link","profile")}});require("confluence/module-exporter").safeRequire("confluence/analytics-bindings",function(b){require("ajs").toInit(b)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.browser.metrics.browser-metrics-plugin:browser-metrics', location = 'browser-metrics-legacy.js' */
(function(){var a=window.BrowserMetrics||{};var b=window.WRM||{};a.isFunction=function(c){return !!(c&&c.constructor&&c.call&&c.apply)};a.isEnabled=function(){if(a.enabled===undefined){var c="com.atlassian.plugins.browser.metrics.browser-metrics-plugin:browser-metrics.feature-data-provider-legacy";a.enabled=a.isFunction(b.data)?b.data(c):b.data.claim(c)}return a.enabled};window.BrowserMetrics=a}());(function(){var b=window.BrowserMetrics||{};if(b.isEnabled()){var f=5;var e=12000;var c=function(g){return Math.round(g)};var a=function(g){return Math.round(g*100)/100};var d=function(k){var h=(function(){var n=/^(\w+):\/\/([^\/]*)(.*)$/;return function(p){var o=p.match(n);if(!o){return{path:p}}return{scheme:o[1],host:o[2],path:o[3]}}}());var i=(function(){var n=["secureConnectionStart","requestStart","responseStart","responseEnd","domContentLoadedEventStart","domContentLoadedEventEnd","loadEventEnd"];return function(o){if(k.performance){var s=k.performance.timing;var p=s.navigationStart;if(p){for(var r=0;r<n.length;++r){var q=n[r];var t=s[q];if(t){o(q,t-p)}}}}}}());var g=(function(){var o=[{key:"LOGIN",pattern:/^\/login.*/i},{key:"J-DASH",pattern:/^\/secure\/dashboard\.jspa.*/i},{key:"J-ISSUE",pattern:/^\/browse\/\w+\-\w+.*/i},{key:"J-NAV",pattern:/^\/issues.*/i},{key:"J-RAPID",pattern:/secure\/rapidboard\.jspa/i},{key:"SD-AGENT",pattern:/^(\/\w+)?\/servicedesk\/agent\/.*/i},{key:"SD-CUSTOMER",pattern:/^(\/\w+)?\/servicedesk\/customer\/.*/i},{key:"C-DASH",pattern:/^\/wiki(\/)?(\?.*|#.*)?$/i},{key:"C-DASH",pattern:/^\/wiki\/dashboard\.action.*$/i},{key:"C-SPACE",pattern:/^\/wiki\/display\/\w+(\?.*|#.*)?$/i},{key:"C-PAGE",pattern:/^\/wiki\/display\/\w+\/.*/i},{key:"C-PAGE",pattern:/^\/wiki\/pages\/viewpage\.action.*/i},{key:"C-BLOG",pattern:/^\/wiki\/display\/~\w+\/\d+\/\d+\/\d+\/.*/i},{key:"C-EDITOR",pattern:/^\/wiki\/pages\/editpage\.action.*/i},{key:"C-CREATE",pattern:/^\/wiki\/pages\/createpage\.action.*/i}];return function n(){var r=h(k.location.href).path;for(var p=0;p<o.length;++p){var q=o[p];if(r.match(q.pattern)){return q.key}}return null}}());function j(){var n=g();if(n){i(function(p,r){var o="browser.metrics."+p,q={version:f,page:n,value:r>e?"x":Math.ceil((r)/100),rawValue:c(r)};AJS.Analytics?AJS.Analytics.triggerPrivacyPolicySafeEvent(o,q):AJS.trigger("analyticsEvent",{name:o,data:q})})}}function m(){try{j()}catch(n){if(window.console){window.console.log("Error reporting browser metrics: "+n)}}}function l(){if(k.performance.timing.loadEventEnd){m()}else{setTimeout(l,1000)}}if(k.performance&&k.performance.timing){l()}};if(!window.ATL_PERF){window.ATL_PERF={}}window.ATL_PERF.initPageLoad=d}}());(function(){var b=window.BrowserMetrics||{};if(b.isEnabled()){var e=5;var d=12000;var a=function(f){return Math.round(f*100)/100};var c=function(g){var l={};function h(){return g.performance&&g.performance.now?g.performance.now():new Date().getTime()}function n(o){return o===Object(o)}function k(o){if(n(o)){return o.eventName+"."+o.eventType}else{return o}}function m(o){if(n(o)){return o.eventName}else{return o}}function j(o){if(n(o)){return o.eventType}else{return""}}function f(o){var p=k(o);l[p]=h()}function i(r,u){var v=k(r);if(!l[v]){throw ("Error logging browser metrics event end: no start event for key '"+v+"'")}var t=h()-l[v];l[v]=null;var o=m(r),q=j(r);var p="browser.metrics.e."+o+(u?"."+u:""),s={version:e,value:t>d?"x":Math.ceil((t)/100),rawValue:a(t),eventType:q};g.AJS.Analytics?g.AJS.Analytics.triggerPrivacyPolicySafeEvent(p,s):g.AJS.trigger("analyticsEvent",{name:p,data:s})}return{start:f,end:i}};if(!window.ATL_PERF){window.ATL_PERF={}}window.ATL_PERF.initEvents=c}}());(function(){var a=window.BrowserMetrics||{};if(a.isEnabled()){if(Math.random()<0.1){window.ATL_PERF&&window.ATL_PERF.initPageLoad&&window.ATL_PERF.initPageLoad(window)}window.ATL_PERF&&window.ATL_PERF.initEvents&&(function(){window.BrowserMetrics=window.ATL_PERF.initEvents(window)}())}}());
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:calendar-on-space-resources', location = 'com/atlassian/confluence/extra/calendar3/templates/upcoming-event-badge.soy' */
// This file was automatically generated from upcoming-event-badge.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.TeamCalendars.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.TeamCalendars == 'undefined') { Confluence.TeamCalendars = {}; }
if (typeof Confluence.TeamCalendars.Templates == 'undefined') { Confluence.TeamCalendars.Templates = {}; }


Confluence.TeamCalendars.Templates.upcomingEventBadge = function(opt_data, opt_ignored) {
  return '<span class="aui-badge teamcal-sidebar-upcoming-msg hidden"></span>';
};
if (goog.DEBUG) {
  Confluence.TeamCalendars.Templates.upcomingEventBadge.soyTemplateName = 'Confluence.TeamCalendars.Templates.upcomingEventBadge';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:calendar-on-space-resources', location = 'com/atlassian/confluence/extra/calendar3/js/calendar-on-space.js' */
(function(a){a(function(){function b(){var h="com.atlassian.confluence.extra.team-calendars:tc-on-space-blueprint-webitem";Confluence.Blueprint.setDirectCallback(h,function(j,i){i.finalUrl=Confluence.getContextPath()+"/display/"+i.spaceKey+"/calendars?src=sidebar&openAddCalDialog=true"})}b();var g=Confluence.TeamCalendars.Templates.upcomingEventBadge();var e=a(".space-calendar-sidebar-link a");if(e){e.append(g);var f=a(".teamcal-sidebar-upcoming-msg");AJS.bind("sidebar.collapsed",function(){if(f.html()===""){f.addClass("hidden")}});AJS.bind("sidebar.expanded",function(){if(f.html()===""){f.addClass("hidden")}else{f.removeClass("hidden")}})}function d(){var h=new Date();var i=new Date(Date.UTC(h.getFullYear(),h.getMonth(),h.getDate())).toISOString();a.cookie("team-calendars.badge.number.click.date."+AJS.Meta.get("space-key"),i)}a(document).on("click",".teamcal-sidebar-upcoming-msg",function(){d();Confluence.TeamCalendars.fireEventForAnalytics("badge.number.click",{spaceKey:AJS.Meta.get("space-key")||""})});a(document).on("click",".space-calendar-sidebar-link",function(){d()});function c(){var p=a(".space-calendar-sidebar-link a");if(!p){return}var k=a.cookie("team-calendars.badge.number.click.date."+AJS.Meta.get("space-key"));var j=new Date();var q=new Date(Date.UTC(j.getFullYear(),j.getMonth(),j.getDate()));var i=q.toISOString();if(i===k){return}q.setDate(q.getDate()+1);var l=q.toISOString();var o=AJS.Meta.get("space-key")||"";var m=a("input[name='userTimeZoneId']").val()||a("#team-calendars-user-timezone").attr("content");var h=AJS.contextPath()+"/rest/calendar-services/1.0/calendar/"+o+"/events/upcoming.json";var n=a(".teamcal-sidebar-upcoming-msg").addClass("hidden");a.ajax({cache:false,data:{calendarContext:"spaceCalendars",viewingSpaceKey:o,start:i,end:l,userTimeZoneId:m},dataType:"json",success:function(r){if(r.upcomingEvents>0){if(r.upcomingEvents===1){n.attr("title",AJS.format("{0} calendar event today",r.upcomingEvents))}else{n.attr("title",AJS.format("{0} calendar events today",r.upcomingEvents))}n.html(r.upcomingEvents);n.removeClass("hidden");n.tooltip({gravity:"w"});a(".space-calendar-sidebar-link").attr("data-collapsed-tooltip","")}else{n.addClass("hidden");n.html("")}},error:function(){n.addClass("hidden");n.html("")},type:"GET",url:h})}if(a(".space-calendar-sidebar-link").length){c()}})}(AJS.$));
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.mywork.mywork-confluence-host-plugin:mw-header-anchor', location = 'templates/anchor.soy' */
// This file was automatically generated from anchor.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace MyWork.Templates.Anchor.
 */

if (typeof MyWork == 'undefined') { var MyWork = {}; }
if (typeof MyWork.Templates == 'undefined') { MyWork.Templates = {}; }
if (typeof MyWork.Templates.Anchor == 'undefined') { MyWork.Templates.Anchor = {}; }


MyWork.Templates.Anchor.tasksFeatureDiscovery = function(opt_data, opt_ignored) {
  return '<p>' + soy.$$escapeHtml("See the tasks assigned to you, or created by you, in the Tasks tab of your profile.") + '</p><ul class="mw-tasks-discovery-controls"><li><a id="mw-tasks-discovery-view" href="' + soy.$$escapeHtml(opt_data.tasksUrl) + '" class="aui-button aui-style"><p>' + soy.$$escapeHtml("View Tasks") + '</p></a></li><li><a id="mw-tasks-discovery-dismiss" href="#">' + soy.$$escapeHtml("Dismiss") + '</a></li></ul>';
};
if (goog.DEBUG) {
  MyWork.Templates.Anchor.tasksFeatureDiscovery.soyTemplateName = 'MyWork.Templates.Anchor.tasksFeatureDiscovery';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.mywork.mywork-confluence-host-plugin:mw-header-anchor', location = 'js/miniview-anchor.js' */
var MW=MW||{$:AJS.$||Zepto};MW.MV={};AJS.toInit(function(){if(AJS.Meta&&!AJS.Meta.get("remote-user")){return}MW.MV.AnchorManager=function(){var l=contextPath,h=l+"/plugins/servlet/notifications-miniview",p=0,e=/[?&]show-miniview/.test(window.location.search);function r(t){t=t.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");var s="[\\?\\#&]"+t+"=([^&#]*)";var v=new RegExp(s);var u=v.exec(window.location.search);if(u!==null){return decodeURIComponent(u[1].replace(/\+/g," "))}}var o=r("show-miniview");if(o){h+="#notification/"+o}function q(){var s="badge-i aui-icon aui-icon-small aui-iconfont-workbox-empty";MW.$("#notifications-anchor").html('<div class="'+s+'"></div><span class="badge-w"><span class="badge"></span></span>').attr("title","Open Notifications")}function f(u){var t=false,s;return function(){if(t){return s}t=true;s=u.apply(this,arguments);return s}}var n=f(function(){MW.Dialog.getOptions().closeOthers=false;MW.Dialog.preload=true;MW.Dialog.show();MW.Dialog.hide();MW.Dialog.getOptions().closeOthers=true});function k(s){return s<=9?s:"9+"}function j(s){var t=MW.$("#notifications-anchor"),u=t.find(".badge"),v=t.find(".aui-icon");u.html(k(s));p=s;if(s>0){t.addClass("unread").removeClass("read");v.addClass("aui-iconfont-workbox").removeClass("aui-iconfont-workbox-empty");if(t.is(":visible")&&!e){n()}}else{t.addClass("read").removeClass("unread");v.addClass("aui-iconfont-workbox-empty").removeClass("aui-iconfont-workbox")}}function m(){c("notifications",h);d()}function d(){MW.$(document).keydown(function(s){if(AJS.InlineDialog.current&&s.which==27&&!MW.$(s.target).is(":input")){AJS.InlineDialog.current.hide()}})}function i(){MW.$("#header-menu-bar").find(".ajs-drop-down").each(function(){this.hide()})}function c(x,v){var w;var u=function(){w=this};var s=function(){if(this.preload!==true){var y=JSON.stringify({markAllRead:true});MW.$("#"+x+"-miniview-iframe")[0].contentWindow.postMessage(y,"*")}};if(!window.addEventListener){window.attachEvent("onmessage",t)}else{window.addEventListener("message",t,false)}function t(A){function B(C){return C===location.protocol+"//"+location.host}if("escKey"===A.data){w.hide();MW.$("#notifications-anchor").focus();document.activeElement.blur()}else{if("getParentConfig"===A.data&&B(A.origin)){var z=JSON.stringify({parentConfig:{parentUrl:location.href,preload:MW.Dialog.preload,unread:p}}),y=MW.$("#"+x+"-miniview-iframe")[0].contentWindow;y.postMessage(z,"*");if(MW.Dialog.preload){MW.Dialog.preload=false}else{y.focus()}}}}MW.Dialog=AJS.InlineDialog(MW.$("#"+x+"-anchor"),x+"-miniview",function(B,z,C){if(MW.$(B).children().length===0){MW.$(B).append(MW.$('<iframe id="'+x+'-miniview-iframe" src="'+v+'" frameborder="0"></iframe>'))}else{var A=JSON.stringify({unread:p}),y=MW.$("#"+x+"-miniview-iframe")[0].contentWindow;y.postMessage(A,"*");setTimeout(function(){y.focus()},100)}i();C()},{width:500,height:520,hideDelay:null,initCallback:u,hideCallback:s,noBind:true});MW.Tasks=(function(){var A=300;var z=20;var B=16;var G;var D=AJS.$("#user-menu-link");var C=AJS.$("#user-menu-link-content");var y=C.find("#view-mytasks-link");var E=function(J,H,K){var I=MyWork.Templates.Anchor.tasksFeatureDiscovery({tasksUrl:AJS.contextPath()+"/plugins/inlinetasks/mytasks.action"});J.html(I);J.find("#mw-tasks-discovery-dismiss").click(function(){G.hide()});K()};var F=function(){MW.Dialog.hide();var J=function(){return C.is(":visible")};if(!J()){D.trigger("aui-button-invoke")}var H=function(){G.hide()};C.one("aui-dropdown2-hide",H);G=AJS.InlineDialog(y,"my-tasks-discovery",E,{hideCallback:function(){G.unbind("click focusin mousedown",I);C.unbind("aui-dropdown2-hide",H);if(J()){D.trigger("aui-button-invoke")}MW.$("#inline-dialog-my-tasks-discovery").remove()},gravity:"w",useLiveEvents:true,width:A,noBind:true});C.find(".user-item.active").removeClass("active");y.addClass("active");y.focus();var I=function(K){K.stopPropagation()};G.on("click focusin mousedown",I);G.show()};return{closeAndDiscoverMyTasks:F}})();MW.$("#"+x+"-anchor").click(function(y){y.preventDefault();if(MW.$("#"+x+"-miniview-iframe").is(":visible")){MW.Dialog.hide()}else{MW.Dialog.show()}});if(e){MW.$("#"+x+"-anchor").click()}}function g(){q();m()}return{setupAnchors:g,updateNotificationCount:j}}();MW.MV.AnchorManager.setupAnchors();var b=new MW.AnchorUtil(MW.$,contextPath,MW.MV.AnchorManager.updateNotificationCount);b.setupAnchors();MW.$("#notifications-anchor").click(function(){AJS.trigger("analytics",{name:"mywork.host.button.clicked.notifications",data:{}});MW.MV.AnchorManager.updateNotificationCount(0)});var a=function(){if(document.hidden){b.stopRequests(true)}else{b.startRequests()}};document.addEventListener("visibilitychange",a,false);if(typeof document.hidden==="undefined"){MW.$(window).focus(function(){b.startRequests()})}MW.$("body").click(function(){b.startRequests()})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.mywork.mywork-confluence-host-plugin:mw-header-anchor', location = 'js/util/anchor-util.js' */
MW.AnchorUtil=function(d,k,e){var f=30000,i=f,s,p=k+"/rest/mywork/latest/status/notification/count";var r=new Date().getTime();var b=5*60*1000;var t=1000*60*5;var h=1.25;var c=0;function q(u){window.clearInterval(s);s=undefined;if(u===true){i=f}}function o(){return(new Date().getTime()-r)<t}function m(){if(!o()||!s){l()}r=new Date().getTime()}function l(){if(s){clearTimeout(s)}s=setTimeout(function(){g()},c=n(c))}function a(w,u){var v=w*1000;b=u*1000||b;if(v&&v!=i){i=v;m()}}function n(u){return Math.min(o()?i:u*h,b)}function g(u){MW.$.getJSON(p+((u)?"?pageid="+u:""),function(w){a(w.timeout,w.maxTimeout);var v=w.count;e(v)});l()}function j(){var u=AJS&&AJS.Meta&&AJS.Meta.get&&(AJS.Meta.get("content-type")==="page"||AJS.Meta.get("content-type")==="blogpost");if(u){g(AJS.Meta.get("page-id"))}else{g()}m()}return{setupAnchors:j,startRequests:m,stopRequests:q,updateAnchors:g}};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'oracle-confluence.oracle-confluence-customiser:fdr-blueprint-resources', location = '/js/fdrbp.js' */
Confluence.Blueprint.setWizard("oracle-confluence:fdr-template-web-item",function(a){a.on("submit.page1Id",function(d,c){var b=c.pageData.vName;if(!b){alert("Please provide a name for the document.");return false}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'oracle-confluence.oracle-confluence-customiser:fdr-blueprint-resources', location = '/soy/fdrbp.soy' */
// This file was automatically generated from fdrbp.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace MyPlugin.Blueprints.Simple.
 */

if (typeof MyPlugin == 'undefined') { var MyPlugin = {}; }
if (typeof MyPlugin.Blueprints == 'undefined') { MyPlugin.Blueprints = {}; }
if (typeof MyPlugin.Blueprints.Simple == 'undefined') { MyPlugin.Blueprints.Simple = {}; }


MyPlugin.Blueprints.Simple.page1Form = function(opt_data, opt_ignored) {
  return '<form action="#" method="post" class="aui"><fieldset><div class="field-group"><label for="vname">' + soy.$$escapeHtml("Blueprint Title") + '</label><input id="vname" class="text" type="text" name="vName"></div></fieldset></form>';
};
if (goog.DEBUG) {
  MyPlugin.Blueprints.Simple.page1Form.soyTemplateName = 'MyPlugin.Blueprints.Simple.page1Form';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'oracle-confluence.oracle-confluence-customiser:almob-blueprint-resources', location = '/js/almobbp.js' */
Confluence.Blueprint.setWizard("oracle-confluence:almob-template-web-item",function(a){a.on("submit.page1Id",function(d,c){var b=c.pageData.vName;if(!b){alert("Please provide a name for the document.");return false}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'oracle-confluence.oracle-confluence-customiser:almob-blueprint-resources', location = '/soy/almobbp.soy' */
// This file was automatically generated from almobbp.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace MyPlugin.Blueprints.Simple.
 */

if (typeof MyPlugin == 'undefined') { var MyPlugin = {}; }
if (typeof MyPlugin.Blueprints == 'undefined') { MyPlugin.Blueprints = {}; }
if (typeof MyPlugin.Blueprints.Simple == 'undefined') { MyPlugin.Blueprints.Simple = {}; }


MyPlugin.Blueprints.Simple.page1Form = function(opt_data, opt_ignored) {
  return '<form action="#" method="post" class="aui"><fieldset><div class="field-group"><label for="vname">' + soy.$$escapeHtml("Blueprint Title") + '</label><input id="vname" class="text" type="text" name="vName"></div></fieldset></form>';
};
if (goog.DEBUG) {
  MyPlugin.Blueprints.Simple.page1Form.soyTemplateName = 'MyPlugin.Blueprints.Simple.page1Form';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.dialog-wizard:dialog-wizard-resources', location = '/soy/dialog-wizard.soy' */
// This file was automatically generated from dialog-wizard.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.DialogWizard.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.DialogWizard == 'undefined') { Confluence.Templates.DialogWizard = {}; }


Confluence.Templates.DialogWizard.pageContainer = function(opt_data, opt_ignored) {
  return '<div class="dialog-wizard-page-wrapper"><div class="dialog-wizard-page-main"></div><div class="dialog-wizard-page-description">' + ((opt_data.descriptionHeaderLink && opt_data.descriptionHeader) ? '<h3><a href=\'' + soy.$$escapeHtml(opt_data.descriptionHeaderLink) + '\' target=\'_blank\'>' + soy.$$escapeHtml(opt_data.descriptionHeader) + '</a></h3>' : (opt_data.descriptionHeader) ? '<h3>' + soy.$$escapeHtml(opt_data.descriptionHeader) + '</h3>' : '') + '<p>' + soy.$$escapeHtml(opt_data.descriptionContent) + '</p></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.DialogWizard.pageContainer.soyTemplateName = 'Confluence.Templates.DialogWizard.pageContainer';
}


Confluence.Templates.DialogWizard.waitIcon = function(opt_data, opt_ignored) {
  return '<img class="wait-icon" src="' + soy.$$escapeHtml("/confluence") + '/images/icons/wait.gif">';
};
if (goog.DEBUG) {
  Confluence.Templates.DialogWizard.waitIcon.soyTemplateName = 'Confluence.Templates.DialogWizard.waitIcon';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.dialog-wizard:dialog-wizard-resources', location = '/js/dialog-wizard.js' */
(function($){function findNextPageId(pageId,pages){var thisPageIdIndex=-1;_.each(pages,function(element,index){if(element.id==pageId){thisPageIdIndex=index;return}});return pages[thisPageIdIndex+1].id}Confluence.DialogWizard=function(dialog,finalAction){function newPage(config,pageId,soyRenderContext,wizardData,wizard){var wizardPage=_.find(config.wizard.pages,function(page){return page.id==pageId});wizard.trigger("pre-render."+pageId,{soyRenderContext:soyRenderContext,wizardData:wizardData});try{var soyTemplateFunction=eval(wizardPage.templateKey);var $soyRender=$(soyTemplateFunction(soyRenderContext))}catch(e){throw Error("wizard points to a non-existent Soy template '"+wizardPage.templateKey+"'. Check your web-resources or server logs.")}$soyRender.find("a, area, button, input, object, select, textarea").attr("tabindex","10");var $panelContent;if(wizardPage.descriptionContent){$panelContent=$(Confluence.Templates.DialogWizard.pageContainer({descriptionHeaderLink:wizardPage.descriptionHeaderLink,descriptionHeader:wizardPage.descriptionHeader,descriptionContent:wizardPage.descriptionContent}));$panelContent.addClass("with-description").find(".dialog-wizard-page-main").append($soyRender)}else{$panelContent=$soyRender}var dialogPageId=pageId;if(dialog.id=="create-dialog"){dialogPageId="create-dialog-"+pageId}var page=dialog.addPage(dialogPageId).page[dialog.curpage];page.addHeader(wizardPage.title).addPanel("SinglePanel",$panelContent,"singlePanel");page.element.find("form").submit(function(){return false});if(wizardPage.descriptionContent){page.element.find(".dialog-panel-body").css({padding:0})}Confluence.Binder.autocompleteMultiUser($soyRender);Confluence.Binder.placeholder($soyRender);function nextCallback(ev){$soyRender.find(".placeholded").val("");var pageData={};var formArray=$soyRender.parent().find("form").serializeArray();_.each(formArray,function(item){pageData[item.name]=item.value});var e=$.Event("submit."+pageId);var state={$container:$soyRender,wizardData:wizardData,pageData:pageData};var validationDeferred=$.Deferred();validationDeferred.done(function(){wizardData.pages[pageId]=pageData;var nextPageId;if(state.nextPageId){nextPageId=state.nextPageId}else{nextPageId=!wizardPage.last&&findNextPageId(pageId,config.wizard.pages)}if(!state.nextPageId&&wizardPage.last){doFinalAction(ev,state,wizardData,finalAction,wizard);dialog.popup.element.find(":input,a").filter(":visible").disable().addClass("disabled");buttons.prepend(Confluence.Templates.DialogWizard.waitIcon())}else{newPage(config,nextPageId,soyRenderContext,wizardData,wizard)}});validationDeferred.fail(function(){AJS.log("dialog aborted by on-submit callback on page: "+pageId)});state.validationDeferred=validationDeferred;wizard.trigger(e,state);if(state.async){return}if(e.isDefaultPrevented()){validationDeferred.reject();return}validationDeferred.resolve()}var buttons=dialog.addFullButtonPanel(page,nextCallback,null,wizardPage.last);buttons.find(".button-panel-back").click(function(){delete wizardData.pages[pageId]});buttons.find(".aui-button-primary").attr("tabindex","10");$soyRender.find("input, select, textarea").eq(0).focus();wizard.trigger("post-render."+pageId,{$container:$soyRender,wizardData:wizardData})}function doFinalAction(ev,state,wizardData,finalAction,wizard){if(state.finalUrl){window.location=state.finalUrl}else{_.each(wizardData.pages,function(pageData){_.extend(wizardData,pageData)});delete wizardData.pages;finalAction(ev,wizardData,null,wizard)}}return{newPage:newPage,doFinalAction:doFinalAction}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.plugins.atlassian-nps-plugin:nps-acknowledgement-resources', location = 'js/nps/server/nps-initialiser.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:common-template-resources', location = 'com/atlassian/confluence/plugins/blueprint/common/soy/common-templates.soy' */
// This file was automatically generated from common-templates.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Blueprints.Common.Index.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Common == 'undefined') { Confluence.Blueprints.Common = {}; }
if (typeof Confluence.Blueprints.Common.Index == 'undefined') { Confluence.Blueprints.Common.Index = {}; }


Confluence.Blueprints.Common.Index.detailsSummaryMacro = function(opt_data, opt_ignored) {
  return '<ac:macro ac:name="detailssummary"><ac:parameter ac:name="label">' + soy.$$escapeHtml(opt_data.label) + '</ac:parameter><ac:parameter ac:name="spaces">' + soy.$$escapeHtml(opt_data.spaces) + '</ac:parameter><ac:parameter ac:name="firstcolumn">' + soy.$$escapeHtml(opt_data.firstcolumn) + '</ac:parameter><ac:parameter ac:name="headings">' + soy.$$escapeHtml(opt_data.headings) + '</ac:parameter><ac:parameter ac:name="blankTitle">' + soy.$$escapeHtml(opt_data.blankTitle) + '</ac:parameter><ac:parameter ac:name="blankDescription">' + soy.$$escapeHtml(opt_data.blankDescription) + '</ac:parameter><ac:parameter ac:name="contentBlueprintId">' + soy.$$escapeHtml(opt_data.contentBlueprintId) + '</ac:parameter><ac:parameter ac:name="blueprintModuleCompleteKey">' + soy.$$escapeHtml(opt_data.blueprintModuleCompleteKey) + '</ac:parameter><ac:parameter ac:name="createButtonLabel">' + soy.$$escapeHtml(opt_data.createButtonLabel) + '</ac:parameter></ac:macro>';
};
if (goog.DEBUG) {
  Confluence.Blueprints.Common.Index.detailsSummaryMacro.soyTemplateName = 'Confluence.Blueprints.Common.Index.detailsSummaryMacro';
}


Confluence.Blueprints.Common.Index.createFromTemplateMacro = function(opt_data, opt_ignored) {
  return '<ac:macro ac:name="create-from-template"><ac:parameter ac:name="blueprintModuleCompleteKey">' + soy.$$escapeHtml(opt_data.moduleKey) + '</ac:parameter><ac:parameter ac:name="buttonLabel">' + soy.$$escapeHtml(opt_data.buttonLabel) + '</ac:parameter><ac:parameter ac:name="spaceKey">' + soy.$$escapeHtml(opt_data.spaceKey) + '</ac:parameter><ac:parameter ac:name="templateName">' + soy.$$escapeHtml(opt_data.templateName) + '</ac:parameter></ac:macro>';
};
if (goog.DEBUG) {
  Confluence.Blueprints.Common.Index.createFromTemplateMacro.soyTemplateName = 'Confluence.Blueprints.Common.Index.createFromTemplateMacro';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:meeting-notes-resources', location = 'com/atlassian/confluence/plugins/meetingnotes/soy/how-to.soy' */
// This file was automatically generated from how-to.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Blueprints.Meeting.Notes.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Blueprints == 'undefined') { Confluence.Blueprints = {}; }
if (typeof Confluence.Blueprints.Meeting == 'undefined') { Confluence.Blueprints.Meeting = {}; }
if (typeof Confluence.Blueprints.Meeting.Notes == 'undefined') { Confluence.Blueprints.Meeting.Notes = {}; }


Confluence.Blueprints.Meeting.Notes.howTo = function(opt_data, opt_ignored) {
  return '<h1>' + soy.$$escapeHtml("With meeting notes you can...") + '</h1><ol class="howto-steps"><li class="howto-step"><div><h3>' + soy.$$escapeHtml("Crowd-source your agenda") + '</h3><p>' + soy.$$escapeHtml("Distribute an agenda and keep meetings focused.") + '</p></div></li><li class="howto-step"><div><h3>' + soy.$$escapeHtml("Capture meeting minutes") + '</h3><p>' + soy.$$escapeHtml("Take notes and make them available to everyone.") + '</p></div></li><li class="howto-step"><div><h3>' + soy.$$escapeHtml("Create and assign tasks") + '</h3><p>' + soy.$$escapeHtml("Assign action items for attendees to work on afterward.") + '</p></div></li></ol>';
};
if (goog.DEBUG) {
  Confluence.Blueprints.Meeting.Notes.howTo.soyTemplateName = 'Confluence.Blueprints.Meeting.Notes.howTo';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-business-blueprints:meeting-notes-resources', location = 'com/atlassian/confluence/plugins/meetingnotes/soy/user-mention.soy' */
// This file was automatically generated from user-mention.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Meeting.Notes.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Meeting == 'undefined') { Confluence.Templates.Meeting = {}; }
if (typeof Confluence.Templates.Meeting.Notes == 'undefined') { Confluence.Templates.Meeting.Notes = {}; }


Confluence.Templates.Meeting.Notes.userMention = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '' + ((opt_data.username) ? '<li><p><ac:link><ri:user ri:username="' + soy.$$escapeHtml(opt_data.username) + '" /></ac:link></p></li><li><p><ac:placeholder ac:type="mention">' + soy.$$escapeHtml("@mention a person to add them as an attendee and they will be notified.") + '</ac:placeholder></p></li>' : '<li><p><ac:placeholder ac:type="mention">' + soy.$$escapeHtml("@mention a person to add them as an attendee and they will be notified.") + '</ac:placeholder></p></li>');
};
if (goog.DEBUG) {
  Confluence.Templates.Meeting.Notes.userMention.soyTemplateName = 'Confluence.Templates.Meeting.Notes.userMention';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/js/request-access.js' */
AJS.toInit(function(e){var b=AJS.Meta.get("page-id"),c=e("#page-restricted-container"),a=AJS.Meta.get("remote-user"),d=e("#page-restricted-container button");if(c.length){e("#breadcrumbs").hide();e("#title-text.with-breadcrumbs").hide();if(d.length){AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.request.access.to.page.view",data:{pageId:b,requestAccessUser:a}})}}d.click(function(){AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.request.access.to.page",data:{pageId:b,requestAccessUser:a}});d.attr("aria-disabled","true");var f,g=e(Confluence.Request.Access.loading({}));d.replaceWith(g);e.ajax({url:Confluence.getContextPath()+"/rest/request-access/latest/page/restriction/"+b,success:function(h){f=e(Confluence.Request.Access.result({success:true,recipient:h}));c.removeClass("page-restricted");c.addClass("access-requested")},error:function(h,i){f=e(Confluence.Request.Access.result({success:false}))},complete:function(){g.replaceWith(f);Confluence.Binder.userHover()}})})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/js/grant-access.js' */
AJS.toInit(function(d){var a=AJS.Meta.get("page-id"),f=AJS.Meta.get("remote-user"),h=j("username"),e=j("userFullName");var c=e.split("+");e=c.join(" ");var g=d("#system-content-items");var k=d("#content-metadata-page-restrictions.restricted").length!==0;if(!g.length||!k||!j("grantAccess")){return}var b=d(Confluence.Request.Access.loading());var i=AJS.InlineDialog(g,"grantAccessDialog",function(m,l,n){m.css({padding:"20px"}).html(Confluence.Grant.Access.dialog({requestAccessUsername:h,requestAccessUserFullName:e}));m.on("click",".aui-button.grant-access",function(q){q.stopPropagation();var p=m.find(".actions-result");p.replaceWith(b);AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.grant.access.to.page",data:{pageId:a,grantAccessUser:f,requestAccessUser:h}});var o="",r=true;d.ajax({url:Confluence.getContextPath()+"/rest/request-access/latest/page/restriction/"+a,type:"POST",contentType:"application/json; charset=utf-8",data:h,success:function(t,u,s){if(s.status==202){o="Access was already granted to the user."}else{o="Access was granted, a notification to the user will be sent."}},error:function(s){r=false;if(s.status==412){o="Access was granted, but there is not a mail server configured so the notification could not be sent."}else{if(s.status==502){o="Access was granted, but an unexpected error happened while sending the notification."}else{o="Sorry, there was an unexpected error while granting access."}}},complete:function(s){b.replaceWith(d(Confluence.Grant.Access.result({success:r,message:o})));setTimeout(function(){i.hide()},6000)}})});m.on("click",".aui-button.deny-access",function(o){AJS.trigger("analyticsEvent",{name:"confluence.request.access.plugin.deny.access.to.page",data:{pageId:a,grantAccessUser:f,requestAccessUser:h}});i.hide()});n();return false},{offsetY:2,offsetX:0,width:350,hideDelay:null,noBind:true,hideCallback:function(){setTimeout(i.hide(),5000)}});i.show();function j(l){l=l.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");var n=new RegExp("[\\?&]"+l+"=([^&#]*)"),m=n.exec(location.search);return m==null?"":decodeURIComponent(m[1].replace(/\+/g," "))}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/templates/soy/request-access.soy' */
// This file was automatically generated from request-access.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Request.Access.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Request == 'undefined') { Confluence.Request = {}; }
if (typeof Confluence.Request.Access == 'undefined') { Confluence.Request.Access = {}; }


Confluence.Request.Access.result = function(opt_data, opt_ignored) {
  var output = '<div id="request-access">';
  if (opt_data.success) {
    var usernameLink__soy6 = '' + Confluence.Request.Access.usernameLink({user: opt_data.recipient});
    output += '<span class="aui-icon aui-icon-small aui-iconfont-approve" data-unicode="UTF+E005" original-title=""></span><p class="title">' + soy.$$filterNoAutoescape(AJS.format("Your request has been sent to {0}. If approved you will receive an email shortly.",usernameLink__soy6)) + '</p>';
  } else {
    output += '<span class="aui-icon aui-icon-small aui-iconfont-error" data-unicode="UTF+E011" original-title=""></span><p class="title">' + soy.$$escapeHtml("Your request for access has not been sent. Contact your space admin.") + '</p>';
  }
  output += '</div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Request.Access.result.soyTemplateName = 'Confluence.Request.Access.result';
}


Confluence.Request.Access.usernameLink = function(opt_data, opt_ignored) {
  return '<a href="' + soy.$$escapeHtml("/confluence") + '/display/~' + soy.$$escapeUri(opt_data.user.name) + '" class="url fn confluence-userlink" title data-username="' + soy.$$escapeHtml(opt_data.user.name) + '">' + soy.$$escapeHtml(opt_data.user.fullName) + '</a>';
};
if (goog.DEBUG) {
  Confluence.Request.Access.usernameLink.soyTemplateName = 'Confluence.Request.Access.usernameLink';
}


Confluence.Request.Access.loading = function(opt_data, opt_ignored) {
  return '<span class=\'aui-icon aui-icon-wait\'>' + soy.$$escapeHtml("Loading, please wait") + '</span>"';
};
if (goog.DEBUG) {
  Confluence.Request.Access.loading.soyTemplateName = 'Confluence.Request.Access.loading';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-request-access-plugin:confluence-request-access-plugin-resources', location = '/templates/soy/grant-access.soy' */
// This file was automatically generated from grant-access.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Grant.Access.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Grant == 'undefined') { Confluence.Grant = {}; }
if (typeof Confluence.Grant.Access == 'undefined') { Confluence.Grant.Access = {}; }


Confluence.Grant.Access.dialog = function(opt_data, opt_ignored) {
  var output = '<div class="grant-access-dialog">';
  var usernameLink__soy4 = '' + Confluence.Grant.Access.usernameLink({username: opt_data.requestAccessUsername, userFullName: opt_data.requestAccessUserFullName});
  output += '<h2 class="grant-access-title">' + soy.$$escapeHtml("Access request") + '</h2><p class="grant-access-message">' + soy.$$filterNoAutoescape(AJS.format("{0} wants to view this page.",usernameLink__soy4)) + '</p><div class="actions-result"><button class="aui-button grant-access">' + soy.$$escapeHtml("Grant access") + '</button><button class="aui-button aui-button-link deny-access">' + soy.$$escapeHtml("Deny") + '</button><div></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Grant.Access.dialog.soyTemplateName = 'Confluence.Grant.Access.dialog';
}


Confluence.Grant.Access.result = function(opt_data, opt_ignored) {
  return '<span class="aui-icon aui-icon-small aui-iconfont-' + ((opt_data.success) ? 'approve' : 'error') + '" data-unicode="UTF+E011" original-title=""></span><p class="title">' + soy.$$escapeHtml(opt_data.message) + '</p>';
};
if (goog.DEBUG) {
  Confluence.Grant.Access.result.soyTemplateName = 'Confluence.Grant.Access.result';
}


Confluence.Grant.Access.usernameLink = function(opt_data, opt_ignored) {
  return '<a href="' + soy.$$escapeHtml("/confluence") + '/display/~' + soy.$$escapeHtml(opt_data.username) + '" class="url fn" title data-username="' + soy.$$escapeHtml(opt_data.username) + '"><strong>' + soy.$$escapeHtml(opt_data.userFullName) + '</strong> (' + soy.$$escapeHtml(opt_data.username) + ')</a>';
};
if (goog.DEBUG) {
  Confluence.Grant.Access.usernameLink.soyTemplateName = 'Confluence.Grant.Access.usernameLink';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jirachart-resources', location = '/jirachart/jirachart.js' */
AJS.toInit(function(){AJS.$(".jira-chart-macro-img").load(function(a){AJS.log("Jira Chart Macro - chart image loaded");AJS.$(".insert-jira-chart-macro-button",window.parent.document).enable()}).error(function(d){AJS.log("Jira Chart Macro - chart image loaded error");AJS.$(".insert-jira-chart-macro-button",window.parent.document).disable();var e=AJS.$(d.target);var c=e.parent();var b=c.parent();c.remove();var a="Unable to render JIRA chart macro due to an execution error.";AJS.messages.error(b,{body:a})})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.extra.jira:jirachart-resources', location = '/jirachart/twodimensionalchart-showlink.js' */
var TwoDimensionalShowLink=(function(e){var d=function(i){var h=e("#two-dimensional-chart-"+i);var g=h.position();e("<div />",{id:"twodimensional-dark-layout-"+i,"class":"jim-sortable-dark-layout",css:{top:g.top+"px",left:g.left+"px",width:h.width()+"px",height:h.height()+"px"}}).appendTo(h.parent())};var a=function(g){e("#twodimensional-dark-layout-"+g).remove()};var b=function(){var h=e(this).attr("data-chart-id");d(h);var g={pageId:e("#chart-page-id-"+h).val(),wikiMarkup:e("#chart-wiki-"+h).val(),isShowMore:e(this).attr("data-is-show-more")};AJS.$.ajax({type:"POST",dataType:"html",url:Confluence.getContextPath()+"/plugins/servlet/twoDimensionalShowMoreRenderer",data:g,success:function(i){if(e(i).find(".aui-message.error").length){var j=e(i).find(".message").text();e("#two-dimensional-chart-"+h).find(".show-error").html(j)}else{var k=e(i).find(".show-link-container a").attr("data-chart-id");e("#two-dimensional-chart-"+h).replaceWith(i);c(k)}a(h)},error:function(){e("#two-dimensional-chart-"+h).find(".show-error").html("Unable to render JIRA chart macro. Execution has timed out.");a(h)}})};var c=function(g){e("#show-link-"+g).on("click",b)};var f=function(){e(".show-link-container a").each(function(){c(e(this).attr("data-chart-id"))})};return{init:f}})(AJS.$);AJS.$(function(){TwoDimensionalShowLink.init()});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/watch-model.js' */
define("confluence-watch-button/watch-model",["ajs","backbone"],function(a,b){return b.Model.extend({saveSettings:function(d,e){this.trigger("request");var c=this;return a.safe.ajax({url:d,type:"POST",dataType:"json",data:e}).done(function(){c.trigger("sync",c)}).fail(function(){c.trigger("error")})},saveWatchPage:function(d){var c=a.contextPath()+"/users/"+(d?"add":"remove")+"pagenotificationajax.action";this.set("watchingPage",d);return this.saveSettings(c,{pageId:this.get("pageId")})},saveWatchBlogs:function(d){var c=a.contextPath()+"/users/"+(d?"add":"remove")+"spacenotificationajax.action";this.set("watchingBlogs",d);return this.saveSettings(c,{spaceKey:this.get("spaceKey"),contentType:"blogpost"})},saveWatchSpace:function(d){var c=a.contextPath()+"/users/"+(d?"add":"remove")+"spacenotificationajax.action";this.set("watchingSpace",d);return this.saveSettings(c,{spaceKey:this.get("spaceKey")})}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/watch-view.js' */
define("confluence-watch-button/watch-view",["jquery","ajs","backbone"],function(b,a,c){return c.View.extend({events:{"change #cw-watch-page":"changeWatchPage","change #cw-watch-blogs":"changeWatchBlogs","change #cw-watch-space":"changeWatchSpace"},initialize:function(){_.bindAll(this,"render","initTooltips","changeWatchPage","changeWatchBlogs","changeWatchSpace","togglePageEnabledState","toggleBlogsEnabledState","startLoading","stopLoading","setTitle");this.model.on("sync change:watchingSpace",this.togglePageEnabledState,this);this.model.on("change:watchingSpace",this.toggleBlogsEnabledState,this);this.model.on("request",this.startLoading,this);this.model.on("sync",this.setTitle,this);this.model.on("sync",this.stopLoading,this)},render:function(){this.$el.html(Confluence.Watch.Templates.dialogBody(this.model.toJSON()));this.initTooltips();this.setTitle(this.model);return this},initTooltips:function(){this.$(".cw-tooltip").tooltip({gravity:"e",offset:5,delayIn:0});this.togglePageEnabledState(this.model);this.toggleBlogsEnabledState(this.model)},changeWatchPage:function(f){var d=b(f.target).is(":checked");this.model.saveWatchPage(d)},changeWatchBlogs:function(f){var d=b(f.target).is(":checked");this.model.saveWatchBlogs(d)},changeWatchSpace:function(f){var d=b(f.target).is(":checked");this.model.saveWatchSpace(d)},togglePageEnabledState:function(d){var e=d.get("watchingPage");var g=d.get("watchingSpace");this.$("#cw-watch-page").prop("disabled",g);this.$("#cw-watch-page").prop("checked",e||g);var f=g?"You will receive updates for this page because you are watching this space.":"";this.$(".cw-tooltip-watch-page").attr("original-title",f)},toggleBlogsEnabledState:function(d){var g=d.get("watchingBlogs");var f=d.get("watchingSpace");this.$("#cw-watch-blogs").prop("disabled",f);this.$("#cw-watch-blogs").prop("checked",g||f);var e=f?"You are subscribed to all blog posts because you are watching this space.":"";this.$(".cw-tooltip-watch-blogs").attr("original-title",e)},startLoading:function(){this.$(".cw-status").addClass("loading")},stopLoading:function(){this.$(".cw-status").removeClass("loading")},setTitle:function(){var e=this.model.get("watchingPage");var i=this.model.get("watchingBlogs");var g=this.model.get("watchingSpace");var d=this.model.get("isBlogPost");function h(){if(g){return{title:"You are watching this space",description:"Receiving email updates for all content in this space.",}}if(e&&d&&i){return{title:"You are watching this blog post",description:"Receiving email updates about changes to this blog post and all new blog posts in this space.",}}if(e&&d){return{title:"You are watching this blog post",description:"Receiving email updates about changes to this blog post.",}}if(e){return{title:"You are watching this page",description:"Receiving email updates about changes to this page.",}}if(d&&i){return{title:"You are watching for new blog posts",description:"Receiving email updates for new blog posts in this space.",}}if(d){return{title:"You are not watching this blog",description:"Start watching to receive email updates about changes to this blog.",}}return{title:"You are not watching this page",description:"Start watching to receive email updates about changes to this page.",}}var f=h();this.$(".cw-title").text(f.title);this.$(".cw-title-description").text(f.description)}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/watch.js' */
require(["jquery","underscore","ajs","confluence-watch-button/watch-model","confluence-watch-button/watch-view","confluence-watch-button/watch-notification"],function(b,i,h,f,d,g){h.toInit(function(){var j=b("#watch-content-button");if(!j.length){return}j.click(function(l){l.preventDefault()});var k=h.Meta.get("page-id");b.getJSON(h.contextPath()+"/rest/watch-button/1.0/watchState/"+k,function(l){i.extend(l,{pageId:k,spaceKey:h.Meta.get("space-key"),spaceName:h.Meta.get("space-name")});a(j,l);j.addClass("watch-state-initialised")})});function a(j,n){e(j,n);var m=new f(n);var l=new d({model:m});h.InlineDialog(j,"confluence-watch",function(p,o,q){l.setElement(p);l.render();q()},{width:325,offsetX:-180,cacheContent:false,hideDelay:null,hideCallback:function(){b(".tipsy").hide()}});m.on("change:watchingPage change:watchingBlogs change:watchingSpace",function(o){e(j,o.toJSON())});m.on("change:watchingPage",function(o,q){var p=q?"watch-page":"unwatch-page";h.trigger("analytics",{name:p})});m.on("change:watchingBlogs",function(o,q){var p=q?"watch-blogs":"unwatch-blogs";h.trigger("analytics",{name:p})});m.on("change:watchingSpace",function(o,q){var p=q?"watch-space":"unwatch-space";h.trigger("analytics",{name:p})});c(m);var k=false;b(document).on("keyup",function(){k=false});window.CW_watchPage=function(){if(k){return}k=true;var q=m.get("watchingSpace");var p=m.get("watchingPage");if(q){b("body, #splitter-content").animate({scrollTop:0},300,function(){j.click();setTimeout(function(){b(".cw-tooltip-watch-page").tipsy("show")},50)})}else{var r=!p;m.saveWatchPage(r);var o=r?"You started watching this page.":"You stopped watching this page.";g(o)}}}function e(k,q){var m=q.watchingPage;var j=q.isBlogPost&&q.watchingBlogs;var o=q.watchingSpace;if(m||j||o){var l=k.find(".aui-icon").removeClass("aui-iconfont-unwatch").addClass("aui-iconfont-watch");var n=h.format("{0}W{1}atching","<u>","</u>");k.prop("title","Stop watching (w)").children("span").empty().append(l).append(" "+n)}else{var l=k.find(".aui-icon").removeClass("aui-iconfont-watch").addClass("aui-iconfont-unwatch");var p=h.format("{0}W{1}atch","<u>","</u>");k.prop("title","Watch (w)").children("span").empty().append(l).append(" "+p)}}function c(j){j.on("change:watchingPage",function(k,m){var l=m?"watchpage.pageoperation":"unwatchpage.pageoperation";h.trigger(l)})}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'js/notification.js' */
define("confluence-watch-button/watch-notification",["jquery","aui/flag"],function(b,a){return function(e){var c=document.getElementById("watch-notification");if(c!=null){c.close()}var d=a({type:"success",body:e,close:"auto"});d.setAttribute("id","watch-notification")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.watch-button:watch-resources', location = 'templates/watch.soy' */
// This file was automatically generated from watch.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Watch.Templates.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Watch == 'undefined') { Confluence.Watch = {}; }
if (typeof Confluence.Watch.Templates == 'undefined') { Confluence.Watch.Templates = {}; }


Confluence.Watch.Templates.dialogBody = function(opt_data, opt_ignored) {
  return '<div class="cw-status"><h2 class="cw-title"></h2><p class="cw-title-description"></p></div><form class="aui cw-dialog"><div class="cw-tooltip cw-tooltip-watch-page"><div class="checkbox"><input class="checkbox" type="checkbox" id="cw-watch-page" ' + ((opt_data.watchingPage) ? 'checked' : '') + '><label for="cw-watch-page">' + ((opt_data.isBlogPost) ? soy.$$escapeHtml("Watch blog post") : soy.$$escapeHtml("Watch page")) + '</label></div></div>' + ((opt_data.isBlogPost) ? '<div class="cw-tooltip cw-tooltip-watch-blogs"><div class="checkbox"><input class="checkbox" type="checkbox" id="cw-watch-blogs" ' + ((opt_data.watchingBlogs) ? 'checked' : '') + '><label for="cw-watch-blogs">' + soy.$$escapeHtml("Watch for new blog posts in this space") + '</label></div></div>' : '') + '<div class="checkbox"><input class="checkbox" type="checkbox" id="cw-watch-space" ' + ((opt_data.watchingSpace) ? 'checked' : '') + '><label for="cw-watch-space">' + soy.$$escapeHtml("Watch all content in this space") + '</label></div></form>' + ((opt_data.isAdmin) ? '<div class="cw-manage-watchers-wrapper"><button class="aui-button aui-button-link cw-manage-watchers">' + soy.$$escapeHtml("Manage Watchers") + '</button></div>' : '');
};
if (goog.DEBUG) {
  Confluence.Watch.Templates.dialogBody.soyTemplateName = 'Confluence.Watch.Templates.dialogBody';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:soy-resources', location = 'soy/sidebar.soy' */
// This file was automatically generated from sidebar.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Sidebar.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Sidebar == 'undefined') { Confluence.Templates.Sidebar = {}; }


Confluence.Templates.Sidebar.headerStyles = function(opt_data, opt_ignored) {
  opt_data = opt_data || {};
  return '' + ((opt_data.sidebarWidth) ? '<style>.ia-fixed-sidebar, .ia-splitter-left {width: ' + soy.$$escapeHtml(opt_data.sidebarWidth) + 'px;}.theme-default .ia-splitter #main {margin-left: ' + soy.$$escapeHtml(opt_data.sidebarWidth) + 'px;}.ia-fixed-sidebar {visibility: hidden;}</style>' : '');
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.headerStyles.soyTemplateName = 'Confluence.Templates.Sidebar.headerStyles';
}


Confluence.Templates.Sidebar.sidebar = function(opt_data, opt_ignored) {
  return '<div class="acs-side-bar ia-scrollable-section"><div class="acs-side-bar-space-info tipsy-enabled" data-configure-tooltip="' + soy.$$escapeHtml("Edit space details") + '"><div class="avatar"><div class="space-logo" data-key="' + soy.$$escapeHtml(opt_data.space.key) + '" data-name="' + soy.$$escapeHtml(opt_data.space.name) + '" data-entity-type="confluence.space"><div class="avatar-img-container"><div class="avatar-img-wrapper"><a href="' + soy.$$escapeHtml(opt_data.space.homeUrl) + '" title="' + soy.$$escapeHtml(opt_data.space.name) + '"><img class="avatar-img" src="' + soy.$$escapeHtml(opt_data.space.logoUrl) + '" alt="' + soy.$$escapeHtml(opt_data.space.name) + '"></a></div></div></div></div><div class="space-information-container"><div class="name"><a href="' + soy.$$escapeHtml(opt_data.space.homeUrl) + '" title="' + soy.$$escapeHtml(opt_data.space.name) + '">' + soy.$$escapeHtml(opt_data.space.name) + '</a></div><div class="flyout-handle icon"></div><div class="favourite-space-icon">' + Confluence.Templates.Sidebar.renderFavouriteSpace(opt_data) + '</div></div></div><div class="acs-side-bar-content"><div class="acs-nav-wrapper"><div class="acs-nav" data-has-create-permission="' + soy.$$escapeHtml(opt_data.hasCreatePermission) + '" data-quick-links-state="' + soy.$$escapeHtml(opt_data.quickLinksState) + '" data-nav-type="' + soy.$$escapeHtml(opt_data.navType) + '">' + Confluence.Templates.Sidebar.renderLinks(opt_data) + '</div></div>' + ((opt_data.contextualNav) ? Confluence.Templates.Sidebar.contextualNav(opt_data) : '') + '</div><div class="hidden"><a href="' + soy.$$escapeHtml(opt_data.space.browseSpaceUrl) + '" id="space-pages-link"></a><script type="text/x-template" title="logo-config-content"><h2>' + soy.$$escapeHtml("Space Details") + '</h2><div class="personal-space-logo-hint">' + soy.$$filterNoAutoescape(AJS.format("Your profile picture is used as the logo for your personal space. \x3ca href\x3d\x22{0}\x22 target\x3d\x22_blank\x22\x3eChange your profile picture\x3c/a\x3e.","/confluence" + '/users/profile/editmyprofilepicture.action')) + '</div><\/script></div></div>' + Confluence.Templates.Sidebar.renderSpaceToolsSection({advancedLinks: opt_data.advancedLinks, hasConfigurePermission: opt_data.hasConfigurePermission, currentlyViewed: opt_data.collectorToHighlight == 'spacebar-advanced'});
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.sidebar.soyTemplateName = 'Confluence.Templates.Sidebar.sidebar';
}


Confluence.Templates.Sidebar.renderFavouriteSpace = function(opt_data, opt_ignored) {
  return '<button title="' + soy.$$escapeHtml("Add to my spaces") + '" id="space-favourite-add" class="space-favourite aui-icon aui-icon-small aui-iconfont-unstar"></button><button class="' + ((! opt_data.isFavouriteSpace) ? ' space-favourite-hidden ' : '') + ' space-favourite aui-icon aui-icon-small aui-iconfont-star" id="space-favourite-remove" title="' + soy.$$escapeHtml("Remove from my spaces") + '"></button>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.renderFavouriteSpace.soyTemplateName = 'Confluence.Templates.Sidebar.renderFavouriteSpace';
}


Confluence.Templates.Sidebar.renderLinks = function(opt_data, opt_ignored) {
  return '<div class="acs-nav-sections">' + ((opt_data.mainLinks.length) ? Confluence.Templates.Sidebar.renderLinksSection({links: opt_data.mainLinks, sectionClass: 'main-links-section', collectorToHighlight: opt_data.collectorToHighlight}) : '') + ((opt_data.quickLinksState != 'hide') ? '<div class="quick-links-wrapper">' + ((opt_data.quickLinks.length) ? '<h5 class="ia-quick-links-header-title">' + soy.$$escapeHtml("Space shortcuts") + '</h5>' + Confluence.Templates.Sidebar.renderLinksSection({links: opt_data.quickLinks, sectionClass: 'quick-links-section tipsy-enabled', collectorToHighlight: null}) : (opt_data.hasConfigurePermission) ? '<h5 class="ia-quick-links-header-title">' + soy.$$escapeHtml("Space shortcuts") + '</h5><p class="tip">' + soy.$$filterNoAutoescape(AJS.format("Here you can add shortcut links to the most important content for your team or project. \x3ca href\x3d\x22{0}\x22 class\x3d\x22{1}\x22\x3eConfigure sidebar\x3c/a\x3e.",'','configure-sidebar')) + '</p>' : '') + '</div>' : '') + ((opt_data.hasSidebarCustomisation) ? Confluence.Templates.Sidebar.renderCustomContent(opt_data) : '') + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.renderLinks.soyTemplateName = 'Confluence.Templates.Sidebar.renderLinks';
}


Confluence.Templates.Sidebar.renderCustomContent = function(opt_data, opt_ignored) {
  return '<div class="custom-sidebar"><div class="custom-sidebar-content"><div class="content">' + soy.$$filterNoAutoescape(opt_data.sidebarCustomisation) + '</div></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.renderCustomContent.soyTemplateName = 'Confluence.Templates.Sidebar.renderCustomContent';
}


Confluence.Templates.Sidebar.renderLinksSection = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.links.length) {
    output += '<div class="' + soy.$$escapeHtml(opt_data.sectionClass) + ' ' + ((opt_data.highlightSection) ? ' current-section' : '') + '"><ul class="acs-nav-list">';
    var linkList123 = opt_data.links;
    var linkListLen123 = linkList123.length;
    for (var linkIndex123 = 0; linkIndex123 < linkListLen123; linkIndex123++) {
      var linkData123 = linkList123[linkIndex123];
      output += '<li class="acs-nav-item ' + soy.$$escapeHtml(linkData123.styleClass) + ((opt_data.collectorToHighlight && linkData123.collectorKey == opt_data.collectorToHighlight) ? ' current-item' : '') + '"' + ((linkData123.collectorKey) ? 'data-collector-key="' + soy.$$escapeHtml(linkData123.collectorKey) + '"' : '') + '><a class="acs-nav-item-link tipsy-enabled" href="' + soy.$$escapeHtml(linkData123.url) + '" data-collapsed-tooltip="' + soy.$$escapeHtml(linkData123.tooltip) + '"><span class="icon"></span><span class="acs-nav-item-label">' + soy.$$escapeHtml(linkData123.title) + '</span></a></li>';
    }
    output += '</ul></div>';
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.renderLinksSection.soyTemplateName = 'Confluence.Templates.Sidebar.renderLinksSection';
}


Confluence.Templates.Sidebar.contextualNav = function(opt_data, opt_ignored) {
  return '<div class="ia-secondary-container tipsy-enabled" data-tree-type="' + ((opt_data.forBlogs) ? 'blogs' : (opt_data.forSettings) ? 'settings' : soy.$$escapeHtml(opt_data.navType)) + '">' + ((opt_data.forBlogs) ? '<div class="ia-secondary-header"><h5 class="ia-secondary-header-title blog"><span class="icon"></span><span class="label">' + soy.$$escapeHtml("Blog") + '</span></h5></div><div class="ia-secondary-content">' + Confluence.Templates.Sidebar.pagetreeList({pagetree: opt_data.contextualNav}) + '</div>' : (opt_data.forSettings) ? '<div class="ia-secondary-header"><h5 class="ia-secondary-header-title settings"><span class="label">' + soy.$$escapeHtml("Advanced") + '</span></h5></div><div class="ia-secondary-content">' + Confluence.Templates.Sidebar.pagetreeList({pagetree: opt_data.contextualNav}) + '</div>' : (opt_data.navType == 'page-tree') ? '<div class="ia-secondary-header"><h5 class="ia-secondary-header-title page-tree"><span class="icon"></span><span class="label">' + soy.$$escapeHtml("Page tree") + '</span></h5></div>' + ((opt_data.pageTreeEmpty) ? '<p class="tip">' + soy.$$filterNoAutoescape(AJS.format("Get started by adding some pages to this space. \x3ca href\x3d\x22{0}\x22 class\x3d\x22{1}\x22\x3eCreate page\x3c/a\x3e.","/confluence" + '/pages/createpage.action?spaceKey=' + opt_data.space.key,'page-tree-create-child-page-link')) + '</p>' : '<div class="ia-secondary-content">' + soy.$$filterNoAutoescape(opt_data.contextualNav) + '</div>') : Confluence.Templates.Sidebar.Pages.renderPageContextualNav({pageContextualNav: opt_data.contextualNav, hasCreatePermission: opt_data.hasCreatePermission})) + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.contextualNav.soyTemplateName = 'Confluence.Templates.Sidebar.contextualNav';
}


Confluence.Templates.Sidebar.pagetreeList = function(opt_data, opt_ignored) {
  var output = '<ul class="' + ((opt_data.isSubtree) ? 'ia-subpagetree' : 'ia-pagetree') + '">';
  var itemList197 = opt_data.pagetree;
  var itemListLen197 = itemList197.length;
  for (var itemIndex197 = 0; itemIndex197 < itemListLen197; itemIndex197++) {
    var itemData197 = itemList197[itemIndex197];
    output += Confluence.Templates.Sidebar.pagetreeItem(itemData197);
  }
  output += '</ul>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.pagetreeList.soyTemplateName = 'Confluence.Templates.Sidebar.pagetreeList';
}


Confluence.Templates.Sidebar.throbber = function(opt_data, opt_ignored) {
  return '<div class="content-container"><div class="throbber-container"><div class="throbber"><div class="spinner"></div><span>' + soy.$$escapeHtml("Loading...") + '</span></div></div></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.throbber.soyTemplateName = 'Confluence.Templates.Sidebar.throbber';
}


Confluence.Templates.Sidebar.treeThrobber = function(opt_data, opt_ignored) {
  return '<ul class="ia-subpagetree"><li class="acs-tree-item leaf"><span class="node-title">' + soy.$$escapeHtml("Loading...") + '</span></li></ul>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.treeThrobber.soyTemplateName = 'Confluence.Templates.Sidebar.treeThrobber';
}


Confluence.Templates.Sidebar.pagetreeItem = function(opt_data, opt_ignored) {
  return '<li class="acs-tree-item' + ((opt_data.hasChildren) ? (opt_data.children.length) ? ' opened' : ' closed' : ' leaf') + ((opt_data.groupType) ? ' grouping' : '') + ((opt_data.active) ? ' current-item' : '') + '"' + ((opt_data.pageId) ? ' data-page-id="' + soy.$$escapeHtml(opt_data.pageId) + '"' : '') + ((opt_data.groupType) ? ' data-group-type="' + soy.$$escapeHtml(opt_data.groupType) + '" data-group-value="' + soy.$$escapeHtml(opt_data.groupValue) + '"' : '') + '>' + ((! opt_data.groupType) ? '<a href="' + soy.$$escapeHtml(opt_data.url) + '">' : '') + '<span class="icon ' + ((opt_data.hasChildren) ? (opt_data.children.length) ? 'icon-section-opened' : 'icon-section-closed' : '') + '"></span><span class="node-title navigation-pseudo-link">' + soy.$$escapeHtml(opt_data.title) + '</span>' + ((! opt_data.groupType) ? '</a>' : '') + ((opt_data.children && opt_data.children.length > 0) ? Confluence.Templates.Sidebar.pagetreeList({pagetree: opt_data.children, isSubtree: true}) : '') + '</li>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.pagetreeItem.soyTemplateName = 'Confluence.Templates.Sidebar.pagetreeItem';
}


Confluence.Templates.Sidebar.renderSpaceToolsSection = function(opt_data, opt_ignored) {
  var output = '<div class="space-tools-section"><div id="space-tools-menu-additional-items" class="hidden">';
  var linkList267 = opt_data.advancedLinks;
  var linkListLen267 = linkList267.length;
  for (var linkIndex267 = 0; linkIndex267 < linkListLen267; linkIndex267++) {
    var linkData267 = linkList267[linkIndex267];
    output += '<div data-label="' + soy.$$escapeHtml(linkData267.title) + '" data-class="' + soy.$$escapeHtml(linkData267.styleClass) + '" data-href="' + soy.$$escapeHtml(linkData267.url) + '">' + soy.$$escapeHtml(linkData267.title) + '</div>';
  }
  output += ((opt_data.hasConfigurePermission) ? '<div data-label="' + soy.$$escapeHtml("Configure sidebar") + '" data-class="configure-sidebar" data-href="">' + soy.$$escapeHtml("Configure sidebar") + '</div>' : '') + '</div>' + aui.dropdown2.trigger({menu: {id: 'space-tools-menu'}, id: 'space-tools-menu-trigger', tagName: 'button', extraClasses: 'aui-button aui-button-subtle tipsy-enabled' + ((opt_data.currentlyViewed) ? ' current-item' : ''), content: aui.icons.icon({useIconFont: true, icon: 'configure', accessibilityText: "Configure"}) + '<span class="aui-button-label">' + soy.$$escapeHtml("Space tools") + '</span>'}) + aui.dropdown2.contents({id: 'space-tools-menu', extraClasses: 'aui-style-default', extraAttributes: {'data-aui-alignment': 'top left'}}) + '<a class="expand-collapse-trigger"></a></div>';
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.renderSpaceToolsSection.soyTemplateName = 'Confluence.Templates.Sidebar.renderSpaceToolsSection';
}


Confluence.Templates.Sidebar.spaceToolsMenu = function(opt_data, opt_ignored) {
  var output = '';
  if (opt_data.isAuiFiveSeven) {
    output += '<div class="space-tools-menu"><div class="aui-dropdown2-section"><ul class="space-tools-navigation">';
    var linkList312 = opt_data.spaceToolLinks;
    var linkListLen312 = linkList312.length;
    for (var linkIndex312 = 0; linkIndex312 < linkListLen312; linkIndex312++) {
      var linkData312 = linkList312[linkIndex312];
      output += '<li><a href="' + soy.$$escapeHtml(linkData312.href) + '" title="' + soy.$$escapeHtml(linkData312.label) + '">' + soy.$$escapeHtml(linkData312.label) + '</a></li>';
    }
    output += '</ul></div>';
    if (opt_data.spaceLinks.length > 0) {
      output += '<div class="aui-dropdown2-section"><ul class="space-operations">';
      var linkList325 = opt_data.spaceLinks;
      var linkListLen325 = linkList325.length;
      for (var linkIndex325 = 0; linkIndex325 < linkListLen325; linkIndex325++) {
        var linkData325 = linkList325[linkIndex325];
        output += '<li><a class="' + soy.$$escapeHtml(linkData325.className) + '" href="' + soy.$$escapeHtml(linkData325.href) + '" title="' + soy.$$escapeHtml(linkData325.label) + '">' + soy.$$escapeHtml(linkData325.label) + '</a></li>';
      }
      output += '</ul></div>';
    }
    output += '</div>';
  } else {
    output += aui.dropdown2.itemGroup({isTruncated: true, items: opt_data.spaceToolLinks}) + ((opt_data.spaceLinks.length > 0) ? aui.dropdown2.itemGroup({isTruncated: true, items: opt_data.spaceLinks}) : '');
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.spaceToolsMenu.soyTemplateName = 'Confluence.Templates.Sidebar.spaceToolsMenu';
}


Confluence.Templates.Sidebar.configure = function(opt_data, opt_ignored) {
  return '<div class="acs-nav-sections"><table id="acs-nav-list-main" class="acs-nav-list"></table><div class="acs-nav-list-quick-section' + ((opt_data.quickLinksState == 'hide') ? ' hidden-section' : '') + '"><div class="quick-links-header"><h5>' + soy.$$escapeHtml("Space shortcuts") + '</h5><a href="#" class="aui-icon aui-icon-small toggle-link" data-tooltip="' + soy.$$escapeHtml("Hide/Show space shortcuts") + '"/></div><table id="acs-nav-list-quick" class="acs-nav-list"></table><p class="tip">' + soy.$$escapeHtml("Click \x22Add link\x22 to add links to the sidebar.") + '</p><a class="acs-add-link" href="#"><span class="icon"></span><span class="label">' + soy.$$escapeHtml("Add link") + '</span></a></div>' + ((opt_data.hasSidebarCustomisation) ? '<p class="tip">' + soy.$$filterNoAutoescape(AJS.format("You can continue editing your customized sidebar in the space admin. \x3ca href\x3d\x22{0}\x22 class\x3d\x22{1}\x22\x3eGo to space admin\x3c/a\x3e.",opt_data.customContentAdminLink,'custom-sidebar-tip')) + '</p>' + Confluence.Templates.Sidebar.renderCustomContent(opt_data) : '') + '<h5>' + soy.$$escapeHtml("Navigation display options") + '</h5><form class="aui"><div class="radio"><input class="radio acs-nav-type" type="radio" name="nav-type" value="pages" id="nav-type-pages" ' + ((! opt_data.pageTree) ? 'checked' : '') + '><label for="nav-type-pages">' + soy.$$escapeHtml("Child pages") + '</label></div><div class="radio"><input class="radio acs-nav-type" type="radio" name="nav-type" value="page-tree" id="nav-type-tree" ' + ((opt_data.pageTree) ? 'checked' : '') + '><label for="nav-type-tree">' + soy.$$escapeHtml("Page tree") + '</label></div></form><button class="aui-style aui-button acs-done-link">' + soy.$$escapeHtml("Done") + '</button></div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.configure.soyTemplateName = 'Confluence.Templates.Sidebar.configure';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:soy-resources', location = 'soy/sidebar-pages.soy' */
// This file was automatically generated from sidebar-pages.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Sidebar.Pages.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Sidebar == 'undefined') { Confluence.Templates.Sidebar = {}; }
if (typeof Confluence.Templates.Sidebar.Pages == 'undefined') { Confluence.Templates.Sidebar.Pages = {}; }


Confluence.Templates.Sidebar.Pages.renderPageContextualNav = function(opt_data, opt_ignored) {
  return '<div class="ia-secondary-header"><h5 class="ia-secondary-header-title pages"><span class="label">' + soy.$$escapeHtml("Child pages") + '</span></h5></div><div class="ia-secondary-parent-content">' + Confluence.Templates.Sidebar.Pages.parentPage({parentPage: opt_data.pageContextualNav.parentPage}) + '</div><div class="ia-secondary-current-content">' + Confluence.Templates.Sidebar.Pages.currentPage({currentPage: opt_data.pageContextualNav.currentPage}) + '</div><div class="ia-secondary-content">' + Confluence.Templates.Sidebar.Pages.childPages({children: opt_data.pageContextualNav, createPermission: opt_data.hasCreatePermission}) + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.Pages.renderPageContextualNav.soyTemplateName = 'Confluence.Templates.Sidebar.Pages.renderPageContextualNav';
}


Confluence.Templates.Sidebar.Pages.childPages = function(opt_data, opt_ignored) {
  return '<div class="contextual-nav-child-pages">' + ((opt_data.children.initialChildPages.length) ? '<ul class="children">' + Confluence.Templates.Sidebar.Pages.renderChildren({children: opt_data.children.initialChildPages}) + '</ul>' + ((opt_data.children.remainingChildPages.length) ? '<ul class="more-children">' + Confluence.Templates.Sidebar.Pages.renderChildren({children: opt_data.children.remainingChildPages}) + '</ul><a class="more-children-link" href=""><span class="icon"></span><span class="label">' + soy.$$escapeHtml(AJS.format("{0} more child pages",opt_data.children.remainingChildPages.length)) + '</span></a>' : '') : '') + ((opt_data.createPermission && opt_data.children.createLink) ? '<a class="create-child-page-link" href="' + soy.$$escapeHtml(opt_data.children.createLink) + '"><span class="icon"></span><span class="label">' + soy.$$escapeHtml("Create child page") + '</span></a>' : '') + '</div>';
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.Pages.childPages.soyTemplateName = 'Confluence.Templates.Sidebar.Pages.childPages';
}


Confluence.Templates.Sidebar.Pages.currentPage = function(opt_data, opt_ignored) {
  return '' + ((opt_data.currentPage) ? '<ul class="ia-secondary-currentPage-title wiki' + ((opt_data.currentPage.active) ? ' current-item' : '') + '"><li><span class="icon"></span><span class="label">' + soy.$$escapeHtml(opt_data.currentPage.title) + '</span></li></ul>' : '');
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.Pages.currentPage.soyTemplateName = 'Confluence.Templates.Sidebar.Pages.currentPage';
}


Confluence.Templates.Sidebar.Pages.parentPage = function(opt_data, opt_ignored) {
  return '' + ((opt_data.parentPage) ? '<ul class="parent ia-secondary-header-title wiki' + ((opt_data.parentPage.active) ? ' current-item' : '') + '"><li class="parent-item"><a class="parent-item-link" href="' + soy.$$escapeHtml(opt_data.parentPage.url) + '" title="' + soy.$$escapeHtml(opt_data.parentPage.title) + '"><span class="icon"></span><span class="label">' + soy.$$escapeHtml(opt_data.parentPage.title) + '</span></a></li></ul>' : '');
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.Pages.parentPage.soyTemplateName = 'Confluence.Templates.Sidebar.Pages.parentPage';
}


Confluence.Templates.Sidebar.Pages.renderChildren = function(opt_data, opt_ignored) {
  var output = '';
  var childList65 = opt_data.children;
  var childListLen65 = childList65.length;
  for (var childIndex65 = 0; childIndex65 < childListLen65; childIndex65++) {
    var childData65 = childList65[childIndex65];
    output += '<li class="child-item" data-page-id="' + soy.$$escapeHtml(childData65.pageId) + '"><span class="icon"></span><a href="' + soy.$$escapeHtml(childData65.url) + '" title="' + soy.$$escapeHtml(childData65.title) + '"><span class="label">' + soy.$$escapeHtml(childData65.title) + '</span></a></li>';
  }
  return output;
};
if (goog.DEBUG) {
  Confluence.Templates.Sidebar.Pages.renderChildren.soyTemplateName = 'Confluence.Templates.Sidebar.Pages.renderChildren';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/linkbrowser-editor-adapter.js' */
AJS.$(function(){if(!$("body").hasClass("with-space-sidebar")){return}Confluence=Confluence||{};Confluence.Editor=Confluence.Editor||{};AJS.Rte=AJS.Rte||{};AJS.Rte.BookmarkManager=AJS.Rte.BookmarkManager||{};AJS.Rte.BookmarkManager.storeBookmark=AJS.$.noop;AJS.Rte.BookmarkManager.restoreBookmark=AJS.$.noop});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-ia.js' */
(function(a){Confluence.Sidebar={};AJS.toInit(function(h){var s=h(window);var G=h(document);var w=Math.min(285,s.width()/3);var H=285;var F=150;var t=55;var q=AJS.contextPath();var p=AJS.Meta.get("space-key");var c=AJS.Meta.get("use-keyboard-shortcuts")?" "+"(\u2009[\u2009)":"";Confluence.Sidebar.collapseTooltip="Collapse sidebar"+c;Confluence.Sidebar.expandTooltip="Expand sidebar"+c;var g=h(".ia-splitter").children();var I=h(".ia-splitter-left");if(I.length<1){return}var n=h(".acs-side-bar");var y=I.find(".ia-fixed-sidebar");var d=h("<div>",{"class":"ia-splitter-handle tipsy-enabled","data-tooltip":Confluence.Sidebar.collapseTooltip}).appendTo(y);h("<div>",{"class":"ia-splitter-handle-highlight"}).appendTo(d);var i=h(".ia-secondary-container");var A=h("#footer, #studio-footer");Confluence.Sidebar.throbberDiv=j;i.length&&E(i.attr("data-tree-type"));s.scroll(x);s.resize(x);s.on("touchend",x);G.ready(x);AJS.bind("confluence.header-resized",x);h("#header-precursor img").load(x);Confluence.Sidebar.applyTooltip=u;l();AJS.bind("sidebar.exit-configure-mode",l);try{var m=localStorage.sidebarWidth||w}catch(C){m=w}var f=m>F?m:t;k(f);v();y.css("visibility","visible");x();o();setTimeout(function(){Confluence.Sidebar.createFlyouts(n)},0);AJS.trigger("sidebar.finished-loading");s.one("pagetree-children-loaded",function(){var e=h(".plugin_pagetree_current");if(e.length){var K=e.offset();if(K.top>n.height()/2){n.scrollTop(K.top-n.height()/3)}if(K.left>n.width()/2){n.scrollLeft(K.left-n.width()/2)}}});AJS.bind("sidebar.enter-configure-mode",function(){b();J();y.addClass("configure-mode")});AJS.bind("sidebar.exit-configure-mode",function(){b();z();y.removeClass("configure-mode")});function b(){AJS.trigger("sidebar.hide-overlays")}function u(e,L){var K={live:true,gravity:"w",title:"data-tooltip",delayIn:500,delayOut:0,offset:5};h(e).tooltip(L?h.extend(K,L):K)}function l(){h(".acs-side-bar .quick-links-section").attr("data-collapsed-tooltip","Space shortcuts");h("#space-tools-menu-trigger").attr("data-collapsed-tooltip","Space tools");if(i.attr("data-tree-type")=="pages"){h(".acs-side-bar .ia-secondary-container").attr("data-collapsed-tooltip","Child pages");u(".collapsed .ia-secondary-container.tipsy-enabled",{title:"data-collapsed-tooltip"})}u(".expand-collapse-trigger");u(".ia-splitter-handle.tipsy-enabled");u(".collapsed .quick-links-section.tipsy-enabled, .collapsed .acs-nav-item > a.tipsy-enabled, .collapsed #space-tools-menu-trigger.tipsy-enabled",{title:"data-collapsed-tooltip"});u(".configure-mode .acs-side-bar-space-info.tipsy-enabled",{title:"data-configure-tooltip"});n.on("mousedown click scroll",b);h(window).on("scroll resize",b);AJS.bind("sidebar.hide-overlays",K);AJS.bind("sidebar.disable-tooltip",L);AJS.bind("sidebar.enable-all-tooltips",e);function L(P,O){var M=h(O).closest(".tipsy-enabled");if(M.size()!=1){return}M.removeClass("tipsy-enabled").addClass("tipsy-disabled").attr("title","");var N=M.data("tipsy");if(N){N.hoverState="out"}K()}function e(){h(".tipsy-disabled").removeClass("tipsy-disabled").addClass("tipsy-enabled")}function K(){h(".tipsy").remove()}}function v(){G.on("mousewheel",".ia-scrollable-section",function(N,O){var M=h(this).scrollTop();var L=h(this).get(0).scrollHeight-h(this).innerHeight()-1;if((O>0&&M<=0)||(O<0&&M>=L)){N.preventDefault()}else{if(h.browser.msie){N.preventDefault();var K=30;h(this).scrollTop(M+(-1*O*K))}}N.stopPropagation()})}function j(){var K=h(Confluence.Templates.Sidebar.throbber()),L=K.find(".spinner"),e=Raphael.spinner(L[0],10,"#666");K.find(".throbber").bind("remove",function(){e()});return K}function E(e){if(e==="blogs"){D(n,r)}else{if(e==="pages"){Confluence.Sidebar.Pages.installHandlers(n)}}}function r(M,N){var L=M.attr("data-group-type");var e=M.attr("data-group-value");var K=q+"/rest/ia/1.0/pagetree/blog/subtree";h.get(K,{spaceKey:p,groupType:L,groupValue:e}).done(N)}function D(e,K){e.delegate(".acs-tree-item > .icon, .acs-tree-item > .node-title","click",function(){var P=h(this);var O=P.parent();var L=O.find("> .icon");if(O.hasClass("opened")){O.children("ul").hide();O.removeClass("opened").addClass("closed");L.removeClass("icon-section-opened").addClass("icon-section-closed")}else{if(O.hasClass("closed")){var M=O.children("ul");if(M.length){M.show()}else{var N=h(Confluence.Templates.Sidebar.treeThrobber());O.append(N);K(O,function(R){var Q=h(Confluence.Templates.Sidebar.pagetreeList({pagetree:R,isSubtree:true}));N.remove();Q.appendTo(O)})}O.removeClass("closed").addClass("opened");L.removeClass("icon-section-closed").addClass("icon-section-opened")}}})}function x(){var e=I.offset().top,K=s.scrollTop(),L=s.scrollLeft();if(K<0){return}if(K>(G.height()-s.height())){return}if(L<0){return}if(L>(G.width()-s.width())){return}if(h("#header").css("position")!=="fixed"){y.css({top:Math.max(e-K,0)+"px",left:Math.min(L*-1,0)+"px"})}else{y.css({left:Math.min(L*-1,0)+"px"})}}function B(){A.css("margin-left",y.outerWidth()+"px")}function o(){var M=h("body");var K=false;var L=false;var N=function(O){L=true;O.preventDefault();g.one("selectstart",function(Q){Q.preventDefault()});var P=function(){if(y.width()<=F){k(t)}else{w=y.width()}L=false;M.off("mousemove.ia-splitter")};K=false;M.on("mousemove.ia-splitter",function(Q){if(Confluence.Sidebar.Configure.mode&&Q.pageX<H){return}k(Q.pageX);K=true});M.one("mouseup mouseleave",P)};d.on("mousedown.ia-splitter",function(O){N(O);b()}).click(function(){if(!K){e()}else{K=false}});Confluence.Sidebar.toggle=e;function e(){if(Confluence.Sidebar.Configure.mode){return}var O=y.width();if(O>t){if(O<=F){w=H;k(w)}else{w=O;k(t)}}else{k(w)}}}function k(K){K=Math.max(K,t);try{localStorage.sidebarWidth=K}catch(L){}if(K<=F){y.addClass("collapsed");d.attr("data-tooltip",Confluence.Sidebar.expandTooltip);AJS.trigger("sidebar.collapsed")}else{if(y.hasClass("collapsed")){y.removeClass("collapsed");d.attr("data-tooltip",Confluence.Sidebar.collapseTooltip);AJS.trigger("sidebar.expanded")}}y.width(K);g.eq(1).css("margin-left",K+"px");B()}function J(){if(y.width()<H){Confluence.Sidebar.widthBeforeConfiguring=y.width();k(H)}}function z(){if(Confluence.Sidebar.widthBeforeConfiguring){k(Confluence.Sidebar.widthBeforeConfiguring);Confluence.Sidebar.widthBeforeConfiguring=undefined}}})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/configurable-nav.js' */
(function(a){AJS.Confluence.ConfigurableNav=AJS.RestfulTable.extend({initialize:function(c){var b=this;b.options=a.extend(true,c,{model:AJS.RestfulTable.EntryModel,Collection:Backbone.Collection.extend({url:c.resources.self,model:AJS.RestfulTable.EntryModel}),columns:[{id:"title"}]});b._events=b._events||AJS.RestfulTable.Events;b._event=b._event||AJS.RestfulTable.Events;b.classNames=AJS.RestfulTable.ClassNames;b.dataKeys=AJS.RestfulTable.DataKeys;b.$table=c.$el.addClass(this.classNames.RESTFUL_TABLE).addClass(this.classNames.ALLOW_HOVER).addClass("aui").addClass(b.classNames.LOADING);b.$table.prepend('<colgroup><col span="1" class="aui-restfultable-order"><col span="1"><col span="1" class="aui-restfultable-operations"></colgroup>');b.$tbody=a("<tbody/>");b._models=this._createCollection();b._rowClass=AJS.Confluence.ConfigurableNav.Row;b.editRows=[];b.enableReordering();b._models.bind("remove",function(d){a.each(b.getRows(),function(e,f){if(f.model===d){if(f.hasFocus()&&b._createRow){b._createRow.trigger(b._event.FOCUS)}b.removeRow(f)}})});a.get(b.options.resources.all,function(d){b.populate(d)});Confluence.Sidebar.applyTooltip(".hide-link, .show-link, .delete-link, .toggle-link",{gravity:"ne"})},enableReordering:function(){var b=this;this.$tbody.sortable({handle:"."+this.classNames.DRAG_HANDLE,helper:function(f,c){var d=c.clone(true).addClass(b.classNames.MOVEABLE);d.children().each(function(e){a(this).width(c.children().eq(e).width())});return d},start:function(c,d){var e=d.placeholder.find("td");d.item.addClass(b.classNames.MOVEABLE).children().each(function(f){a(this).width(e.eq(f).width())});d.placeholder.html('<td colspan="'+b.getColumnCount()+'">&nbsp;</td>').css("visibility","visible");b.getRowFromElement(d.item[0]).trigger(b._event.MODAL)},stop:function(c,d){if(jQuery(d.item[0]).is(":visible")){d.item.removeClass(b.classNames.MOVEABLE).children().attr("style","");d.placeholder.removeClass(b.classNames.ROW);b.getRowFromElement(d.item[0]).trigger(b._event.MODELESS)}},update:function(e,g){var c,d,f={},h=b.getRowFromElement(g.item[0]);if(h){if(b.options.reverseOrder){d=g.item.next();if(!d.length){f.position="First"}else{c=b.getRowFromElement(d).model;f.after=c.url()}}else{d=g.item.prev();if(!d.length){f.position="First"}else{c=b.getRowFromElement(d).model;f.after=c.url()}}f.spaceKey=AJS.Meta.get("space-key");a.ajax({url:h.model.url()+"/move",type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify(f),complete:function(){h.hideLoading()},success:function(i){AJS.triggerEvtForInst(b._event.REORDER_SUCCESS,b,[i])},error:function(j){var i=a.parseJSON(j.responseText||j.data);AJS.triggerEvtForInst(b._event.SERVER_ERROR,b,[i,j])}});h.showLoading()}},axis:"y",delay:0,containment:"document",cursor:"move",scroll:true,zIndex:8000});this.$tbody.bind("selectstart mousedown",function(c){return !a(c.target).is("."+b.classNames.DRAG_HANDLE)})}});AJS.Confluence.ConfigurableNav.ReadView=AJS.RestfulTable.CustomReadView.extend({render:function(b){return _.template('<span class="acs-nav-item-link" title="<%=title%>"><span class="icon"></span><span class="acs-nav-item-label"><%=title%></span></span>',{title:AJS.escapeHtml(b.title)})}});AJS.Confluence.ConfigurableNav.Row=AJS.RestfulTable.Row.extend({render:function(){var b=this,d=this.model.toJSON(),e=a("<td class='aui-restfultable-operations' />").append(this.renderOperations(d.canHide,d.hidden)),c=a('<td class="'+this.classNames.ORDER+'"/>').append(this.renderDragHandle());b._event=b._event||b._events;b.$el.attr("data-id",this.model.id);b.$el.append(c);a.each(b.columns,function(f,g){var h,k=a("<td />"),j=d[g.id];if(j){b.$el.attr("data-"+g.id,j)}h=new AJS.Confluence.ConfigurableNav.ReadView().render(d);k.append(h);b.$el.append(k)});b.$el.append(e);d.canHide&&d.hidden&&b.$el.addClass("hidden-link");b.$el.addClass(this.classNames.ROW+" "+b.classNames.READ_ONLY+" acs-nav-item "+d.styleClass);b.trigger(this._event.RENDER,this.$el,d);b.$el.trigger(this._event.CONTENT_REFRESHED,[b.$el]);return b},renderOperations:function(f,e){var c=this,b=a('<a href="#" class="aui-icon aui-icon-small"/>');if(f){function d(g){if(g.hasClass("hide-link")){g.attr("data-tooltip","Hide link")}else{g.attr("data-tooltip","Show link")}}b.addClass(e?"show-link":"hide-link").click(function(g){g.preventDefault();a.ajax({url:c.model.url()+(e?"/show":"/hide"),type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:AJS.Meta.get("space-key")})}).done(function(){b.closest(".acs-nav-item").toggleClass("hidden-link");b.toggleClass("hide-link").toggleClass("show-link");d(b)})});d(b)}else{b.addClass("delete-link tipsy-enabled").click(function(g){g.preventDefault();if(a(".acs-nav").data("quick-links-state")!="hide"){AJS.trigger("sidebar.disable-tooltip",this);c.destroy()}}).attr("data-tooltip","Remove link")}return b},destroy:function(){this.model.destroy({data:{spaceKey:AJS.Meta.get("space-key")}})}})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-pages.js' */
(function(b){var a=AJS.Meta.get("context-path");Confluence.Sidebar.Pages={installHandlers:function(d){d.find(".more-children-link").click(function(f){f.preventDefault();d.find("ul.more-children").show();b(this).hide()})},quickLinksContent:function(){return new b.Deferred().resolve(b(".acs-side-bar .quick-links-wrapper").html())},childPageCollapsedContent:function(){var e=b(".acs-side-bar .ia-secondary-header");var d=b(".acs-side-bar .ia-secondary-parent-content");var g=b(".acs-side-bar .ia-secondary-current-content");var f=b(".acs-side-bar .ia-secondary-content");return new b.Deferred().resolve(b("<div>").append(b("<div>").addClass("acs-side-bar-flyout-wiki-wrapper").append(e.clone()).append(d.clone()).append(g.clone()).append(f.clone())).html())},pageTreeCollapsedContent:function(){var d=b(".page-tree-flyout-content");if(d.length==0){return c().pipe(function(e){var f=b("<div>").addClass("acs-side-bar-flyout-wiki-wrapper").append(Confluence.Templates.Sidebar.Pages.renderPageContextualNav({pageContextualNav:e,hasCreatePermission:b(".acs-nav").data("has-create-permission")}));b("body").append(b("<div>").addClass("page-tree-flyout-content hidden").append(f.clone()));return f})}else{return new b.Deferred().resolve(d.html())}}};function c(){return b.ajax({url:a+"/rest/ia/1.0/space/childPagesContextualNav",data:{pageId:AJS.Meta.get("page-id")}})}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-links.js' */
AJS.$(function(){Confluence.Sidebar.Configure={mode:false};var c=AJS.$,m=AJS.Meta.get("context-path"),k=AJS.Meta.get("space-key"),i=c(".acs-side-bar"),q=i.find(".ia-secondary-container"),d,o,j,l,g=c(".acs-nav");c.ajaxSetup({cache:false});c("body").on("click","#acs-configure-link, a.configure-sidebar",function(u){u.preventDefault();t()});c("#space-favourite-remove").on("click",function(){b("remove");c("#space-favourite-add").show();c("#space-favourite-remove").hide()});c("#space-favourite-add").on("click",function(){b("add");c("#space-favourite-remove").show();c("#space-favourite-add").hide()});function b(v){var w;var u;if(v==="add"){w="PUT";u="confluence.space-sidebar.favourite.click"}else{w="DELETE";u='confluence.space-sidebar.favourite-remove.click"'}c.ajax({url:m+"/rest/experimental/relation/user/current/favourite/toSpace/"+k,type:w,dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:k})});AJS.trigger("analyticsEvent",{name:u})}function t(){AJS.trigger("sidebar-before-enter-configure-mode");var u=c(".custom-sidebar-content");var x=u.length;var A;var z;if(x){z=m+"/spaces/custompagecontent.action?key="+k;A=u.children().html()}l=g.data("nav-type");Confluence.Sidebar.Configure.mode=true;j=c(".acs-nav-sections .acs-nav-item.current-item").data("collector-key");d=Confluence.Sidebar.throbberDiv();d.height(c(".acs-nav-sections").height());q.hide();c(".acs-nav-sections").replaceWith(d);var w=Confluence.Templates.Sidebar.configure({pageTree:l==="page-tree",quickLinksState:g.data("quick-links-state"),hasSidebarCustomisation:x,customContentAdminLink:z,sidebarCustomisation:A});o=c(w).hide();d.after(o);h();f();r();var y={};var v=function(){d.replaceWith(o);o.show()};c("#acs-nav-list-main").one(AJS.RestfulTable.Events.INITIALIZED,function(){y.main=true;y.quick&&v()});c("#acs-nav-list-quick").one(AJS.RestfulTable.Events.INITIALIZED,function(){y.quick=true;y.main&&v()});c(".acs-nav-type").change(function(B){s("nav-type",c(this).val(),function(C){q.data("tree-type",C);g.data("nav-type",C)})});c(".acs-done-link").click(function(B){B.preventDefault();c(".acs-done-link").attr("aria-disabled",true).prop("disabled",true);n()});c(".quick-links-header a").click(function(C){C.preventDefault();var B=g.data("quick-links-state")=="hide"?"show":"hide";s("quick-links-state",B,a)});AJS.$(".acs-side-bar-space-info").on("click.configurelogo",p);AJS.trigger("sidebar.enter-configure-mode")}function p(w){var v=AJS.$(".acs-side-bar-space-info > .flyout-handle");v.addClass("loading").spin();var u=WRM.require("wr!com.atlassian.confluence.plugins.confluence-space-ia:avatar-picker",function(){AJS.trigger("deferred.spaceia.open.configure.space")});u.always(function(){v.removeClass("loading").spinStop()});w.preventDefault()}function s(u,v,w){c.ajax({url:m+"/rest/ia/1.0/space/option",type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:k,option:u,value:v}),success:function(x){w(v)}})}function n(){if(l!==g.data("nav-type")){location.reload();return}var u=c(".custom-sidebar-content");var w=u.length;var y;if(w){y=u.children().html()}d=Confluence.Sidebar.throbberDiv();d.height(o.height());o.replaceWith(d);e();q.show().css("display","");var v=function(){var z=c(Confluence.Templates.Sidebar.renderLinks({mainLinks:x.main,quickLinks:x.quick.reverse(),advancedLinks:x.advanced,hasConfigurePermission:true,collectorToHighlight:j,quickLinksState:g.data("quick-links-state"),hasSidebarCustomisation:w,sidebarCustomisation:y}));d.replaceWith(z);Confluence.Sidebar.Configure.mode=false;AJS.trigger("sidebar.exit-configure-mode")};var x={};c.get(m+"/rest/ia/1.0/link/main",{spaceKey:k,includeHidden:false}).done(function(z){x.main=z;x.quick&&x.advanced&&v()});c.get(m+"/rest/ia/1.0/link/quick",{spaceKey:k}).done(function(z){x.quick=z;x.main&&x.advanced&&v()});c.get(m+"/rest/ia/1.0/link/advanced",{spaceKey:k}).done(function(z){x.advanced=z;x.main&&x.quick&&v()});Confluence.Sidebar.Configure.Logo&&Confluence.Sidebar.Configure.Logo.unbind()}function h(){WRM.require("wr!com.atlassian.confluence.plugins.confluence-space-ia:link-dialog",function(){var u=new c.Deferred();c(".acs-add-link").click(function(v){u.done(function(){v.preventDefault();if(g.data("quick-links-state")!=="hide"){Confluence.Sidebar.LinkAdapter.hijackLinkBrowser();Confluence.Editor.LinkBrowser.open();c("#recentlyviewed-panel-id").click()}})}).addClass("acs-add-link-ready");if(AJS.Meta.get("space-key")){AJS.Confluence.EditorLoader.load(function(){u.resolve()},function(){AJS.log("Attempted to load editor for space ia side bar. Loading the editor failed.");u.reject()})}else{u.resolve()}})}function f(){var u=c("#acs-nav-list-quick");var w=c(".acs-nav-sections .tip").hide();var v=function(){if(Confluence.Sidebar.Configure.QuickLinks.isEmpty()){u.hide();w.show()}else{w.hide();u.show()}};AJS.bindEvt(AJS.RestfulTable.Events.INITIALIZED,v);AJS.bindEvt(AJS.RestfulTable.Events.ROW_ADDED,v);AJS.bindEvt(AJS.RestfulTable.Events.ROW_REMOVED,v)}function r(){Confluence.Sidebar.Configure.MainLinks=new AJS.Confluence.ConfigurableNav({$el:c("#acs-nav-list-main"),resources:{all:m+"/rest/ia/1.0/link/main?spaceKey="+k+"&includeHidden=true",self:m+"/rest/ia/1.0/link"}});Confluence.Sidebar.Configure.QuickLinks=new AJS.Confluence.ConfigurableNav({$el:c("#acs-nav-list-quick"),resources:{all:m+"/rest/ia/1.0/link/quick?spaceKey="+k,self:m+"/rest/ia/1.0/link"},reverseOrder:true})}function e(){Confluence.Sidebar.Configure.MainLinks.remove();Confluence.Sidebar.Configure.MainLinks.unbind();Confluence.Sidebar.Configure.QuickLinks.remove();Confluence.Sidebar.Configure.QuickLinks.unbind();c(AJS).unbind(AJS.RestfulTable.Events.INITIALIZED);c(AJS).unbind(AJS.RestfulTable.Events.ROW_ADDED);c(AJS).unbind(AJS.RestfulTable.Events.ROW_REMOVED)}function a(u){g.data("quick-links-state",u);if(u==="hide"){c(".acs-nav-list-quick-section").addClass("hidden-section")}else{c(".acs-nav-list-quick-section").removeClass("hidden-section")}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-space-tools.js' */
define("confluence-space-ia/sidebar-space-tools",["ajs","jquery","confluence/legacy"],function(b,c,d){function a(){var e=[];var h=[];var k=b.version.indexOf("5.7")===0;var i;var l;var f,j;if(!k){f=c("#space-tools-menu-trigger");j=c("#space-tools-menu")}var g;if(k){c("#space-tools-web-items").children("div").each(function(){e.push({label:c(this).data("label"),href:c(this).data("href")})})}else{b.warn("Remove legacy sidebar code when upgrade to AUI 5.8+");j.on({"aui-dropdown2-show":function(){b.trigger("sidebar.disable-tooltip",f)},"aui-dropdown2-hide":function(){b.trigger("sidebar.enable-all-tooltips")}});c("#space-tools-web-items").children("div").each(function(){e.push({text:c(this).data("label"),href:c(this).data("href")})})}if(k){c("#space-tools-menu-additional-items").children("div").each(function(){h.push({className:c(this).data("class"),label:c(this).data("label"),href:c(this).data("href")})})}else{c("#space-tools-menu-additional-items").children("div").each(function(){h.push({extraClasses:c(this).data("class"),text:c(this).data("label"),href:c(this).data("href")})})}if(k){l={hideDelay:null,width:170,displayShadow:false,calculatePositions:function(m,n){var o=n.target.offset();return{popupCss:{top:o.top-m.height(),left:o.left},arrowCss:{display:"none"}}},hideCallback:function(){b.trigger("sidebar.enable-all-tooltips")}};i=b.InlineDialog(c("#space-tools-menu-trigger"),"space-tools",function(n,m,o){n.html(d.Templates.Sidebar.spaceToolsMenu({spaceToolLinks:e,spaceLinks:h,isAuiFiveSeven:k}));c(m).one("click",function(p){if(c("#inline-dialog-space-tools").is(":visible")){setTimeout(function(){i.hide()},0)}});b.trigger("sidebar.disable-tooltip",m);b.trigger("sidebar.spacetools-loaded");o();return false},l);i.addClass("aui-dropdown2 aui-style-default");b.bind("sidebar.hide-overlays",i.hide)}else{j.html(d.Templates.Sidebar.spaceToolsMenu({spaceToolLinks:e,spaceLinks:h}));if(b&&b.Confluence&&b.Confluence.Analytics&&b.Confluence.Analytics.setAnalyticsSource){b.Confluence.Analytics.setAnalyticsSource(j.find("a:not(.configure-sidebar)"),"spacetools")}b.bind("sidebar.hide-overlays",function(){if(j.filter('[aria-hidden="false"]').length){c("#space-tools-menu-trigger").trigger("aui-button-invoke")}})}g=c(".expand-collapse-trigger");g.click(function(m){m.preventDefault();d.Sidebar.toggle()});g.attr("data-tooltip",c(".ia-fixed-sidebar").hasClass("collapsed")?d.Sidebar.expandTooltip:d.Sidebar.collapseTooltip);b.bind("sidebar.collapsed",function(){g.attr("data-tooltip",d.Sidebar.expandTooltip)});b.bind("sidebar.expanded",function(){g.attr("data-tooltip",d.Sidebar.collapseTooltip)})}return a});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-space-tools-require.js' */
require(["confluence-space-ia/sidebar-space-tools"],function(a){AJS.toInit(function(){a()})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-flyouts.js' */
(function(d){var b,c,a;Confluence.Sidebar.createFlyouts=function(g){b=f(d(".collapsed .quick-links-section"),Confluence.Sidebar.Pages.quickLinksContent,"sidebar-quick-links-flyout",{flyout:"quick-links"});var h=g.find(".ia-secondary-container");if(h.length&&h.attr("data-tree-type")=="pages"){c=f(d(".collapsed .ia-secondary-header-title.wiki"),Confluence.Sidebar.Pages.childPageCollapsedContent,"sidebar-children-flyout",{flyout:"children"})}if(h.length&&h.attr("data-tree-type")=="page-tree"){a=f(d(".collapsed .ia-secondary-header-title.page-tree"),Confluence.Sidebar.Pages.pageTreeCollapsedContent,"sidebar-page-tree-flyout",{flyout:"pagetree"})}};function f(g,j,i,l){var k=function(n,m,o){d(n).addClass("acs-side-bar-flyout ia-scrollable-section");d(n).empty().append(Confluence.Sidebar.throbberDiv());j().done(function(p){d(n).html(p)});AJS.trigger("sidebar.flyout-triggered",l);o();d(m).one("click",function(p){if(d("#inline-dialog-"+i).is(":visible")){setTimeout(function(){h.hide()},0)}});AJS.trigger("sidebar.disable-tooltip",m)};var h=AJS.InlineDialog(g,i,k,{gravity:"w",calculatePositions:e,useLiveEvents:true,hideDelay:null,hideCallback:function(){AJS.trigger("sidebar.enable-all-tooltips")}});AJS.bind("sidebar.hide-overlays",h.hide);return h}function e(h,k,p,g){var q=k.target.offset();var o=k.target.width();var l=k.target.height();var n={top:q.top+l/2-15,left:q.left+o+5,right:"auto"};var i=d(window);var m=20;n.maxHeight=i.height()+i.scrollTop()-n.top-m;if(d.browser.msie&&parseInt(d.browser.version,10)<=8){n.maxHeight-=40}var j={top:9};return{popupCss:n,arrowCss:j,gravity:"w"}}})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/external/jquery.mousewheel.min.js' */
/*! Copyright (c) 2011 Brandon Aaron (http://brandonaaron.net)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Thanks to: http://adomas.org/javascript-mouse-wheel/ for some pointers.
 * Thanks to: Mathias Bank(http://www.mathias-bank.de) for a scope bug fix.
 * Thanks to: Seamus Leahy for adding deltaX and deltaY
 *
 * Version: 3.0.6
 * 
 * Requires: 1.2.2+
 */
(function(a){function d(b){var c=b||window.event,d=[].slice.call(arguments,1),e=0,f=!0,g=0,h=0;return b=a.event.fix(c),b.type="mousewheel",c.wheelDelta&&(e=c.wheelDelta/120),c.detail&&(e=-c.detail/3),h=e,c.axis!==undefined&&c.axis===c.HORIZONTAL_AXIS&&(h=0,g=-1*e),c.wheelDeltaY!==undefined&&(h=c.wheelDeltaY/120),c.wheelDeltaX!==undefined&&(g=-1*c.wheelDeltaX/120),d.unshift(b,e,g,h),(a.event.dispatch||a.event.handle).apply(this,d)}var b=["DOMMouseScroll","mousewheel"];if(a.event.fixHooks)for(var c=b.length;c;)a.event.fixHooks[b[--c]]=a.event.mouseHooks;a.event.special.mousewheel={setup:function(){if(this.addEventListener)for(var a=b.length;a;)this.addEventListener(b[--a],d,!1);else this.onmousewheel=d},teardown:function(){if(this.removeEventListener)for(var a=b.length;a;)this.removeEventListener(b[--a],d,!1);else this.onmousewheel=null}},a.fn.extend({mousewheel:function(a){return a?this.bind("mousewheel",a):this.trigger("mousewheel")},unmousewheel:function(a){return this.unbind("mousewheel",a)}})})(jQuery);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:spacesidebar', location = 'js/sidebar-logo.js' */
AJS.toInit(function(f){Confluence.Sidebar.Configure.Logo={};var b=f(".acs-side-bar-space-info div.name a");var h;var a;var e=function(i){f(".space-logo .avatar-img").attr("src",AJS.Meta.get("context-path")+i)};var d=function(i){b.attr("title",i).text(i)};var g=function(i){if(!h){h=new i({onCrop:function(k,j){f.ajax({type:"POST",dataType:"json",contentType:"application/json",data:JSON.stringify({spaceKey:AJS.Meta.get("space-key"),spaceName:j,logoDataURI:k}),url:AJS.Meta.get("context-path")+"/rest/ia/1.0/space/setLogo",success:function(l){e(l.logoDownloadPath);d(l.name);h.hide()},error:function(l){h.setMessage("An error occurred while updating space details");h._removeSaveImageLoadingIcon()}})}})}h.show(f(".acs-side-bar-space-info div.name a").text());return false};var c=function(){var i=function(l,k,m){f(l).addClass("acs-side-bar-flyout");f(l).empty();l.html(AJS.template.load("logo-config-content"));l.unbind("mouseover mouseout");AJS.trigger("sidebar.disable-tooltip",k);m()};if(!a){a=AJS.InlineDialog(f(".acs-side-bar-space-info"),"space-logo-config",i,{gravity:"w",calculatePositions:j,useLiveEvents:true,hideCallback:function(){AJS.trigger("sidebar.enable-all-tooltips")},hideDelay:null,noBind:true,width:635})}function j(l,n,r,k){var s=n.target.offset();var q=n.target.width();var o=n.target.height();var p={top:s.top+o/2-15,left:s.left+q+5,right:"auto"};var m={top:9};return{popupCss:p,arrowCss:m,gravity:"w"}}a.show()};AJS.bind("sidebar-before-enter-configure-mode",function(){AJS.bind("deferred.spaceia.open.configure.space",function(i){if(AJS.Meta.get("space-key")=="~"+AJS.Meta.get("remote-user")){c()}else{require(["confluence-space-ia/avatar-picker/avatar-picker-dialog",],g)}i.preventDefault();return false})});Confluence.Sidebar.Configure.Logo.unbind=function(){f("#inline-dialog-space-logo-config .cancel").click();f(".acs-side-bar-space-info").off("click.configurelogo");AJS.unbind("deferred.spaceia.open.configure.space")}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'soy/sidebar-relevant.soy' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-heuristics.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-parser.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-structure.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/content-tracker.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/page-mode-view.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/keyboard-mode-view.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.confluence-space-ia:sidebar-relevant', location = 'js/relevant/controller.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.share-page:mail-page-resources', location = 'templates/sharepage/share-dialog.soy' */
// This file was automatically generated from share-dialog.soy.
// Please don't edit this file by hand.

/**
 * @fileoverview Templates in namespace Confluence.Templates.Share.Dialog.
 */

if (typeof Confluence == 'undefined') { var Confluence = {}; }
if (typeof Confluence.Templates == 'undefined') { Confluence.Templates = {}; }
if (typeof Confluence.Templates.Share == 'undefined') { Confluence.Templates.Share = {}; }
if (typeof Confluence.Templates.Share.Dialog == 'undefined') { Confluence.Templates.Share.Dialog = {}; }


Confluence.Templates.Share.Dialog.shareContentPopup = function(opt_data, opt_ignored) {
  return '<form action="#" method="post" class="aui share-content-popup"><div class="field-group"><div class="autocomplete-user-target"><input class="text autocomplete-sharepage" id="users" data-max="10" data-dropdown-target=".autocomplete-user-target" data-none-message="' + soy.$$escapeHtml("No matches") + '" placeholder="' + soy.$$escapeHtml("User name, group or email") + '"/></div><ol class="recipients"></ol></div><div class="field-group"><textarea class="textarea" id="note" placeholder="' + soy.$$escapeHtml("Add an optional note") + '"/></div><div class="field-group button-panel"><div class="progress-messages-icon"></div><div class="progress-messages"></div><input class="button submit" type="submit" value="' + soy.$$escapeHtml("Share") + '" disabled/><a class="close-dialog" href="#">' + soy.$$escapeHtml("Cancel") + '</a></div></form>';
};
if (goog.DEBUG) {
  Confluence.Templates.Share.Dialog.shareContentPopup.soyTemplateName = 'Confluence.Templates.Share.Dialog.shareContentPopup';
}


Confluence.Templates.Share.Dialog.recipientUser = function(opt_data, opt_ignored) {
  return '<li data-userkey="' + soy.$$escapeHtml(opt_data.userKey) + '" style="display: none" class="recipient-user"><img src="' + soy.$$escapeHtml(opt_data.thumbnailLink.href) + '" title="' + soy.$$escapeHtml(opt_data.title) + '"/><span class="title" title="' + soy.$$escapeHtml(opt_data.title) + '">' + soy.$$escapeHtml(opt_data.title) + '</span><span class="remove-recipient"/></li>';
};
if (goog.DEBUG) {
  Confluence.Templates.Share.Dialog.recipientUser.soyTemplateName = 'Confluence.Templates.Share.Dialog.recipientUser';
}


Confluence.Templates.Share.Dialog.recipientEmail = function(opt_data, opt_ignored) {
  return '<li data-email="' + soy.$$escapeHtml(opt_data.email) + '" style="display: none" class="recipient-email"><img src="' + soy.$$escapeHtml(opt_data.icon) + '" title="' + soy.$$escapeHtml(opt_data.email) + '"/><span class="title" title="' + soy.$$escapeHtml(opt_data.email) + '">' + soy.$$escapeHtml(opt_data.email) + '</span><span class="remove-recipient"/></li>';
};
if (goog.DEBUG) {
  Confluence.Templates.Share.Dialog.recipientEmail.soyTemplateName = 'Confluence.Templates.Share.Dialog.recipientEmail';
}


Confluence.Templates.Share.Dialog.recipientGroup = function(opt_data, opt_ignored) {
  return '<li data-group="' + soy.$$escapeHtml(opt_data.title) + '" style="display: none" class="recipient-group"><span><img src="' + soy.$$escapeHtml(opt_data.thumbnailLink.href) + '" title="' + soy.$$escapeHtml(opt_data.title) + '"/><span>' + soy.$$escapeHtml(opt_data.title) + '</span><span class="remove-recipient"/></span></li>';
};
if (goog.DEBUG) {
  Confluence.Templates.Share.Dialog.recipientGroup.soyTemplateName = 'Confluence.Templates.Share.Dialog.recipientGroup';
}

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.share-page:mail-page-resources', location = 'js/mailpage.js' */
AJS.Confluence.SharePage={};AJS.Confluence.SharePage.autocompleteUser=function(d){d=d||document.body;var e=AJS.$,a=/^([a-zA-Z0-9_\.\-\+\!#\$%&'\*/=\?\^_`{|}~])+\@.*/;var c=function(j){if(!j||!j.result){throw new Error("Invalid JSON format")}var f=[];for(var g=0;g<j.result.length;g++){var h=j.result[g];if(h.type=="group"){h=b(h)}}f.push(j.result);return f};function b(f){if(f.name=="confluence-users"||f.name=="confluence-administrators"){return f}f.title=f.name;f.group=f.name;f.thumbnailLink={href:Confluence.getContextPath()+"/download/resources/com.atlassian.confluence.plugins.share-page:mail-page-resources/images/group.png",type:"image/png",rel:"thumbnail"};f.link=[{href:Confluence.getContextPath(),rel:"self"}];return f}e("input.autocomplete-sharepage[data-autocomplete-user-bound!=true]",d).each(function(){var h=e(this).attr("data-autocomplete-sharepage-bound","true").attr("autocomplete","off");var g=h.attr("data-max")||10,j=h.attr("data-alignment")||"left",i=h.attr("data-dropdown-target"),f=null;if(i){f=e(i)}else{f=e("<div></div>");h.after(f)}f.addClass("aui-dd-parent autocomplete");h.quicksearch(AJS.REST.getBaseUrl()+"search/user-or-group.json",function(){h.trigger("open.autocomplete-sharepage")},{makeParams:function(k){return{"max-results":g,query:k.replace("{|}","")}},dropdownPlacement:function(k){f.append(k)},makeRestMatrixFromData:c,addDropdownData:function(l){var k=e.trim(h.val());if(a.test(k)){l.push([{name:k,email:k,href:"#",icon:Confluence.getContextPath()+"/download/resources/com.atlassian.confluence.plugins.share-page:mail-page-resources/images/envelope.png"}])}if(!l.length){var m=h.attr("data-none-message");if(m){l.push([{name:m,className:"no-results",href:"#"}])}}return l},ajsDropDownOptions:{alignment:j,displayHandler:function(k){if(k.restObj&&k.restObj.username){return k.name+" ("+k.restObj.username+")"}return k.name},selectionHandler:function(m,l){if(l.find(".search-for").length){h.trigger("selected.autocomplete-sharepage",{searchFor:h.val()});return}if(l.find(".no-results").length){this.hide();m.preventDefault();return}var k=e("span:eq(0)",l).data("properties");if(!k.email){k=k.restObj}h.trigger("selected.autocomplete-sharepage",{content:k});this.hide();m.preventDefault()}}})})};(function(a){jQuery.fn.extend({elastic:function(){var b=["paddingTop","paddingRight","paddingBottom","paddingLeft","fontSize","lineHeight","fontFamily","width","fontWeight","border-top-width","border-right-width","border-bottom-width","border-left-width","borderTopStyle","borderTopColor","borderRightStyle","borderRightColor","borderBottomStyle","borderBottomColor","borderLeftStyle","borderLeftColor"];return this.each(function(){if(this.type!=="textarea"){return false}var g=jQuery(this),c=jQuery("<div />").css({position:"absolute",display:"none","word-wrap":"break-word","white-space":"pre-wrap"}),j=parseInt(g.css("line-height"),10)||parseInt(g.css("font-size"),"10"),l=parseInt(g.css("height"),10)||j*3,k=parseInt(g.css("max-height"),10)||Number.MAX_VALUE,d=0;if(k<0){k=Number.MAX_VALUE}c.appendTo(g.parent());var f=b.length;while(f--){c.css(b[f].toString(),g.css(b[f].toString()))}function h(){var i=Math.floor(parseInt(g.width(),10));if(c.width()!==i){c.css({width:i+"px"});e(true)}}function m(i,o){var n=Math.floor(parseInt(i,10));if(g.height()!==n){g.css({height:n+"px",overflow:o})}}function e(p){var o=g.val().replace(/&/g,"&amp;").replace(/ {2}/g,"&nbsp;").replace(/<|>/g,"&gt;").replace(/\n/g,"<br />");var i=c.html().replace(/<br>/ig,"<br />");if(p||o+"&nbsp;"!==i){c.html(o+"&nbsp;");if(Math.abs(c.height()+j-g.height())>3){var n=c.height()+j;if(n>=k){m(k,"auto")}else{if(n<=l){m(l,"hidden")}else{m(n,"hidden")}}}}}g.css({overflow:"hidden"});g.bind("keyup change cut paste",function(){e()});a(window).bind("resize",h);g.bind("resize",h);g.bind("update",e);g.bind("input paste",function(i){setTimeout(e,250)});e()})}})})(AJS.$);(function(f){var e,c={hideCallback:a,width:250,hideDelay:3600000,calculatePositions:function(h,o,w,s){var p;var y;var u;var l=-7;var m;var q;var x=o.target.offset();var g=o.target.outerWidth();var j=x.left+g/2;var t=(window.pageYOffset||document.documentElement.scrollTop)+f(window).height();var k=10;u=x.top+o.target.outerHeight()+s.offsetY;p=x.left+s.offsetX;var n=x.top>h.height();var i=(u+h.height())<t;q=(!i&&n)||(s.onTop&&n);var r=f(window).width()-(p+s.width+k);if(q){u=x.top-h.height()-8;var v=s.displayShadow?(AJS.$.browser.msie?10:9):0;l=h.height()-v}m=j-p+s.arrowOffsetX;if(s.isRelativeToMouse){if(r<0){y=k;p="auto";m=w.x-(f(window).width()-s.width)}else{p=w.x-20;y="auto";m=w.x-p}}else{if(r<0){y=k;p="auto";m=j-(f(window).width()-h.outerWidth())}else{if(s.width<=g/2){m=s.width/2;p=j-s.width/2}}}return{displayAbove:q,popupCss:{left:p,right:y,top:u},arrowCss:{position:"absolute",left:m,right:"auto",top:l}}}};var a=function(){f(".dashboard-actions .explanation").hide()};var d=function(j,h,i){if(j.find("input").length){i();return}j.append(Confluence.Templates.Share.Dialog.shareContentPopup());AJS.Confluence.SharePage.autocompleteUser();var k=function(m){AJS.Confluence.SharePage.current.hide();if(m){setTimeout(function(){j.empty()},300)}return false};f(document).keyup(function(m){if(m.keyCode==27){k(true);f(document).unbind("keyup",arguments.callee);return false}return true});j.find(".close-dialog").click(function(){k(true)});j.find("#note").elastic();j.find("form").submit(function(){var r=[];j.find(".recipients li").each(function(s,t){r.push(f(t).attr("data-userKey"))});if(r.length<=0){return false}f("button,input,textarea",this).attr("disabled","disabled");j.find(".progress-messages-icon").removeClass("error");j.find(".progress-messages").text("Sending");j.find(".progress-messages").attr("title","Sending");var o=Raphael.spinner(j.find(".progress-messages-icon")[0],7,"#666");j.find(".progress-messages-icon").css("position","absolute").css("left","0").css("margin-top","3px");j.find(".progress-messages").css("padding-left",j.find(".progress-messages-icon").innerWidth()+20);var r=[];j.find(".recipients li[data-userKey]").each(function(s,t){r.push(f(t).attr("data-userKey"))});var q=[];j.find(".recipients li[data-email]").each(function(s,t){q.push(f(t).attr("data-email"))});var m=[];j.find(".recipients li[data-group]").each(function(s,t){m.push(f(t).attr("data-group"))});var n=j.find("#note");var p={users:r,emails:q,groups:m,note:n.hasClass("placeholded")?"":n.val(),entityId:AJS.params.pageId};f.ajax({type:"POST",contentType:"application/json; charset=utf-8",url:Confluence.getContextPath()+"/rest/share-page/latest/share",data:JSON.stringify(p),dataType:"text",success:function(){setTimeout(function(){o();j.find(".progress-messages-icon").addClass("done");j.find(".progress-messages").text("Sent");j.find(".progress-messages").attr("title","Sent");setTimeout(function(){j.find(".progress-messages").text("");j.find(".progress-messages-icon").removeClass("done");j.find("#note").val("");f("button,input,textarea",j).removeAttr("disabled");k(false)},1000)},500)},error:function(t,s){o();j.find(".progress-messages-icon").addClass("error");j.find(".progress-messages").text("Error sending");j.find(".progress-messages").attr("title","Error sending"+": "+s);f("button,input,textarea",j).removeAttr("disabled")}});return false});var l=j.find("#users");var g=j.find("input.submit");l.bind("selected.autocomplete-sharepage",function(n,m){var o=function(r,q,s){var u=j.find(".recipients"),t,p;t="li[data-"+r+'="'+s.content[r]+'"]';if(u.find(t).length>0){u.find(t).hide()}else{u.append(q(s.content))}p=u.find(t);p.find(".remove-recipient").click(function(){p.remove();if(u.find("li").length==0){g.attr("disabled","true")}AJS.Confluence.SharePage.current.refresh();l.focus();return false});p.fadeIn(200)};if(m.content.email){o("email",Confluence.Templates.Share.Dialog.recipientEmail,m)}else{if(m.content.type=="group"){o("group",Confluence.Templates.Share.Dialog.recipientGroup,m)}else{o("userKey",Confluence.Templates.Share.Dialog.recipientUser,m)}}AJS.Confluence.SharePage.current.refresh();g.removeAttr("disabled");l.val("");l.focus();return false});l.bind("open.autocomplete-sharepage",function(n,m){if(f("a:not(.no-results)",AJS.dropDown.current.links).length>0){AJS.dropDown.current.moveDown()}});l.keypress(function(m){return m.keyCode!=13});f(document).bind("showLayer",function(o,n,m){if(n=="inlineDialog"&&m.popup==AJS.Confluence.SharePage.current){m.popup.find("#users").focus()}});f(h).parents().filter(function(){return this.scrollTop>0}).scrollTop(0);i()};var b=function(g){var h=f("#splitter-content");if(h.length!==0){g.container=h;g.offsetY=AJS.InlineDialog.opts.offsetY-h.offset().top}return g};AJS.Confluence.SharePage.initDialog=function(g,i,h){if(g.length){var j=f.extend(false,b(c),h);AJS.Confluence.SharePage.current=AJS.InlineDialog(g,i,d,j)}};AJS.toInit(function(g){AJS.Confluence.SharePage.initDialog(g("#shareContentLink"),"shareContentPopup")})})(AJS.$);
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.editor.confluence-source-editor:atlassian-source-editor-view-storage-javascript', location = 'jscripts/source-editor/view-source.js' */
AJS.toInit(function(a){if(a("#action-view-storage-link").length){a("#action-source-editor-view-storage-link").closest("li").hide()}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.web.resources:page-analytics', location = '/includes/js/page.js' */
define("confluence/page",["ajs","jquery","confluence/analytics-support","window","document"],function(b,c,e,f,g){var j=b.Meta.get("page-id"),d=function(a,b){e.publish("confluence.page."+a,c.extend({pageID:j},b||{}))},i=function(a){setTimeout(function(){d("reading");i(a)},a)},k=(new Date).getTime();return function(){var a=c("#main-content");d("view");a.on("click","a",function(a){a=-1<a.currentTarget.href.indexOf(f.location.host)?"internal":"external";d("link.click",{linkType:a})});var h=c(f),e=(new Date).getTime();
h.on("scroll.content",b.debounce(function(){var b=g.body.scrollTop+g.body.offsetHeight,c=a.offset().top+a.height();b>c&&(d("scroll-to-bottom",{secondsSinceReadyEvent:((new Date).getTime()-e)/1E3,secondsSincePageLoad:((new Date).getTime()-k)/1E3}),h.off("scroll.content"))},200));i(3E5)}});require("confluence/module-exporter").safeRequire("confluence/page",function(b){require("ajs").toInit(b)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:almond', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/almond-noconflict-pre.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:almond', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/almond/almond.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:almond', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/almond-noconflict-post.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd-for-confluence-lt-5.7', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/shim/ajs-amd.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd-for-confluence-lt-5.7', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/shim/jquery-amd.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd-for-confluence-lt-5.7', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/shim/underscore-amd.js' */

} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd', location = '/com/atlassian/confluence/extra/calendar3/amd/shim/templates-amd.js' */
define("tc/templates",function(){return Confluence.TeamCalendars.Templates});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd', location = '/com/atlassian/confluence/extra/calendar3/amd/shim/dialogs-amd.js' */
define("tc/dialogs",function(){return Confluence.TeamCalendars.Dialogs});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/shim/backbone-amd.js' */
(function(a,b){if(typeof define==="function"&&define.amd){define(["underscore","jquery","exports"],function(e,f,d){a.Backbone=b(a,d,e,f)})}else{if(typeof exports!=="undefined"){var c=require("underscore");b(a,exports,c)}else{a.Backbone=b(a,{},a._,(a.jQuery||a.Zepto||a.ender||a.$))}}}(this,function(t,c,G,h){var r=t.Backbone;var j=[];var s=j.slice;c.VERSION="1.1.2";c.$=h;c.noConflict=function(){t.Backbone=r;return this};c.emulateHTTP=false;c.emulateJSON=false;var p=c.Events={on:function(J,M,L){if(!I(this,"on",J,[M,L])||!M){return this}this._events||(this._events={});var K=this._events[J]||(this._events[J]=[]);K.push({callback:M,context:L,ctx:L||this});return this},once:function(K,N,L){if(!I(this,"once",K,[N,L])||!N){return this}var J=this;var M=G.once(function(){J.off(K,M);N.apply(this,arguments)});M._callback=N;return this.on(K,M,L)},off:function(K,S,L){if(!this._events||!I(this,"off",K,[S,L])){return this}if(!K&&!S&&!L){this._events=void 0;return this}var R=K?[K]:G.keys(this._events);for(var Q=0,M=R.length;Q<M;Q++){K=R[Q];var T=this._events[K];if(!T){continue}if(!S&&!L){delete this._events[K];continue}var O=[];for(var P=0,N=T.length;P<N;P++){var J=T[P];if(S&&S!==J.callback&&S!==J.callback._callback||L&&L!==J.context){O.push(J)}}if(O.length){this._events[K]=O}else{delete this._events[K]}}return this},trigger:function(L){if(!this._events){return this}var K=s.call(arguments,1);if(!I(this,"trigger",L,K)){return this}var M=this._events[L];var J=this._events.all;if(M){d(M,K)}if(J){d(J,arguments)}return this},stopListening:function(M,K,O){var L=this._listeningTo;if(!L){return this}var J=!K&&!O;if(!O&&typeof K==="object"){O=this}if(M){(L={})[M._listenId]=M}for(var N in L){M=L[N];M.off(K,O,this);if(J||G.isEmpty(M._events)){delete this._listeningTo[N]}}return this}};var a=/\s+/;var I=function(Q,O,J,M){if(!J){return true}if(typeof J==="object"){for(var L in J){Q[O].apply(Q,[L,J[L]].concat(M))}return false}if(a.test(J)){var P=J.split(a);for(var K=0,N=P.length;K<N;K++){Q[O].apply(Q,[P[K]].concat(M))}return false}return true};var d=function(O,M){var P,N=-1,L=O.length,K=M[0],J=M[1],Q=M[2];switch(M.length){case 0:while(++N<L){(P=O[N]).callback.call(P.ctx)}return;case 1:while(++N<L){(P=O[N]).callback.call(P.ctx,K)}return;case 2:while(++N<L){(P=O[N]).callback.call(P.ctx,K,J)}return;case 3:while(++N<L){(P=O[N]).callback.call(P.ctx,K,J,Q)}return;default:while(++N<L){(P=O[N]).callback.apply(P.ctx,M)}return}};var q={listenTo:"on",listenToOnce:"once"};G.each(q,function(J,K){p[K]=function(N,L,P){var M=this._listeningTo||(this._listeningTo={});var O=N._listenId||(N._listenId=G.uniqueId("l"));M[O]=N;if(!P&&typeof L==="object"){P=this}N[J](L,P,this);return this}});p.bind=p.on;p.unbind=p.off;G.extend(c,p);var m=c.Model=function(J,L){var K=J||{};L||(L={});this.cid=G.uniqueId("c");this.attributes={};if(L.collection){this.collection=L.collection}if(L.parse){K=this.parse(K,L)||{}}K=G.defaults({},K,G.result(this,"defaults"));this.set(K,L);this.changed={};this.initialize.apply(this,arguments)};G.extend(m.prototype,p,{changed:null,validationError:null,idAttribute:"id",initialize:function(){},toJSON:function(J){return G.clone(this.attributes)},sync:function(){return c.sync.apply(this,arguments)},get:function(J){return this.attributes[J]},escape:function(J){return G.escape(this.get(J))},has:function(J){return this.get(J)!=null},set:function(R,K,V){var P,S,T,Q,O,U,L,N;if(R==null){return this}if(typeof R==="object"){S=R;V=K}else{(S={})[R]=K}V||(V={});if(!this._validate(S,V)){return false}T=V.unset;O=V.silent;Q=[];U=this._changing;this._changing=true;if(!U){this._previousAttributes=G.clone(this.attributes);this.changed={}}N=this.attributes,L=this._previousAttributes;if(this.idAttribute in S){this.id=S[this.idAttribute]}for(P in S){K=S[P];if(!G.isEqual(N[P],K)){Q.push(P)}if(!G.isEqual(L[P],K)){this.changed[P]=K}else{delete this.changed[P]}T?delete N[P]:N[P]=K}if(!O){if(Q.length){this._pending=V}for(var M=0,J=Q.length;M<J;M++){this.trigger("change:"+Q[M],this,N[Q[M]],V)}}if(U){return this}if(!O){while(this._pending){V=this._pending;this._pending=false;this.trigger("change",this,V)}}this._pending=false;this._changing=false;return this},unset:function(J,K){return this.set(J,void 0,G.extend({},K,{unset:true}))},clear:function(K){var J={};for(var L in this.attributes){J[L]=void 0}return this.set(J,G.extend({},K,{unset:true}))},hasChanged:function(J){if(J==null){return !G.isEmpty(this.changed)}return G.has(this.changed,J)},changedAttributes:function(L){if(!L){return this.hasChanged()?G.clone(this.changed):false}var N,M=false;var K=this._changing?this._previousAttributes:this.attributes;for(var J in L){if(G.isEqual(K[J],(N=L[J]))){continue}(M||(M={}))[J]=N}return M},previous:function(J){if(J==null||!this._previousAttributes){return null}return this._previousAttributes[J]},previousAttributes:function(){return G.clone(this._previousAttributes)},fetch:function(K){K=K?G.clone(K):{};if(K.parse===void 0){K.parse=true}var J=this;var L=K.success;K.success=function(M){if(!J.set(J.parse(M,K),K)){return false}if(L){L(J,M,K)}J.trigger("sync",J,M,K)};e(this,K);return this.sync("read",this,K)},save:function(N,K,R){var O,J,Q,L=this.attributes;if(N==null||typeof N==="object"){O=N;R=K}else{(O={})[N]=K}R=G.extend({validate:true},R);if(O&&!R.wait){if(!this.set(O,R)){return false}}else{if(!this._validate(O,R)){return false}}if(O&&R.wait){this.attributes=G.extend({},L,O)}if(R.parse===void 0){R.parse=true}var M=this;var P=R.success;R.success=function(T){M.attributes=L;var S=M.parse(T,R);if(R.wait){S=G.extend(O||{},S)}if(G.isObject(S)&&!M.set(S,R)){return false}if(P){P(M,T,R)}M.trigger("sync",M,T,R)};e(this,R);J=this.isNew()?"create":(R.patch?"patch":"update");if(J==="patch"){R.attrs=O}Q=this.sync(J,this,R);if(O&&R.wait){this.attributes=L}return Q},destroy:function(K){K=K?G.clone(K):{};var J=this;var N=K.success;var L=function(){J.trigger("destroy",J,J.collection,K)};K.success=function(O){if(K.wait||J.isNew()){L()}if(N){N(J,O,K)}if(!J.isNew()){J.trigger("sync",J,O,K)}};if(this.isNew()){K.success();return false}e(this,K);var M=this.sync("delete",this,K);if(!K.wait){L()}return M},url:function(){var J=G.result(this,"urlRoot")||G.result(this.collection,"url")||x();if(this.isNew()){return J}return J.replace(/([^\/])$/,"$1/")+encodeURIComponent(this.id)},parse:function(K,J){return K},clone:function(){return new this.constructor(this.attributes)},isNew:function(){return !this.has(this.idAttribute)},isValid:function(J){return this._validate({},G.extend(J||{},{validate:true}))},_validate:function(L,K){if(!K.validate||!this.validate){return true}L=G.extend({},this.attributes,L);var J=this.validationError=this.validate(L,K)||null;if(!J){return true}this.trigger("invalid",this,J,G.extend(K,{validationError:J}));return false}});var C=["keys","values","pairs","invert","pick","omit","chain"];G.each(C,function(J){if(!G[J]){return}m.prototype[J]=function(){var K=s.call(arguments);K.unshift(this.attributes);return G[J].apply(G,K)}});var H=c.Collection=function(K,J){J||(J={});if(J.model){this.model=J.model}if(J.comparator!==void 0){this.comparator=J.comparator}this._reset();this.initialize.apply(this,arguments);if(K){this.reset(K,G.extend({silent:true},J))}};var z={add:true,remove:true,merge:true};var n={add:true,remove:false};G.extend(H.prototype,p,{model:m,initialize:function(){},toJSON:function(J){return this.map(function(K){return K.toJSON(J)})},sync:function(){return c.sync.apply(this,arguments)},add:function(K,J){return this.set(K,G.extend({merge:false},J,n))},remove:function(Q,L){var N=!G.isArray(Q);Q=N?[Q]:G.clone(Q);L||(L={});for(var M=0,O=Q.length;M<O;M++){var K=Q[M]=this.get(Q[M]);if(!K){continue}var P=this.modelId(K.attributes);if(P!=null){delete this._byId[P]}delete this._byId[K.cid];var J=this.indexOf(K);this.models.splice(J,1);this.length--;if(!L.silent){L.index=J;K.trigger("remove",K,this,L)}this._removeReference(K,L)}return N?Q[0]:Q},set:function(ab,L){L=G.defaults({},L,z);if(L.parse){ab=this.parse(ab,L)}var O=!G.isArray(ab);ab=O?(ab?[ab]:[]):ab.slice();var T,M,V,S,aa;var Q=L.at;var J=this.comparator&&(Q==null)&&L.sort!==false;var Z=G.isString(this.comparator)?this.comparator:null;var ac=[],W=[],U={};var R=L.add,N=L.merge,ad=L.remove;var X=!J&&R&&ad?[]:false;for(var Y=0,K=ab.length;Y<K;Y++){V=ab[Y];if(S=this.get(V)){if(ad){U[S.cid]=true}if(N&&V!==S){V=this._isModel(V)?V.attributes:V;if(L.parse){V=S.parse(V,L)}S.set(V,L);if(J&&!aa&&S.hasChanged(Z)){aa=true}}ab[Y]=S}else{if(R){M=ab[Y]=this._prepareModel(V,L);if(!M){continue}ac.push(M);this._addReference(M,L)}}M=S||M;if(!M){continue}T=this.modelId(M.attributes);if(X&&(M.isNew()||!U[T])){X.push(M)}U[T]=true}if(ad){for(var Y=0,K=this.length;Y<K;Y++){if(!U[(M=this.models[Y]).cid]){W.push(M)}}if(W.length){this.remove(W,L)}}if(ac.length||(X&&X.length)){if(J){aa=true}this.length+=ac.length;if(Q!=null){for(var Y=0,K=ac.length;Y<K;Y++){this.models.splice(Q+Y,0,ac[Y])}}else{if(X){this.models.length=0}var P=X||ac;for(var Y=0,K=P.length;Y<K;Y++){this.models.push(P[Y])}}}if(aa){this.sort({silent:true})}if(!L.silent){for(var Y=0,K=ac.length;Y<K;Y++){(M=ac[Y]).trigger("add",M,this,L)}if(aa||(X&&X.length)){this.trigger("sort",this,L)}}return O?ab[0]:ab},reset:function(M,J){J||(J={});for(var K=0,L=this.models.length;K<L;K++){this._removeReference(this.models[K],J)}J.previousModels=this.models;this._reset();M=this.add(M,G.extend({silent:true},J));if(!J.silent){this.trigger("reset",this,J)}return M},push:function(K,J){return this.add(K,G.extend({at:this.length},J))},pop:function(K){var J=this.at(this.length-1);this.remove(J,K);return J},unshift:function(K,J){return this.add(K,G.extend({at:0},J))},shift:function(K){var J=this.at(0);this.remove(J,K);return J},slice:function(){return s.apply(this.models,arguments)},get:function(J){if(J==null){return void 0}var K=this.modelId(this._isModel(J)?J.attributes:J);return this._byId[J]||this._byId[K]||this._byId[J.cid]},at:function(J){return this.models[J]},where:function(J,K){if(G.isEmpty(J)){return K?void 0:[]}return this[K?"find":"filter"](function(L){for(var M in J){if(J[M]!==L.get(M)){return false}}return true})},findWhere:function(J){return this.where(J,true)},sort:function(J){if(!this.comparator){throw new Error("Cannot sort a set without a comparator")}J||(J={});if(G.isString(this.comparator)||this.comparator.length===1){this.models=this.sortBy(this.comparator,this)}else{this.models.sort(G.bind(this.comparator,this))}if(!J.silent){this.trigger("sort",this,J)}return this},pluck:function(J){return G.invoke(this.models,"get",J)},fetch:function(J){J=J?G.clone(J):{};if(J.parse===void 0){J.parse=true}var L=J.success;var K=this;J.success=function(M){var N=J.reset?"reset":"set";K[N](M,J);if(L){L(K,M,J)}K.trigger("sync",K,M,J)};e(this,J);return this.sync("read",this,J)},create:function(K,J){J=J?G.clone(J):{};if(!(K=this._prepareModel(K,J))){return false}if(!J.wait){this.add(K,J)}var M=this;var L=J.success;J.success=function(N,O){if(J.wait){M.add(N,J)}if(L){L(N,O,J)}};K.save(null,J);return K},parse:function(K,J){return K},clone:function(){return new this.constructor(this.models,{model:this.model,comparator:this.comparator})},modelId:function(J){return J[this.model.prototype.idAttribute||"id"]},_reset:function(){this.length=0;this.models=[];this._byId={}},_prepareModel:function(L,K){if(this._isModel(L)){if(!L.collection){L.collection=this}return L}K=K?G.clone(K):{};K.collection=this;var J=new this.model(L,K);if(!J.validationError){return J}this.trigger("invalid",this,J.validationError,K);return false},_isModel:function(J){return J instanceof m},_addReference:function(K,J){this._byId[K.cid]=K;var L=this.modelId(K.attributes);if(L!=null){this._byId[L]=K}K.on("all",this._onModelEvent,this)},_removeReference:function(K,J){if(this===K.collection){delete K.collection}K.off("all",this._onModelEvent,this)},_onModelEvent:function(L,K,N,J){if((L==="add"||L==="remove")&&N!==this){return}if(L==="destroy"){this.remove(K,J)}if(L==="change"){var M=this.modelId(K.previousAttributes());var O=this.modelId(K.attributes);if(M!==O){if(M!=null){delete this._byId[M]}if(O!=null){this._byId[O]=K}}}this.trigger.apply(this,arguments)}});var D=["forEach","each","map","collect","reduce","foldl","inject","reduceRight","foldr","find","detect","filter","select","reject","every","all","some","any","include","contains","invoke","max","min","toArray","size","first","head","take","initial","rest","tail","drop","last","without","difference","indexOf","shuffle","lastIndexOf","isEmpty","chain","sample","partition"];G.each(D,function(J){if(!G[J]){return}H.prototype[J]=function(){var K=s.call(arguments);K.unshift(this.models);return G[J].apply(G,K)}});var i=["groupBy","countBy","sortBy","indexBy"];G.each(i,function(J){if(!G[J]){return}H.prototype[J]=function(M,K){var L=G.isFunction(M)?M:function(N){return N.get(M)};return G[J](this.models,L,K)}});var w=c.View=function(J){this.cid=G.uniqueId("view");J||(J={});G.extend(this,G.pick(J,y));this._ensureElement();this.initialize.apply(this,arguments)};var g=/^(\S+)\s*(.*)$/;var y=["model","collection","el","id","attributes","className","tagName","events"];G.extend(w.prototype,p,{tagName:"div",$:function(J){return this.$el.find(J)},initialize:function(){},render:function(){return this},remove:function(){this._removeElement();this.stopListening();return this},_removeElement:function(){this.$el.remove()},setElement:function(J){this.undelegateEvents();this._setElement(J);this.delegateEvents();return this},_setElement:function(J){this.$el=J instanceof c.$?J:c.$(J);this.el=this.$el[0]},delegateEvents:function(L){if(!(L||(L=G.result(this,"events")))){return this}this.undelegateEvents();for(var K in L){var M=L[K];if(!G.isFunction(M)){M=this[L[K]]}if(!M){continue}var J=K.match(g);this.delegate(J[1],J[2],G.bind(M,this))}return this},delegate:function(K,J,L){this.$el.on(K+".delegateEvents"+this.cid,J,L)},undelegateEvents:function(){if(this.$el){this.$el.off(".delegateEvents"+this.cid)}return this},undelegate:function(K,J,L){this.$el.off(K+".delegateEvents"+this.cid,J,L)},_createElement:function(J){return document.createElement(J)},_ensureElement:function(){if(!this.el){var J=G.extend({},G.result(this,"attributes"));if(this.id){J.id=G.result(this,"id")}if(this.className){J["class"]=G.result(this,"className")}this.setElement(this._createElement(G.result(this,"tagName")));this._setAttributes(J)}else{this.setElement(G.result(this,"el"))}},_setAttributes:function(J){this.$el.attr(J)}});c.sync=function(Q,L,K){var N=u[Q];G.defaults(K||(K={}),{emulateHTTP:c.emulateHTTP,emulateJSON:c.emulateJSON});var P={type:N,dataType:"json"};if(!K.url){P.url=G.result(L,"url")||x()}if(K.data==null&&L&&(Q==="create"||Q==="update"||Q==="patch")){P.contentType="application/json";P.data=JSON.stringify(K.attrs||L.toJSON(K))}if(K.emulateJSON){P.contentType="application/x-www-form-urlencoded";P.data=P.data?{model:P.data}:{}}if(K.emulateHTTP&&(N==="PUT"||N==="DELETE"||N==="PATCH")){P.type="POST";if(K.emulateJSON){P.data._method=N}var M=K.beforeSend;K.beforeSend=function(R){R.setRequestHeader("X-HTTP-Method-Override",N);if(M){return M.apply(this,arguments)}}}if(P.type!=="GET"&&!K.emulateJSON){P.processData=false}var J=K.error;K.error=function(S,T,R){K.textStatus=T;K.errorThrown=R;if(J){J.apply(this,arguments)}};var O=K.xhr=c.ajax(G.extend(P,K));L.trigger("request",L,O,K);return O};var u={create:"POST",update:"PUT",patch:"PATCH","delete":"DELETE",read:"GET"};c.ajax=function(){return c.$.ajax.apply(c.$,arguments)};var F=c.Router=function(J){J||(J={});if(J.routes){this.routes=J.routes}this._bindRoutes();this.initialize.apply(this,arguments)};var l=/\((.*?)\)/g;var k=/(\(\?)?:\w+/g;var E=/\*\w+/g;var f=/[\-{}\[\]+?.,\\\^$|#\s]/g;G.extend(F.prototype,p,{initialize:function(){},route:function(K,L,M){if(!G.isRegExp(K)){K=this._routeToRegExp(K)}if(G.isFunction(L)){M=L;L=""}if(!M){M=this[L]}var J=this;c.history.route(K,function(O){var N=J._extractParameters(K,O);if(J.execute(M,N,L)!==false){J.trigger.apply(J,["route:"+L].concat(N));J.trigger("route",L,N);c.history.trigger("route",J,L,N)}});return this},execute:function(L,K,J){if(L){L.apply(this,K)}},navigate:function(K,J){c.history.navigate(K,J);return this},_bindRoutes:function(){if(!this.routes){return}this.routes=G.result(this,"routes");var K,J=G.keys(this.routes);while((K=J.pop())!=null){this.route(K,this.routes[K])}},_routeToRegExp:function(J){J=J.replace(f,"\\$&").replace(l,"(?:$1)?").replace(k,function(L,K){return K?L:"([^/?]+)"}).replace(E,"([^?]*?)");return new RegExp("^"+J+"(?:\\?([\\s\\S]*))?$")},_extractParameters:function(J,K){var L=J.exec(K).slice(1);return G.map(L,function(N,M){if(M===L.length-1){return N||null}return N?decodeURIComponent(N):null})}});var b=c.History=function(){this.handlers=[];G.bindAll(this,"checkUrl");if(typeof window!=="undefined"){this.location=window.location;this.history=window.history}};var o=/^[#\/]|\s+$/g;var B=/^\/+|\/+$/g;var v=/#.*$/;b.started=false;G.extend(b.prototype,p,{interval:50,atRoot:function(){var J=this.location.pathname.replace(/[^\/]$/,"$&/");return J===this.root&&!this.location.search},getHash:function(K){var J=(K||this).location.href.match(/#(.*)$/);return J?J[1]:""},getPath:function(){var K=decodeURI(this.location.pathname+this.location.search);var J=this.root.slice(0,-1);if(!K.indexOf(J)){K=K.slice(J.length)}return K.slice(1)},getFragment:function(J){if(J==null){if(this._hasPushState||!this._wantsHashChange){J=this.getPath()}else{J=this.getHash()}}return J.replace(o,"")},start:function(K){if(b.started){throw new Error("Backbone.history has already been started")}b.started=true;this.options=G.extend({root:"/"},this.options,K);this.root=this.options.root;this._wantsHashChange=this.options.hashChange!==false;this._hasHashChange="onhashchange" in window;this._wantsPushState=!!this.options.pushState;this._hasPushState=!!(this.options.pushState&&this.history&&this.history.pushState);this.fragment=this.getFragment();var M=window.addEventListener||function(N,O){return attachEvent("on"+N,O)};this.root=("/"+this.root+"/").replace(B,"/");if(!this._hasHashChange&&this._wantsHashChange&&(!this._wantsPushState||!this._hasPushState)){var L=document.createElement("iframe");L.src="javascript:0";L.style.display="none";L.tabIndex=-1;var J=document.body;this.iframe=J.insertBefore(L,J.firstChild).contentWindow;this.navigate(this.fragment)}if(this._hasPushState){M("popstate",this.checkUrl,false)}else{if(this._wantsHashChange&&this._hasHashChange&&!this.iframe){M("hashchange",this.checkUrl,false)}else{if(this._wantsHashChange){this._checkUrlInterval=setInterval(this.checkUrl,this.interval)}}}if(this._wantsHashChange&&this._wantsPushState){if(!this._hasPushState&&!this.atRoot()){this.location.replace(this.root+"#"+this.getPath());return true}else{if(this._hasPushState&&this.atRoot()){this.navigate(this.getHash(),{replace:true})}}}if(!this.options.silent){return this.loadUrl()}},stop:function(){var J=window.removeEventListener||function(K,L){return detachEvent("on"+K,L)};if(this._hasPushState){J("popstate",this.checkUrl,false)}else{if(this._wantsHashChange&&this._hasHashChange&&!this.iframe){J("hashchange",this.checkUrl,false)}}if(this.iframe){document.body.removeChild(this.iframe.frameElement);this.iframe=null}if(this._checkUrlInterval){clearInterval(this._checkUrlInterval)}b.started=false},route:function(J,K){this.handlers.unshift({route:J,callback:K})},checkUrl:function(K){var J=this.getFragment();if(J===this.fragment&&this.iframe){J=this.getHash(this.iframe)}if(J===this.fragment){return false}if(this.iframe){this.navigate(J)}this.loadUrl()},loadUrl:function(J){J=this.fragment=this.getFragment(J);return G.any(this.handlers,function(K){if(K.route.test(J)){K.callback(J);return true}})},navigate:function(L,K){if(!b.started){return false}if(!K||K===true){K={trigger:!!K}}var J=this.root+(L=this.getFragment(L||""));L=decodeURI(L.replace(v,""));if(this.fragment===L){return}this.fragment=L;if(L===""&&J!=="/"){J=J.slice(0,-1)}if(this._hasPushState){this.history[K.replace?"replaceState":"pushState"]({},document.title,J)}else{if(this._wantsHashChange){this._updateHash(this.location,L,K.replace);if(this.iframe&&(L!==this.getHash(this.iframe))){if(!K.replace){this.iframe.document.open().close()}this._updateHash(this.iframe.location,L,K.replace)}}else{return this.location.assign(J)}}if(K.trigger){return this.loadUrl(L)}},_updateHash:function(J,L,M){if(M){var K=J.href.replace(/(javascript:|#).*$/,"");J.replace(K+"#"+L)}else{J.hash="#"+L}}});c.history=new b;var A=function(J,L){var K=this;var N;if(J&&G.has(J,"constructor")){N=J.constructor}else{N=function(){return K.apply(this,arguments)}}G.extend(N,K,L);var M=function(){this.constructor=N};M.prototype=K.prototype;N.prototype=new M;if(J){G.extend(N.prototype,J)}N.__super__=K.prototype;return N};m.extend=H.extend=F.extend=w.extend=b.extend=A;var x=function(){throw new Error('A "url" property or function must be specified')};var e=function(L,K){var J=K.error;K.error=function(M){if(J){J(L,M,K)}L.trigger("error",L,M,K)}};return c}));if(typeof Backbone!=="undefined"){var backboneTCVersion=Backbone.noConflict();define("tc-backbone",["underscore"],function(){return backboneTCVersion})};
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:amd', location = '/com/atlassian/confluence/extra/calendar3/lib/amd/shim/wrm-amd.js' */
define("wrm",function(){return WRM});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:initialiser-common', location = 'com/atlassian/confluence/extra/calendar3/components/initialiser/init-resources.js' */
define("tc/init-resources",["wrm","jquery"],function(a,c){var b=function(d){return d.removeClass("spinner").removeClass("aui-icon").removeClass("aui-icon-wait")};return{requireResources:function(){a.require(["wrc!com.atlassian.confluence.extra.team-calendars.resources-batch"],function(){b(c("div.plugin-calendar"))}).fail(function(){b(c("div.plugin-calendar")).text("Failed to load calendar resources")})}}});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.extra.team-calendars:calendar-init-viewpage', location = 'com/atlassian/confluence/extra/calendar3/components/initialiser/initialiser-viewpage.js' */
require(["tc/init-resources","jquery"],function(a,b){b(function(){if(b("div.plugin-calendar").length>0){a.requireResources()}})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.macros.advanced:blog-post-resources', location = 'com/atlassian/confluence/plugins/macros/advanced/blog-posts.js' */
jQuery(function(a){a(".macro-blank-experience .create-post").bind("click",function(){var b=AJS.Meta.get("base-url")+"/pages/createblogpost.action?spaceKey="+AJS.Meta.get("space-key");window.location=b})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'confluence.macros.multimedia:flash-autosize', location = 'javascript/flash-autosize.js' */
AJS.toInit(function(b){function a(e,d){var c;if(d>=20){AJS.log("unable to auto size flash - took too long to load");return}c=b([]);e.each(function(){var g=b(this);var i;var f;if(this.GetVariable){if(!g.attr("height")){i=this.GetVariable("height");if(i){g.height(i)}else{c=c.add(g);return}}if(!g.attr("width")){f=this.GetVariable("width");if(f){g.width(f)}else{c=c.add(g);return}}}});if(c.length){setTimeout(function(){a(c,d+1)},100)}}a(b('embed[type="application/x-shockwave-flash"]'),0);b(window).bind("render-content-loaded",function(d,c){a(b('embed[type="application/x-shockwave-flash"]',c),0)})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.view-source:view-source-menu-resources', location = 'com/atlassian/confluence/plugins/viewsource/js/viewsource.js' */
define("confluence-view-source/viewsource",["jquery","window"],function(a,b){return function(){a("#action-view-source-link").click(function(a){b.open(this.href,(this.id+"-popupwindow").replace(/-/g,"_"),"width=800, height=600, scrollbars, resizable");a.preventDefault();return!1})}});require("confluence/module-exporter").safeRequire("confluence-view-source/viewsource",function(a){require("ajs").toInit(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.view-storage-format:view-storage-menu-resources', location = 'com/atlassian/confluence/plugins/viewstorage/js/viewstorage.js' */
AJS.toInit(function(a){a(".view-storage-link, .view-storage-link a").click(function(b){window.open(this.href,(this.id+"-popupwindow").replace(/-/g,"_"),"width=800, height=600, scrollbars, resizable");b.preventDefault();return false})});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
;try {
/* module-key = 'com.atlassian.confluence.plugins.quickedit:quick-comment-hide-traditional', location = 'jscripts/add-comment-hider.js' */
define("confluence-quick-edit/add-comment-hider",[],function(){return function(a){a("#comments-actions").hide()}});require("confluence/module-exporter").safeRequire("confluence-quick-edit/add-comment-hider",function(a){require("ajs").toInit(a)});
} catch (err) {
    if (console && console.log && console.error) {
        console.log("Error running batched script.");
        console.error(err);
    }
}

;
